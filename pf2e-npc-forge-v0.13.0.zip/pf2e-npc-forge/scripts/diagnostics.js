import { catalogAvailability } from "./catalog.js";

const REQUIRED_PACKS = [
  ["pf2e.equipment-srd", "Снаряжение PF2e", true],
  ["pf2e.actionspf2e", "Действия PF2e", true],
  ["pf2e.spells-srd", "Заклинания PF2e", true],
  ["sf2e-anachronism.equipment", "Снаряжение SF2e Anachronism", false],
  ["sf2e-anachronism.spells", "Заклинания SF2e Anachronism", false],
];

function check(id, label, ok, details = "", required = true) {
  return { id, label, ok: Boolean(ok), details: String(details ?? ""), required };
}

export async function runDiagnostics() {
  const checks = [];
  checks.push(
    check("system", "Активна система Pathfinder 2e", game.system?.id === "pf2e", `${game.system?.id ?? "нет"} ${game.system?.version ?? ""}`.trim()),
  );
  checks.push(
    check("foundry", "Доступен Foundry VTT 14", String(game.version ?? "").startsWith("14."), String(game.version ?? "неизвестно")),
  );
  checks.push(
    check("application-v2", "Доступен ApplicationV2", typeof foundry.applications?.api?.ApplicationV2 === "function"),
  );
  checks.push(
    check("handlebars-mixin", "Доступен HandlebarsApplicationMixin", typeof foundry.applications?.api?.HandlebarsApplicationMixin === "function"),
  );
  checks.push(
    check("form", "Доступен FormDataExtended", typeof foundry.applications?.ux?.FormDataExtended === "function" || typeof globalThis.FormDataExtended === "function"),
  );
  checks.push(check("gm", "Пользователь имеет права ведущего", game.user?.isGM === true));

  for (const [packId, label, required] of REQUIRED_PACKS) {
    const pack = game.packs?.get?.(packId);
    let details = required ? "не найден" : "не установлен — функции SF2e будут пропущены";
    let ok = false;
    if (pack) {
      try {
        const index = await pack.getIndex({ fields: ["type", "system.slug"] });
        ok = true;
        details = `документов: ${index?.size ?? index?.length ?? "?"}`;
      } catch (error) {
        details = `ошибка чтения: ${error.message}`;
      }
    }
    checks.push(check(packId, label, ok, details, required));
  }

  const availability = await catalogAvailability();
  checks.push(check(
    "catalog",
    "Единый каталог PF2e/SF2e готов",
    availability.some((entry) => entry.kind === "equipment" && entry.source === "pf2e" && entry.available),
    availability.filter((entry) => entry.available).map((entry) => entry.packId).join(", "),
  ));

  const filePicker =
    foundry.applications?.apps?.FilePicker?.implementation ??
    foundry.applications?.apps?.FilePicker ??
    globalThis.FilePicker;
  checks.push(
    check("file-picker", "Доступен просмотр файлов токенов", typeof filePicker?.browse === "function" || typeof filePicker?.implementation?.browse === "function"),
  );
  checks.push(check(
    "scene-deployment",
    "Активная сцена поддерживает размещение жетонов",
    typeof globalThis.canvas?.scene?.createEmbeddedDocuments === "function",
    globalThis.canvas?.scene?.name ?? "активная сцена не открыта",
    false,
  ));

  const activeModules = [...(game.modules?.values?.() ?? [])]
    .filter((module) => module.active)
    .map((module) => ({ id: module.id, title: module.title, version: module.version }));
  const failed = checks.filter((entry) => entry.required && !entry.ok);
  return {
    format: "pf2e-npc-forge-diagnostics",
    createdAt: new Date().toISOString(),
    foundry: game.version ?? null,
    system: { id: game.system?.id ?? null, version: game.system?.version ?? null },
    userIsGM: game.user?.isGM === true,
    checks,
    activeModules,
    catalog: availability,
    ok: failed.length === 0,
    failed: failed.map((entry) => entry.id),
  };
}

export function diagnosticsHtml(report) {
  const rows = report.checks
    .map(
      (entry) => `<li class="${entry.ok ? "forge-check-ok" : entry.required ? "forge-check-fail" : "forge-check-warn"}"><i class="fa-solid ${entry.ok ? "fa-circle-check" : entry.required ? "fa-circle-xmark" : "fa-circle-exclamation"}"></i> <strong>${entry.label}</strong>${entry.details ? ` — ${entry.details}` : ""}</li>`,
    )
    .join("");
  return `<div class="forge-diagnostics"><h3>${report.ok ? "Кузница готова к работе" : "Найдены проблемы среды"}</h3><ul>${rows}</ul></div>`;
}
