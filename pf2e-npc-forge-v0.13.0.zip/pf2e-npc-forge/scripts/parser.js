import { ANCESTRIES, ARMORS, PROFESSIONS, ROLES, WEAPONS } from "./blueprints.js";
import { deriveSeed, hashSeed, randomNameForGender } from "./randomizer.js";
import { CREATURE_KINDS, MONSTER_FAMILIES, detectMonsterFamily } from "./monsters.js";
import { ENCOUNTER_DIFFICULTIES } from "./encounters.js";
import { CONTENT_SOURCES, TECHNOLOGY_LEVELS } from "./catalog.js";
import { ADVENTURE_MODES, LOOT_RICHNESS, MONSTER_TEMPLATES } from "./director.js";

const WORDS = {
  ancestry: [
    ["halfElf", /полу[\s-]?эльф/iu],
    ["tiefling", /тифлинг|нефилим/iu],
    ["kitsune", /кицун[эе]/iu],
    ["catfolk", /котолюд|амуррун/iu],
    ["halfling", /полурослик|халфлинг/iu],
    ["dwarf", /дворф|гном(?=$|[\s,.;:])/iu],
    ["giantSpider", /гигантск.*паук|огромн.*паук|паучих/iu],
    ["lizardfolk", /ящеролюд|ирукси/iu],
    ["hobgoblin", /хобгоблин/iu],
    ["bugbear", /багбер|бугбер/iu],
    ["kobold", /кобольд/iu],
    ["gnoll", /гнолл|холо(?=$|[\s,.;:])/iu],
    ["skeleton", /скелет/iu],
    ["zombie", /зомби|ходяч.*мертв/iu],
    ["ghoul", /гул(?=$|[\s,.;:])|упыр/iu],
    ["warg", /варг/iu],
    ["wolf", /волк|волчиц/iu],
    ["troll", /тролл/iu],
    ["ogre", /огр(?=$|[\s,.;:])/iu],
    ["construct", /конструкт|голем|автоматон/iu],
    ["ooze", /слиз|желе|студен|ам[её]б/iu],
    ["goblin", /гоблин/iu],
    ["orc", /полу[\s-]?орк|орк/iu],
    ["elf", /эльф/iu],
    ["human", /человек|человеческ/iu],
  ],
  gender: [
    ["female", /женщин|девушк|девочк|она(?=$|[\s,.;:])|женск/iu],
    ["male", /мужчин|парень|юнош|мальчик|он(?=$|[\s,.;:])|мужск/iu],
  ],
  profession: [
    ["technomancer", /техномант|техно-?маг/iu],
    ["engineer", /инженер|механик|ремонтник|техник/iu],
    ["operative", /оперативник|диверсант|хакер|агент/iu],
    ["mercenary", /на[её]мник.*(?:винтов|лазер|пистолет)|космодесантник/iu],
    ["mystic", /мистик|псионик|менталист/iu],
    ["pilot", /пилот|л[её]тчик|водитель.*машин/iu],
    ["doctor", /врач|лекар|целител|медик|аптекар/iu],
    ["knight", /рыцар|кавалер/iu],
    ["guard", /страж|охранник|дозорн/iu],
    ["scout", /разведчик|лазутчик|следопыт/iu],
    ["alchemist", /алхимик/iu],
    ["priest", /жрец|священник|служител.*вер/iu],
    ["mage", /маг(?=$|[\s,.;:])|волшебник|колдун|заклинател/iu],
    ["thief", /вор(?=$|[\s,.;:])|взломщик|карманник/iu],
    ["bandit", /бандит|разбойник|нал[её]тчик/iu],
    ["merchant", /торговец|купец|лавочник/iu],
    ["hunter", /охотник|егерь/iu],
    ["necromancer", /некромант/iu],
    ["shaman", /шаман|духовид/iu],
    ["chieftain", /вожак|главарь|старейшин/iu],
    ["trapper", /ловушечник|капканщик|сап[её]р/iu],
    ["packHunter", /стайн.*охотник|загонщик/iu],
    ["tribalHunter", /племенн.*охотник/iu],
    ["raider", /нал[её]тчик|рейдер/iu],
    ["construct", /конструкт|автоматон|голем/iu],
    ["undead", /нежить|скелет|зомби|гул/iu],
    ["beast", /зверь|животн/iu],
    ["monster", /чудовищ|монстр/iu],
    ["warrior", /воин|боец|солдат|на[её]мник/iu],
  ],
  role: [
    ["gunner", /тяж[её]л.*стрелок|пулем[её]тчик|огневая поддержка|подавляющ.*огонь/iu],
    ["saboteur", /саботажник|диверсант|взрывник|гранатом[её]тчик/iu],
    ["technician", /техник.*поддерж|инженер.*поддерж|ремонт.*союзник/iu],
    ["infiltrator", /оперативник|проникнов|скрыт.*агент|хакер/iu],
    ["ambusher", /засадник|напад.*из засад/iu],
    ["packHunter", /стайн.*охотник|окруж.*цель|загонщик/iu],
    ["defender", /защитник|щитовой|держит проход/iu],
    ["artillery", /артиллери|пращник|метатель|дальн.*урон/iu],
    ["leader", /вожак|капитан|предводитель|лидер/iu],
    ["berserker", /берсерк|яростн|неистов/iu],
    ["lurker", /скрытн.*хищник|крадущ|душител/iu],
    ["summoner", /призывател|вызывает.*существ/iu],
    ["brute", /громил|тяжел.*удар|живуч.*сильн/iu],
    ["sniper", /снайпер|стрелок|лучник|дальн.*бой/iu],
    ["skirmisher", /застрельщик|подвижн.*боец|дуэлянт/iu],
    ["controller", /тактик|командир|контрол.*пол/iu],
    ["healer", /лекарь|целител|врач|лечени/iu],
    ["caster", /заклинател|боев.*маг|волшебник|колдун/iu],
    ["support", /поддержк|помощник/iu],
    ["soldier", /строев|фронтовик|рыцар|страж|солдат/iu],
  ],
  armor: [
    ["none", /без доспех|без брон/iu],
    ["heavy", /тяж[её]л.*(?:доспех|брон)|латы|латн/iu],
    ["medium", /средн.*(?:доспех|брон)|кирас|кольчуг/iu],
    ["light", /л[её]гк.*(?:доспех|брон)|кожан.*доспех/iu],
  ],
  weapon: [
    ["laserRifle", /лазерн.*винтовк/iu],
    ["laserPistol", /лазерн.*пистолет/iu],
    ["arcRifle", /дугов.*винтовк|электрическ.*винтовк/iu],
    ["plasmaCaster", /плазмом[её]т|плазменн.*винтовк|плазменн.*пушк/iu],
    ["plasmaSword", /плазменн.*меч|энергетическ.*клинок/iu],
    ["shockTruncheon", /шоков.*дубин|электродубин/iu],
    ["semiAutoPistol", /полуавтоматическ.*пистолет|автоматическ.*пистолет/iu],
    ["scattergun", /дробовик/iu],
    ["arquebus", /аркебуз|длинн.*ружь[её]|мушкет/iu],
    ["duelingPistol", /дуэльн.*пистолет|однозарядн.*пистолет/iu],
    ["longswordShield", /меч.*щит|щит.*меч/iu],
    ["spearShield", /копь[её].*щит|щит.*копь/iu],
    ["greataxe", /двуручн.*топор|секир|бердыш/iu],
    ["greatsword", /двуручн.*меч|больш.*меч/iu],
    ["halberd", /алебард|глеф/iu],
    ["shortbow", /коротк.*лук|лук(?=$|[\s,.;:])|лучник/iu],
    ["acidSpit", /кислотн.*плев/iu],
    ["pseudopod", /ложнонож|щупальц.*слиз/iu],
    ["slam", /удар.*корпус|встроенн.*удар/iu],
    ["dogslicer", /собакорез/iu],
    ["morningstar", /моргенштерн|шипаст.*булав/iu],
    ["maul", /боев.*молот|огромн.*молот/iu],
    ["flail", /цеп(?=$|[\s,.;:])|кистень/iu],
    ["sling", /пращ/iu],
    ["javelin", /дротик/iu],
    ["jaws", /челюст|укус/iu],
    ["claws", /когт/iu],
    ["crossbow", /арбалет/iu],
    ["staff", /посох/iu],
    ["spear", /копь|пик[аеи](?=$|[\s,.;:])/iu],
    ["longsword", /длинн.*меч|меч(?=$|[\s,.;:])/iu],
    ["shortsword", /коротк.*меч/iu],
    ["dagger", /кинжал|нож(?=$|[\s,.;:])/iu],
    ["fists", /кулак|рукопаш|без оруж/iu],
  ],
};

const STAT_WORDS = {
  ac: /кб|защит|доспех/iu,
  hp: /оз|здоров|живуч/iu,
  attack: /атак|точност|попадани/iu,
  damage: /урон|сил.*удар|разруш/iu,
  perception: /восприяти|наблюдательн|зорк/iu,
  dc: /сложност|сс(?=$|[\s,.;:])|сильн.*способност/iu,
  fortitude: /стойкост|телослож|фортитуд/iu,
  reflex: /рефлекс|ловкост/iu,
  will: /вол[яи]|стальн.*вол/iu,
};

const ABILITY_WORDS = {
  str: /сил[аыуе](?=$|[\s,.;:])/iu,
  dex: /ловкост/iu,
  con: /телослож/iu,
  int: /интеллект|ум(?=$|[\s,.;:])/iu,
  wis: /мудрост/iu,
  cha: /харизм/iu,
};

const SKILL_WORDS = {
  acrobatics: /акробатик/iu,
  arcana: /аркан[аыуе]|магическ.*знани/iu,
  athletics: /атлетик/iu,
  crafting: /ремесл|изготовлени/iu,
  computers: /компьютер|хакер|программирован|сеть/iu,
  deception: /обман|лжив/iu,
  diplomacy: /дипломати|переговор/iu,
  intimidation: /запугивани|угроз/iu,
  medicine: /медицин|врачевани|лечени/iu,
  nature: /природ[аые]|естествознани/iu,
  occultism: /оккультизм/iu,
  performance: /выступлени|артистизм/iu,
  piloting: /пилотирован|управлени.*транспорт|л[её]тчик/iu,
  religion: /религи|теологи/iu,
  society: /обществ|светск.*знани/iu,
  stealth: /скрытност|незаметност/iu,
  survival: /выживани/iu,
  thievery: /воровств|взлом|отмыч/iu,
};

const TIER_WORDS = {
  terrible: /ужасн|ничтожн|провальн/iu,
  low: /низк|слаб/iu,
  moderate: /средн|умерен/iu,
  high: /высок|сильн/iu,
  extreme: /предельн|экстремальн|максимальн/iu,
};

function detect(entries, text) {
  return entries.find(([, pattern]) => pattern.test(text))?.[0] ?? null;
}

function detectTierNear(text, subjectPattern) {
  for (const [tier, tierPattern] of Object.entries(TIER_WORDS)) {
    const subject = subjectPattern.source;
    const quality = tierPattern.source;
    const direct = new RegExp(`(?:${subject})[^,.\\n]{0,24}(?:${quality})`, "iu");
    const reverse = new RegExp(`(?:${quality})[^,.\\n]{0,24}(?:${subject})`, "iu");
    if (direct.test(text) || reverse.test(text)) return tier;
  }
  return null;
}

function detectedLevel(text) {
  const explicit = text.match(
    /(?:уров(?:ень|ня)?|ур\.?|level|lvl)\s*[:=-]?\s*(-?\d{1,3})\b/iu,
  );
  if (explicit) return Number(explicit[1]);

  const inverse = text.match(/\b(-?\d{1,3})\s*[- ]?(?:й|го)?\s*уров/iu);
  return inverse ? Number(inverse[1]) : null;
}

function cleanName(value) {
  const name = String(value ?? "").trim().replace(/\s+/gu, " ");
  return name.slice(0, 80);
}

function detectedName(text) {
  const match = text.match(
    /(?:зовут|по имени|имя)\s*[:—-]?\s*([А-ЯЁ][а-яё-]+(?:\s+[А-ЯЁ][а-яё-]+){0,2})/u,
  );
  return cleanName(match?.[1]);
}

function valueOrDetected(formValue, detected, fallback) {
  return formValue && formValue !== "auto" ? formValue : detected ?? fallback;
}

export function parseConcept(formData) {
  const prompt = String(formData.prompt ?? "").trim().slice(0, 4000);
  const detectedFamily = detectMonsterFamily(prompt);
  const monsterFamily =
    formData.monsterFamily && formData.monsterFamily !== "auto"
      ? formData.monsterFamily
      : detectedFamily ?? "none";
  const family = MONSTER_FAMILIES[monsterFamily] ?? MONSTER_FAMILIES.none;
  const creatureKind =
    formData.creatureKind && formData.creatureKind !== "auto"
      ? formData.creatureKind
      : family.kind ?? "person";
  const detectedProfession = detect(WORDS.profession, prompt);
  const profession = valueOrDetected(
    formData.profession,
    detectedProfession,
    family.defaultProfession ?? "warrior",
  );
  const professionRole = PROFESSIONS[profession]?.role ?? family.defaultRole ?? "soldier";

  const ancestry = valueOrDetected(
    formData.ancestry,
    detect(WORDS.ancestry, prompt),
    family.ancestry ?? "human",
  );
  const gender = valueOrDetected(
    formData.gender,
    detect(WORDS.gender, prompt),
    "unspecified",
  );
  const role = valueOrDetected(
    formData.role,
    detect(WORDS.role, prompt),
    professionRole,
  );
  const armor = valueOrDetected(
    formData.armor,
    detect(WORDS.armor, prompt),
    family.defaultArmor ?? ROLES[role]?.defaultArmor ?? "light",
  );
  const weapon = valueOrDetected(
    formData.weapon,
    detect(WORDS.weapon, prompt),
    family.defaultWeapon ?? ROLES[role]?.defaultWeapon ?? "longsword",
  );

  const promptLevel = detectedLevel(prompt);
  const enteredLevel =
    formData.level === "" || formData.level === null || formData.level === undefined
      ? null
      : Number(formData.level);
  const level = enteredLevel ?? promptLevel ?? 1;

  const statTiers = {};
  for (const [key, pattern] of Object.entries(STAT_WORDS)) {
    const explicit = formData[`tier_${key}`];
    statTiers[key] =
      explicit && explicit !== "auto" ? explicit : detectTierNear(prompt, pattern);
  }

  const abilityTiers = {};
  for (const [key, pattern] of Object.entries(ABILITY_WORDS)) {
    abilityTiers[key] = detectTierNear(prompt, pattern);
  }

  const skillTiers = {};
  for (const [key, pattern] of Object.entries(SKILL_WORDS)) {
    skillTiers[key] = detectTierNear(prompt, pattern);
  }

  const elements = [];
  if (/огонь|плам|жар|инферн/iu.test(prompt)) elements.push("fire");
  if (/вод[аыу]|прилив|волна|лед|л[её]д/iu.test(prompt)) elements.push("water");
  if (/молни|электр|гром/iu.test(prompt)) elements.push("electricity");
  if (/холод|мороз|иней/iu.test(prompt)) elements.push("cold");

  const detectedTechnology = /лазер|плазм|высокотех|кибер|космич|нанит|силов.*поле|звездол[её]т/iu.test(prompt)
    ? "starfinder"
    : /магитех|магическ.*техн|техномаг/iu.test(prompt)
      ? "magitech"
      : /порох|мушкет|аркебуз|однозарядн.*ружь|кремн[её]в.*пистолет/iu.test(prompt)
        ? "blackpowder"
        : "fantasy";
  const technology = TECHNOLOGY_LEVELS[formData.technology]
    ? formData.technology
    : detectedTechnology;
  const contentSource = CONTENT_SOURCES[formData.contentSource]
    ? formData.contentSource
    : technology === "starfinder"
      ? "sf2e"
      : technology === "magitech"
        ? "mixed"
        : "pf2e";

  const requestedSeed = String(formData.randomSeed ?? "").trim();
  const randomSeed = requestedSeed || String(hashSeed(`${prompt}:${formData.name ?? ""}:${level}:${profession}`));
  const requestedName = cleanName(formData.name);
  const name = requestedName || detectedName(prompt) || randomNameForGender(gender, randomSeed, { ancestry, technology });
  const quality =
    formData.quality && formData.quality !== "auto"
      ? formData.quality
      : /мини[\s-]?босс|элитн|особо опасн/iu.test(prompt)
        ? "elite"
        : "standard";
  const requestedTarget = ["new", "duplicate", "selected"].includes(
    formData.target,
  )
    ? formData.target
    : "new";
  const requestedCount =
    formData.count === "" ||
    formData.count === null ||
    formData.count === undefined
      ? 1
      : Number(formData.count);
  const itemPolicy = ["generated", "all", "keep"].includes(formData.itemPolicy)
    ? formData.itemPolicy
    : formData.replaceItems === true || formData.replaceItems === "true"
      ? "all"
      : "generated";

  const requestedComplexity = ["simple", "standard", "tactical"].includes(
    formData.complexity,
  )
    ? formData.complexity
    : /тактическ|сложн(?:ый|ая|ое)|комбинац|мини[\s-]?босс/iu.test(prompt)
      ? "tactical"
      : /прост(?:ой|ая|ое)|статист|без сложн/iu.test(prompt)
        ? "simple"
        : "standard";
  const requestedSpellTheme = [
    "auto",
    "battle",
    "fire",
    "storm",
    "control",
    "defense",
    "illusion",
    "healing",
    "death",
    "nature",
    "tech",
    "gravity",
    "time",
    "cosmic",
  ].includes(formData.spellTheme)
    ? formData.spellTheme
    : "auto";
  const categorySeed = (value, salt) => {
    const clean = String(value ?? "").trim();
    return clean || String(deriveSeed(randomSeed, salt));
  };

  const result = {
    prompt,
    name,
    level,
    creatureKind,
    monsterFamily,
    ancestry,
    gender,
    profession,
    role,
    armor,
    weapon,
    quality,
    technology,
    contentSource,
    target: requestedTarget,
    count: requestedTarget === "new" ? requestedCount : 1,
    itemPolicy,
    backupOriginal:
      formData.backupOriginal !== false && formData.backupOriginal !== "false",
    openSheet: formData.openSheet !== false && formData.openSheet !== "false",
    randomSeed,
    seedPersonality: categorySeed(formData.seedPersonality, "personality"),
    seedAbilities: categorySeed(formData.seedAbilities, "abilities"),
    seedSpells: categorySeed(formData.seedSpells, "spells"),
    seedConsumables: categorySeed(formData.seedConsumables, "consumables"),
    seedToken: categorySeed(formData.seedToken, "token"),
    randomized: formData.randomized === true || formData.randomized === "true",
    complexity: requestedComplexity,
    spellTheme: requestedSpellTheme,
    autoCorrect: formData.autoCorrect !== false && formData.autoCorrect !== "false",
    includeSkillActions:
      formData.includeSkillActions !== false && formData.includeSkillActions !== "false",
    randomAbilities:
      formData.randomAbilities !== false && formData.randomAbilities !== "false",
    randomSpells:
      formData.randomSpells !== false && formData.randomSpells !== "false",
    randomConsumables:
      formData.randomConsumables !== false && formData.randomConsumables !== "false",
    randomToken: formData.randomToken === true || formData.randomToken === "true",
    tokenPath: String(formData.tokenPath ?? "tokens").trim().slice(0, 500),
    tokenImage: String(formData.tokenImage ?? "").trim().slice(0, 1000),
    batchMode: ["clones", "squad", "encounter"].includes(formData.batchMode)
      ? formData.batchMode
      : "clones",
    encounterDifficulty: ENCOUNTER_DIFFICULTIES[formData.encounterDifficulty]
      ? formData.encounterDifficulty
      : "none",
    partyLevel: Math.max(1, Math.min(20, Number(formData.partyLevel) || Math.max(1, level))),
    partySize: Math.max(1, Math.min(8, Number(formData.partySize) || 4)),
    deploymentMode: ["none", "cluster", "line", "wedge", "ring"].includes(formData.deploymentMode)
      ? formData.deploymentMode
      : "none",
    addToCombat: formData.addToCombat === true || formData.addToCombat === "true",
    createBriefing: formData.createBriefing === true || formData.createBriefing === "true",
    sendChatSummary: formData.sendChatSummary === true || formData.sendChatSummary === "true",
    confirmRiskyOperations:
      formData.confirmRiskyOperations !== false && formData.confirmRiskyOperations !== "false",
    adventureMode: ADVENTURE_MODES[formData.adventureMode] ? formData.adventureMode : "off",
    includeLootPlan: formData.includeLootPlan === true || formData.includeLootPlan === "true",
    lootRichness: LOOT_RICHNESS[formData.lootRichness] ? formData.lootRichness : "normal",
    monsterTemplate: MONSTER_TEMPLATES[formData.monsterTemplate] ? formData.monsterTemplate : "none",
    statTiers,
    abilityTiers,
    skillTiers,
    elements: [...new Set(elements)],
  };

  validateConcept(result);
  return result;
}

export function validateConcept(concept) {
  const validTiers = new Set(["terrible", "low", "moderate", "high", "extreme"]);
  if (!CREATURE_KINDS[concept.creatureKind]) {
    throw new Error("Не удалось определить тип существа.");
  }
  if (!MONSTER_FAMILIES[concept.monsterFamily]) {
    throw new Error("Не удалось определить семейство монстра.");
  }
  if (!ANCESTRIES[concept.ancestry]) {
    throw new Error("Не удалось определить происхождение.");
  }
  if (!PROFESSIONS[concept.profession]) {
    throw new Error("Не удалось определить профессию.");
  }
  if (!ROLES[concept.role]) {
    throw new Error("Не удалось определить боевую роль.");
  }
  if (!ARMORS[concept.armor]) {
    throw new Error("Не удалось определить доспех.");
  }
  if (!WEAPONS[concept.weapon]) {
    throw new Error("Не удалось определить оружие.");
  }
  if (!Number.isInteger(concept.level) || concept.level < -1 || concept.level > 20) {
    throw new Error("Уровень должен быть целым числом от −1 до 20.");
  }
  if (!Number.isInteger(concept.count) || concept.count < 1 || concept.count > 20) {
    throw new Error("Количество должно быть целым числом от 1 до 20.");
  }
  if (!TECHNOLOGY_LEVELS[concept.technology]) {
    throw new Error("Неизвестный технологический уровень мира.");
  }
  if (!CONTENT_SOURCES[concept.contentSource]) {
    throw new Error("Неизвестный источник контента.");
  }
  if (!ADVENTURE_MODES[concept.adventureMode]) {
    throw new Error("Неизвестный режим мастерского сценария.");
  }
  if (!LOOT_RICHNESS[concept.lootRichness]) {
    throw new Error("Неизвестная насыщенность добычи.");
  }
  if (!MONSTER_TEMPLATES[concept.monsterTemplate]) {
    throw new Error("Неизвестный шаблон преобразования существа.");
  }
  if (!["none", "cluster", "line", "wedge", "ring"].includes(concept.deploymentMode)) {
    throw new Error("Неизвестная схема размещения жетонов.");
  }
  if (!["standard", "elite"].includes(concept.quality)) {
    throw new Error("Сила заготовки должна быть обычной или элитной.");
  }
  if (!["new", "duplicate", "selected"].includes(concept.target)) {
    throw new Error("Неизвестный режим применения результата.");
  }
  if (!["generated", "all", "keep"].includes(concept.itemPolicy)) {
    throw new Error("Неизвестный режим замены предметов.");
  }
  if (!["simple", "standard", "tactical"].includes(concept.complexity)) {
    throw new Error("Неизвестная сложность управления NPC.");
  }
  if (!["clones", "squad", "encounter"].includes(concept.batchMode)) {
    throw new Error("Неизвестный режим пакетной генерации.");
  }
  if (!ENCOUNTER_DIFFICULTIES[concept.encounterDifficulty]) {
    throw new Error("Неизвестная сложность столкновения.");
  }
  if (!Number.isInteger(concept.partyLevel) || concept.partyLevel < 1 || concept.partyLevel > 20) {
    throw new Error("Уровень группы должен быть целым числом от 1 до 20.");
  }
  if (!Number.isInteger(concept.partySize) || concept.partySize < 1 || concept.partySize > 8) {
    throw new Error("Размер группы должен быть целым числом от 1 до 8.");
  }
  if (![
    "auto", "battle", "fire", "storm", "control", "defense",
    "illusion", "healing", "death", "nature", "tech", "gravity", "time", "cosmic",
  ].includes(concept.spellTheme)) {
    throw new Error("Неизвестная тематика заклинаний.");
  }
  if (!String(concept.randomSeed ?? "").trim()) {
    throw new Error("Не удалось определить зерно случайной генерации.");
  }
  for (const tiers of [
    concept.statTiers,
    concept.abilityTiers,
    concept.skillTiers,
  ]) {
    for (const tier of Object.values(tiers ?? {}).filter(Boolean)) {
      if (!validTiers.has(tier)) {
        throw new Error(`Неизвестная шкала характеристики: ${tier}.`);
      }
    }
  }
  return true;
}

export function conceptSummary(concept) {
  return [
    `${ANCESTRIES[concept.ancestry].description}, ${genderLabel(concept.gender)}`,
    concept.monsterFamily !== "none" ? `семейство: ${MONSTER_FAMILIES[concept.monsterFamily].label}` : null,
    `${concept.level}-й уровень`,
    `профессия: ${PROFESSIONS[concept.profession].label}`,
    `роль: ${ROLES[concept.role].label}`,
    `защита: ${ARMORS[concept.armor].label}`,
    `оружие: ${WEAPONS[concept.weapon].label}`,
    `технологии: ${TECHNOLOGY_LEVELS[concept.technology].label.toLowerCase()}`,
    `источники: ${CONTENT_SOURCES[concept.contentSource].label.toLowerCase()}`,
    concept.quality === "elite" ? "элитная надстройка" : "обычная сила",
    `сложность управления: ${concept.complexity === "simple" ? "простая" : concept.complexity === "tactical" ? "тактическая" : "стандартная"}`,
    concept.randomAbilities ? "вариативные способности" : null,
    concept.randomSpells && (concept.profession === "mage" || concept.profession === "priest" || concept.role === "caster")
      ? `тематические заклинания${concept.spellTheme !== "auto" ? `: ${concept.spellTheme}` : ""}`
      : null,
    concept.tokenImage ? "выбранный токен" : concept.randomToken ? "случайный токен" : null,
    concept.count > 1 && concept.batchMode === "squad" ? "разнообразный отряд" : null,
    concept.count > 1 && concept.batchMode === "encounter" ? "тематическое столкновение" : null,
    concept.encounterDifficulty !== "none" ? `целевая опасность: ${ENCOUNTER_DIFFICULTIES[concept.encounterDifficulty].label.toLowerCase()}` : null,
    concept.deploymentMode !== "none" ? `разместить на сцене: ${concept.deploymentMode}` : null,
    concept.addToCombat ? "добавить в бой" : null,
    concept.includeSkillActions ? "рабочие действия навыков" : null,
    concept.createBriefing ? "создать мастерскую сводку" : null,
    concept.sendChatSummary ? "личный отчёт GM в чат" : null,
    concept.adventureMode !== "off" ? `мастерский сценарий: ${ADVENTURE_MODES[concept.adventureMode].label.toLowerCase()}` : null,
    concept.monsterTemplate !== "none" ? `преобразование: ${MONSTER_TEMPLATES[concept.monsterTemplate].label.toLowerCase()}` : null,
    concept.includeLootPlan ? `добыча: ${LOOT_RICHNESS[concept.lootRichness].label.toLowerCase()}` : null,
  ].filter(Boolean).join("; ");
}

export function genderLabel(gender) {
  if (gender === "female") return "женщина";
  if (gender === "male") return "мужчина";
  return "пол не указан";
}
