import { createRng, deriveSeed, pick } from "./randomizer.js";

const COMPLICATIONS = [
  "Шум боя привлекает третью сторону через 1d4 раунда.",
  "Один противник знает важную информацию и пытается выжить.",
  "Местность начинает разрушаться или меняться после первого критического попадания.",
  "В логове находится пленник, которого легко задеть площадным эффектом.",
  "Главная цель имеет приказ отступить с важным предметом.",
  "Среди противников есть сомневающийся участник, готовый сменить сторону.",
];

const CLUES = [
  "Отличительный знак связывает группу с более крупной фракцией.",
  "Следы показывают, что противники пришли сюда не по собственной воле.",
  "В снаряжении есть карта, код или письмо к следующей сцене.",
  "Один предмет явно принадлежал предыдущей жертве.",
  "Положение лагеря выдаёт скрытый путь или запасной выход.",
  "Разговор перед боем раскрывает имя нанимателя или хозяина логова.",
];

const PEACEFUL = [
  "Предложить безопасный отход и не приближаться к охраняемой зоне.",
  "Доказать, что герои не связаны с настоящим врагом группы.",
  "Предложить припасы, лечение, ремонт или сведения вместо боя.",
  "Вывести из строя лидера морально: разоблачить ложь, приказ или слабость.",
  "Использовать скрытый страх или желание лидера, указанное в его заметках.",
];

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

export function buildEncounterBriefing(results, concept) {
  const seed = concept.randomSeed ?? `${concept.name}:${concept.level}`;
  const rng = createRng(deriveSeed(seed, "briefing"));
  const actors = results.map((result) => result.actor).filter(Boolean);
  const actorRows = actors.map((actor, index) => {
    const intelligence = results[index]?.intelligence;
    const tactics = intelligence?.tactics;
    return `<li>@UUID[${actor.uuid}]{${escapeHtml(actor.name)}}${tactics?.opening ? ` — <em>${escapeHtml(tactics.opening)}</em>` : ""}</li>`;
  });
  const complication = pick(COMPLICATIONS, rng);
  const clue = pick(CLUES, rng);
  const peaceful = pick(PEACEFUL, rng);
  const adventure = results[0]?.intelligence?.adventure ?? null;
  const director = adventure?.director ?? null;
  const loot = adventure?.loot ?? null;
  const title = concept.count > 1
    ? `${concept.name}: мастерская сводка столкновения`
    : `${actors[0]?.name ?? concept.name}: мастерская сводка`;
  const content = `
    <h1>${escapeHtml(title)}</h1>
    <p><strong>Уровень:</strong> ${concept.level}. <strong>Количество:</strong> ${actors.length}. <strong>Режим:</strong> ${escapeHtml(concept.batchMode ?? "одиночный NPC")}.</p>
    <h2>Участники</h2><ul>${actorRows.join("")}</ul>
    <h2>Как провести сцену</h2>
    <p><strong>Поведение в сцене:</strong> ${escapeHtml(results[0]?.intelligence?.tactics?.before ?? "занимает подходящую позицию и оценивает обстановку")}</p>
    ${director?.objective ? `<p><strong>Цель противников:</strong> ${escapeHtml(director.objective)}</p>` : ""}
    ${director?.playerObjective ? `<p><strong>Цель героев:</strong> ${escapeHtml(director.playerObjective)}</p>` : ""}
    ${director?.stake ? `<p><strong>Ставка социальной сцены:</strong> ${escapeHtml(director.stake)}. Базовая КС: ${director.dc}.</p>` : ""}
    ${director?.crime ? `<p><strong>Расследование:</strong> ${escapeHtml(director.crime)}. Мотив виновника: ${escapeHtml(director.culpritMotive)}.</p>` : ""}
    <p><strong>Мирное решение:</strong> ${escapeHtml(director?.peaceful ?? peaceful)}</p>
    <p><strong>Подсказка:</strong> ${escapeHtml(clue)}</p>
    <p><strong>Осложнение:</strong> ${escapeHtml(director?.complication ?? complication)}</p>
    ${director?.phases?.length ? `<h3>Фазы</h3><ul>${director.phases.map((phase) => `<li><strong>${escapeHtml(phase.trigger)}:</strong> ${escapeHtml(phase.effect)}</li>`).join("")}</ul>` : ""}
    ${director?.approaches?.length ? `<h3>Рабочие подходы</h3><ul>${director.approaches.map((approach) => `<li><strong>${escapeHtml(approach.skill)} (КС ${approach.dc}):</strong> ${escapeHtml(approach.method)}</li>`).join("")}</ul>` : ""}
    ${director?.clues?.length ? `<h3>Улики</h3><ul>${director.clues.map((entry) => `<li>${escapeHtml(entry.clue)} — ${escapeHtml(entry.skill)}, КС ${entry.dc}${entry.essential ? " (ключевая)" : ""}</li>`).join("")}</ul>` : ""}
    <h2>Боевая шпаргалка</h2>
    ${results.map((result) => {
      const tactics = result.intelligence?.tactics;
      return `<h3>${escapeHtml(result.actor?.name)}</h3><ul><li><strong>Начало:</strong> ${escapeHtml(tactics?.opening ?? "занимает выгодную позицию")}</li><li><strong>Цикл:</strong> ${escapeHtml(tactics?.routine ?? "использует основной удар и яркую способность")}</li><li><strong>При половине ОЗ:</strong> ${escapeHtml(tactics?.bloodied ?? "переходит к защите или отступлению")}</li><li><strong>Конец:</strong> ${escapeHtml(tactics?.retreat ?? "отступает, сдаётся или сражается до конца согласно характеру")}</li></ul>`;
    }).join("")}
    ${loot ? `<h2>Добыча и последствия</h2><p><strong>${escapeHtml(loot.label)}:</strong> ${escapeHtml(loot.coins)}; расходников: ${loot.consumableCount}.</p>${loot.inventory?.length ? `<h3>Физически добавлено в инвентарь</h3><ul>${loot.inventory.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>` : ""}<ul>${loot.themes.map((theme) => `<li>${escapeHtml(theme)}</li>`).join("")}<li><strong>Сюжетный предмет:</strong> ${escapeHtml(loot.storyItem)}</li></ul><p>${escapeHtml(loot.rule)}</p>` : ""}
  `;
  return { title, content, complication, clue, peaceful };
}

export async function createEncounterBriefing(results, concept) {
  const briefing = buildEncounterBriefing(results, concept);
  if (!concept.createBriefing || typeof globalThis.JournalEntry?.create !== "function") {
    return { ...briefing, journal: null, warnings: [] };
  }
  const warnings = [];
  try {
    let journal = await globalThis.JournalEntry.create({
      name: briefing.title,
      pages: [{
        name: "Сводка ведущего",
        type: "text",
        text: { content: briefing.content, format: 1 },
        ownership: { default: 0 },
      }],
      ownership: { default: 0 },
      flags: { "pf2e-npc-forge": { generated: true, kind: "encounter-briefing" } },
    });
    if (Array.isArray(journal)) journal = journal[0];
    return { ...briefing, journal, warnings };
  } catch (error) {
    warnings.push(`Мастерскую сводку не удалось сохранить в журнал: ${error.message}`);
    return { ...briefing, journal: null, warnings };
  }
}
