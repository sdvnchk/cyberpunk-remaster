import { createRng, deriveSeed, pick, sample } from "./randomizer.js";

export const ADVENTURE_MODES = {
  auto: { label: "Автоматически по концепту" },
  encounter: { label: "Боевое столкновение" },
  social: { label: "Социальная сцена" },
  investigation: { label: "Расследование" },
  off: { label: "Не создавать мастерский сценарий" },
};

export const LOOT_RICHNESS = {
  poor: { label: "Скудная — мелочь и минимум припасов", multiplier: 0.45 },
  normal: { label: "Обычная — деньги и одна полезная находка", multiplier: 1 },
  generous: { label: "Щедрая — больше денег и несколько предметов", multiplier: 1.8 },
  consumables: { label: "Расходники — зелья, гранаты и препараты", multiplier: 1.15 },
  story: { label: "Сюжетная — улика или ключ вместо денег", multiplier: 0 },
};

export const MONSTER_TEMPLATES = {
  none: { label: "Без преобразования" },
  fire: { label: "Огненное" },
  frost: { label: "Морозное" },
  storm: { label: "Грозовое" },
  shadow: { label: "Теневое" },
  undead: { label: "Неживое" },
  construct: { label: "Механическое" },
  demonic: { label: "Демоническое" },
  giant: { label: "Исполинское" },
  young: { label: "Молодое и ослабленное" },
};


const FANTASY_LOOT = {
  poor: [
    { slug: "silver-pieces", name: "Серебряные монеты", quantity: 8 },
  ],
  normal: [
    { slug: "gold-pieces", name: "Золотые монеты", quantity: 6 },
    { slug: "agate", name: "Небольшой агат", quantity: 1 },
  ],
  generous: [
    { slug: "gold-pieces", name: "Золотые монеты", quantity: 16 },
    { slug: "silver-statuette-of-a-raven", name: "Серебряная статуэтка", quantity: 1 },
    { slug: "illustrated-book", name: "Иллюстрированная книга", quantity: 1 },
  ],
  story: [
    { slug: "engraved-copper-ring", name: "Сюжетная улика", quantity: 1, description: "Кольцо, ключ, печать или иной предмет, который напрямую ведёт к следующей сцене." },
  ],
  consumables: [
    { slug: "healing-potion-lesser", name: "Малое зелье лечения", quantity: 2 },
    { slug: "antidote-lesser", name: "Малое противоядие", quantity: 1 },
    { slug: "smoke-ball-lesser", name: "Малый дымный шар", quantity: 1 },
  ],
};

const STARFINDER_LOOT = {
  poor: [
    { slug: "battery-commercial", name: "Серийный аккумулятор", quantity: 1, source: "sf2e" },
  ],
  normal: [
    { slug: "data-chip", name: "Чип с данными", quantity: 1, source: "sf2e" },
    { slug: "battery-commercial", name: "Серийный аккумулятор", quantity: 2, source: "sf2e" },
  ],
  generous: [
    { slug: "data-chip", name: "Защищённый чип с данными", quantity: 2, source: "sf2e" },
    { slug: "battery-tactical", name: "Тактический аккумулятор", quantity: 2, source: "sf2e", minLevel: 5 },
    { slug: "medpatch-commercial", name: "Медпластырь", quantity: 3, source: "sf2e" },
  ],
  story: [
    { slug: "data-chip", name: "Сюжетный чип данных", quantity: 1, source: "sf2e", description: "Зашифрованные координаты, запись или код доступа, ведущий к следующей сцене." },
  ],
  consumables: [
    { slug: "medpatch-commercial", name: "Серийный медпластырь", quantity: 2, source: "sf2e" },
    { slug: "frag-grenade-commercial", name: "Серийная осколочная граната", quantity: 1, source: "sf2e" },
    { slug: "smoke-grenade-commercial", name: "Серийная дымовая граната", quantity: 1, source: "sf2e" },
  ],
};

export function lootInventoryPlan(concept) {
  if (!concept.includeLootPlan) return [];
  const key = LOOT_RICHNESS[concept.lootRichness] ? concept.lootRichness : "normal";
  const starfinder = concept.contentSource === "sf2e" || concept.technology === "starfinder";
  const level = Math.max(0, Number(concept.level) || 0);
  const source = starfinder ? STARFINDER_LOOT : FANTASY_LOOT;
  return (source[key] ?? []).filter((item) => !item.minLevel || level >= item.minLevel).map((item) => ({
    ...item,
    quantity: Math.max(1, Math.round(Number(item.quantity || 1) * (key === "generous" ? Math.max(1, 1 + level / 12) : key === "poor" ? 1 : Math.max(1, 1 + level / 20)))),
  }));
}

const OBJECTIVES = [
  "удержать проход до завершения сигнала или ритуала",
  "похитить важный предмет и вывести носителя со сцены",
  "задержать героев на три раунда, не принимая смертельный бой",
  "вывести из строя одного конкретного участника группы и отступить",
  "защитить лидера, пленника или механизм",
  "сбежать с добычей через заранее подготовленный путь",
  "сломать мост, дверь, терминал или иной ключевой объект",
];

const PLAYER_OBJECTIVES = [
  "не дать главной цели противников покинуть сцену",
  "добраться до охраняемого объекта раньше третьего раунда",
  "спасти пленника, не повредив его площадными эффектами",
  "захватить лидера живым для допроса",
  "остановить тревогу до прибытия подкрепления",
  "получить доказательство и уйти, не обязательно побеждая всех",
];

const COMPLICATIONS = [
  "на втором раунде местность становится опасной или начинает разрушаться",
  "один противник не согласен с приказом и может сменить сторону",
  "шум привлекает нейтральную третью сторону",
  "важный предмет оказывается нестабильным и требует отдельного действия каждый раунд",
  "один из врагов знает критически важную информацию и пытается выжить",
  "путь отступления одновременно является кратчайшим путём к мирной развязке",
];

const SOCIAL_STAKES = [
  "доступ в закрытую область",
  "цена и условия редкого товара",
  "освобождение задержанного или пленника",
  "получение поддержки фракции",
  "право провести расследование",
  "отказ от нападения или преследования",
];

const SOCIAL_APPROACHES = [
  ["Дипломатия", "показать взаимную выгоду и сохранить достоинство собеседника"],
  ["Обман", "предложить правдоподобную версию, которую трудно проверить немедленно"],
  ["Запугивание", "продемонстрировать реальные последствия, не переходя к пустым угрозам"],
  ["Общество", "сослаться на закон, обычай, статус или репутацию"],
];

const CRIMES = [
  "исчезновение важного свидетеля",
  "кража реликвии или технического прототипа",
  "саботаж снабжения перед нападением",
  "подмена лекарств или боеприпасов",
  "убийство, замаскированное под несчастный случай",
  "утечка маршрута каравана или патруля",
];

const MOTIVES = [
  "долг перед фракцией",
  "страх разоблачения старого преступления",
  "желание спасти близкого человека",
  "корысть и уверенность в безнаказанности",
  "идеологическая ненависть",
  "шантаж со стороны настоящего организатора",
];

function autoMode(concept) {
  if (concept.adventureMode && concept.adventureMode !== "auto") return concept.adventureMode;
  if (["merchant", "priest", "doctor"].includes(concept.profession) && ["support", "controller", "healer"].includes(concept.role)) return "social";
  if (["guard", "scout", "thief", "operative", "investigator"].includes(concept.profession)) return "investigation";
  return "encounter";
}

function encounterDirector(concept, rng) {
  const objective = pick(OBJECTIVES, rng);
  const playerObjective = pick(PLAYER_OBJECTIVES, rng);
  const complication = pick(COMPLICATIONS, rng);
  const reinforcementRound = 2 + Math.floor(rng() * 3);
  return {
    mode: "encounter",
    title: "Режиссёр столкновения",
    objective,
    playerObjective,
    phases: [
      { trigger: "До боя", effect: "противники занимают позиции, выбирают объект защиты и путь отхода" },
      { trigger: "Первый раунд", effect: "одна роль удерживает героев, другая немедленно работает на главную цель" },
      { trigger: `Раунд ${reinforcementRound}`, effect: "срабатывает осложнение или появляется небольшое подкрепление, если сцена идёт слишком легко" },
      { trigger: "Половина состава выведена из строя", effect: "лидер предлагает сделку, меняет цель или начинает организованное отступление" },
    ],
    victory: `Герои достигают цели: ${playerObjective}. Полное уничтожение врагов не обязательно.`,
    defeat: `Противники выполняют задачу: ${objective}. Это создаёт следующую сцену, а не завершает приключение.`,
    peaceful: "Обещать безопасный отход, доказать наличие общего врага или предложить ресурс, который напрямую решает цель противников.",
    complication,
    levers: {
      easier: "отложить осложнение на один раунд, убрать реакцию лидера или позволить одному врагу отказаться от боя",
      harder: "ускорить осложнение, дать лидеру одно дополнительное применение яркой способности или открыть второй путь подхода подкрепления",
    },
  };
}

function socialDirector(concept, dc, rng) {
  const stake = pick(SOCIAL_STAKES, rng);
  const approaches = sample(SOCIAL_APPROACHES, 3, rng);
  return {
    mode: "social",
    title: "Социальная сцена",
    stake,
    startingAttitude: pick(["настороженное", "нейтральное", "раздражённое", "деловое"], rng),
    dc,
    approaches: approaches.map(([skill, method], index) => ({
      skill,
      method,
      dc: dc + (index === 0 ? 0 : index === 1 ? 1 : -1),
    })),
    concession: `Собеседник готов уступить по вопросу «${stake}», если сохранит лицо или получит конкретную встречную услугу.`,
    redLine: pick([
      "публичное оскорбление его компетентности",
      "угроза подчинённым или семье",
      "попытка немедленно проверить скрываемый секрет",
      "требование отказаться от формального статуса",
    ], rng),
    success: "Герои получают желаемое и один дополнительный полезный слух.",
    partial: "Герои получают желаемое, но принимают долг, ограничение или неудобный срок.",
    failure: "Сделка не закрыта; собеседник повышает цену, требует поручителя или обращается к соперникам героев.",
  };
}

function investigationDirector(concept, dc, rng) {
  const crime = pick(CRIMES, rng);
  const motive = pick(MOTIVES, rng);
  const clues = sample([
    "несоответствие времени в показаниях",
    "след редкого вещества, магии или боеприпаса",
    "документ с исправленной подписью или датой",
    "предмет жертвы в месте, где его не должно быть",
    "маршрут, известный лишь ограниченному кругу",
    "свидетель, который врёт не о преступлении, а о собственной тайне",
    "повреждение, которое требует профессионального навыка",
  ], 5, rng);
  return {
    mode: "investigation",
    title: "Расследование",
    crime,
    culpritMotive: motive,
    suspects: [
      "очевидный подозреваемый с сильным мотивом, но слабой возможностью",
      "уважаемый свидетель с доступом и скрываемой личной тайной",
      "настоящий виновник, чья версия почти правдива, кроме одной детали",
    ],
    clues: clues.map((clue, index) => ({
      clue,
      skill: ["Восприятие", "Общество", "Медицина", "Ремесло", "Обман"][index % 5],
      dc: dc + (index > 2 ? 1 : 0),
      essential: index < 3,
    })),
    falseClue: "Правдивая улика указывает на невиновного, потому что её неверно связывают со временем преступления.",
    clock: "После двух длительных пауз виновник уничтожает одну второстепенную улику; после третьей пытается сбежать или подставить другого подозреваемого.",
    reveal: `Ключ к разгадке — сопоставить возможность с мотивом «${motive}», а не только найти самый подозрительный предмет.`,
  };
}

function lootDirector(concept, rng) {
  const richness = LOOT_RICHNESS[concept.lootRichness] ?? LOOT_RICHNESS.normal;
  const level = Math.max(0, Number(concept.level) || 0);
  const inventory = lootInventoryPlan(concept);
  const consumableCount = concept.lootRichness === "consumables"
    ? Math.max(4, 2 + Math.ceil(level / 3))
    : concept.lootRichness === "poor"
      ? 1
      : Math.max(1, Math.round((1 + level / 5) * Math.max(0.5, richness.multiplier)));
  const themes = concept.contentSource === "sf2e"
    ? ["батареи и боеприпасы", "технический расходник", "защищённый носитель данных"]
    : ["лечебный расходник", "алхимический или магический расходник", "карта, письмо или ключ"];
  return {
    label: richness.label,
    permanentCount: inventory.length,
    consumableCount,
    inventory: inventory.map((item) => `${item.name}${item.quantity > 1 ? ` ×${item.quantity}` : ""}`),
    coins: richness.multiplier === 0 ? "денежной награды нет" : `${Math.max(1, Math.round((level + 1) * 5 * richness.multiplier))} зм ориентировочной ценности`,
    themes: sample(themes, Math.min(themes.length, 2), rng),
    storyItem: pick([
      "письмо, связывающее сцену с более крупной фракцией",
      "ключ, код или карта к следующему месту",
      "личный предмет жертвы или пленника",
      "повреждённый прототип, который можно восстановить",
    ], rng),
    rule: "Выбранные предметы физически добавляются в инвентарь первого NPC группы; остальные ценности — ориентир для ведущего.",
  };
}

export function adventurePlan(concept, { dc = 15 } = {}) {
  const mode = autoMode(concept);
  const rng = createRng(deriveSeed(concept.randomSeed, `adventure:${mode}`));
  const director = mode === "off"
    ? null
    : mode === "social"
      ? socialDirector(concept, dc, rng)
      : mode === "investigation"
        ? investigationDirector(concept, dc, rng)
        : encounterDirector(concept, rng);
  const loot = concept.includeLootPlan ? lootDirector(concept, rng) : null;
  return { mode, director, loot };
}

function feature(name, slug, description, traits = []) {
  return {
    name,
    slug,
    actionType: "passive",
    actions: null,
    category: "defensive",
    traits,
    description,
    rules: [],
    automation: "manual",
  };
}

export function monsterTemplatePlan(concept) {
  const id = MONSTER_TEMPLATES[concept.monsterTemplate] ? concept.monsterTemplate : "none";
  const resistance = Math.max(2, Math.floor((Number(concept.level) + 3) / 2));
  const weakness = Math.max(2, Math.floor((Number(concept.level) + 2) / 2));
  const base = {
    id,
    label: MONSTER_TEMPLATES[id].label,
    traits: [],
    immunities: [],
    resistances: [],
    weaknesses: [],
    size: null,
    hpMultiplier: 1,
    speedAdjustment: 0,
    features: [],
  };
  if (id === "none") return base;
  const profiles = {
    fire: {
      traits: ["fire"], resistances: [{ type: "fire", value: resistance }], weaknesses: [{ type: "cold", value: weakness }],
      features: [feature("Пылающее тело", "forge-template-burning-body", "<p>Существо излучает жар; первый соседний враг, попавший по нему безоружной атакой, получает огненный урон, равный половине уровня существа.</p>", ["fire"])],
    },
    frost: {
      traits: ["cold"], resistances: [{ type: "cold", value: resistance }], weaknesses: [{ type: "fire", value: weakness }], speedAdjustment: -5,
      features: [feature("Леденящее присутствие", "forge-template-chilling-presence", "<p>Первая цель, получившая урон от существа в раунде, снижает Скорость на 5 футов до начала следующего хода.</p>", ["cold"])],
    },
    storm: {
      traits: ["electricity"], resistances: [{ type: "electricity", value: resistance }],
      features: [feature("Грозовой разряд", "forge-template-storm-discharge", "<p>Раз в раунд после критического попадания существо наносит ближайшей второй цели электрический урон, равный половине своего уровня.</p>", ["electricity"])],
    },
    shadow: {
      traits: ["shadow"], resistances: [{ type: "void", value: resistance }], weaknesses: [{ type: "vitality", value: weakness }], speedAdjustment: 5,
      features: [feature("Слиться с тенью", "forge-template-merge-shadow", "<p>В тусклом свете существо может Прятаться даже без обычного укрытия.</p>", ["darkness", "shadow"])],
    },
    undead: {
      traits: ["undead"], immunities: [{ type: "death-effects" }, { type: "disease" }, { type: "poison" }, { type: "unconscious" }], weaknesses: [{ type: "vitality", value: weakness }],
      features: [feature("Пустотное исцеление", "forge-template-void-healing", "<p>Существо исцеляется пустотной энергией и получает урон от эффектов жизненной энергии согласно обычным правилам нежити.</p>", ["void"])],
    },
    construct: {
      traits: ["construct"], immunities: [{ type: "bleed" }, { type: "disease" }, { type: "poison" }, { type: "unconscious" }], resistances: [{ type: "physical", value: Math.max(1, resistance - 1) }],
      features: [feature("Механическая точность", "forge-template-mechanical-precision", "<p>Существо не получает штрафов от боли, кровотечения или усталости, но может быть отремонтировано Ремеслом.</p>", [])],
    },
    demonic: {
      traits: ["demon", "fiend"], resistances: [{ type: "fire", value: resistance }], weaknesses: [{ type: "cold-iron", value: weakness }, { type: "holy", value: weakness }],
      features: [feature("Демоническая жестокость", "forge-template-demonic-cruelty", "<p>Первый Удар по напуганной цели в каждом раунде наносит дополнительный урон, равный половине уровня существа.</p>", ["unholy"])],
    },
    giant: {
      traits: [], size: "lg", hpMultiplier: 1.25, speedAdjustment: -5,
      features: [feature("Исполинский размах", "forge-template-giant-reach", "<p>Досягаемость основных атак существа увеличивается на 5 футов, если анатомия и оружие это допускают.</p>")],
    },
    young: {
      traits: [], size: "sm", hpMultiplier: 0.75, speedAdjustment: 5,
      features: [feature("Неопытное", "forge-template-young", "<p>Существо действует быстро, но избегает затяжного боя и отступает при первой серьёзной ране.</p>")],
    },
  };
  return { ...base, ...(profiles[id] ?? {}) };
}
