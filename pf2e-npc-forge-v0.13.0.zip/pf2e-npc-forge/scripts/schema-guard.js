const FALLBACK = Object.freeze({
  actionTypes: ["action", "reaction", "free", "passive"],
  actionCategories: ["interaction", "defensive", "offensive", "familiar"],
  actionsNumber: ["1", "2", "3"],
  actorSizes: ["tiny", "sm", "med", "lg", "huge", "grg"],
  magicTraditions: ["arcane", "divine", "occult", "primal"],
  preparedTypes: ["prepared", "spontaneous", "innate", "focus", "items"],
  abilities: ["str", "dex", "con", "int", "wis", "cha"],
  rarities: ["common", "uncommon", "rare", "unique"],
  damageTypes: [
    "acid", "bleed", "bludgeoning", "cold", "electricity", "fire", "force",
    "mental", "piercing", "poison", "slashing", "sonic", "spirit", "untyped",
    "vitality", "void",
  ],
  damageCategories: ["persistent", "precision", "splash"],
  movementTypes: ["burrow", "climb", "fly", "swim"],
  embeddedItemTypes: [
    "action", "ammo", "armor", "backpack", "book", "consumable", "effect",
    "equipment", "melee", "shield", "spell", "spellcastingEntry", "treasure", "weapon",
  ],
});

const ACTION_CATEGORY_ALIASES = Object.freeze({
  support: "interaction",
  healing: "interaction",
  utility: "interaction",
  exploration: "interaction",
  control: "offensive",
});

function configKeys(key, fallback = []) {
  const record = globalThis.CONFIG?.PF2E?.[key];
  if (record && typeof record === "object") return new Set(Object.keys(record));
  return new Set(fallback);
}


const TRAIT_CONFIG_BY_TYPE = Object.freeze({
  action: "actionTraits",
  ammo: "consumableTraits",
  armor: "armorTraits",
  backpack: "equipmentTraits",
  book: "equipmentTraits",
  consumable: "consumableTraits",
  effect: "effectTraits",
  equipment: "equipmentTraits",
  melee: "npcAttackTraits",
  shield: "shieldTraits",
  spell: "spellTraits",
  treasure: "equipmentTraits",
  weapon: "weaponTraits",
});

function typeKeys(value) {
  if (!value) return [];
  if (value instanceof Map) return [...value.keys()].map(String);
  if (value instanceof Set) return [...value.values()].map(String);
  if (Array.isArray(value)) return value.map(String);
  if (typeof value === "object") return Object.keys(value);
  return [];
}

/**
 * Return all runtime evidence describing Item subtypes.
 *
 * PF2e 8.x does not expose every physical Item subtype in
 * CONFIG.Item.dataModels. Many types (armor, weapon, consumable, backpack,
 * etc.) share a base data model and are instead listed by the Item document
 * class and by game.system.documentTypes.Item. Therefore dataModels is useful
 * diagnostic evidence, but it is not a complete allow-list and must never be
 * used alone to reject an Item.
 */
export function itemTypeRegistrySnapshot() {
  const configDataModels = typeKeys(globalThis.CONFIG?.Item?.dataModels);
  const documentClassTypes = typeKeys(globalThis.CONFIG?.Item?.documentClass?.TYPES);
  const implementationTypes = typeKeys(globalThis.CONFIG?.Item?.documentClass?.implementation?.TYPES);
  const systemDocumentTypes = typeKeys(globalThis.game?.system?.documentTypes?.Item);
  const runtimeEvidence = [...new Set([
    ...documentClassTypes,
    ...implementationTypes,
    ...systemDocumentTypes,
    ...configDataModels,
  ])].sort();
  const usedFallback = runtimeEvidence.length === 0;
  const registered = usedFallback
    ? [...FALLBACK.embeddedItemTypes]
    : runtimeEvidence;
  const authoritativeSource = documentClassTypes.length
    ? "CONFIG.Item.documentClass.TYPES"
    : implementationTypes.length
      ? "CONFIG.Item.documentClass.implementation.TYPES"
      : systemDocumentTypes.length
        ? "game.system.documentTypes.Item"
        : configDataModels.length
          ? "CONFIG.Item.dataModels (partial evidence)"
          : "module strict PF2e allow-list";

  return {
    authoritativeSource,
    configDataModels,
    documentClassTypes,
    implementationTypes,
    systemDocumentTypes,
    registered,
    usedFallback,
    dataModelsArePartial: configDataModels.length > 0
      && FALLBACK.embeddedItemTypes.some((type) => !configDataModels.includes(type)),
  };
}

function runtimeItemTypes() {
  return new Set(itemTypeRegistrySnapshot().registered);
}

function trustedCatalogClone(item) {
  const forge = item?.flags?.["pf2e-npc-forge"];
  return forge?.catalogClone === true || (typeof forge?.sourcePack === "string" && forge.sourcePack.length > 0);
}

function cleanDocumentMetadata(item, corrections) {
  for (const key of ["_id", "_stats", "folder", "ownership", "sort"]) delete item[key];
  delete item._forgeSourceUuid;
  delete item._forgeSourcePack;
  if (item.flags && typeof item.flags === "object") {
    if (Object.hasOwn(item.flags, "babele")) {
      delete item.flags.babele;
      corrections.push(`${item.name ?? "Item"}: служебные флаги Babele удалены из клона.`);
    }
    if (!Object.keys(item.flags).length) delete item.flags;
  }
}

function sanitizeCommonItem(item, corrections) {
  const system = item.system ??= {};
  const catalogClone = trustedCatalogClone(item);
  system.description = system.description && typeof system.description === "object"
    ? { gm: String(system.description.gm ?? ""), value: String(system.description.value ?? "") }
    : { gm: "", value: "" };
  system.rules = sanitizeRules(system.rules, corrections, item.name, {
    generated: item.flags?.["pf2e-npc-forge"]?.generated === true,
    trustedCatalog: catalogClone,
  });
  system.traits = system.traits && typeof system.traits === "object" ? system.traits : {};
  const traitConfig = TRAIT_CONFIG_BY_TYPE[item.type];
  const allowedTraits = traitConfig ? configKeys(traitConfig, []) : new Set();
  if (!catalogClone && allowedTraits.size) {
    system.traits.value = filtered(system.traits.value, allowedTraits, `${item.name}: признаки ${item.type}`, corrections);
  } else {
    system.traits.value = [...new Set(Array.isArray(system.traits.value) ? system.traits.value.map(String) : [])];
  }
  system.traits.otherTags = Array.isArray(system.traits.otherTags) ? system.traits.otherTags.map(String) : [];
  if ("rarity" in system.traits) {
    system.traits.rarity = FALLBACK.rarities.includes(system.traits.rarity) ? system.traits.rarity : "common";
  }
  if (system.level && typeof system.level === "object") {
    const level = Number(system.level.value);
    system.level.value = Number.isFinite(level) ? Math.max(0, Math.trunc(level)) : 0;
  }
  if ("quantity" in system) system.quantity = Math.max(1, Math.trunc(Number(system.quantity) || 1));
  const usages = configKeys("usages", []);
  if (!catalogClone && system.usage?.value && usages.size && !usages.has(String(system.usage.value))) {
    corrections.push(`${item.name}: неподдерживаемое использование «${system.usage.value}» очищено.`);
    system.usage.value = "held-in-one-hand";
  }
}

function sanitizeSpell(item, corrections) {
  const system = item.system ??= {};
  const traditions = configKeys("magicTraditions", FALLBACK.magicTraditions);
  system.traits ??= {};
  if (Array.isArray(system.traits.traditions)) {
    system.traits.traditions = filtered(system.traits.traditions, traditions, `${item.name}: традиции заклинания`, corrections);
  }
  const rank = Number(system.level?.value ?? 0);
  system.level = { ...(system.level ?? {}), value: Number.isFinite(rank) ? Math.max(0, Math.min(10, Math.trunc(rank))) : 0 };
  system.location = system.location && typeof system.location === "object" ? system.location : { value: null };
  if (system.location.value !== null && typeof system.location.value !== "string") {
    corrections.push(`${item.name}: некорректная привязка заклинания очищена.`);
    system.location.value = null;
  }
}

function sanitizePhysicalItem(item, corrections) {
  const system = item.system ??= {};
  if (["weapon", "armor", "shield"].includes(item.type)) {
    system.equipped = system.equipped && typeof system.equipped === "object" ? system.equipped : {};
    if (item.type === "weapon") {
      const categories = configKeys("weaponCategories", []);
      if (categories.size && !categories.has(String(system.category))) {
        corrections.push(`${item.name}: категория оружия «${system.category ?? "пусто"}» заменена на simple.`);
        system.category = "simple";
      }
      const groups = configKeys("weaponGroups", []);
      if (system.group && groups.size && !groups.has(String(system.group))) {
        corrections.push(`${item.name}: неподдерживаемая группа оружия очищена.`);
        system.group = null;
      }
    }
    if (item.type === "armor") {
      const categories = configKeys("armorCategories", []);
      if (categories.size && !categories.has(String(system.category))) {
        corrections.push(`${item.name}: категория брони «${system.category ?? "пусто"}» заменена на unarmored.`);
        system.category = "unarmored";
      }
    }
  }
}

function clone(source) {
  return typeof structuredClone === "function"
    ? structuredClone(source)
    : JSON.parse(JSON.stringify(source));
}

function choice(value, allowed, fallback, label, corrections, aliases = null) {
  const raw = value === null ? null : String(value ?? "");
  const normalized = aliases?.[raw] ?? raw;
  if (allowed.has(normalized)) return normalized;
  corrections.push(`${label}: значение «${raw || "пусто"}» заменено на «${fallback}».`);
  return fallback;
}

function filtered(values, allowed, label, corrections) {
  const result = [];
  for (const raw of Array.isArray(values) ? values : []) {
    const value = String(raw);
    if (allowed.has(value)) result.push(value);
    else corrections.push(`${label}: неподдерживаемый признак «${value}» удалён.`);
  }
  return [...new Set(result)];
}

function sanitizeRules(rules, corrections, itemName, { generated = false, trustedCatalog = false } = {}) {
  const result = [];
  for (const rawRule of Array.isArray(rules) ? rules : []) {
    if (!rawRule || typeof rawRule !== "object") {
      corrections.push(`${itemName}: пустой Rule Element удалён.`);
      continue;
    }
    const rule = clone(rawRule);
    if (trustedCatalog) {
      result.push(rule);
      continue;
    }
    if (rule.key === "FlatModifier") {
      const selectors = Array.isArray(rule.selector) ? rule.selector : [rule.selector];
      if (!selectors.some((selector) => typeof selector === "string" && selector.trim())) {
        corrections.push(`${itemName}: FlatModifier без selector удалён.`);
        continue;
      }
      if (!Number.isFinite(Number(rule.value))) {
        corrections.push(`${itemName}: FlatModifier с нечисловым value удалён.`);
        continue;
      }
      rule.value = Number(rule.value);
    } else if (rule.key === "RollOption") {
      if (typeof rule.domain !== "string" || !rule.domain.trim() || typeof rule.option !== "string" || !rule.option.trim()) {
        corrections.push(`${itemName}: некорректный RollOption удалён.`);
        continue;
      }
      rule.toggleable = Boolean(rule.toggleable);
    } else if (generated) {
      corrections.push(`${itemName}: неподдерживаемый внутренний Rule Element «${rule.key ?? "пусто"}» удалён.`);
      continue;
    }
    result.push(rule);
  }
  return result;
}

export function normalizeActionCategory(category, fallback = "interaction") {
  if (category === null) return null;
  const allowed = configKeys("actionCategories", FALLBACK.actionCategories);
  const raw = String(category ?? "");
  const normalized = ACTION_CATEGORY_ALIASES[raw] ?? raw;
  return allowed.has(normalized) ? normalized : fallback;
}

function sanitizeAction(item, corrections) {
  const system = item.system ??= {};
  const actionTypes = configKeys("actionTypes", FALLBACK.actionTypes);
  const categories = configKeys("actionCategories", FALLBACK.actionCategories);
  const actionTraits = configKeys("actionTraits", []);
  const type = choice(
    system.actionType?.value,
    actionTypes,
    "passive",
    `${item.name}: тип действия`,
    corrections,
  );
  system.actionType = { ...(system.actionType ?? {}), value: type };
  const rawCategory = ACTION_CATEGORY_ALIASES[String(system.category ?? "")] ?? String(system.category ?? "");
  system.category = choice(
    rawCategory,
    categories,
    "interaction",
    `${item.name}: категория действия`,
    corrections,
  );
  if (type === "action") {
    const raw = Number(system.actions?.value ?? 1);
    const valid = configKeys("actionsNumber", FALLBACK.actionsNumber);
    const value = valid.has(String(raw)) ? raw : 1;
    if (value !== raw) corrections.push(`${item.name}: число действий «${raw}» заменено на 1.`);
    system.actions = { ...(system.actions ?? {}), value };
  } else {
    system.actions = { ...(system.actions ?? {}), value: null };
  }
  system.traits ??= {};
  if (actionTraits.size) {
    system.traits.value = filtered(system.traits.value, actionTraits, `${item.name}: признаки action`, corrections);
  } else {
    system.traits.value = [...new Set(Array.isArray(system.traits.value) ? system.traits.value.map(String) : [])];
  }
  system.traits.otherTags = Array.isArray(system.traits.otherTags) ? system.traits.otherTags : [];
}

function sanitizeMelee(item, corrections) {
  const system = item.system ??= {};
  const damageTypes = configKeys("damageTypes", FALLBACK.damageTypes);
  const damageCategories = configKeys("damageCategories", FALLBACK.damageCategories);
  const attackTraits = configKeys("npcAttackTraits", []);
  system.action = "strike";
  system.subjectToMAP = system.subjectToMAP !== false;
  system.traits ??= {};
  if (attackTraits.size) {
    system.traits.value = filtered(system.traits.value, attackTraits, `${item.name}: признаки удара`, corrections);
  } else {
    system.traits.value = [...new Set(Array.isArray(system.traits.value) ? system.traits.value.map(String) : [])];
  }
  system.traits.otherTags = Array.isArray(system.traits.otherTags) ? system.traits.otherTags : [];
  system.traits.config = system.traits.config && typeof system.traits.config === "object" ? system.traits.config : {};
  system.damageRolls = system.damageRolls && typeof system.damageRolls === "object" ? system.damageRolls : {};
  for (const [key, rawRoll] of Object.entries(system.damageRolls)) {
    const roll = rawRoll && typeof rawRoll === "object" ? rawRoll : {};
    roll.damage = String(roll.damage || "1d4");
    roll.damageType = choice(
      roll.damageType,
      damageTypes,
      "untyped",
      `${item.name}: тип урона`,
      corrections,
    );
    if (roll.category !== null && roll.category !== undefined && roll.category !== "") {
      roll.category = choice(
        roll.category,
        damageCategories,
        null,
        `${item.name}: категория урона`,
        corrections,
      );
    } else {
      roll.category = null;
    }
    system.damageRolls[key] = roll;
  }
  if (system.range !== null && system.range !== undefined) {
    const increment = Number(system.range?.increment);
    system.range = Number.isFinite(increment) && increment > 0
      ? { increment, max: null }
      : null;
    if (!system.range) corrections.push(`${item.name}: некорректная дальность удалена.`);
  }
}

function sanitizeSpellcastingEntry(item, corrections) {
  const system = item.system ??= {};
  const abilities = new Set(FALLBACK.abilities);
  const traditions = configKeys("magicTraditions", FALLBACK.magicTraditions);
  const prepared = new Set(FALLBACK.preparedTypes);
  system.ability = {
    ...(system.ability ?? {}),
    value: choice(system.ability?.value, abilities, "cha", `${item.name}: ключевая характеристика`, corrections),
  };
  system.tradition = {
    ...(system.tradition ?? {}),
    value: choice(system.tradition?.value, traditions, "arcane", `${item.name}: традиция`, corrections),
  };
  system.prepared = {
    ...(system.prepared ?? {}),
    value: choice(system.prepared?.value, prepared, "innate", `${item.name}: тип подготовки`, corrections),
    flexible: Boolean(system.prepared?.flexible),
  };
  system.showSlotlessLevels = { value: Boolean(system.showSlotlessLevels?.value) };
  const proficiency = Number(system.proficiency?.value ?? 0);
  system.proficiency = { value: Number.isInteger(proficiency) && proficiency >= 0 && proficiency <= 4 ? proficiency : 0 };
}

export function sanitizePf2eItemSource(source) {
  const item = clone(source);
  const corrections = [];
  if (!item || typeof item !== "object" || typeof item.type !== "string") {
    throw new Error("Кузница подготовила некорректный источник Item.");
  }
  if (!FALLBACK.embeddedItemTypes.includes(item.type)) {
    throw new Error(`Кузница отказалась встраивать неподдерживаемый тип Item «${item.type}».`);
  }
  const registry = itemTypeRegistrySnapshot();
  const registered = runtimeItemTypes();
  // The module's strict embedded allow-list above defines what the generator is
  // permitted to create. Runtime registries are advisory only: PF2e can expose
  // shared-model physical items outside CONFIG.Item.dataModels. The real final
  // authority is the PF2e document constructor/createEmbeddedDocuments call.
  if (!registered.has(item.type)) {
    corrections.push(
      `${item.name ?? item.type}: runtime-реестры не перечислили тип «${item.type}»; `
      + `тип разрешён строгим allow-list Кузницы и будет физически проверен PF2e при создании.`,
    );
  }
  cleanDocumentMetadata(item, corrections);
  item.system = item.system && typeof item.system === "object" ? item.system : {};
  sanitizeCommonItem(item, corrections);
  if (item.type === "action") sanitizeAction(item, corrections);
  else if (item.type === "melee") sanitizeMelee(item, corrections);
  else if (item.type === "spellcastingEntry") sanitizeSpellcastingEntry(item, corrections);
  else if (item.type === "spell") sanitizeSpell(item, corrections);
  else sanitizePhysicalItem(item, corrections);
  return { source: item, corrections };
}

export function sanitizePf2eItemSources(sources = []) {
  const corrections = [];
  const result = (Array.isArray(sources) ? sources : []).map((source) => {
    const checked = sanitizePf2eItemSource(source);
    corrections.push(...checked.corrections);
    return checked.source;
  });
  return { sources: result, corrections };
}

export function sanitizeNpcSystem(source) {
  const system = clone(source);
  const corrections = [];
  const sizes = configKeys("actorSizes", FALLBACK.actorSizes);
  const creatureTraits = configKeys("creatureTraits", []);
  const languages = configKeys("languages", []);
  const senses = configKeys("senses", []);
  const senseAcuities = configKeys("senseAcuities", []);
  const skills = configKeys("skills", []);
  const immunityTypes = configKeys("immunityTypes", []);
  const resistanceTypes = configKeys("resistanceTypes", []);
  const weaknessTypes = configKeys("weaknessTypes", []);

  system.traits ??= {};
  system.traits.size = {
    ...(system.traits.size ?? {}),
    value: choice(system.traits.size?.value, sizes, "med", "Размер NPC", corrections),
  };
  system.traits.rarity = FALLBACK.rarities.includes(system.traits.rarity) ? system.traits.rarity : "common";
  if (creatureTraits.size) system.traits.value = filtered(system.traits.value, creatureTraits, "Признаки NPC", corrections);

  system.details ??= {};
  system.details.languages ??= { details: "", value: [] };
  if (languages.size) system.details.languages.value = filtered(system.details.languages.value, languages, "Языки NPC", corrections);

  system.perception ??= {};
  if (senses.size) {
    system.perception.senses = (Array.isArray(system.perception.senses) ? system.perception.senses : [])
      .filter((sense) => {
        const valid = sense && senses.has(String(sense.type));
        if (!valid) corrections.push(`Чувство NPC «${sense?.type ?? "пусто"}» удалено.`);
        return valid;
      })
      .map((sense) => ({
        ...sense,
        acuity: senseAcuities.size && !senseAcuities.has(String(sense.acuity)) ? "precise" : sense.acuity,
        range: Number.isFinite(Number(sense.range)) ? Number(sense.range) : null,
      }));
  }

  system.skills = system.skills && typeof system.skills === "object" ? system.skills : {};
  if (skills.size) {
    for (const key of Object.keys(system.skills)) {
      if (!skills.has(key)) {
        delete system.skills[key];
        corrections.push(`Навык NPC «${key}» удалён: система его не зарегистрировала.`);
      }
    }
  }
  const initiative = String(system.initiative?.statistic ?? "perception");
  if (initiative !== "perception" && !Object.hasOwn(system.skills, initiative)) {
    system.initiative = { ...(system.initiative ?? {}), statistic: "perception" };
    corrections.push(`Инициатива «${initiative}» заменена на Восприятие.`);
  }

  system.attributes ??= {};
  const cleanIwr = (key, allowed, requireValue) => {
    if (!allowed.size) return;
    system.attributes[key] = (Array.isArray(system.attributes[key]) ? system.attributes[key] : [])
      .filter((entry) => {
        const valid = entry && allowed.has(String(entry.type));
        if (!valid) corrections.push(`${key}: неподдерживаемый тип «${entry?.type ?? "пусто"}» удалён.`);
        return valid;
      })
      .map((entry) => requireValue
        ? { ...entry, value: Math.max(0, Number(entry.value) || 0) }
        : { ...entry });
  };
  cleanIwr("immunities", immunityTypes, false);
  cleanIwr("resistances", resistanceTypes, true);
  cleanIwr("weaknesses", weaknessTypes, true);

  const otherSpeeds = Array.isArray(system.attributes.speed?.otherSpeeds) ? system.attributes.speed.otherSpeeds : [];
  system.attributes.speed ??= { value: 25, otherSpeeds: [] };
  system.attributes.speed.otherSpeeds = otherSpeeds.filter((speed) => {
    const valid = speed && FALLBACK.movementTypes.includes(String(speed.type)) && Number.isFinite(Number(speed.value));
    if (!valid) corrections.push(`Дополнительная Скорость «${speed?.type ?? "пусто"}» удалена.`);
    return valid;
  });

  return { system, corrections };
}
