import { SKILL_LABELS, WEAPONS } from "./blueprints.js";

const SKILL_SLUGS = new Set(Object.keys(SKILL_LABELS));

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function signed(value) {
  return Number(value) >= 0 ? `+${Number(value)}` : String(Number(value));
}

function checkOptions({ dc = null, name = null, defense = null, traits = [] } = {}) {
  const options = [];
  if (Number.isFinite(Number(dc))) options.push(`dc:${Number(dc)}`);
  if (defense) options.push(`defense:${defense}`);
  if (name) options.push(`name:${String(name).replaceAll("|", "/")}`);
  if (traits.length) options.push(`traits:${traits.join(",")}`);
  return options;
}

/**
 * PF2e inline checks use the owning Actor as roll context. This means the value
 * from system.skills.<slug>.base and all applicable Rule Elements are included.
 */
export function inlineSkillCheck(skill, label, options = {}) {
  const suffix = checkOptions(options);
  return `@Check[${skill}${suffix.length ? `|${suffix.join("|")}` : ""}]{${escapeHtml(label)}}`;
}

export function skillCheckPanelSpec(concept, skills = {}) {
  const rows = Object.entries(skills)
    .filter(([slug, data]) => SKILL_SLUGS.has(slug) && Number.isFinite(Number(data?.base)))
    .sort((left, right) => Number(right[1].base) - Number(left[1].base));

  if (!rows.length) return null;
  const links = rows.map(([slug, data]) => {
    const label = `${SKILL_LABELS[slug] ?? slug} ${signed(data.base)}`;
    return `<li>${inlineSkillCheck(slug, label, { name: `${concept.name}: ${SKILL_LABELS[slug] ?? slug}` })}</li>`;
  });

  return {
    name: "Рабочие проверки навыков",
    slug: "forge-working-skill-checks",
    actionType: "passive",
    actions: null,
    category: "interaction",
    traits: [],
    automation: "full",
    description: [
      "<p><strong>Эти кнопки используют настоящий модификатор навыка с листа NPC.</strong> Бросок не является голым d20: PF2e берёт значение из <code>system.skills</code> и добавляет подходящие Rule Elements.</p>",
      `<ul>${links.join("")}</ul>`,
    ].join(""),
    rules: [],
  };
}

function treatmentRow(skillMod, dc, healing, rankLabel) {
  const name = `Лечить раны — ${rankLabel}, КС ${dc}`;
  const check = inlineSkillCheck("medicine", `Медицина ${signed(skillMod)} против КС ${dc}`, {
    dc,
    name,
    traits: ["healing", "manipulate"],
  });
  return `<li><strong>${escapeHtml(rankLabel)}:</strong> ${check}; при успехе @Damage[${healing}[healing]] ОЗ, при критическом успехе удвой лечение.</li>`;
}

export function medicalProcedureSpec(concept, skills = {}) {
  const medicine = Number(skills.medicine?.base);
  if (!Number.isFinite(medicine)) return null;

  const rows = [
    treatmentRow(medicine, 15, "2d8", "обученный"),
    treatmentRow(medicine, 20, "2d8+10", "эксперт"),
    treatmentRow(medicine, 30, "2d8+30", "мастер"),
    treatmentRow(medicine, 40, "2d8+50", "легенда"),
  ];
  const stabilize = inlineSkillCheck("medicine", `Стабилизировать: Медицина ${signed(medicine)}`, {
    dc: 15,
    name: `${concept.name}: Стабилизировать`,
    traits: ["healing", "manipulate"],
  });
  const stopBleeding = inlineSkillCheck("medicine", `Остановить кровотечение: Медицина ${signed(medicine)}`, {
    dc: 15,
    name: `${concept.name}: Остановить кровотечение`,
    traits: ["healing", "manipulate"],
  });

  return {
    name: "Медицинские процедуры — рабочие броски",
    slug: "forge-working-medicine-procedures",
    actionType: "passive",
    actions: null,
    category: "interaction",
    traits: ["healing", "manipulate"],
    automation: "full",
    description: [
      `<p><strong>Модификатор Медицины на листе: ${signed(medicine)}.</strong> Все ссылки ниже совершают проверку именно этим NPC и включают его модификатор навыка вместе с работающими бонусами от Rule Elements.</p>`,
      "<h4>Лечить раны</h4>",
      `<ul>${rows.join("")}</ul>`,
      "<p>После попытки цель получает обычную временную невосприимчивость к Лечить раны. Ранг владения NPC-существа явно не хранится в навыке, поэтому ведущий выбирает допустимую строку по концепту персонажа.</p>",
      "<h4>Оказать первую помощь</h4>",
      `<ul><li>${stabilize}</li><li>${stopBleeding}</li></ul>`,
      "<p><strong>Боевая медицина:</strong> используй ту же строку КС и лечения, но с обычной суточной невосприимчивостью цели.</p>",
    ].join(""),
    rules: [],
  };
}

function selectorList(rule) {
  const selector = rule?.selector;
  if (Array.isArray(selector)) return selector.map(String);
  return selector ? [String(selector)] : [];
}

function checkSlugs(description) {
  return [...String(description ?? "").matchAll(/@Check\[([a-z-]+)/giu)].map((match) => match[1]);
}

function describedSkills(description) {
  const text = String(description ?? "").toLowerCase();
  return Object.entries(SKILL_LABELS)
    .filter(([, label]) => text.includes(String(label).toLowerCase()))
    .map(([slug]) => slug);
}

export function auditAutomation({ concept, skills = {}, featureSpecs = [] } = {}) {
  const findings = [];
  let full = 0;
  let partial = 0;
  let manual = 0;

  for (const feature of featureSpecs.filter(Boolean)) {
    const description = feature.description ?? feature.system?.description?.value ?? "";
    const rules = feature.rules ?? feature.system?.rules ?? [];
    const checks = checkSlugs(description);
    const flatSelectors = rules
      .filter((rule) => rule?.key === "FlatModifier")
      .flatMap(selectorList);
    const numericBonus = /(?:бонус|штраф)[^<.]{0,120}[+−-]\d/iu.test(description);
    const skillMentions = describedSkills(description);
    const promisedSkillBonus = numericBonus && skillMentions.length > 0;
    const coveredSkills = skillMentions.filter(
      (skill) => checks.includes(skill) || flatSelectors.includes(skill),
    );

    if (feature.automation === "full" || checks.length || rules.length) full += 1;
    else if (feature.automation === "partial") partial += 1;
    else manual += 1;

    for (const skill of checks.filter((candidate) => SKILL_SLUGS.has(candidate))) {
      if (!skills[skill]) {
        findings.push({
          severity: "error",
          code: "missing-inline-skill",
          feature: feature.name,
          message: `Кнопка «${feature.name}» вызывает ${SKILL_LABELS[skill] ?? skill}, которого нет на листе.`,
        });
      }
    }

    if ((feature.actionType ?? feature.system?.actionType?.value) === "passive" && promisedSkillBonus && coveredSkills.length < skillMentions.length) {
      const missing = skillMentions.filter((skill) => !coveredSkills.includes(skill));
      findings.push({
        severity: "warning",
        code: "decorative-skill-bonus",
        feature: feature.name,
        message: `В описании «${feature.name}» заявлен числовой бонус к ${missing.map((skill) => SKILL_LABELS[skill] ?? skill).join(", ")}, но нет соответствующего FlatModifier или рабочей кнопки проверки.`,
      });
    }
  }

  const healer = concept?.profession === "doctor" || concept?.role === "healer";
  if (healer) {
    if (!skills.medicine) {
      findings.push({
        severity: "error",
        code: "healer-without-medicine",
        message: "Лекарь создан без навыка Медицины.",
      });
    }
    const descriptions = featureSpecs.map((feature) => feature?.description ?? "").join("\n");
    if (!/@Check\[medicine(?:\||\])/u.test(descriptions)) {
      findings.push({
        severity: "error",
        code: "medicine-without-working-roll",
        message: "Лекарь не получил рабочую кнопку проверки Медицины с контекстом Actor.",
      });
    }
  }

  const errors = findings.filter((finding) => finding.severity === "error").length;
  const warnings = findings.filter((finding) => finding.severity === "warning").length;
  const score = Math.max(0, 100 - errors * 30 - warnings * 8);
  return {
    score,
    grade: errors ? "есть критические разрывы" : warnings ? "частично автоматизировано" : "проверяемая автоматизация",
    counts: { full, partial, manual },
    findings,
  };
}

function reloadValue(weapon) {
  const trait = (weapon?.traits ?? []).find((value) => /^reload-/u.test(value));
  if (!trait) return 0;
  const value = Number(trait.split("-")[1]);
  return Number.isFinite(value) ? value : 1;
}

export function actionEconomyPlan(concept, featureSpecs = []) {
  const weapon = WEAPONS[concept.weapon];
  const reload = reloadValue(weapon);
  const twoHanded = Boolean(weapon?.twoHanded) || (weapon?.traits ?? []).some((trait) => /^two-hand/u.test(trait));
  const hasShield = (weapon?.extraGear ?? []).includes("steel-shield");
  const actions = featureSpecs
    .filter((feature) => feature?.actionType === "action")
    .map((feature) => ({ name: feature.name, cost: Math.max(1, Number(feature.actions) || 1) }));

  const preferred = actions.find((entry) => entry.cost === 2) ?? actions[0] ?? null;
  const oneAction = actions.find((entry) => entry.cost === 1 && entry !== preferred) ?? null;
  const firstTurn = preferred
    ? `${preferred.name} (${preferred.cost})${preferred.cost < 3 ? ` → ${oneAction?.name ?? (reload ? "Перезарядить" : "Шаг или основная проверка")} (1)` : ""}`
    : reload
      ? "Выстрел (1) → Перезарядить (1) → Шаг или Искать (1)"
      : "Основной Удар (1) → яркая способность или перемещение (2)";
  const routine = reload
    ? `Выстрел (1) → Перезарядить (${reload})${reload < 2 ? " → Шаг, Искать или укрыться (1)" : ""}`
    : preferred
      ? `${preferred.name} (${preferred.cost}) → ${preferred.cost === 2 ? (oneAction?.name ?? "Шаг или основная проверка") : "основной Удар"} (${3 - Math.min(2, preferred.cost)})`
      : "Основной Удар → перемещение → подходящее третье действие";

  const issues = [];
  if (twoHanded && hasShield) {
    issues.push("Двуручное оружие и щит нельзя использовать одновременно: переключение между ними требует освободить руки.");
  }
  if (reload >= 2) {
    issues.push(`Оружие требует ${reload} действий перезарядки; без укрытия каждый второй ход заметно слабее.`);
  }
  if (actions.some((entry) => entry.cost > 3)) {
    issues.push("Найдена способность дороже трёх действий.");
  }
  const hasThirdAction = actions.some((entry) => entry.cost === 1) || reload === 1 || !reload;
  if (!hasThirdAction) issues.push("У NPC нет очевидного третьего действия после основной комбинации.");

  return {
    firstTurn,
    routine,
    reload,
    twoHanded,
    hasShield,
    issues,
    status: issues.length ? "требует внимания" : "укладывается в три действия",
  };
}
