/**
 * Живая библиотека документов Foundry.
 *
 * Кузница больше не привязана к одному компендиуму: она умеет безопасно
 * искать документы в PF2e и SF2e Anachronism, сохраняя источник и обходя
 * неподдерживаемые типы документов.
 */

export const CONTENT_SOURCES = {
  auto: { label: "Автоматически по концепту" },
  pf2e: { label: "Только классический PF2e" },
  mixed: { label: "Смешивать PF2e и SF2e" },
  sf2e: { label: "Приоритет SF2e Anachronism" },
};

export const TECHNOLOGY_LEVELS = {
  fantasy: { label: "Классическое фэнтези" },
  blackpowder: { label: "Порох и раннее огнестрельное" },
  magitech: { label: "Магитех" },
  starfinder: { label: "Высокие технологии SF2e" },
};

export const CATALOG_PACKS = {
  equipment: {
    pf2e: "pf2e.equipment-srd",
    sf2e: "sf2e-anachronism.equipment",
  },
  spells: {
    pf2e: "pf2e.spells-srd",
    sf2e: "sf2e-anachronism.spells",
  },
  actions: {
    pf2e: "pf2e.actionspf2e",
  },
};

export const UNSUPPORTED_EMBEDDED_TYPES = new Set([
  "ancestry",
  "background",
  "class",
  "deity",
  "heritage",
  "kit",
]);

const INDEX_CACHE = new Map();
const SOURCE_CACHE = new Map();

function clone(value) {
  return typeof structuredClone === "function"
    ? structuredClone(value)
    : JSON.parse(JSON.stringify(value));
}

function cleanCandidates(candidates) {
  return (Array.isArray(candidates) ? candidates : [candidates])
    .filter(Boolean)
    .map((value) => String(value).trim().toLowerCase())
    .filter(Boolean);
}

function isTechConcept(concept = {}) {
  return (
    concept.technology === "starfinder" ||
    concept.technology === "magitech" ||
    [
      "engineer",
      "mercenary",
      "operative",
      "technomancer",
      "mystic",
      "pilot",
    ].includes(concept.profession) ||
    [
      "laserPistol",
      "laserRifle",
      "arcRifle",
      "plasmaCaster",
      "scattergun",
      "plasmaSword",
      "shockTruncheon",
      "semiAutoPistol",
    ].includes(concept.weapon)
  );
}

export function catalogPackOrder(kind, concept = {}) {
  const packs = CATALOG_PACKS[kind] ?? {};
  const source = CONTENT_SOURCES[concept.contentSource]
    ? concept.contentSource
    : "auto";

  if (kind === "actions") return [packs.pf2e].filter(Boolean);
  if (source === "pf2e") return [packs.pf2e].filter(Boolean);
  if (source === "sf2e") return [packs.sf2e, packs.pf2e].filter(Boolean);
  if (source === "mixed") {
    return isTechConcept(concept)
      ? [packs.sf2e, packs.pf2e].filter(Boolean)
      : [packs.pf2e, packs.sf2e].filter(Boolean);
  }
  return isTechConcept(concept)
    ? [packs.sf2e, packs.pf2e].filter(Boolean)
    : [packs.pf2e, packs.sf2e].filter(Boolean);
}

async function packIndex(packId) {
  if (INDEX_CACHE.has(packId)) return INDEX_CACHE.get(packId);
  const pack = game.packs.get(packId);
  if (!pack) return null;
  const index = await pack.getIndex({
    fields: [
      "system.slug",
      "system.level.value",
      "system.traits.value",
      "system.traits.traditions",
      "system.category",
      "system.group",
      "type",
    ],
  });
  INDEX_CACHE.set(packId, index);
  return index;
}

function entryMatches(entry, wanted, allowedTypes) {
  if (allowedTypes?.size && entry.type && !allowedTypes.has(entry.type)) return false;
  const values = [entry.system?.slug, entry.slug, entry.name]
    .filter(Boolean)
    .map((value) => String(value).toLowerCase());
  return values.some((value) => wanted.includes(value));
}

function stripDocumentSource(data, packId, entry) {
  const source = clone(data);
  source._forgeSourceUuid = `Compendium.${packId}.Item.${entry._id}`;
  source._forgeSourcePack = packId;
  delete source._id;
  delete source.folder;
  delete source.ownership;
  delete source._stats;
  delete source.sort;
  if (source.flags && typeof source.flags === "object") {
    // Переведённый текст уже находится в клоне. Служебные флаги Babele не
    // переносятся в Actor, чтобы переводчик не пытался повторно обрабатывать
    // embedded-документ и не затрагивал чужие листы.
    delete source.flags.babele;
    if (!Object.keys(source.flags).length) delete source.flags;
  }
  return source;
}

/**
 * Возвращает клон документа или null. При required=true выбрасывает понятную
 * ошибку только после проверки всех допустимых компендиумов.
 */
export async function cloneCatalogDocument(
  kind,
  candidates,
  concept = {},
  {
    allowedTypes = null,
    required = false,
    preferredPack = null,
  } = {},
) {
  const wanted = cleanCandidates(candidates);
  if (!wanted.length) return null;
  const typeSet = allowedTypes
    ? new Set(Array.isArray(allowedTypes) ? allowedTypes : [allowedTypes])
    : null;
  const order = [
    ...(preferredPack ? [preferredPack] : []),
    ...catalogPackOrder(kind, concept),
  ].filter((value, index, values) => value && values.indexOf(value) === index);
  const errors = [];

  for (const packId of order) {
    const pack = game.packs.get(packId);
    if (!pack) continue;
    let index;
    try {
      index = await packIndex(packId);
    } catch (error) {
      errors.push(`${packId}: индекс — ${error.message}`);
      continue;
    }
    const entry = index?.find((candidate) => entryMatches(candidate, wanted, typeSet));
    if (!entry) continue;

    const cacheKey = `${packId}:${entry._id}`;
    let cached = SOURCE_CACHE.get(cacheKey);
    if (!cached) {
      try {
        const document = await pack.getDocument(entry._id);
        if (!document) continue;
        cached = document.toObject();
        SOURCE_CACHE.set(cacheKey, cached);
      } catch (error) {
        // Babele и другие переводчики иногда ломают один документ. Это не
        // должно останавливать поиск в следующем компендиуме.
        errors.push(`${packId}:${entry.name} — ${error.message}`);
        continue;
      }
    }

    const source = stripDocumentSource(cached, packId, entry);
    if (typeSet?.size && !typeSet.has(source.type)) continue;
    return source;
  }

  if (required) {
    const details = errors.length ? ` Ошибки чтения: ${errors.join("; ")}.` : "";
    throw new Error(
      `Документ «${wanted.join(" / ")}» не найден в доступных сборниках ${order.join(", ")}.${details}`,
    );
  }
  return null;
}

export async function catalogAvailability() {
  const rows = [];
  for (const [kind, sources] of Object.entries(CATALOG_PACKS)) {
    for (const [source, packId] of Object.entries(sources)) {
      const pack = game.packs.get(packId);
      rows.push({
        kind,
        source,
        packId,
        available: Boolean(pack),
        label: pack?.metadata?.label ?? pack?.title ?? packId,
      });
    }
  }
  return rows;
}

export function supportedEmbeddedType(type) {
  return Boolean(type) && !UNSUPPORTED_EMBEDDED_TYPES.has(type);
}

export function clearCatalogCaches() {
  INDEX_CACHE.clear();
  SOURCE_CACHE.clear();
}
