import { runDiagnostics } from "./diagnostics.js";
import { itemTypeRegistrySnapshot } from "./schema-guard.js";
import { generateNpc, generateNpcBatch, getPreview, MODULE_ID, restoreFromHistoryEntry } from "./generator.js";
import { parseConcept } from "./parser.js";
import { BUILTIN_PRESETS, completePresetValues } from "./presets.js";
import { randomFormValues, randomSeed } from "./randomizer.js";
import { CREATURE_KINDS, MONSTER_FAMILIES, randomMonsterFormValues } from "./monsters.js";
import { createEncounterBriefing } from "./briefing.js";
import { CONTENT_SOURCES, TECHNOLOGY_LEVELS, catalogAvailability } from "./catalog.js";

import { ANCESTRIES, ARMORS, PROFESSIONS, ROLES, WEAPONS } from "./blueprints.js";
import { ADVENTURE_MODES, LOOT_RICHNESS, MONSTER_TEMPLATES } from "./director.js";
import { DEPLOYMENT_MODES, deployActorsToScene } from "./deployment.js";
import { ENCOUNTER_DIFFICULTIES } from "./encounters.js";
import { SPELL_THEME_LABELS } from "./random-content.js";
import {
  addRecentHistory,
  deleteCustomPreset,
  exportCustomPresets,
  getCustomPresets,
  getLastAuditReportMeta,
  getLastForm,
  getRecentHistory,
  importCustomPresets,
  saveCustomPreset,
  setLastAuditReportMeta,
  setLastForm,
} from "./storage.js";

export const SESSION_AUDIT_FORMAT = "pf2e-npc-forge-session-audit";
export const SESSION_AUDIT_VERSION = 5;

const RELEVANT_PACKS = [
  "pf2e.equipment-srd",
  "pf2e.actionspf2e",
  "pf2e.spells-srd",
  "sf2e-anachronism.equipment",
  "sf2e-anachronism.spells",
];

export const DEFAULT_SESSION_AUDIT_OPTIONS = Object.freeze({
  liveActorCreation: true,
  testUiControls: true,
  testOptionMatrix: true,
  liveOptionMatrixCreation: true,
  randomLiveCases: 12,
  testSelectedWorkflows: true,
  testDeploymentModes: true,
  testStorageRoundTrip: true,
  testChatMessage: true,
  scanAllPackIndexes: true,
  testBatchCreation: true,
  testTemporaryJournal: true,
  testTemporaryScene: true,
  testTemporaryMacro: true,
  scanWorldActors: true,
  scanCompendiums: true,
  deepCompendiumScan: true,
  maxDocumentsPerPack: 0,
  cleanup: true,
  seed: "pf2e-npc-forge-session-audit",
});

function now() {
  return Date.now();
}

function duration(startedAt) {
  return Math.max(0, now() - startedAt);
}

function stringValue(value) {
  try {
    if (typeof value === "string") return value;
    if (value instanceof Error) return value.message;
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

export function serializeAuditError(error) {
  return {
    name: error?.name ?? "Error",
    message: error?.message ?? String(error),
    stack: String(error?.stack ?? "").split("\n").slice(0, 20).join("\n"),
  };
}

function compactSource(document) {
  return {
    id: document?.id ?? document?._id ?? null,
    uuid: document?.uuid ?? null,
    name: document?.name ?? null,
    type: document?.type ?? null,
  };
}

function moduleVersion() {
  return game.modules?.get?.(MODULE_ID)?.version ?? null;
}

function environmentSnapshot() {
  const navigatorData = globalThis.navigator ?? {};
  const modulePackage = game.modules?.get?.(MODULE_ID) ?? null;
  return {
    foundry: game.version ?? null,
    system: { id: game.system?.id ?? null, version: game.system?.version ?? null },
    module: {
      id: MODULE_ID,
      version: moduleVersion(),
      persistentStorage: modulePackage?.persistentStorage ?? modulePackage?._source?.persistentStorage ?? null,
      hasStorage: modulePackage?.hasStorage ?? null,
    },
    world: { id: game.world?.id ?? null, title: game.world?.title ?? null },
    user: { id: game.user?.id ?? null, isGM: game.user?.isGM === true },
    browser: {
      userAgent: navigatorData.userAgent ?? null,
      language: navigatorData.language ?? null,
      viewport: { width: globalThis.innerWidth ?? null, height: globalThis.innerHeight ?? null },
    },
    activeScene: globalThis.canvas?.scene
      ? { id: globalThis.canvas.scene.id, name: globalThis.canvas.scene.name, grid: globalThis.canvas.scene.grid?.size ?? null }
      : null,
    activeModules: [...(game.modules?.values?.() ?? [])]
      .filter((entry) => entry.active)
      .map((entry) => ({ id: entry.id, title: entry.title, version: entry.version }))
      .sort((left, right) => left.id.localeCompare(right.id)),
  };
}

function schemaSnapshot() {
  const keys = [
    "actionCategories", "actionTypes", "actionsNumber", "actionTraits", "npcAttackTraits",
    "damageTypes", "damageCategories", "creatureTraits", "languages", "senses",
    "skills", "spellTraditions", "preparationType", "proficiencyLevels", "sizes",
    "immunityTypes", "resistanceTypes", "weaknessTypes", "speedTypes",
  ];
  return {
    ...Object.fromEntries(keys.map((key) => {
      const value = globalThis.CONFIG?.PF2E?.[key];
      if (!value) return [key, []];
      if (value instanceof Map) return [key, [...value.keys()]];
      if (Array.isArray(value)) return [key, [...value]];
      return [key, Object.keys(value)];
    })),
    itemTypes: itemTypeRegistrySnapshot(),
  };
}

function createReport(options) {
  return {
    format: SESSION_AUDIT_FORMAT,
    formatVersion: SESSION_AUDIT_VERSION,
    createdAt: new Date().toISOString(),
    finishedAt: null,
    status: "running",
    options,
    environment: environmentSnapshot(),
    schema: schemaSnapshot(),
    summary: { passed: 0, warnings: 0, failed: 0, skipped: 0, durationMs: 0 },
    coverage: [],
    steps: [],
    issues: [],
    observations: [],
    issueGroups: [],
    uiControls: null,
    optionMatrix: [],
    randomCases: [],
    selectedWorkflows: [],
    deployment: [],
    storageRoundTrip: null,
    moduleFiles: [],
    allPackIndexes: [],
    presets: [],
    batches: [],
    packs: [],
    worldScan: null,
    captured: { console: [], notifications: [], windowErrors: [] },
    cleanup: [],
    recommendations: [],
  };
}

function issue(report, severity, code, message, context = {}) {
  const entry = {
    severity,
    code,
    message: String(message),
    context,
    at: new Date().toISOString(),
  };
  report.issues.push(entry);
  if (severity === "error") report.summary.failed += 1;
  else if (severity === "warning") report.summary.warnings += 1;
  return entry;
}

function observation(report, code, message, context = {}) {
  const entry = {
    severity: "info",
    code,
    message: String(message),
    context,
    at: new Date().toISOString(),
  };
  report.observations.push(entry);
  return entry;
}

function actionableGenerationWarning(message) {
  const text = String(message ?? "");
  return [
    /не найден/u,
    /не прочитан/u,
    /не удалось/u,
    /отклон/u,
    /памятк/u,
    /Rule Element/u,
    /RollOption/u,
    /неподдерживаемый признак/u,
    /неподдерживаемое использование/u,
    /категория действия: значение/u,
    /runtime-реестры не перечислили/u,
    /служебные флаги Babele/u,
  ].some((pattern) => pattern.test(text));
}

function recordGenerationWarning(report, code, message, context = {}) {
  return actionableGenerationWarning(message)
    ? issue(report, "warning", code, message, context)
    : observation(report, code, message, context);
}

function assertNotAborted(signal) {
  if (signal?.aborted) {
    const error = new Error("Проверка остановлена пользователем.");
    error.name = "AbortError";
    throw error;
  }
}

async function runStep(report, id, label, fn, { signal, onProgress, critical = false } = {}) {
  assertNotAborted(signal);
  const entry = { id, label, status: "running", startedAt: new Date().toISOString(), durationMs: 0 };
  report.steps.push(entry);
  onProgress?.({ phase: id, label, completed: report.steps.length - 1, report });
  const startedAt = now();
  try {
    const result = await fn();
    entry.result = result ?? null;
    const failed = Number(result?.failed ?? 0);
    const warnings = Array.isArray(result?.warnings)
      ? result.warnings.length
      : Number(result?.warnings ?? 0);
    entry.status = failed > 0 ? "failed" : warnings > 0 ? "warning" : "passed";
    if (entry.status === "passed") report.summary.passed += 1;
    return result;
  } catch (error) {
    entry.status = error?.name === "AbortError" ? "cancelled" : "failed";
    entry.error = serializeAuditError(error);
    if (error?.name !== "AbortError") {
      issue(report, "error", `step:${id}`, `${label}: ${error?.message ?? error}`, { error: entry.error });
    }
    if (critical || error?.name === "AbortError") throw error;
    return null;
  } finally {
    entry.durationMs = duration(startedAt);
    entry.finishedAt = new Date().toISOString();
    onProgress?.({ phase: id, label, completed: report.steps.length, report });
  }
}

function captureRuntime(report) {
  const restores = [];
  for (const level of ["warn", "error"]) {
    const original = console[level];
    if (typeof original !== "function") continue;
    console[level] = (...args) => {
      if (report.captured.console.length < 500) {
        report.captured.console.push({ level, at: new Date().toISOString(), values: args.map(stringValue).slice(0, 8) });
      }
      return original.apply(console, args);
    };
    restores.push(() => { console[level] = original; });
  }

  const notifications = globalThis.ui?.notifications;
  for (const level of ["info", "warn", "error"]) {
    const original = notifications?.[level];
    if (typeof original !== "function") continue;
    notifications[level] = (message, options) => {
      if (report.captured.notifications.length < 1000) {
        report.captured.notifications.push({
          level,
          at: new Date().toISOString(),
          message: stringValue(message),
          options: options && typeof options === "object" ? { ...options } : null,
          suppressedDuringAudit: true,
        });
      }
      // Hundreds of transient toasts during a physical run can race with
      // Foundry's notification removal and produce an unrelated unhandled
      // rejection. The call is still recorded, but rendering is muted until
      // the checker restores the original notification methods.
      return null;
    };
    restores.push(() => { notifications[level] = original; });
  }

  const onError = (event) => report.captured.windowErrors.push({
    type: "error",
    at: new Date().toISOString(),
    message: event?.message ?? "window error",
    filename: event?.filename ?? null,
    line: event?.lineno ?? null,
    column: event?.colno ?? null,
    error: event?.error ? serializeAuditError(event.error) : null,
  });
  const onRejection = (event) => report.captured.windowErrors.push({
    type: "unhandledrejection",
    at: new Date().toISOString(),
    reason: event?.reason ? serializeAuditError(event.reason) : null,
  });
  globalThis.addEventListener?.("error", onError);
  globalThis.addEventListener?.("unhandledrejection", onRejection);
  restores.push(() => globalThis.removeEventListener?.("error", onError));
  restores.push(() => globalThis.removeEventListener?.("unhandledrejection", onRejection));

  return () => restores.reverse().forEach((restore) => {
    try { restore(); } catch { /* noop */ }
  });
}

function auditConcept(values, overrides = {}) {
  return parseConcept({
    ...completePresetValues(values),
    target: "new",
    count: 1,
    openSheet: false,
    randomToken: false,
    tokenPath: "",
    tokenImage: "",
    deploymentMode: "none",
    addToCombat: false,
    createBriefing: false,
    sendChatSummary: false,
    confirmRiskyOperations: true,
    includeSkillActions: true,
    randomAbilities: true,
    randomSpells: true,
    randomConsumables: true,
    autoCorrect: true,
    ...overrides,
  });
}

function inspectCreatedActor(actor, presetId, report) {
  const findings = [];
  if (!actor) findings.push("Foundry не вернул Actor.");
  if (actor?.type !== "npc") findings.push(`Создан тип ${actor?.type ?? "неизвестно"}, ожидался npc.`);
  const items = [...(actor?.items ?? [])];
  const actionCategories = new Set(Object.keys(CONFIG?.PF2E?.actionCategories ?? {}));
  const itemIds = new Set(items.map((item) => item.id).filter(Boolean));
  for (const item of items) {
    if (item.type === "action" && item.system?.category && actionCategories.size && !actionCategories.has(item.system.category)) {
      findings.push(`Item «${item.name}»: недопустимая category=${item.system.category}.`);
    }
    if (item.flags?.babele) findings.push(`Item «${item.name}»: перенесён служебный flags.babele.`);
    if (item.type === "spell") {
      const location = item.system?.location?.value;
      if (location && !itemIds.has(location)) findings.push(`Заклинание «${item.name}» ссылается на отсутствующую запись ${location}.`);
    }
  }
  const fallbacks = items.filter((item) => String(item.flags?.[MODULE_ID]?.kind ?? "").includes("fallback"));
  if (fallbacks.length) {
    issue(report, "warning", `preset:${presetId}:fallback`, `Пресет ${presetId} создал ${fallbacks.length} запасных памяток вместо исходных документов.`, {
      items: fallbacks.map(compactSource),
    });
  }
  return { itemCount: items.length, fallbacks: fallbacks.map(compactSource), findings };
}

async function deleteDocument(document, report, kind) {
  if (!document?.delete) return;
  try {
    await document.delete();
    report.cleanup.push({ kind, id: document.id ?? null, name: document.name ?? null, ok: true });
  } catch (error) {
    report.cleanup.push({ kind, id: document.id ?? null, name: document.name ?? null, ok: false, error: serializeAuditError(error) });
    issue(report, "error", "cleanup-failed", `Не удалось удалить временный документ «${document.name ?? kind}»: ${error.message}`, { kind, id: document.id ?? null });
  }
}

async function auditPresets(report, options, signal, onProgress) {
  const entries = Object.entries(BUILTIN_PRESETS);
  let index = 0;
  for (const [presetId, preset] of entries) {
    assertNotAborted(signal);
    const startedAt = now();
    const result = { id: presetId, label: preset.label, status: "running", durationMs: 0, warnings: [], errors: [] };
    report.presets.push(result);
    onProgress?.({ phase: "presets", label: `Пресет ${index + 1}/${entries.length}: ${preset.label}`, completed: index, total: entries.length, report });
    let createdActor = null;
    try {
      const concept = auditConcept(preset.values, { randomSeed: `${options.seed}:${presetId}` });
      const preview = getPreview(concept);
      result.preview = {
        name: preview.name,
        level: preview.effectiveLevel,
        strikes: preview.strikes?.length ?? 0,
        actions: preview.actions?.length ?? 0,
        equipment: preview.equipment?.length ?? 0,
        spells: preview.spells?.length ?? 0,
        warnings: preview.warnings ?? [],
      };
      if (options.liveActorCreation) {
        const generated = await generateNpc(concept);
        createdActor = generated.actor;
        result.actor = compactSource(createdActor);
        result.warnings.push(...(generated.warnings ?? []));
        const inspection = inspectCreatedActor(createdActor, presetId, report);
        result.inspection = inspection;
        if (inspection.findings.length) {
          result.errors.push(...inspection.findings);
          inspection.findings.forEach((message) => issue(report, "error", `preset:${presetId}:validation`, message));
        }
        for (const warning of generated.warnings ?? []) {
          recordGenerationWarning(report, `preset:${presetId}:warning`, warning, { presetId });
        }
      }
      result.status = result.errors.length
        ? "failed"
        : result.warnings.some(actionableGenerationWarning)
          ? "warning"
          : "passed";
    } catch (error) {
      result.status = "failed";
      result.errors.push(error.message ?? String(error));
      result.error = serializeAuditError(error);
      issue(report, "error", `preset:${presetId}:create`, `Пресет «${preset.label}»: ${error.message}`, { presetId, error: result.error });
    } finally {
      if (options.cleanup && createdActor) await deleteDocument(createdActor, report, "Actor");
      result.durationMs = duration(startedAt);
      index += 1;
    }
  }
  return { total: entries.length, failed: report.presets.filter((entry) => entry.status === "failed").length };
}

async function auditBatches(report, options, signal) {
  if (!options.testBatchCreation) return { skipped: true };
  const cases = [
    ["clones", BUILTIN_PRESETS.guard.values, { count: 3, batchMode: "clones" }],
    ["squad", BUILTIN_PRESETS.guard.values, { count: 3, batchMode: "squad" }],
    ["encounter", BUILTIN_PRESETS.goblinRaid.values, { count: 3, batchMode: "encounter" }],
  ];
  for (const [id, values, overrides] of cases) {
    assertNotAborted(signal);
    const entry = { id, status: "running", actors: [], warnings: [], errors: [] };
    report.batches.push(entry);
    let results = [];
    try {
      const concept = auditConcept(values, { ...overrides, randomSeed: `${options.seed}:batch:${id}` });
      results = await generateNpcBatch(concept);
      entry.actors = results.map((result) => compactSource(result.actor));
      entry.warnings = results.flatMap((result) => result.warnings ?? []);
      if (results.length !== overrides.count) throw new Error(`Создано ${results.length}, ожидалось ${overrides.count}.`);
      entry.status = entry.warnings.some(actionableGenerationWarning) ? "warning" : "passed";
      entry.warnings.forEach((warning) => recordGenerationWarning(report, `batch:${id}:warning`, warning));
    } catch (error) {
      entry.status = "failed";
      entry.error = serializeAuditError(error);
      issue(report, "error", `batch:${id}:create`, error.message, { error: entry.error });
    } finally {
      if (options.cleanup) {
        for (const result of results) await deleteDocument(result.actor, report, "Actor");
      }
    }
  }
  return { total: cases.length, failed: report.batches.filter((entry) => entry.status === "failed").length };
}

async function auditCompendiums(report, options, signal, onProgress) {
  if (!options.scanCompendiums) return { skipped: true };
  const availability = await catalogAvailability();
  const byPack = new Map(availability.map((entry) => [entry.packId, entry]));
  for (let packIndex = 0; packIndex < RELEVANT_PACKS.length; packIndex += 1) {
    assertNotAborted(signal);
    const packId = RELEVANT_PACKS[packIndex];
    const pack = game.packs?.get?.(packId);
    const entry = { packId, available: Boolean(pack), status: "running", indexCount: 0, attempted: 0, read: 0, errors: [] };
    report.packs.push(entry);
    onProgress?.({ phase: "packs", label: `Компендиум ${packIndex + 1}/${RELEVANT_PACKS.length}: ${packId}`, completed: packIndex, total: RELEVANT_PACKS.length, report });
    if (!pack) {
      entry.status = byPack.get(packId)?.required ? "failed" : "skipped";
      if (packId.startsWith("pf2e.")) issue(report, "error", `pack:${packId}:missing`, `Обязательный компендиум ${packId} не найден.`);
      else issue(report, "warning", `pack:${packId}:missing`, `Необязательный компендиум ${packId} не найден.`);
      continue;
    }
    try {
      const index = await pack.getIndex({ fields: ["name", "type", "system.slug", "system.level.value"] });
      const rows = [...(index ?? [])];
      entry.indexCount = rows.length;
      const limit = options.deepCompendiumScan
        ? rows.length
        : Math.min(rows.length, Math.max(1, Number(options.maxDocumentsPerPack) || 40));
      const selected = rows.slice(0, limit);
      for (const row of selected) {
        assertNotAborted(signal);
        entry.attempted += 1;
        if (entry.attempted === 1 || entry.attempted % 25 === 0 || entry.attempted === selected.length) {
          onProgress?.({ phase: "packs", label: `${packId}: ${entry.attempted}/${selected.length}`, completed: entry.attempted, total: selected.length, report });
        }
        try {
          const document = await pack.getDocument(row._id ?? row.id);
          if (!document) throw new Error("getDocument вернул null");
          entry.read += 1;
          if (document.flags?.babele && document.flags.babele.translated && !document.name) {
            throw new Error("Babele отметил документ переведённым, но имя отсутствует.");
          }
        } catch (error) {
          const failure = { id: row._id ?? row.id ?? null, name: row.name ?? null, type: row.type ?? null, error: serializeAuditError(error) };
          entry.errors.push(failure);
          issue(report, "error", `pack:${packId}:document`, `${packId}: не удалось прочитать «${row.name ?? row._id}»: ${error.message}`, failure);
        }
      }
      entry.status = entry.errors.length ? "failed" : "passed";
    } catch (error) {
      entry.status = "failed";
      entry.error = serializeAuditError(error);
      issue(report, "error", `pack:${packId}:index`, `${packId}: ${error.message}`, { error: entry.error });
    }
  }
  return { total: report.packs.length, failed: report.packs.filter((entry) => entry.status === "failed").length };
}

function actionCategoryAllowed(value) {
  if (!value) return true;
  const options = CONFIG?.PF2E?.actionCategories;
  if (!options) return true;
  return options instanceof Map ? options.has(value) : Object.hasOwn(options, value);
}

async function auditWorldActors(report, options, signal) {
  if (!options.scanWorldActors) return { skipped: true };
  const scan = { actors: 0, npcs: 0, characters: 0, items: 0, findings: [] };
  for (const actor of [...(game.actors ?? [])]) {
    assertNotAborted(signal);
    scan.actors += 1;
    if (actor.type === "npc") scan.npcs += 1;
    if (actor.type === "character") scan.characters += 1;
    try {
      const items = [...(actor.items ?? [])];
      scan.items += items.length;
      const ids = new Set(items.map((item) => item.id));
      for (const item of items) {
        if (item.type === "action" && !actionCategoryAllowed(item.system?.category)) {
          scan.findings.push({ actor: compactSource(actor), item: compactSource(item), code: "invalid-action-category", value: item.system?.category });
        }
        if (item.type === "spell") {
          const location = item.system?.location?.value;
          if (location && !ids.has(location)) scan.findings.push({ actor: compactSource(actor), item: compactSource(item), code: "missing-spellcasting-entry", value: location });
        }
        if (item.flags?.babele?.translated && !item.name) {
          scan.findings.push({ actor: compactSource(actor), item: compactSource(item), code: "babele-empty-name" });
        }
      }
    } catch (error) {
      scan.findings.push({ actor: compactSource(actor), code: "actor-read-error", error: serializeAuditError(error) });
    }
  }
  for (const finding of scan.findings) {
    issue(report, finding.code === "actor-read-error" ? "error" : "warning", `world:${finding.code}`, `Проблема в Actor «${finding.actor?.name ?? "без имени"}»: ${finding.code}`, finding);
  }
  report.worldScan = scan;
  return scan;
}

function auditUiGeometry(report) {
  const body = globalThis.document?.querySelector?.(".pf2e-npc-forge");
  const footer = globalThis.document?.querySelector?.(".forge-app-footer");
  if (!body || !footer) return { available: false, reason: "Окно Кузницы не найдено в DOM." };
  const bodyRect = body.getBoundingClientRect();
  const footerRect = footer.getBoundingClientRect();
  const viewport = { width: globalThis.innerWidth ?? 0, height: globalThis.innerHeight ?? 0 };
  const findings = [];
  if (bodyRect.left < -1 || bodyRect.right > viewport.width + 1) findings.push("Основная часть выходит за ширину viewport.");
  if (footerRect.left < -1 || footerRect.right > viewport.width + 1) findings.push("Нижняя панель выходит за ширину viewport.");
  if (footerRect.bottom > viewport.height + 1) findings.push("Нижняя панель находится ниже viewport.");
  const style = globalThis.getComputedStyle?.(body);
  if (style && !["auto", "scroll"].includes(style.overflowY)) findings.push(`Основная область не прокручивается: overflow-y=${style.overflowY}.`);
  findings.forEach((message) => issue(report, "error", "ui-geometry", message, { bodyRect, footerRect, viewport }));
  return {
    available: true,
    viewport,
    bodyRect: { left: bodyRect.left, top: bodyRect.top, right: bodyRect.right, bottom: bodyRect.bottom, width: bodyRect.width, height: bodyRect.height },
    footerRect: { left: footerRect.left, top: footerRect.top, right: footerRect.right, bottom: footerRect.bottom, width: footerRect.width, height: footerRect.height },
    scroll: { clientHeight: body.clientHeight, scrollHeight: body.scrollHeight, overflowY: style?.overflowY ?? null },
    findings,
  };
}

async function temporaryIntegrationTests(report, options, signal) {
  const result = { actor: null, journal: null, scene: null, combat: null, macro: null };
  let generated = null;
  try {
    assertNotAborted(signal);
    generated = await generateNpc(auditConcept(BUILTIN_PRESETS.guard.values, {
      name: "[AUDIT] Временный стражник",
      randomSeed: `${options.seed}:temporary-integration`,
    }));
    result.actor = compactSource(generated.actor);

    if (options.testTemporaryJournal) {
      const briefing = await createEncounterBriefing([generated], {
        ...auditConcept(BUILTIN_PRESETS.guard.values),
        name: "[AUDIT] Временная сводка",
        count: 1,
        createBriefing: true,
      });
      result.journal = compactSource(briefing.journal);
      if (!briefing.journal) throw new Error(briefing.warnings?.join(" ") || "JournalEntry не создан.");
      if (options.cleanup) await deleteDocument(briefing.journal, report, "JournalEntry");
    }

    if (options.testTemporaryMacro && typeof globalThis.Macro?.create === "function") {
      let macro = await Macro.create({
        name: `[AUDIT] Кузница ${Date.now()}`,
        type: "script",
        scope: "global",
        command: "// temporary pf2e-npc-forge audit macro",
        flags: { [MODULE_ID]: { audit: true } },
      });
      if (Array.isArray(macro)) macro = macro[0];
      result.macro = compactSource(macro);
      if (options.cleanup) await deleteDocument(macro, report, "Macro");
    }

    if (options.testTemporaryScene && typeof globalThis.Scene?.create === "function") {
      let scene = await Scene.create({
        name: `[AUDIT] Кузница ${Date.now()}`,
        width: 1000,
        height: 1000,
        padding: 0,
        grid: { type: 1, size: 100, distance: 5 },
        active: false,
        navigation: false,
        flags: { [MODULE_ID]: { audit: true } },
      });
      if (Array.isArray(scene)) scene = scene[0];
      result.scene = compactSource(scene);
      const prototype = generated.actor.prototypeToken?.toObject?.() ?? generated.actor.prototypeToken ?? {};
      const tokens = await scene.createEmbeddedDocuments("Token", [{ ...structuredClone(prototype), _id: undefined, actorId: generated.actor.id, actorLink: true, name: generated.actor.name, x: 100, y: 100, delta: {} }]);
      if (!tokens?.length) throw new Error("Временный Token не создан.");
      if (typeof globalThis.Combat?.create === "function") {
        let combat = await Combat.create({ scene: scene.id, active: false });
        if (Array.isArray(combat)) combat = combat[0];
        result.combat = compactSource(combat);
        await combat.createEmbeddedDocuments("Combatant", [{ actorId: generated.actor.id, tokenId: tokens[0].id, sceneId: scene.id, hidden: true }]);
        if (options.cleanup) await deleteDocument(combat, report, "Combat");
      }
      if (options.cleanup) await deleteDocument(scene, report, "Scene");
    }
    return result;
  } finally {
    if (options.cleanup && generated?.actor) await deleteDocument(generated.actor, report, "Actor");
  }
}


function recordAuditFailure(report, code, label, error, context = {}) {
  const serialized = serializeAuditError(error);
  issue(report, "error", code, `${label}: ${serialized.message}`, { ...context, error: serialized });
  return serialized;
}

function objectEntries(record) {
  return Object.entries(record ?? {}).filter(([key]) => key !== "auto" && key !== "none");
}

async function auditModuleFiles(report, signal) {
  const paths = [
    "module.json",
    "scripts/main.js",
    "scripts/generator.js",
    "scripts/schema-guard.js",
    "scripts/session-auditor.js",
    "scripts/audit-reports.js",
    "templates/generator.hbs",
    "templates/forge-footer.hbs",
    "styles/forge.css",
  ];
  const getRoute = globalThis.foundry?.utils?.getRoute;
  for (const relative of paths) {
    assertNotAborted(signal);
    const raw = `modules/${MODULE_ID}/${relative}`;
    const url = typeof getRoute === "function" ? getRoute(raw) : raw;
    const entry = { path: relative, url, ok: false, status: null, bytes: 0, sha256: null, error: null };
    report.moduleFiles.push(entry);
    try {
      const response = await fetch(url, { cache: "no-store" });
      entry.status = response.status;
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const bytes = new Uint8Array(await response.arrayBuffer());
      entry.bytes = bytes.byteLength;
      if (globalThis.crypto?.subtle) {
        const digest = await globalThis.crypto.subtle.digest("SHA-256", bytes);
        entry.sha256 = [...new Uint8Array(digest)].map((value) => value.toString(16).padStart(2, "0")).join("");
      }
      entry.ok = true;
    } catch (error) {
      entry.error = serializeAuditError(error);
      issue(report, "error", `module-file:${relative}`, `Файл модуля не читается: ${relative}. ${error.message}`, entry);
    }
  }
  return { total: report.moduleFiles.length, failed: report.moduleFiles.filter((entry) => !entry.ok).length };
}

async function auditUiControls(report, options, signal) {
  if (!options.testUiControls) return { skipped: true };
  const fn = game.modules?.get?.(MODULE_ID)?.api?.runUiControlAudit;
  if (typeof fn !== "function") throw new Error("В API модуля отсутствует физическая UI-проверка.");
  const result = await fn({ signal });
  report.uiControls = result;
  for (const failure of result.failures ?? []) {
    issue(report, "error", `ui-control:${failure.id}`, `Кнопка или режим не сработали: ${failure.id}. ${failure.detail ?? ""}`, failure);
  }
  return result;
}

const MATRIX_GROUPS = [
  ["creatureKind", "Тип существа", CREATURE_KINDS],
  ["ancestry", "Происхождение", ANCESTRIES],
  ["profession", "Профессия", PROFESSIONS],
  ["role", "Роль", ROLES],
  ["armor", "Броня", ARMORS],
  ["weapon", "Оружие", WEAPONS],
  ["monsterFamily", "Семейство монстров", MONSTER_FAMILIES],
  ["technology", "Технологический уровень", TECHNOLOGY_LEVELS],
  ["contentSource", "Источник контента", CONTENT_SOURCES],
  ["monsterTemplate", "Шаблон монстра", MONSTER_TEMPLATES],
  ["adventureMode", "Режим приключения", ADVENTURE_MODES],
  ["lootRichness", "Насыщенность добычи", LOOT_RICHNESS],
  ["encounterDifficulty", "Сложность столкновения", ENCOUNTER_DIFFICULTIES],
  ["spellTheme", "Тема заклинаний", Object.fromEntries(Object.entries(SPELL_THEME_LABELS).map(([value, label]) => [value, { label }]))],
  ["quality", "Качество", { standard: { label: "Обычный" }, elite: { label: "Элитный" } }],
  ["complexity", "Сложность управления", { simple: { label: "Простая" }, standard: { label: "Стандартная" }, tactical: { label: "Тактическая" } }],
];

async function auditOptionMatrix(report, options, signal, onProgress) {
  if (!options.testOptionMatrix) return { skipped: true };
  const cases = [];
  for (const [field, label, record] of MATRIX_GROUPS) {
    for (const [value, data] of objectEntries(record)) cases.push({ field, label, value, valueLabel: data?.label ?? value });
  }
  let completed = 0;
  for (const test of cases) {
    assertNotAborted(signal);
    onProgress?.({ phase: "matrix", label: `${test.label}: ${test.valueLabel}`, completed, total: cases.length, report });
    const entry = { ...test, status: "running", preview: null, actor: null, warnings: [], error: null };
    report.optionMatrix.push(entry);
    let generated = null;
    try {
      const overrides = { [test.field]: test.value, name: `[AUDIT] ${test.label}: ${test.valueLabel}`, randomSeed: `${options.seed}:matrix:${test.field}:${test.value}` };
      if (test.field === "monsterFamily") overrides.creatureKind = recordKindForFamily(test.value);
      const concept = auditConcept(BUILTIN_PRESETS.guard.values, overrides);
      const preview = getPreview(concept);
      entry.preview = { name: preview.name, level: preview.effectiveLevel, warnings: preview.warnings ?? [], itemPlan: (preview.actions?.length ?? 0) + (preview.strikes?.length ?? 0) + (preview.equipment?.length ?? 0) + (preview.spells?.length ?? 0) };
      if (options.liveOptionMatrixCreation) {
        generated = await generateNpc(concept);
        entry.actor = compactSource(generated.actor);
        entry.warnings = generated.warnings ?? [];
        const inspection = inspectCreatedActor(generated.actor, `matrix:${test.field}:${test.value}`, report);
        if (inspection.findings.length) throw new Error(inspection.findings.join(" "));
      }
      entry.status = entry.warnings.some(actionableGenerationWarning) ? "warning" : "passed";
      for (const warning of entry.warnings) {
        recordGenerationWarning(report, `matrix:${test.field}:${test.value}:warning`, warning, test);
      }
    } catch (error) {
      entry.status = "failed";
      entry.error = recordAuditFailure(report, `matrix:${test.field}:${test.value}`, `${test.label} «${test.valueLabel}»`, error, test);
    } finally {
      if (options.cleanup && generated?.actor) await deleteDocument(generated.actor, report, "Actor");
      completed += 1;
    }
  }
  return { total: cases.length, failed: report.optionMatrix.filter((entry) => entry.status === "failed").length };
}

function recordKindForFamily(familyId) {
  return MONSTER_FAMILIES?.[familyId]?.kind ?? "monster";
}

async function auditRandomCases(report, options, signal, onProgress) {
  const count = Math.max(1, Number(options.randomLiveCases) || 12);
  const cases = [];
  for (let index = 0; index < count; index += 1) {
    cases.push({ kind: "npc", values: randomFormValues({ seed: `${options.seed}:live-random:npc:${index}` }) });
    cases.push({ kind: "monster", values: randomMonsterFormValues(`${options.seed}:live-random:monster:${index}`, {}) });
  }
  let completed = 0;
  for (const test of cases) {
    assertNotAborted(signal);
    onProgress?.({ phase: "random-live", label: `Случайный ${test.kind} ${completed + 1}/${cases.length}`, completed, total: cases.length, report });
    const entry = { kind: test.kind, index: completed, status: "running", actor: null, warnings: [], error: null };
    report.randomCases.push(entry);
    let generated = null;
    try {
      const concept = auditConcept(test.values, { name: `[AUDIT] Random ${test.kind} ${completed + 1}` });
      getPreview(concept);
      generated = await generateNpc(concept);
      entry.actor = compactSource(generated.actor);
      entry.warnings = generated.warnings ?? [];
      const inspection = inspectCreatedActor(generated.actor, `random:${test.kind}:${completed}`, report);
      if (inspection.findings.length) throw new Error(inspection.findings.join(" "));
      entry.status = entry.warnings.some(actionableGenerationWarning) ? "warning" : "passed";
    } catch (error) {
      entry.status = "failed";
      entry.error = recordAuditFailure(report, `random:${test.kind}:${completed}`, `Случайная сборка ${test.kind}`, error, entry);
    } finally {
      if (options.cleanup && generated?.actor) await deleteDocument(generated.actor, report, "Actor");
      completed += 1;
    }
  }
  return { total: cases.length, failed: report.randomCases.filter((entry) => entry.status === "failed").length };
}

function selectedTokenPlaceable(tokenDocument) {
  return tokenDocument?.object ?? globalThis.canvas?.tokens?.get?.(tokenDocument?.id) ?? null;
}

async function createAuditToken(actor, scene, suffix) {
  const prototype = actor.prototypeToken?.toObject?.() ?? actor.prototypeToken ?? {};
  const created = await scene.createEmbeddedDocuments("Token", [{
    ...structuredClone(prototype),
    _id: undefined,
    actorId: actor.id,
    actorLink: true,
    name: `[AUDIT] ${suffix}`,
    hidden: true,
    alpha: 0.05,
    x: 0,
    y: 0,
    delta: {},
    flags: { [MODULE_ID]: { audit: true } },
  }]);
  if (!created?.[0]) throw new Error("Временный выбранный Token не создан.");
  return created[0];
}

async function createUserMarker(actor, suffix) {
  const sourceItem = [...(actor.items ?? [])].find((item) => !["condition", "effect", "spell", "spellcastingEntry"].includes(item.type));
  if (!sourceItem?.toObject) throw new Error("Не найден Item для создания пользовательского маркера.");
  const copy = sourceItem.toObject();
  delete copy._id;
  delete copy._stats;
  copy.name = `[AUDIT USER ITEM] ${suffix}`;
  copy.flags = structuredClone(copy.flags ?? {});
  delete copy.flags[MODULE_ID];
  delete copy.flags.babele;
  const created = await actor.createEmbeddedDocuments("Item", [copy]);
  if (!created?.[0]) throw new Error("Пользовательский Item-маркер не создан.");
  return created[0];
}

function restoreControlledTokens(ids = []) {
  globalThis.canvas?.tokens?.releaseAll?.();
  for (const id of ids) {
    const token = globalThis.canvas?.tokens?.get?.(id);
    token?.control?.({ releaseOthers: false });
  }
}

async function auditSelectedWorkflows(report, options, signal) {
  if (!options.testSelectedWorkflows) return { skipped: true };
  const scene = globalThis.canvas?.scene;
  if (!scene || typeof scene.createEmbeddedDocuments !== "function") {
    issue(report, "warning", "selected:no-active-scene", "Выбранные режимы не проверены: нет активной сцены.");
    return { skipped: true, reason: "no-active-scene" };
  }
  const previousControlled = [...(globalThis.canvas?.tokens?.controlled ?? [])].map((token) => token.id);

  try {
    for (const policy of ["keep", "generated", "all"]) {
      assertNotAborted(signal);
      const entry = { id: `selected:${policy}`, status: "running", policy, actor: null, backup: null, safetyBackup: null, markerPreserved: null, restored: null };
      report.selectedWorkflows.push(entry);
      let source = null;
      let tokenDocument = null;
      let backup = null;
      let safetyBackup = null;
      try {
        source = await generateNpc(auditConcept(BUILTIN_PRESETS.guard.values, { name: `[AUDIT] Selected ${policy} source`, randomSeed: `${options.seed}:selected:${policy}:source` }));
        const originalName = source.actor.name;
        const marker = await createUserMarker(source.actor, policy);
        tokenDocument = await createAuditToken(source.actor, scene, `Selected ${policy}`);
        const placeable = selectedTokenPlaceable(tokenDocument);
        if (!placeable?.control) throw new Error("Временный Token не получил placeable на активной сцене.");
        placeable.control({ releaseOthers: true });
        const result = await generateNpc(auditConcept(BUILTIN_PRESETS.medic?.values ?? BUILTIN_PRESETS.guard.values, {
          name: `[AUDIT] Selected ${policy} rebuilt`,
          target: "selected",
          itemPolicy: policy,
          backupOriginal: true,
          randomSeed: `${options.seed}:selected:${policy}:rebuild`,
        }));
        backup = result.backup;
        entry.actor = compactSource(result.actor);
        entry.backup = compactSource(backup);
        const markerExists = Boolean(result.actor.items?.get?.(marker.id) ?? [...(result.actor.items ?? [])].find((item) => item.name === marker.name));
        entry.markerPreserved = markerExists;
        const expectedMarker = policy !== "all";
        if (markerExists !== expectedMarker) throw new Error(`itemPolicy=${policy}: пользовательский Item ${markerExists ? "сохранён" : "удалён"}, ожидалось ${expectedMarker ? "сохранение" : "удаление"}.`);
        if (!backup) throw new Error("Резервная копия выбранного NPC не создана.");
        const restored = await restoreFromHistoryEntry({ actorUuids: [result.actor.uuid], backupUuids: [backup.uuid] }, { openSheet: false });
        safetyBackup = restored.safetyBackup;
        entry.safetyBackup = compactSource(safetyBackup);
        entry.restored = restored.actor.name === originalName;
        if (!entry.restored) throw new Error(`Восстановление вернуло имя «${restored.actor.name}», ожидалось «${originalName}».`);
        entry.status = "passed";
      } catch (error) {
        entry.status = "failed";
        entry.error = recordAuditFailure(report, `selected:${policy}`, `Режим выбранного NPC (${policy})`, error, entry);
      } finally {
        if (options.cleanup && tokenDocument) {
          try { await scene.deleteEmbeddedDocuments("Token", [tokenDocument.id]); report.cleanup.push({ kind: "Token", id: tokenDocument.id, name: tokenDocument.name, ok: true }); }
          catch (error) { issue(report, "error", "cleanup-failed", `Не удалось удалить временный Token: ${error.message}`); }
        }
        if (options.cleanup && safetyBackup) await deleteDocument(safetyBackup, report, "Actor");
        if (options.cleanup && backup) await deleteDocument(backup, report, "Actor");
        if (options.cleanup && source?.actor) await deleteDocument(source.actor, report, "Actor");
      }
    }

    const entry = { id: "duplicate", status: "running", source: null, duplicate: null, tokenReassigned: false };
    report.selectedWorkflows.push(entry);
    let source = null;
    let duplicate = null;
    let tokenDocument = null;
    try {
      source = await generateNpc(auditConcept(BUILTIN_PRESETS.guard.values, { name: "[AUDIT] Duplicate source", randomSeed: `${options.seed}:duplicate:source` }));
      tokenDocument = await createAuditToken(source.actor, scene, "Duplicate source");
      const placeable = selectedTokenPlaceable(tokenDocument);
      if (!placeable?.control) throw new Error("Временный Token для копирования не получил placeable.");
      placeable.control({ releaseOthers: true });
      duplicate = await generateNpc(auditConcept(BUILTIN_PRESETS.scout?.values ?? BUILTIN_PRESETS.guard.values, { name: "[AUDIT] Duplicate result", target: "duplicate", randomSeed: `${options.seed}:duplicate:result` }));
      entry.source = compactSource(source.actor);
      entry.duplicate = compactSource(duplicate.actor);
      entry.tokenReassigned = tokenDocument.actorId === duplicate.actor.id;
      if (!entry.tokenReassigned) throw new Error("Выбранный временный Token не переключился на созданную копию.");
      entry.status = "passed";
    } catch (error) {
      entry.status = "failed";
      entry.error = recordAuditFailure(report, "selected:duplicate", "Создание копии выбранного NPC", error, entry);
    } finally {
      if (options.cleanup && tokenDocument) {
        try { await scene.deleteEmbeddedDocuments("Token", [tokenDocument.id]); report.cleanup.push({ kind: "Token", id: tokenDocument.id, name: tokenDocument.name, ok: true }); }
        catch (error) { issue(report, "error", "cleanup-failed", `Не удалось удалить Token копирования: ${error.message}`); }
      }
      if (options.cleanup && duplicate?.actor) await deleteDocument(duplicate.actor, report, "Actor");
      if (options.cleanup && source?.actor) await deleteDocument(source.actor, report, "Actor");
    }
  } finally {
    restoreControlledTokens(previousControlled);
  }
  return { total: report.selectedWorkflows.length, failed: report.selectedWorkflows.filter((entry) => entry.status === "failed").length };
}

async function auditDeploymentModes(report, options, signal) {
  if (!options.testDeploymentModes) return { skipped: true };
  const scene = globalThis.canvas?.scene;
  if (!scene) {
    issue(report, "warning", "deployment:no-active-scene", "Размещение формаций не проверено: нет активной сцены.");
    return { skipped: true };
  }
  let actors = [];
  try {
    for (let index = 0; index < 3; index += 1) actors.push(await generateNpc(auditConcept(BUILTIN_PRESETS.guard.values, { name: `[AUDIT] Deployment ${index + 1}`, randomSeed: `${options.seed}:deployment:${index}` })));
    for (const mode of Object.keys(DEPLOYMENT_MODES).filter((value) => value !== "none")) {
      assertNotAborted(signal);
      const entry = { mode, status: "running", tokenIds: [], combat: null, warnings: [] };
      report.deployment.push(entry);
      try {
        const deployed = await deployActorsToScene(actors, { deploymentMode: mode, addToCombat: false });
        entry.tokenIds = (deployed.tokens ?? []).map((token) => token.id);
        entry.warnings = deployed.warnings ?? [];
        if (entry.tokenIds.length !== actors.length) throw new Error(`Создано жетонов ${entry.tokenIds.length}, ожидалось ${actors.length}.`);
        entry.status = entry.warnings.length ? "warning" : "passed";
      } catch (error) {
        entry.status = "failed";
        entry.error = recordAuditFailure(report, `deployment:${mode}`, `Размещение «${mode}»`, error, entry);
      } finally {
        if (options.cleanup && entry.tokenIds.length) {
          try { await scene.deleteEmbeddedDocuments("Token", entry.tokenIds); report.cleanup.push(...entry.tokenIds.map((id) => ({ kind: "Token", id, name: `[AUDIT] deployment ${mode}`, ok: true }))); }
          catch (error) { issue(report, "error", "cleanup-failed", `Не удалось удалить жетоны формации ${mode}: ${error.message}`); }
        }
      }
    }
    if (!game.combat) {
      const entry = { mode: "cluster+combat", status: "running", tokenIds: [], combat: null, warnings: [] };
      report.deployment.push(entry);
      let createdCombat = null;
      try {
        const deployed = await deployActorsToScene(actors.slice(0, 2), { deploymentMode: "cluster", addToCombat: true });
        entry.tokenIds = (deployed.tokens ?? []).map((token) => token.id);
        createdCombat = deployed.combat;
        entry.combat = compactSource(createdCombat);
        entry.warnings = deployed.warnings ?? [];
        if (!createdCombat || createdCombat.combatants.size < 2) throw new Error("Combat/Combatant не созданы через размещение.");
        entry.status = entry.warnings.length ? "warning" : "passed";
      } catch (error) {
        entry.status = "failed";
        entry.error = recordAuditFailure(report, "deployment:combat", "Размещение с добавлением в бой", error, entry);
      } finally {
        if (options.cleanup && createdCombat) await deleteDocument(createdCombat, report, "Combat");
        if (options.cleanup && entry.tokenIds.length) {
          try { await scene.deleteEmbeddedDocuments("Token", entry.tokenIds); report.cleanup.push(...entry.tokenIds.map((id) => ({ kind: "Token", id, name: "[AUDIT] deployment combat", ok: true }))); }
          catch (error) { issue(report, "error", "cleanup-failed", `Не удалось удалить жетоны боевой формации: ${error.message}`); }
        }
      }
    } else {
      report.deployment.push({ mode: "cluster+combat", status: "skipped", reason: "В мире уже идёт активный бой; checker не вмешивается в него." });
      issue(report, "warning", "deployment:combat-skipped", "Добавление через deployActorsToScene не проверено, потому что в мире уже есть активный бой.");
    }
  } finally {
    if (options.cleanup) for (const result of actors) await deleteDocument(result.actor, report, "Actor");
  }
  return { total: report.deployment.length, failed: report.deployment.filter((entry) => entry.status === "failed").length };
}

async function auditStorageRoundTrip(report, options) {
  if (!options.testStorageRoundTrip) return { skipped: true };
  const keys = ["customPresets", "lastForm", "recentHistory", "lastAuditReportMeta"];
  const before = Object.fromEntries(keys.map((key) => [key, structuredClone(game.settings.get(MODULE_ID, key))]));
  const result = { status: "running", operations: [], error: null };
  report.storageRoundTrip = result;
  try {
    const presetId = await saveCustomPreset(MODULE_ID, `[AUDIT] ${Date.now()}`, BUILTIN_PRESETS.guard.values);
    result.operations.push({ id: "saveCustomPreset", ok: Boolean(getCustomPresets(MODULE_ID)[presetId]) });
    const exported = exportCustomPresets(MODULE_ID);
    result.operations.push({ id: "exportCustomPresets", ok: exported.format === "pf2e-npc-forge-presets" });
    await deleteCustomPreset(MODULE_ID, presetId);
    result.operations.push({ id: "deleteCustomPreset", ok: !getCustomPresets(MODULE_ID)[presetId] });
    const imported = await importCustomPresets(MODULE_ID, { entries: { audit: { name: "[AUDIT] Imported", values: BUILTIN_PRESETS.guard.values } } });
    result.operations.push({ id: "importCustomPresets", ok: imported === 1 });
    await setLastForm(MODULE_ID, { ...BUILTIN_PRESETS.guard.values, count: 2 });
    result.operations.push({ id: "lastForm", ok: getLastForm(MODULE_ID).target === "new" });
    await addRecentHistory(MODULE_ID, auditConcept(BUILTIN_PRESETS.guard.values), []);
    result.operations.push({ id: "recentHistory", ok: getRecentHistory(MODULE_ID).length > 0 });
    await setLastAuditReportMeta(MODULE_ID, { auditProbe: true, at: new Date().toISOString() });
    result.operations.push({ id: "auditMeta", ok: getLastAuditReportMeta(MODULE_ID).auditProbe === true });
    const failed = result.operations.filter((entry) => !entry.ok);
    if (failed.length) throw new Error(`Не прошли операции: ${failed.map((entry) => entry.id).join(", ")}`);
    result.status = "passed";
  } catch (error) {
    result.status = "failed";
    result.error = recordAuditFailure(report, "storage:round-trip", "Хранилище настроек Кузницы", error, result);
  } finally {
    for (const [key, value] of Object.entries(before)) {
      try { await game.settings.set(MODULE_ID, key, value); }
      catch (error) { issue(report, "error", "storage:restore", `Не удалось восстановить setting ${key}: ${error.message}`); }
    }
  }
  return result;
}

async function auditAllPackIndexes(report, options, signal, onProgress) {
  if (!options.scanAllPackIndexes) return { skipped: true };
  const packs = [...(game.packs?.values?.() ?? game.packs ?? [])];
  for (let index = 0; index < packs.length; index += 1) {
    assertNotAborted(signal);
    const pack = packs[index];
    const entry = { packId: pack.collection ?? pack.metadata?.id ?? pack.metadata?.name ?? "unknown", label: pack.title ?? pack.metadata?.label ?? null, ok: false, count: 0, error: null };
    report.allPackIndexes.push(entry);
    if (index === 0 || index % 25 === 0 || index === packs.length - 1) onProgress?.({ phase: "all-pack-indexes", label: `Индексы всех компендиумов: ${index + 1}/${packs.length}`, completed: index + 1, total: packs.length, report });
    try {
      const rows = await pack.getIndex({ fields: ["name", "type"] });
      entry.count = rows?.size ?? rows?.length ?? 0;
      entry.ok = true;
    } catch (error) {
      entry.error = serializeAuditError(error);
      issue(report, "warning", `pack-index:${entry.packId}`, `Не удалось прочитать индекс компендиума ${entry.packId}: ${error.message}`, entry);
    }
  }
  return { total: report.allPackIndexes.length, failed: report.allPackIndexes.filter((entry) => !entry.ok).length };
}

async function auditChatMessage(report, options) {
  if (!options.testChatMessage || typeof globalThis.ChatMessage?.create !== "function") return { skipped: true };
  let message = null;
  try {
    message = await ChatMessage.create({ speaker: { alias: "[AUDIT] Кузница" }, content: "<p>Временная проверка ChatMessage.</p>", whisper: [game.user.id], flags: { [MODULE_ID]: { audit: true } } });
    if (Array.isArray(message)) message = message[0];
    if (!message) throw new Error("ChatMessage.create не вернул документ.");
    return { created: compactSource(message) };
  } finally {
    if (options.cleanup && message) await deleteDocument(message, report, "ChatMessage");
  }
}

function addCoverage(report, id, label, status, detail = "") {
  report.coverage.push({ id, label, status, detail });
  if (status === "skipped") report.summary.skipped += 1;
}

function normalizedRootMessage(entry) {
  const direct = entry?.context?.error?.message ?? entry?.context?.reason?.message ?? entry?.message ?? "";
  return String(direct)
    .replace(/^.*?:\s+(?=Кузница|Пакетная|Cannot|Не удалось|Foundry)/u, "")
    .replace(/«[^»]+»/gu, "«…»")
    .replace(/\b[A-Za-z0-9_-]{16}\b/gu, "<id>")
    .trim();
}

function buildIssueGroups(report) {
  const grouped = new Map();
  for (const entry of report.issues) {
    const rootMessage = normalizedRootMessage(entry);
    const stackLine = String(entry?.context?.error?.stack ?? entry?.context?.reason?.stack ?? "")
      .split("\n")
      .find((line) => line.includes("/modules/pf2e-npc-forge/")) ?? null;
    const fingerprint = `${entry.severity}|${rootMessage}|${stackLine ?? ""}`;
    const group = grouped.get(fingerprint) ?? {
      fingerprint,
      severity: entry.severity,
      rootMessage,
      stackLine,
      count: 0,
      codes: [],
      examples: [],
    };
    group.count += 1;
    if (!group.codes.includes(entry.code)) group.codes.push(entry.code);
    if (group.examples.length < 12) {
      group.examples.push({
        code: entry.code,
        message: entry.message,
        at: entry.at,
        context: entry.context,
      });
    }
    grouped.set(fingerprint, group);
  }
  return [...grouped.values()].sort((left, right) =>
    right.count - left.count || left.rootMessage.localeCompare(right.rootMessage));
}

function buildRecommendations(report) {
  const codes = new Set(report.issues.map((entry) => entry.code));
  const rows = [];
  const errorGroups = report.issueGroups.filter((group) => group.severity === "error");
  const registryFailure = errorGroups.some((group) =>
    group.rootMessage.includes("отказалась встраивать")
    || group.rootMessage.includes("runtime-реестры не перечислили"));
  const presetFailure = report.presets.some((entry) => entry.status === "failed")
    || [...codes].some((code) => /^preset:.*:(create|validation|fallback)$/u.test(code));
  const fallbackCount = [
    ...report.presets,
    ...report.randomCases,
  ].reduce((total, entry) => total + Number(entry?.inspection?.fallbacks?.length ?? 0), 0);
  const moduleWindowErrors = report.captured.windowErrors.filter((entry) => {
    const text = `${entry?.message ?? ""}\n${entry?.reason?.message ?? ""}\n${entry?.reason?.stack ?? ""}`;
    return text.includes(`/modules/${MODULE_ID}/`) || text.includes(`modules\\${MODULE_ID}\\`);
  });
  const externalWindowErrors = report.captured.windowErrors.filter((entry) => !moduleWindowErrors.includes(entry));

  if (registryFailure) {
    rows.push({
      priority: "critical",
      code: "fix-runtime-item-registry",
      text: "Исправить реальное отклонение Item защитным слоем; использовать schema.itemTypes и сохранённый стек ошибки.",
    });
  }
  if (presetFailure) {
    rows.push({
      priority: "high",
      code: "fix-preset-generation",
      text: "Исправить провалившиеся пресеты или запасные памятки; конкретные документы перечислены в presets и issues.",
    });
  }
  if (fallbackCount > 0 || [...codes].some((code) => code.includes(":fallback"))) {
    rows.push({
      priority: "high",
      code: "replace-fallback-documents",
      text: "Заменить неверные slug/UUID документов, из-за которых Кузница создала запасные памятки.",
    });
  }
  if ([...codes].some((code) => code.startsWith("pack:")) || codes.has("runtime-notification-errors")) {
    rows.push({
      priority: "high",
      code: "inspect-compendium-or-translation",
      text: "Проверить конкретные документы компендиумов и переводчик; ошибки чтения перечислены в packs и captured.notifications.",
    });
  }
  if ([...codes].some((code) => code.startsWith("world:"))) {
    rows.push({
      priority: "medium",
      code: "repair-world-items",
      text: "Проверить конкретные Actor и Item из worldScan.findings; реальные документы мира не изменялись.",
    });
  }
  if (codes.has("cleanup-failed") || report.cleanup.some((entry) => !entry.ok)) {
    rows.push({
      priority: "critical",
      code: "manual-cleanup",
      text: "Удалить оставшиеся временные документы вручную по ID и именам из cleanup.",
    });
  }
  if (codes.has("ui-geometry")) {
    rows.push({
      priority: "high",
      code: "fix-responsive-layout",
      text: "Исправить геометрию ApplicationV2 на viewport, записанном в environment.browser.viewport и шаге ui.",
    });
  }
  if (moduleWindowErrors.length) {
    rows.push({
      priority: "high",
      code: "inspect-module-unhandled-errors",
      text: "Разобрать необработанные ошибки со стеком Кузницы из captured.windowErrors.",
    });
  }
  if (externalWindowErrors.length) {
    rows.push({
      priority: "info",
      code: "external-module-errors",
      text: "Во время прогона сработала внешняя ошибка Foundry или другого модуля; она сохранена отдельно и не считается поломкой Кузницы.",
    });
  }
  if (report.summary.warningCount > 0 && !rows.some((entry) => entry.priority === "critical" || entry.priority === "high")) {
    rows.push({
      priority: "medium",
      code: "inspect-actionable-warnings",
      text: "Проверить оставшиеся предупреждения: они означают потерю, замену или исправление создаваемого содержимого.",
    });
  }
  if (!rows.length) {
    rows.push({
      priority: "info",
      code: "no-critical-findings",
      text: "Все физические этапы Кузницы прошли; информационные автокоррекции вынесены в observations и не считаются дефектами.",
    });
  }
  return rows;
}

function finalizeReport(report, startedAt, status) {
  report.finishedAt = new Date().toISOString();
  report.status = status;
  report.summary.durationMs = duration(startedAt);
  report.summary.issueCount = report.issues.length;
  report.summary.errorCount = report.issues.filter((entry) => entry.severity === "error").length;
  report.summary.warningCount = report.issues.filter((entry) => entry.severity === "warning").length;
  report.summary.observationCount = report.observations.length;
  report.summary.cleanupFailures = report.cleanup.filter((entry) => !entry.ok).length;
  report.issueGroups = buildIssueGroups(report);
  report.summary.uniqueIssueGroupCount = report.issueGroups.length;
  report.summary.stepPassed = report.steps.filter((entry) => entry.status === "passed").length;
  report.summary.stepWarning = report.steps.filter((entry) => entry.status === "warning").length;
  report.summary.stepFailed = report.steps.filter((entry) => entry.status === "failed").length;
  report.ok = status === "completed" && report.summary.errorCount === 0 && report.summary.cleanupFailures === 0;
  report.recommendations = buildRecommendations(report);
  return report;
}

export async function runSessionAudit(inputOptions = {}, { signal = null, onProgress = null } = {}) {
  const options = { ...DEFAULT_SESSION_AUDIT_OPTIONS, ...inputOptions };
  const report = createReport(options);
  const startedAt = now();
  const restoreRuntime = captureRuntime(report);
  let status = "completed";

  try {
    if (!game.user?.isGM) throw new Error("Полную проверку может запускать только ведущий.");
    if (game.system?.id !== "pf2e") throw new Error("Проверка рассчитана на активную систему PF2e.");

    await runStep(report, "environment", "Среда, версии и права", async () => {
      const diagnostics = await runDiagnostics();
      for (const failed of diagnostics.checks.filter((entry) => entry.required && !entry.ok)) {
        issue(report, "error", `diagnostics:${failed.id}`, `${failed.label}: ${failed.details || "проверка не пройдена"}`);
      }
      const api = game.modules?.get?.(MODULE_ID)?.api ?? {};
      const expected = ["openGenerator", "parseConcept", "generateNpc", "generateNpcBatch", "getPreview", "restoreFromHistoryEntry", "runDiagnostics", "runSessionAudit", "runUiControlAudit", "deployActorsToScene", "createEncounterBriefing", "createLauncherMacro"];
      const missing = expected.filter((key) => typeof api[key] !== "function");
      if (missing.length) issue(report, "error", "module-api-missing", `В API модуля отсутствуют функции: ${missing.join(", ")}.`);
      return { diagnostics, api: { expected, missing } };
    }, { signal, onProgress, critical: true });
    addCoverage(report, "environment", "Среда и обязательные API", "tested");

    await runStep(report, "module-files", "Чтение и хэши файлов установленного модуля", async () => auditModuleFiles(report, signal), { signal, onProgress });
    addCoverage(report, "module-files", "Фактически загруженные файлы модуля", "tested");

    await runStep(report, "ui", "Геометрия открытого интерфейса", async () => auditUiGeometry(report), { signal, onProgress });
    addCoverage(report, "ui", "Viewport, скролл и постоянный footer", "tested");

    await runStep(report, "ui-controls", "Физические нажатия безопасных кнопок интерфейса", async () => auditUiControls(report, options, signal), { signal, onProgress });
    addCoverage(report, "ui-controls", "Кнопки, режимы, пресеты и reroll в открытом окне", options.testUiControls ? "tested" : "skipped");

    await runStep(report, "dry-presets", "Предварительная сборка всех пресетов", async () => {
      for (const [presetId, preset] of Object.entries(BUILTIN_PRESETS)) {
        assertNotAborted(signal);
        getPreview(auditConcept(preset.values, { randomSeed: `${options.seed}:dry:${presetId}` }));
      }
      const person = randomFormValues({ seed: `${options.seed}:random-person` });
      const monster = randomMonsterFormValues(`${options.seed}:random-monster`, {});
      getPreview(auditConcept(person));
      getPreview(auditConcept(monster));
      return { presets: Object.keys(BUILTIN_PRESETS).length, randomCases: 2 };
    }, { signal, onProgress });
    addCoverage(report, "preview", "Парсер, рандомизатор и предпросмотр", "tested");

    await runStep(report, "matrix", "Матрица всех значений конструктора", async () => auditOptionMatrix(report, options, signal, onProgress), { signal, onProgress });
    addCoverage(report, "matrix", "Каждое происхождение, профессия, роль, броня, оружие, семейство, технология, источник и шаблон", options.testOptionMatrix ? "tested" : "skipped");

    await runStep(report, "random-live", "Живые случайные NPC и монстры", async () => auditRandomCases(report, options, signal, onProgress), { signal, onProgress });
    addCoverage(report, "random-live", "Многократный физический random-прогон", "tested", `${Math.max(1, Number(options.randomLiveCases) || 12) * 2} Actor`);

    await runStep(report, "presets", "Живое создание всех встроенных пресетов", async () => auditPresets(report, options, signal, onProgress), { signal, onProgress });
    addCoverage(report, "actor-create", "Actor.create и embedded Item для всех пресетов", options.liveActorCreation ? "tested" : "skipped", options.liveActorCreation ? "" : "Отключено в параметрах проверки.");

    await runStep(report, "batches", "Пакетное создание отряда и столкновения", async () => auditBatches(report, options, signal), { signal, onProgress });
    addCoverage(report, "batch", "Пакетная сборка и очистка", options.testBatchCreation ? "tested" : "skipped");

    await runStep(report, "integration", "Временные Journal, Scene, Token, Combat и Macro", async () => temporaryIntegrationTests(report, options, signal), { signal, onProgress });
    addCoverage(report, "journal", "Временный JournalEntry", options.testTemporaryJournal ? "tested" : "skipped");
    addCoverage(report, "scene", "Временные Scene, Token и Combat", options.testTemporaryScene ? "tested" : "skipped");
    addCoverage(report, "macro", "Временный Macro", options.testTemporaryMacro ? "tested" : "skipped");

    await runStep(report, "selected-workflows", "Выбранный NPC: keep/generated/all, backup, restore и duplicate", async () => auditSelectedWorkflows(report, options, signal), { signal, onProgress });
    addCoverage(report, "selected-update", "Физическая перестройка временного выбранного NPC и восстановление", options.testSelectedWorkflows ? "tested" : "skipped");

    await runStep(report, "deployment", "Физическое размещение всех формаций", async () => auditDeploymentModes(report, options, signal), { signal, onProgress });
    addCoverage(report, "deployment", "cluster, line, wedge, ring и Combat при безопасных условиях", options.testDeploymentModes ? "tested" : "skipped");

    await runStep(report, "storage", "Round-trip настроек, пресетов и истории", async () => auditStorageRoundTrip(report, options), { signal, onProgress });
    addCoverage(report, "storage", "Сохранение, импорт, экспорт, удаление и восстановление settings", options.testStorageRoundTrip ? "tested" : "skipped");

    await runStep(report, "chat", "Временный ChatMessage", async () => auditChatMessage(report, options), { signal, onProgress });
    addCoverage(report, "chat", "Физическое создание и удаление личного сообщения", options.testChatMessage ? "tested" : "skipped");

    await runStep(report, "all-pack-indexes", "Индексы всех компендиумов мира", async () => auditAllPackIndexes(report, options, signal, onProgress), { signal, onProgress });
    addCoverage(report, "all-pack-indexes", "Доступность каждого зарегистрированного компендиума", options.scanAllPackIndexes ? "tested" : "skipped");

    await runStep(report, "packs", "Глубокое чтение рабочих компендиумов", async () => auditCompendiums(report, options, signal, onProgress), { signal, onProgress });
    addCoverage(report, "packs", "Индексы и документы компендиумов", options.scanCompendiums ? "tested" : "skipped", options.deepCompendiumScan ? "Глубокий прогон всех документов." : `До ${options.maxDocumentsPerPack} документов на пакет.`);

    await runStep(report, "world", "Проверка Actor и embedded Item мира", async () => auditWorldActors(report, options, signal), { signal, onProgress });
    addCoverage(report, "world", "Чтение существующих Actor без изменений", options.scanWorldActors ? "tested" : "skipped");

    addCoverage(report, "artwork", "Семантическое качество выбранных изображений", "skipped", "Без компьютерного зрения проверяются только доступность путей и ошибки FilePicker.");
  } catch (error) {
    if (error?.name === "AbortError") {
      status = "cancelled";
      issue(report, "warning", "audit-cancelled", "Проверка остановлена пользователем; сохранён частичный отчёт.");
    } else {
      status = "failed";
      issue(report, "error", "audit-fatal", error.message ?? String(error), { error: serializeAuditError(error) });
    }
  } finally {
    restoreRuntime();
    const uncaught = report.captured.windowErrors.length;
    if (uncaught) {
      const moduleErrors = report.captured.windowErrors.filter((entry) => {
        const text = `${entry?.message ?? ""}
${entry?.reason?.message ?? ""}
${entry?.reason?.stack ?? ""}`;
        return text.includes(`/modules/${MODULE_ID}/`) || text.includes(`modules\\${MODULE_ID}\\`);
      });
      const externalErrors = report.captured.windowErrors.filter((entry) => !moduleErrors.includes(entry));
      if (moduleErrors.length) {
        issue(report, "error", "runtime-window-errors", `В коде Кузницы зафиксировано необработанных ошибок: ${moduleErrors.length}.`, { errors: moduleErrors });
      }
      if (externalErrors.length) {
        observation(report, "runtime-external-window-errors", `Во время проверки зафиксировано внешних ошибок Foundry или других модулей: ${externalErrors.length}.`, { errors: externalErrors });
      }
    }
    const externalErrors = report.captured.notifications.filter((entry) => entry.level === "error");
    if (externalErrors.length) issue(report, "warning", "runtime-notification-errors", `Во время проверки показано уведомлений об ошибках: ${externalErrors.length}.`, { notifications: externalErrors });
  }

  return finalizeReport(report, startedAt, status);
}

export function sessionAuditHtml(report) {
  const status = report.status === "cancelled" ? "Проверка остановлена" : report.ok ? "Полная проверка пройдена" : "Проверка нашла проблемы";
  const cls = report.ok ? "forge-check-ok" : report.status === "cancelled" ? "forge-check-warn" : "forge-check-fail";
  const topIssues = report.issues.slice(0, 12).map((entry) => `<li><strong>${entry.severity === "error" ? "Ошибка" : "Предупреждение"}:</strong> ${String(entry.message).replaceAll("<", "&lt;").replaceAll(">", "&gt;")}</li>`).join("");
  return `<div class="forge-diagnostics ${cls}">
    <h3>${status}</h3>
    <p>Шагов: ${report.steps.length}; ошибок: ${report.summary.errorCount}; корневых групп: ${report.summary.uniqueIssueGroupCount ?? report.summary.errorCount}; предупреждений: ${report.summary.warningCount}; наблюдений: ${report.summary.observationCount ?? 0}; длительность: ${(report.summary.durationMs / 1000).toFixed(1)} с.</p>
    ${topIssues ? `<ul>${topIssues}</ul>` : "<p>Критических проблем не зафиксировано.</p>"}
    <p><strong>Отчёт сохранён резервно внутри Foundry.</strong> Используй кнопки «Сохранить последний JSON» или «Скопировать JSON». Команда на загрузку больше не считается подтверждением сохранения файла.</p>
  </div>`;
}
