import { createRng, deriveSeed, pick, sample } from "./randomizer.js";
import { normalizeActionCategory } from "./schema-guard.js";

const action = (name, slug, actions, description, traits = [], category = "offensive") => ({
  name,
  slug,
  actionType: "action",
  actions,
  traits,
  category: normalizeActionCategory(category),
  description,
});
const passive = (name, slug, description, rules = []) => ({
  name,
  slug,
  actionType: "passive",
  actions: null,
  traits: [],
  category: "defensive",
  description,
  rules,
});
const reaction = (
  name,
  slug,
  description,
  traits = [],
  category = "offensive",
) => ({
  name,
  slug,
  actionType: "reaction",
  actions: null,
  traits,
  category: normalizeActionCategory(category),
  description,
});

function rolePool(role, context) {
  const { dc, damage } = context;
  const pools = {
    brute: {
      active: [
        action("Сокрушающий натиск", "forge-crushing-rush", 2, `<p>Существо Перемещается на расстояние до своей Скорости и наносит Удар. При попадании цель должна пройти @Check[fortitude|dc:${dc}] или будет оттолкнута на 5 футов.</p>`, ["flourish", "move"]),
        action("Размашистый удар", "forge-sweeping-blow", 2, `<p>Существо наносит по одному Удару двум разным целям в досягаемости. Оба Удара учитывают текущий штраф множественной атаки, но штраф увеличивается только после завершения действия.</p>`, ["flourish"]),
        action("Швырнуть прочь", "forge-hurl-away", 1, `<p><strong>Требования:</strong> существо удерживает противника. Оно совершает проверку Атлетики против КС Стойкости цели. При успехе бросает цель на 10 футов и наносит @Damage[${damage}[bludgeoning]] урона.</p>`, ["attack"]),
      ],
      passive: [
        passive("Неумолимый", "forge-relentless", "<p>Первый раз за бой, когда ОЗ существа опускаются ниже половины, оно получает 10 временных ОЗ.</p>"),
        passive("Тяжёлая туша", "forge-heavy-frame", "<p>Существо получает обстоятельственный бонус +1 к КС Стойкости против Толчка, Опрокидывания и принудительного перемещения.</p>"),
        passive("Угрожающая масса", "forge-menacing-bulk", "<p>Существо получает обстоятельственный бонус +1 к Запугиванию.</p>", [{ key: "FlatModifier", selector: "intimidation", type: "circumstance", value: 1 }]),
      ],
    },
    soldier: {
      active: [
        action("Защищённое продвижение", "forge-shielded-advance", 2, "<p>Существо Поднимает щит и Перемещается на расстояние до своей Скорости. Это перемещение не провоцирует реакции от первой клетки, которую оно покидает.</p>", ["move"]),
        action("Прижать к линии", "forge-press-the-line", 1, `<p>После успешного Удара существо может заставить цель пройти @Check[fortitude|dc:${dc}]. При провале цель становится застигнута врасплох до начала следующего хода существа.</p>`, ["press"]),
        reaction("Карающий выпад", "forge-punishing-lunge", "<p><strong>Триггер:</strong> противник в досягаемости использует действие с признаком move. Существо наносит по нему Удар со штрафом −2.</p>"),
      ],
      passive: [
        passive("Держать позицию", "forge-hold-position", "<p>Пока существо не двигалось с начала своего последнего хода, оно получает обстоятельственный бонус +1 к КБ против первой атаки каждого врага.</p>"),
        passive("Строевая выучка", "forge-formation-training", "<p>Когда рядом находится союзник, существо получает обстоятельственный бонус +1 к спасброскам против страха.</p>"),
        passive("Ветеран караула", "forge-watch-veteran", "<p>Существо получает обстоятельственный бонус +1 к Восприятию для инициативы и обнаружения засад.</p>", [{ key: "FlatModifier", selector: "perception", type: "circumstance", value: 1 }]),
      ],
    },
    skirmisher: {
      active: [
        action("Скользящая атака", "forge-darting-assault", 2, "<p>Существо делает Шаг, наносит Удар, затем снова делает Шаг. Оно не может закончить оба Шага в одной клетке.</p>", ["flourish", "move"]),
        action("Подсечь сухожилие", "forge-hamstring", 1, `<p>Существо наносит Удар со штрафом −2. При попадании Скорость цели уменьшается на 10 футов до конца её следующего хода.</p>`, ["flourish"]),
        reaction("Ускользнуть", "forge-slip-away", "<p><strong>Триггер:</strong> враг промахивается по существу атакой ближнего боя. Существо делает Шаг.</p>"),
      ],
      passive: [
        passive("Подвижный боец", "forge-mobile-combatant", "<p>Сложная местность от существ не снижает Скорость этого NPC.</p>"),
        passive("Оппортунист", "forge-opportunist", "<p>Существо наносит +1d4 точного урона целям, застигнутым врасплох.</p>"),
        passive("Скользкий", "forge-slippery", "<p>Существо получает обстоятельственный бонус +1 к Акробатике для Вырваться.</p>", [{ key: "FlatModifier", selector: "acrobatics", type: "circumstance", value: 1 }]),
      ],
    },
    sniper: {
      active: [
        action("Выверенный выстрел", "forge-measured-shot", 2, "<p>Существо наносит дальнобойный Удар с обстоятельственным бонусом +1. Этот Удар игнорирует обстоятельственный бонус цели к КБ от малого укрытия.</p>", ["concentrate", "flourish"]),
        action("Сменить позицию", "forge-relocate", 2, "<p>Существо Перемещается на расстояние до половины Скорости, затем Прячется или Крадётся.</p>", ["move"]),
        action("Пригвоздить", "forge-pinning-shot", 1, `<p>Существо наносит дальнобойный Удар со штрафом −2. При попадании цель должна пройти @Check[reflex|dc:${dc}] или станет обездвижена до конца своего следующего хода либо пока не потратит действие, чтобы освободиться.</p>`, ["flourish"]),
      ],
      passive: [
        passive("Терпеливый охотник", "forge-patient-hunter", "<p>Если существо не двигалось в свой предыдущий ход, его первый дальнобойный Удар в этом ходу наносит +1d6 точного урона.</p>"),
        passive("Преимущество высоты", "forge-high-ground", "<p>Находясь выше цели, существо получает обстоятельственный бонус +1 к дальнобойным атакам по ней.</p>"),
        passive("Тихая перезарядка", "forge-quiet-reload", "<p>Перезарядка оружия не выдаёт позицию скрытого существа автоматически; противники всё ещё могут Искать его.</p>"),
      ],
    },
    controller: {
      active: [
        action("Тактическое перемещение", "forge-tactical-reposition", 1, "<p>Один союзник в пределах 30 футов может реакцией сделать Шаг.</p>", ["auditory", "concentrate"], "interaction"),
        action("Обозначить цель", "forge-mark-target", 1, "<p>Существо выбирает видимого противника в пределах 60 футов. До начала следующего хода первая атака каждого союзника по этой цели получает обстоятельственный бонус +1.</p>", ["auditory", "concentrate"], "interaction"),
        action("Сломать строй", "forge-break-formation", 2, `<p>Все враги в 10-футовой эманации проходят @Check[will|dc:${dc}]. При провале они не могут использовать реакции до начала следующего хода существа.</p>`, ["auditory", "emotion", "mental"]),
      ],
      passive: [
        passive("Читает поле боя", "forge-battlefield-reader", "<p>Существо получает обстоятельственный бонус +1 к инициативе и проверкам Восприятия для Понять намерения.</p>"),
        passive("Приготовленные приказы", "forge-prepared-orders", "<p>В начале первого раунда один союзник в пределах 30 футов может сделать Шаг.</p>"),
        passive("Командное присутствие", "forge-command-presence", "<p>Союзники в пределах 15 футов получают бонус состояния +1 к спасброскам против страха.</p>"),
      ],
    },
    support: {
      active: [
        action("Подбодрить", "forge-rally", 1, "<p>Один союзник в пределах 30 футов получает 5 временных ОЗ и бонус состояния +1 к следующему спасброску Воли до начала следующего хода NPC.</p>", ["auditory", "emotion", "mental"], "interaction"),
        action("Отвлекающий совет", "forge-distracting-advice", 1, `<p>Один враг в пределах 30 футов проходит @Check[will|dc:${dc}]. При провале он становится застигнут врасплох для следующей атаки союзника до начала следующего хода NPC.</p>`, ["auditory", "linguistic", "mental"], "interaction"),
        reaction("Своевременная помощь", "forge-timely-aid", "<p><strong>Триггер:</strong> союзник в пределах 30 футов проваливает проверку навыка. NPC даёт ему обстоятельственный бонус +1, который может превратить провал в успех.</p>", ["fortune"]),
      ],
      passive: [
        passive("Находчивый", "forge-resourceful", "<p>Один раз за сцену NPC может достать обычный расходный предмет подходящего уровня, который правдоподобно был у него при себе.</p>"),
        passive("Спокойное присутствие", "forge-calm-presence", "<p>Союзники в пределах 10 футов получают обстоятельственный бонус +1 к проверкам для восстановления от страха.</p>"),
        passive("Читает людей", "forge-reads-people", "<p>Включи переключатель для Понять намерения; бонус +1 к Обману действует постоянно.</p>", [{ key: "RollOption", domain: "all", label: "Читает намерения", option: "forge:reads-people", toggleable: true }, { key: "FlatModifier", selector: "perception", type: "circumstance", value: 1, predicate: ["forge:reads-people"] }, { key: "FlatModifier", selector: "deception", type: "circumstance", value: 1 }]),
      ],
    },
    healer: {
      active: [
        action("Экстренная помощь", "forge-emergency-care", 2, `<p>NPC лечит соседнее живое существо на @Damage[${damage}[healing]] ОЗ. Одно и то же существо временно невосприимчиво на 10 минут.</p>`, ["healing", "manipulate"], "interaction"),
        action("Быстрая доза", "forge-quick-dose", 1, "<p>NPC достаёт и применяет к себе или соседнему добровольному существу зелье либо эликсир, находящийся у него в инвентаре.</p>", ["manipulate"], "interaction"),
        reaction("Не сейчас", "forge-not-yet", `<p><strong>Триггер:</strong> союзник в пределах 30 футов должен получить состояние dying. Он остаётся при 1 ОЗ, а затем временно невосприимчив к этой реакции на сутки.</p>`, ["healing"], "interaction"),
      ],
      passive: [
        passive("Клинический взгляд", "forge-clinical-eye", "<p>NPC мгновенно замечает явные болезни, яды и тяжёлые ранения. Включи переключатель при диагностике: он даёт обстоятельственный бонус +1 к Медицины.</p>", [{ key: "RollOption", domain: "all", label: "Клиническая диагностика", option: "forge:clinical-diagnosis", toggleable: true }, { key: "FlatModifier", selector: "medicine", type: "circumstance", value: 1, predicate: ["forge:clinical-diagnosis"] }]),
        passive("Запас медикаментов", "forge-medical-stock", "<p>При первом применении расходника лечения в сцене NPC не тратит его на результате 15+ на простой проверке.</p>"),
        passive("Уверенные руки", "forge-steady-hands-random", "<p>Провал проверки Медицины при Лечить раны считается обычным провалом, даже если должен был стать критическим.</p>"),
      ],
    },
    caster: {
      active: [
        action("Магический заслон", "forge-arcane-ward", 1, "<p>До начала следующего хода NPC получает обстоятельственный бонус +1 к КБ и спасброскам против заклинаний.</p>", ["concentrate", "magical"], "defensive"),
        action("Перегрузка заклинания", "forge-overchannel", 1, "<p>Следующее атакующее заклинание NPC в этом ходу наносит дополнительный урон, равный половине его уровня (минимум 1), но после применения NPC получает столько же урона силой.</p>", ["concentrate", "magical"]),
        reaction("Чутьё контрмагии", "forge-countermagic-sense", "<p><strong>Триггер:</strong> существо в пределах 60 футов начинает Сотворять заклинание. NPC получает обстоятельственный бонус +2 к проверке для распознавания этого заклинания.</p>", ["concentrate", "magical"]),
      ],
      passive: [
        passive("Магический резерв", "forge-magical-reserve", "<p>Один раз за бой NPC может повторно применить заклинание наивысшего доступного ранга, даже если соответствующие слоты закончились.</p>"),
        passive("Фокус школы", "forge-school-focus", "<p>Первое заклинание с уроном в каждом бою наносит дополнительный урон, равный рангу заклинания.</p>"),
        passive("Защитные формулы", "forge-defensive-formulas", "<p>NPC получает обстоятельственный бонус +1 к спасброскам против магии.</p>"),
      ],
    },
  };
  pools.gunner = {
    active: [
      action("Контролируемая очередь", "forge-controlled-burst", 2, "<p>Стрелок совершает две дальнобойные атаки по одной цели. Обе учитывают текущий штраф множественной атаки, но штраф увеличивается только после завершения действия.</p>", ["flourish", "tech"]),
      action("Подавляющий огонь", "forge-suppressive-fire", 2, `<p>Выбери 10-футовый взрыв в пределах первой дистанции оружия. Существа в области проходят @Check[will|dc:${dc}]. При провале становятся напуганы 1 и не могут использовать реакции до начала следующего хода стрелка.</p>`, ["auditory", "tech"]),
      action("Сменить батарею", "forge-combat-reload", 1, "<p>Стрелок Перезаряжает оружие или меняет батарею и делает Шаг.</p>", ["manipulate", "move", "tech"]),
    ],
    passive: [
      passive("Контроль отдачи", "forge-recoil-control", "<p>Первая дальнобойная атака после Перезарядки получает обстоятельственный бонус +1.</p>"),
      passive("Профессиональный боезапас", "forge-professional-ammo", "<p>Один раз за бой стрелок может считать пустой магазин или батарею заряженными без траты действия.</p>"),
    ],
  };
  pools.saboteur = {
    active: [
      action("Быстрый заряд", "forge-quick-charge", 2, `<p>Саботёр устанавливает заряд в соседней клетке. Первое существо, вошедшее туда, получает @Damage[${damage}[fire]] урона с @Check[reflex|dc:${dc}|basic] базовым спасброском Рефлекса.</p>`, ["manipulate", "tech"]),
      action("Глушащий импульс", "forge-jamming-pulse", 2, `<p>Технические устройства и конструкты в 10-футовой эманации проходят @Check[fortitude|dc:${dc}]. При провале становятся замедлены 1 на 1 раунд.</p>`, ["tech"]),
    ],
    passive: [
      passive("Заранее подготовил", "forge-prepared-saboteur", "<p>Саботёр начинает сцену с одним дополнительным подходящим техническим расходником или гранатой.</p>"),
      passive("Не оставляет следов", "forge-clean-exit", "<p>Для обнаружения следов работы саботёра требуется успех проверки против его КС Ремесла или Воровства.</p>"),
    ],
  };
  pools.technician = {
    active: [
      action("Аварийный ремонт", "forge-emergency-repair", 2, `<p>Техник восстанавливает соседнему конструкту, устройству или предмету @Damage[${damage}[healing]] ОЗ либо временно устраняет состояние сломан.</p>`, ["manipulate", "tech"], "interaction"),
      action("Перенаправить питание", "forge-reroute-power", 1, "<p>Один союзник с техническим оружием в пределах 30 футов получает бонус состояния +1 к следующей атаке или КБ до начала следующего хода техника.</p>", ["concentrate", "tech"], "interaction"),
    ],
    passive: [
      passive("Видит неисправность", "forge-sees-fault", "<p>Включи переключатель при поиске технических угроз: он даёт обстоятельственный бонус +1 к Восприятию, Ремеслу и Компьютерам.</p>", [{ key: "RollOption", domain: "all", label: "Поиск технической угрозы", option: "forge:technical-search", toggleable: true }, { key: "FlatModifier", selector: ["perception", "crafting", "computers"], type: "circumstance", value: 1, predicate: ["forge:technical-search"] }]),
      passive("Запасные детали", "forge-spare-parts", "<p>Один раз за сцену техник достаёт обычную батарею, кабель, деталь или инструмент подходящего уровня.</p>"),
    ],
  };
  pools.infiltrator = {
    active: [
      action("Призрачный проход", "forge-ghost-entry", 2, "<p>Лазутчик Перемещается на расстояние до половины Скорости, затем Крадётся или взаимодействует с замком, терминалом либо сигнализацией.</p>", ["move", "tech"]),
      action("Тихое устранение", "forge-silent-takedown", 2, "<p>Лазутчик наносит Удар по застигнутой врасплох цели. При попадании атака наносит дополнительно 1d6 точного урона, а цель не может использовать реакции до начала следующего хода лазутчика.</p>", ["flourish"]),
    ],
    passive: [
      passive("Поддельный доступ", "forge-false-clearance", "<p>Первый провал проверки Обмана или Компьютеров для прохождения охраны в сцене считается успехом, но оставляет подозрение.</p>"),
      passive("План отхода", "forge-extraction-route", "<p>В начале сцены лазутчик определяет ближайший путь отхода, укрытие и точку отключения сигнализации.</p>"),
    ],
  };
  const aliases = {
    ambusher: "skirmisher",
    packHunter: "skirmisher",
    defender: "soldier",
    artillery: "sniper",
    leader: "controller",
    berserker: "brute",
    lurker: "skirmisher",
    summoner: "caster",
  };
  return pools[role] ?? pools[aliases[role]] ?? pools.soldier;
}

function professionPool(profession, context) {
  const { dc, damage } = context;
  const pools = {
    merchant: {
      active: [
        action("Продать идею", "forge-sell-the-idea", 1, `<p>Враг в пределах 30 футов проходит @Check[will|dc:${dc}]. При провале до конца следующего хода NPC получает обстоятельственный бонус +1 к Обману и Дипломатии против него.</p>`, ["auditory", "linguistic", "mental"], "interaction"),
        reaction("У меня как раз есть", "forge-i-have-that", "<p><strong>Триггер:</strong> союзнику нужен обычный предмет не выше уровня NPC. Торговец достаёт подходящий предмет из товара; ведущий решает его цену и количество.</p>"),
      ],
      passive: [passive("Глаз оценщика", "forge-appraisers-eye", "<p>Торговец получает обстоятельственный бонус +2 к проверкам для определения стоимости, подделки и происхождения товара.</p>")],
    },
    hunter: {
      active: [action("Метка добычи", "forge-hunters-mark", 1, "<p>NPC выбирает одну видимую цель. До конца боя он получает обстоятельственный бонус +1 к Выслеживанию этой цели, а первый успешный Удар по ней в каждом раунде наносит +1d4 точного урона.</p>", ["concentrate"])],
      passive: [passive("Знает повадки", "forge-knows-habits", "<p>Включи переключатель против существа, которое NPC выслеживал хотя бы 10 минут: бонус +1 к Восприятию и Выживанию.</p>", [{ key: "RollOption", domain: "all", label: "Изученная добыча", option: "forge:studied-prey", toggleable: true }, { key: "FlatModifier", selector: ["perception", "survival"], type: "circumstance", value: 1, predicate: ["forge:studied-prey"] }])],
    },
    thief: {
      active: [action("Грязный финт", "forge-dirty-feint", 1, `<p>NPC совершает Финт. При успехе цель также получает штраф обстоятельства −1 к Восприятию до начала следующего хода NPC.</p>`, ["mental"] )],
      passive: [passive("Всегда выход", "forge-always-an-exit", "<p>В начале столкновения NPC автоматически замечает ближайший очевидный путь отхода или укрытие.</p>")],
    },
    bandit: {
      active: [action("Бери живым", "forge-take-alive", 1, "<p>До начала следующего хода атаки NPC получают признак nonlethal без штрафа и наносят +1 урона запуганным целям.</p>")],
      passive: [passive("Засадная привычка", "forge-ambush-habit", "<p>Если NPC начинает бой скрытым, он получает обстоятельственный бонус +1 к инициативе.</p>")],
    },
    doctor: {
      active: [action("Полевой стимулятор", "forge-field-stimulant", 1, "<p>Соседний союзник получает бонус состояния +10 футов к Скорости до конца своего следующего хода, после чего становится утомлён на 1 раунд.</p>", ["healing", "manipulate"], "interaction")],
      passive: [passive("Анатомические знания", "forge-anatomical-knowledge", "<p>Первый раз за раунд, когда NPC наносит точный урон живому существу, он наносит дополнительно 1 урон за каждые 4 уровня NPC (минимум 1).</p>")],
    },
    alchemist: {
      active: [action("Смешать на ходу", "forge-mix-on-the-fly", 1, "<p>NPC создаёт временный алхимический расходник из своего списка. Он должен быть использован до конца следующего хода.</p>", ["manipulate"] )],
      passive: [passive("Устойчивые реактивы", "forge-stable-reagents", "<p>NPC получает обстоятельственный бонус +1 к спасброскам против яда и алхимических эффектов.</p>")],
    },
    priest: {
      active: [action("Слово поддержки", "forge-word-of-support", 1, "<p>Один союзник в пределах 30 футов получает бонус состояния +1 к следующей атаке или спасброску до начала следующего хода жреца.</p>", ["auditory", "divine", "emotion", "mental"], "interaction")],
      passive: [passive("Освящённое присутствие", "forge-sanctified-presence", "<p>Нежить и нечисть в пределах 10 футов получают штраф обстоятельства −1 к проверкам для Деморализовать NPC.</p>")],
    },
    mage: {
      active: [action("Быстрая формула", "forge-quick-formula", 1, "<p>NPC меняет тип урона следующего магического эффекта в этом ходу на огонь, холод или электричество.</p>", ["concentrate", "magical"] )],
      passive: [passive("Память заклинателя", "forge-spell-memory", "<p>Включи переключатель при распознавании заклинания: NPC получает обстоятельственный бонус +1 к Аркане и Оккультизму.</p>", [{ key: "RollOption", domain: "all", label: "Распознавание заклинания", option: "forge:recognize-spell", toggleable: true }, { key: "FlatModifier", selector: ["arcana", "occultism"], type: "circumstance", value: 1, predicate: ["forge:recognize-spell"] }])],
    },
  };
  pools.engineer = {
    active: [action("Быстрая диагностика", "forge-quick-diagnostics", 1, "<p>NPC узнаёт одну важную уязвимость видимого устройства, конструкта или технического оружия.</p>", ["concentrate", "tech"], "interaction")],
    passive: [passive("Сертифицированный специалист", "forge-certified-specialist", "<p>NPC получает обстоятельственный бонус +1 к Ремеслу и Компьютерам.</p>", [{ key: "FlatModifier", selector: ["crafting", "computers"], type: "circumstance", value: 1 }])],
  };
  pools.technomancer = pools.mage;
  pools.mystic = {
    active: [action("Психическая поддержка", "forge-psychic-support", 1, "<p>Один союзник в пределах 30 футов получает бонус состояния +1 к следующему спасброску Воли.</p>", ["concentrate", "emotion", "mental"], "interaction")],
    passive: [passive("Чуткость к разуму", "forge-mental-sensitivity", "<p>Включи переключатель при попытке Понять намерения; бонус +1 к Оккультизму действует постоянно.</p>", [{ key: "RollOption", domain: "all", label: "Понять намерения", option: "forge:sense-motive", toggleable: true }, { key: "FlatModifier", selector: "perception", type: "circumstance", value: 1, predicate: ["forge:sense-motive"] }, { key: "FlatModifier", selector: "occultism", type: "circumstance", value: 1 }])],
  };
  const aliases = {
    mercenary: "warrior",
    operative: "thief",
    pilot: "scout",
    raider: "bandit",
    packHunter: "hunter",
    trapper: "thief",
    shaman: "priest",
    chieftain: "guard",
    tribalHunter: "hunter",
    beast: "hunter",
    undead: "bandit",
    necromancer: "mage",
    monster: "warrior",
    construct: "guard",
  };
  return pools[profession] ?? pools[aliases[profession]] ?? { active: [], passive: [] };
}

export function randomFeaturePlan(concept, context) {
  if (!concept.randomAbilities) return [];
  const seed = concept.seedAbilities ?? concept.randomSeed;
  const rng = createRng(deriveSeed(seed, "features"));
  const role = rolePool(concept.role, context);
  const profession = professionPool(concept.profession, context);
  const complexity = concept.complexity ?? "standard";
  const activeCount =
    complexity === "simple"
      ? 1
      : complexity === "tactical"
        ? concept.level >= 7
          ? 3
          : 2
        : concept.level >= 3
          ? 2
          : 1;
  const passiveCount =
    complexity === "simple"
      ? concept.level >= 4
        ? 1
        : 0
      : complexity === "tactical"
        ? concept.level >= 8
          ? 2
          : 1
        : concept.level >= 10
          ? 2
          : 1;
  const activePool = [...profession.active, ...role.active];
  const chosenActive = sample(activePool, activeCount, rng);
  if (!chosenActive.some((feature) => feature.actionType === "action")) {
    const actualAction = activePool.find((feature) => feature.actionType === "action");
    if (actualAction) chosenActive[0] = actualAction;
  }
  const passives = sample([...profession.passive, ...role.passive], passiveCount, rng);
  return [...chosenActive, ...passives];
}

const SPELLS = {
  arcane: {
    0: [["detect-magic", "Обнаружение магии"], ["electric-arc", "Электрическая дуга"], ["ignition", "Воспламенение"], ["shield", "Щит"], ["telekinetic-projectile", "Телекинетический снаряд"], ["light", "Свет"], ["message", "Сообщение"]],
    1: [["fear", "Страх"], ["force-barrage", "Силовой залп"], ["grease", "Смазка"], ["gust-of-wind", "Порыв ветра"], ["illusory-object", "Иллюзорный объект"], ["mystic-armor", "Мистическая броня"], ["sure-strike", "Верный удар"]],
    2: [["invisibility", "Невидимость"], ["mirror-image", "Зеркальное отражение"], ["resist-energy", "Сопротивление энергии"], ["see-the-unseen", "Видеть незримое"], ["revealing-light", "Проявляющий свет"]],
    3: [["fireball", "Огненный шар"], ["haste", "Ускорение"], ["slow", "Замедление"], ["lightning-bolt", "Молния"], ["dispel-magic", "Рассеивание магии"]],
    4: [["fly", "Полёт"], ["confusion", "Замешательство"], ["unfettered-movement", "Свободное движение"], ["mountain-resilience", "Стойкость горы"]],
    5: [["wall-of-stone", "Каменная стена"], ["sending", "Послание"], ["telekinetic-haul", "Телекинетическая переноска"]],
    6: [["chain-lightning", "Цепная молния"], ["disintegrate", "Дезинтеграция"], ["truesight", "Истинное зрение"], ["teleport", "Телепортация"]],
    7: [["energy-aegis", "Энергетическая эгида"], ["interplanar-teleport", "Межпланарный телепорт"], ["project-image", "Проекция"]],
    8: [["earthquake", "Землетрясение"], ["disappearance", "Исчезновение"], ["maze-of-locked-doors", "Лабиринт запертых дверей"]],
    9: [["foresight", "Предвидение"], ["falling-stars", "Падающие звёзды"], ["overwhelming-presence", "Подавляющее присутствие"]],
    10: [["cataclysm", "Катаклизм"], ["freeze-time", "Заморозка времени"], ["wish", "Желание"]],
  },
  divine: {
    0: [["guidance", "Наставление"], ["shield", "Щит"], ["light", "Свет"], ["detect-magic", "Обнаружение магии"], ["stabilize", "Стабилизация"], ["divine-lance", "Божественное копьё"]],
    1: [["heal", "Исцеление"], ["bless", "Благословение"], ["bane", "Проклятие"], ["sanctuary", "Святилище"], ["fear", "Страх"], ["protection", "Защита"]],
    2: [["restoration", "Восстановление"], ["resist-energy", "Сопротивление энергии"], ["spiritual-weapon", "Духовное оружие"], ["calm", "Спокойствие"], ["silence", "Тишина"]],
    3: [["heroism", "Героизм"], ["crisis-of-faith", "Кризис веры"], ["blindness", "Слепота"], ["dispel-magic", "Рассеивание магии"], ["noise-blast", "Взрыв звука"]],
    4: [["unfettered-movement", "Свободное движение"], ["divine-wrath", "Божественный гнев"], ["air-walk", "Хождение по воздуху"]],
    5: [["breath-of-life", "Дыхание жизни"], ["banishment", "Изгнание"], ["death-ward", "Защита от смерти"], ["sending", "Послание"]],
    6: [["blade-barrier", "Барьер клинков"], ["field-of-life", "Поле жизни"], ["truesight", "Истинное зрение"]],
    7: [["regenerate", "Регенерация"], ["resurrect", "Воскрешение"], ["divine-decree", "Божественный указ"]],
    8: [["divine-aura", "Божественная аура"], ["moment-of-renewal", "Миг обновления"]],
    9: [["foresight", "Предвидение"], ["overwhelming-presence", "Подавляющее присутствие"]],
    10: [["avatar", "Аватар"], ["miracle", "Чудо"]],
  },
  occult: {
    0: [["daze", "Ошеломление"], ["detect-magic", "Обнаружение магии"], ["shield", "Щит"], ["telekinetic-projectile", "Телекинетический снаряд"], ["message", "Сообщение"], ["read-aura", "Чтение ауры"]],
    1: [["soothe", "Успокоение"], ["fear", "Страх"], ["illusory-object", "Иллюзорный объект"], ["grim-tendrils", "Мрачные щупальца"], ["charm", "Очарование"], ["command", "Приказ"]],
    2: [["invisibility", "Невидимость"], ["mirror-image", "Зеркальное отражение"], ["laughing-fit", "Приступ смеха"], ["paranoia", "Паранойя"], ["silence", "Тишина"]],
    3: [["haste", "Ускорение"], ["slow", "Замедление"], ["heroism", "Героизм"], ["mind-reading", "Чтение мыслей"], ["enthrall", "Заворожить"]],
    4: [["confusion", "Замешательство"], ["suggestion", "Внушение"], ["phantasmal-killer", "Фантазм убийцы"], ["fly", "Полёт"]],
    5: [["synaptic-pulse", "Синаптический импульс"], ["sending", "Послание"], ["shadow-jump", "Теневой прыжок"]],
    6: [["dominate", "Подчинение"], ["truesight", "Истинное зрение"], ["phantasmal-calamity", "Фантазм бедствия"]],
    7: [["project-image", "Проекция"], ["warp-mind", "Искажение разума"]],
    8: [["disappearance", "Исчезновение"], ["uncontrollable-dance", "Неудержимый танец"]],
    9: [["foresight", "Предвидение"], ["weird", "Жуть"], ["overwhelming-presence", "Подавляющее присутствие"]],
    10: [["alter-reality", "Изменение реальности"]],
  },
  primal: {
    0: [["electric-arc", "Электрическая дуга"], ["ignition", "Воспламенение"], ["frostbite", "Обморожение"], ["tangle-vine", "Опутывающая лоза"], ["detect-magic", "Обнаружение магии"], ["light", "Свет"]],
    1: [["heal", "Исцеление"], ["fear", "Страх"], ["gust-of-wind", "Порыв ветра"], ["runic-body", "Руническое тело"], ["hydraulic-push", "Гидравлический толчок"], ["summon-animal", "Призыв животного"]],
    2: [["entangling-flora", "Опутывающая флора"], ["resist-energy", "Сопротивление энергии"], ["animal-form", "Форма животного"], ["acid-grip", "Кислотная хватка"], ["mist", "Туман"]],
    3: [["fireball", "Огненный шар"], ["lightning-bolt", "Молния"], ["haste", "Ускорение"], ["wall-of-wind", "Стена ветра"], ["aqueous-orb", "Водяная сфера"]],
    4: [["fly", "Полёт"], ["mountain-resilience", "Стойкость горы"], ["air-walk", "Хождение по воздуху"], ["unfettered-movement", "Свободное движение"]],
    5: [["wall-of-stone", "Каменная стена"], ["howling-blizzard", "Воющая метель"], ["elemental-form", "Форма элементаля"]],
    6: [["chain-lightning", "Цепная молния"], ["dragon-form", "Форма дракона"], ["field-of-life", "Поле жизни"]],
    7: [["regenerate", "Регенерация"], ["volcanic-eruption", "Извержение вулкана"]],
    8: [["earthquake", "Землетрясение"], ["monstrosity-form", "Форма чудовища"]],
    9: [["storm-of-vengeance", "Буря возмездия"], ["metamorphosis", "Метаморфоза"]],
    10: [["primal-herd", "Первобытное стадо"], ["cataclysm", "Катаклизм"]],
  },
};

export const SPELL_THEME_LABELS = {
  auto: "Автоматически",
  battle: "Боевой универсал",
  fire: "Огонь и разрушение",
  storm: "Буря и электричество",
  control: "Контроль поля",
  defense: "Защита и мобильность",
  illusion: "Иллюзии и обман",
  healing: "Лечение и поддержка",
  death: "Смерть и подавление",
  nature: "Природа и превращения",
  tech: "Техника и взлом",
  gravity: "Гравитация и пространство",
  time: "Время и вероятность",
  cosmic: "Космос и пустота",
};

const SPELL_THEME_SLUGS = {
  battle: new Set(["force-barrage", "sure-strike", "haste", "slow", "heroism", "dispel-magic", "spiritual-weapon", "divine-wrath", "telekinetic-projectile", "runic-body"]),
  fire: new Set(["ignition", "fireball", "falling-stars", "cataclysm", "alchemists-fire-lesser", "divine-wrath"]),
  storm: new Set(["electric-arc", "lightning-bolt", "chain-lightning", "gust-of-wind", "wall-of-wind", "storm-of-vengeance", "hydraulic-push", "aqueous-orb"]),
  control: new Set(["grease", "fear", "slow", "confusion", "maze-of-locked-doors", "command", "calm", "silence", "entangling-flora", "tangle-vine", "wall-of-stone", "wall-of-wind"]),
  defense: new Set(["shield", "mystic-armor", "mirror-image", "resist-energy", "invisibility", "fly", "unfettered-movement", "mountain-resilience", "energy-aegis", "sanctuary", "protection", "death-ward", "divine-aura"]),
  illusion: new Set(["illusory-object", "invisibility", "mirror-image", "phantasmal-killer", "project-image", "disappearance", "charm", "suggestion", "enthrall", "shadow-jump"]),
  healing: new Set(["heal", "soothe", "stabilize", "restoration", "breath-of-life", "field-of-life", "regenerate", "resurrect", "moment-of-renewal", "bless", "guidance"]),
  death: new Set(["bane", "fear", "grim-tendrils", "crisis-of-faith", "blindness", "phantasmal-killer", "dominate", "warp-mind", "weird", "overwhelming-presence"]),
  nature: new Set(["tangle-vine", "summon-animal", "animal-form", "entangling-flora", "mist", "wall-of-stone", "elemental-form", "dragon-form", "volcanic-eruption", "earthquake", "metamorphosis", "primal-herd"]),
  tech: new Set(["analyze-target", "implant-data", "recharge-weapon", "supercharge-weapon", "summon-robot", "inject-nanobots", "logic-bomb", "instant-virus", "speak-with-computers", "commune-with-tech", "control-machine", "overload-systems", "awaken-computer", "data-drain"]),
  gravity: new Set(["stumble", "personal-gravity", "electrotether", "gravity-field", "singularity-seed", "event-horizon"]),
  time: new Set(["warp-probability", "warp-time", "temporal-bullets", "times-edge", "accelerate", "chrono-push", "time-loop", "alternate-outcome", "new-game"]),
  cosmic: new Set(["seek-the-stars", "void-seed", "void-whispers", "entropy-strike", "pocket-vacuum", "slice-reality", "void-scour", "void-vessel", "call-cosmos", "atomic-blast"]),
};

const SF2E_SPELLS = {
  0: [["analyze-target", "Анализ цели"], ["implant-data", "Внедрение данных"], ["reorient", "Восстановить равновесие"], ["measure", "Измерение"], ["eldritch-lance", "Мистическое копьё"], ["injury-echo", "Отголосок травмы"], ["recharge-weapon", "Перезарядка оружия"], ["scan-environment", "Сканирование окружения"], ["stumble", "Притяжение земли"], ["ricochet", "Рикошет"]],
  1: [["adaptive-camouflage", "Адаптивный камуфляж"], ["cellular-stimulant", "Клеточный стимулятор"], ["overheat", "Перегрев"], ["supercharge-weapon", "Перегрузка оружия"], ["summon-robot", "Призыв робота"], ["mind-skewer", "Пронзание разума"], ["enhance-weapon", "Улучшить оружие"], ["enhance-body", "Улучшить тело"], ["sonic-scream", "Оглушительный крик"]],
  2: [["caustic-conversion", "Едкое преобразование"], ["inject-nanobots", "Инъекция наноботов"], ["logic-bomb", "Логическая бомба"], ["instant-virus", "Мгновенный вирус"], ["detect-thoughts", "Обнаружение мыслей"], ["temporal-bullets", "Темпоральные пули"], ["void-seed", "Семя пустоты"]],
  3: [["personal-gravity", "Личная гравитация"], ["discharge", "Разрядка"], ["electrotether", "Электроякорь"], ["entropy-strike", "Энтропийный удар"], ["selective-invisibility", "Избирательная невидимость"], ["irradiate", "Облучение"], ["void-whispers", "Шёпот из пустоты"]],
  4: [["elemental-barrier", "Стихийный барьер"], ["speak-with-computers", "Разговор с компьютерами"], ["accelerate", "Ускорить"], ["commune-with-tech", "Связь с технологиями"], ["genetic-regeneration", "Генетическая регенерация"], ["alternate-outcome", "Альтернативный исход"], ["vitality-nova", "Всплеск жизненности"]],
  5: [["overload-systems", "Перегрузка системы"], ["control-machine", "Управление механизмом"], ["subjective-reality", "Субъективная реальность"], ["chrono-push", "Темпоральный толчок"], ["wave-of-warning", "Волна тревоги"]],
  6: [["rocket-dash", "Реактивный рывок"], ["data-drain", "Вытягивание данных"], ["x-ray-vision", "Рентгеновское зрение"], ["awaken-computer", "Пробуждение компьютера"], ["time-loop", "Петля времени"], ["wall-of-plasma", "Стена плазмы"], ["quantum-analysis", "Квантовый анализ"]],
  7: [["wall-of-steel", "Стена из стали"], ["absolute-zero", "Абсолютный ноль"], ["void-scour", "Очищение пустотой"], ["death-sentence", "Смертный приговор"]],
  8: [["vitality-web", "Жизненная паутина"], ["phantasmal-fleet", "Призрачный флот"], ["singularity-seed", "Семя сингулярности"], ["gravity-field", "Гравитационное поле"], ["void-vessel", "Вместилище пустоты"]],
  9: [["telekinetic-tantrum", "Телекинетическое неистовство"], ["call-cosmos", "Призыв космоса"], ["atomic-blast", "Атомный взрыв"]],
  10: [["event-horizon", "Горизонт событий"], ["quantum-negation", "Квантовое отрицание"], ["new-game", "Новая игра"]],
};

function inferredSpellTheme(concept, profile, rng) {
  if (concept.spellTheme && concept.spellTheme !== "auto") return concept.spellTheme;
  if (concept.elements?.includes("fire")) return "fire";
  if (concept.elements?.includes("electricity") || concept.elements?.includes("water")) return "storm";
  if (["technomancer", "engineer"].includes(concept.profession)) return pick(["tech", "gravity", "time"], rng);
  if (concept.profession === "mystic") return pick(["healing", "cosmic", "gravity", "time"], rng);
  if (concept.technology === "starfinder") return pick(["tech", "gravity", "time", "cosmic"], rng);
  if (concept.profession === "doctor") return "healing";
  if (concept.profession === "priest") return pick(["healing", "defense", "battle", "death"], rng);
  if (profile.tradition === "primal") return pick(["nature", "storm", "healing", "control"], rng);
  if (profile.tradition === "occult") return pick(["illusion", "control", "death", "defense"], rng);
  return pick(["battle", "fire", "storm", "control", "defense", "illusion"], rng);
}

function themedSample(pool, count, theme, rng) {
  const preferred = SPELL_THEME_SLUGS[theme] ?? new Set();
  const themed = pool.filter(([slug]) => preferred.has(slug));
  const other = pool.filter(([slug]) => !preferred.has(slug));
  const result = sample(themed, Math.min(count, Math.max(1, Math.ceil(count * 0.67))), rng);
  const used = new Set(result.map(([slug]) => slug));
  const remainder = [...themed, ...other].filter(([slug]) => !used.has(slug));
  result.push(...sample(remainder, count - result.length, rng));
  return result;
}

function spellProfile(concept) {
  if (concept.profession === "technomancer") return { tradition: "arcane", ability: "int", prepared: "spontaneous", source: "sf2e" };
  if (concept.profession === "mystic") return { tradition: "occult", ability: "wis", prepared: "spontaneous", source: "sf2e" };
  if (concept.profession === "priest") return { tradition: "divine", ability: "wis", prepared: "prepared", source: "pf2e" };
  if (concept.profession === "shaman") return { tradition: "primal", ability: "wis", prepared: "prepared", source: "pf2e" };
  if (concept.profession === "necromancer") {
    const rng = createRng(deriveSeed(concept.randomSeed, "tradition"));
    return { tradition: pick(["occult", "divine"], rng), ability: "int", prepared: "prepared", source: "pf2e" };
  }
  if (concept.profession === "mage") {
    const rng = createRng(deriveSeed(concept.randomSeed, "tradition"));
    return { tradition: pick(["arcane", "arcane", "occult"], rng), ability: "int", prepared: "prepared", source: concept.contentSource === "sf2e" ? "mixed" : "pf2e" };
  }
  if (["caster", "summoner"].includes(concept.role)) {
    const rng = createRng(deriveSeed(concept.randomSeed, "tradition"));
    return { tradition: pick(["arcane", "occult", "primal", "divine"], rng), ability: "cha", prepared: "spontaneous", source: concept.contentSource === "sf2e" ? "sf2e" : concept.contentSource === "mixed" ? "mixed" : "pf2e" };
  }

  // Явно включённая пользователем магия доступна любой профессии. Это не
  // превращает роль в мага: боевые показатели остаются прежними, а лист
  // получает компактную тематическую запись заклинателя.
  if (concept.randomSpells) {
    const theme = concept.spellTheme && concept.spellTheme !== "auto" ? concept.spellTheme : null;
    const tradition = ["healing", "defense", "battle"].includes(theme)
      ? "divine"
      : ["nature", "storm"].includes(theme)
        ? "primal"
        : ["illusion", "control", "death", "cosmic", "time", "gravity"].includes(theme)
          ? "occult"
          : "arcane";
    const source = concept.contentSource === "sf2e" || concept.technology === "starfinder"
      ? "sf2e"
      : concept.contentSource === "mixed"
        ? "mixed"
        : "pf2e";
    const ability = ["healer", "support"].includes(concept.role)
      ? "wis"
      : ["technician", "controller"].includes(concept.role)
        ? "int"
        : "cha";
    return { tradition, ability, prepared: "spontaneous", source };
  }
  return null;
}

export function randomSpellPlan(concept) {
  if (!concept.randomSpells) return null;
  const profile = spellProfile(concept);
  if (!profile) return null;
  const seed = concept.seedSpells ?? concept.randomSeed;
  const rng = createRng(deriveSeed(seed, "spells"));
  const theme = inferredSpellTheme(concept, profile, rng);
  const maxRank = concept.level <= 0 ? 0 : Math.min(10, Math.max(1, Math.ceil(concept.level / 2)));
  const complexity = concept.complexity ?? "standard";
  const spells = [];
  const cantripCount = complexity === "simple" ? 4 : complexity === "tactical" ? 5 : 4;
  const rankPool = (rank) => {
    const classic = SPELLS[profile.tradition][rank] ?? [];
    const science = SF2E_SPELLS[rank] ?? [];
    if (profile.source === "sf2e") return science.length ? science : classic;
    if (profile.source === "mixed") return [...classic, ...science];
    return classic;
  };
  for (const [slug, name] of themedSample(rankPool(0), cantripCount, theme, rng)) {
    const source = SF2E_SPELLS[0]?.some(([candidate]) => candidate === slug) ? "sf2e" : "pf2e";
    spells.push({ slug, name, rank: 0, source });
  }
  for (let rank = 1; rank <= maxRank; rank += 1) {
    const count =
      complexity === "simple"
        ? 1
        : complexity === "tactical"
          ? rank === maxRank
            ? 3
            : 2
          : rank === maxRank
            ? 2
            : 2;
    const pool = rankPool(rank).length ? rankPool(rank) : rankPool(Math.max(1, rank - 1));
    for (const [slug, name] of themedSample(pool, count, theme, rng)) {
      const source = SF2E_SPELLS[rank]?.some(([candidate]) => candidate === slug) ? "sf2e" : "pf2e";
      spells.push({ slug, name, rank, source });
    }
  }
  const slots = Object.fromEntries(
    Array.from({ length: maxRank + 1 }, (_, rank) => [
      rank,
      rank === 0
        ? 0
        : complexity === "simple"
          ? 1
          : rank === maxRank
            ? 2
            : 3,
    ]),
  );
  return {
    ...profile,
    maxRank,
    theme,
    themeLabel: SPELL_THEME_LABELS[theme] ?? theme,
    spells,
    slots,
    name: `${profile.tradition === "divine" ? "Божественные" : profile.tradition === "occult" ? "Оккультные" : profile.tradition === "primal" ? "Природные" : "Арканные"} заклинания — ${SPELL_THEME_LABELS[theme] ?? theme}`,
  };
}

const CONSUMABLES = {
  healing: {
    minor: [["healing-potion-minor", "Малое зелье лечения"], ["elixir-of-life-minor", "Малый эликсир жизни"]],
    lesser: [["healing-potion-lesser", "Меньшее зелье лечения"], ["elixir-of-life-lesser", "Меньший эликсир жизни"]],
    moderate: [["healing-potion-moderate", "Умеренное зелье лечения"], ["elixir-of-life-moderate", "Умеренный эликсир жизни"]],
    greater: [["healing-potion-greater", "Большое зелье лечения"], ["elixir-of-life-greater", "Большой эликсир жизни"]],
    major: [["healing-potion-major", "Сильнейшее зелье лечения"], ["elixir-of-life-major", "Сильнейший эликсир жизни"]],
  },
  utility: [["antidote-lesser", "Противоядие"], ["antiplague-lesser", "Противочумное средство"], ["smoke-ball-lesser", "Малый дымный шар"], ["silver-salve", "Серебряная мазь"]],
  bombs: [["alchemists-fire-lesser", "Малый алхимический огонь"], ["acid-flask-lesser", "Малая кислотная склянка"], ["bottled-lightning-lesser", "Малая бутылочная молния"], ["frost-vial-lesser", "Малая морозная склянка"]],
  techHealing: [["medpatch-commercial", "Серийный медпластырь", "sf2e"], ["hypopen-commercial", "Серийный гипоспрей", "sf2e"], ["sprayflesh", "Спрей-плоть", "sf2e"]],
  techUtility: [["smoke-grenade-commercial", "Серийная дымовая граната", "sf2e"], ["flash-grenade-commercial", "Серийная световая граната", "sf2e"], ["commando-serum", "Сыворотка командос", "sf2e"], ["infiltrator-serum", "Сыворотка лазутчика", "sf2e"]],
  techBombs: [["frag-grenade-commercial", "Серийная осколочная граната", "sf2e"], ["electromag-grenade-commercial", "Серийная электромагнитная граната", "sf2e"], ["incendiary-grenade-commercial", "Серийная зажигательная граната", "sf2e"]],
};

function healingTier(level) {
  if (level >= 15) return "major";
  if (level >= 9) return "greater";
  if (level >= 5) return "moderate";
  if (level >= 2) return "lesser";
  return "minor";
}

export function randomConsumablePlan(concept) {
  if (!concept.randomConsumables) return [];
  const rng = createRng(deriveSeed(concept.seedConsumables ?? concept.randomSeed, "consumables"));
  const heal = CONSUMABLES.healing[healingTier(concept.level)];
  let pool = [];
  let count = 0;
  const tech = ["magitech", "starfinder"].includes(concept.technology) || ["mercenary", "engineer", "operative", "technomancer", "mystic", "pilot"].includes(concept.profession);
  if (tech && ["doctor", "mystic", "engineer"].includes(concept.profession)) {
    pool = [...CONSUMABLES.techHealing, ...CONSUMABLES.techUtility];
    count = concept.profession === "mystic" ? 4 : 5;
  } else if (tech && ["operative", "mercenary"].includes(concept.profession)) {
    pool = [...CONSUMABLES.techHealing, ...CONSUMABLES.techUtility, ...CONSUMABLES.techBombs];
    count = 4;
  } else if (tech) {
    pool = [...CONSUMABLES.techHealing, ...CONSUMABLES.techUtility];
    count = 2;
  } else if (concept.profession === "doctor") {
    pool = [...heal, ...CONSUMABLES.utility];
    count = 5;
  } else if (concept.profession === "alchemist") {
    pool = [...heal, ...CONSUMABLES.bombs, ...CONSUMABLES.utility];
    count = 7;
  } else if (["priest", "shaman"].includes(concept.profession)) {
    pool = [...heal, ...CONSUMABLES.utility.slice(0, 2)];
    count = 3;
  } else if (concept.profession === "necromancer") {
    pool = [...CONSUMABLES.utility, ...CONSUMABLES.bombs.slice(0, 1)];
    count = 2;
  } else if (["hunter", "scout", "bandit", "thief", "raider", "packHunter", "trapper", "tribalHunter"].includes(concept.profession)) {
    pool = [...heal, ...CONSUMABLES.utility];
    count = 2;
  } else if (concept.profession === "merchant") {
    pool = [...heal, ...CONSUMABLES.utility, ...CONSUMABLES.bombs.slice(0, 2)];
    count = 4;
  } else if (concept.level >= 2) {
    pool = heal;
    count = 1;
  }

  const lootMode = concept.includeLootPlan ? concept.lootRichness : "normal";
  if (lootMode === "poor") count = Math.min(count, 1);
  if (lootMode === "generous") count += 2;
  if (lootMode === "consumables") count += 4;
  const chosen = sample(pool, Math.min(pool.length, count), rng);
  return chosen.map(([slug, name, source], index) => {
    const professional = ["doctor", "mystic", "engineer", "alchemist", "priest"].includes(concept.profession);
    const lootQuantity = lootMode === "consumables" ? 2 : lootMode === "generous" && index < 2 ? 2 : 1;
    return {
      slug,
      name,
      source: source ?? "pf2e",
      quantity: Math.max(lootQuantity, professional && index < 2 ? 2 : 1),
    };
  });
}

export function randomContentPlan(concept, context) {
  return {
    features: randomFeaturePlan(concept, context),
    spells: randomSpellPlan(concept),
    consumables: randomConsumablePlan(concept),
  };
}
