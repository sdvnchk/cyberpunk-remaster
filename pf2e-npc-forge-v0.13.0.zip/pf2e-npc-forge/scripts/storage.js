import { contentPresetValues, safePresetValues } from "./presets.js";

const SETTINGS = {
  customPresets: "customPresets",
  lastForm: "lastForm",
  recentHistory: "recentHistory",
  lastAuditReportMeta: "lastAuditReportMeta",
};

function plain(value) {
  return JSON.parse(JSON.stringify(value ?? {}));
}

export function registerForgeSettings(moduleId) {
  game.settings.register(moduleId, SETTINGS.customPresets, {
    name: "Пользовательские заготовки Кузницы",
    hint: "Скрытое хранилище общих заготовок ведущего.",
    scope: "world",
    config: false,
    type: Object,
    default: { entries: {} },
  });
  game.settings.register(moduleId, SETTINGS.lastForm, {
    name: "Последние параметры Кузницы",
    hint: "Скрытая память формы для текущего пользователя.",
    scope: "user",
    config: false,
    type: Object,
    default: {},
  });
  game.settings.register(moduleId, SETTINGS.recentHistory, {
    name: "История Кузницы",
    hint: "Скрытая история последних сборок текущего пользователя.",
    scope: "user",
    config: false,
    type: Object,
    default: { entries: [] },
  });
  game.settings.register(moduleId, SETTINGS.lastAuditReportMeta, {
    name: "Последний отчёт полного прогона Кузницы",
    hint: "Метаданные резервной копии последнего runtime-аудита для текущего пользователя.",
    scope: "user",
    config: false,
    type: Object,
    default: {},
  });
}

export function getLastForm(moduleId) {
  const stored = plain(game.settings.get(moduleId, SETTINGS.lastForm));
  return {
    ...stored,
    target: "new",
    itemPolicy: "generated",
    backupOriginal: true,
    deploymentMode: "none",
    addToCombat: false,
    createBriefing: false,
    sendChatSummary: false,
    confirmRiskyOperations: true,
  };
}

export async function setLastForm(moduleId, values) {
  const safe = {
    ...safePresetValues(values),
    target: "new",
    count: Math.max(1, Math.min(20, Number(values.count) || 1)),
    itemPolicy: ["generated", "all", "keep"].includes(values.itemPolicy)
      ? values.itemPolicy
      : "generated",
    backupOriginal: true,
    openSheet: values.openSheet !== false,
    deploymentMode: "none",
    addToCombat: false,
    createBriefing: false,
    sendChatSummary: false,
    confirmRiskyOperations: true,
    includeSkillActions: values.includeSkillActions !== false,
    includeLootPlan: values.includeLootPlan === true,
  };
  return game.settings.set(moduleId, SETTINGS.lastForm, safe);
}

export function getCustomPresets(moduleId) {
  const stored = plain(game.settings.get(moduleId, SETTINGS.customPresets));
  if (!stored.entries || typeof stored.entries !== "object") return {};
  return Object.fromEntries(
    Object.entries(stored.entries).map(([id, preset]) => [
      id,
      {
        ...preset,
        values: contentPresetValues(preset?.values ?? {}),
      },
    ]),
  );
}

export async function saveCustomPreset(moduleId, name, values) {
  const cleanName = String(name ?? "").trim().slice(0, 60);
  if (!cleanName) throw new Error("Укажи название заготовки.");

  const entries = getCustomPresets(moduleId);
  const id =
    Object.entries(entries).find(([, preset]) => preset.name === cleanName)?.[0] ??
    `preset-${globalThis.crypto?.randomUUID?.() ?? Date.now()}`;
  entries[id] = {
    name: cleanName,
    values: contentPresetValues(values),
    updatedAt: new Date().toISOString(),
  };

  const ordered = Object.entries(entries)
    .sort(([, left], [, right]) =>
      String(right.updatedAt).localeCompare(String(left.updatedAt)),
    )
    .slice(0, 40);
  await game.settings.set(moduleId, SETTINGS.customPresets, {
    entries: Object.fromEntries(ordered),
  });
  return id;
}

export async function deleteCustomPreset(moduleId, id) {
  const entries = getCustomPresets(moduleId);
  if (!entries[id]) return false;
  delete entries[id];
  await game.settings.set(moduleId, SETTINGS.customPresets, { entries });
  return true;
}

export async function importCustomPresets(moduleId, payload) {
  const parsed = typeof payload === "string" ? JSON.parse(payload) : plain(payload);
  const incoming = parsed.entries ?? parsed;
  if (!incoming || typeof incoming !== "object" || Array.isArray(incoming)) {
    throw new Error("В файле нет подходящих заготовок.");
  }

  const entries = getCustomPresets(moduleId);
  let imported = 0;
  for (const [rawId, preset] of Object.entries(incoming)) {
    if (!preset || typeof preset !== "object") continue;
    const name = String(preset.name ?? "").trim().slice(0, 60);
    if (!name) continue;
    const id = `imported-${String(rawId).replace(/[^\w-]+/gu, "-").slice(0, 40)}-${imported}`;
    entries[id] = {
      name,
      values: contentPresetValues(preset.values ?? preset),
      updatedAt: new Date().toISOString(),
    };
    imported += 1;
  }
  if (!imported) throw new Error("Не найдено ни одной корректной заготовки.");

  await game.settings.set(moduleId, SETTINGS.customPresets, { entries });
  return imported;
}

export function exportCustomPresets(moduleId) {
  return {
    format: "pf2e-npc-forge-presets",
    version: 1,
    entries: getCustomPresets(moduleId),
  };
}

export function getRecentHistory(moduleId) {
  const stored = plain(game.settings.get(moduleId, SETTINGS.recentHistory));
  return Array.isArray(stored.entries) ? stored.entries : [];
}

export async function addRecentHistory(moduleId, concept, results) {
  const rows = Array.isArray(results) ? results : [results].filter(Boolean);
  const actors = rows.map((result) => result.actor).filter(Boolean);
  const backups = rows.map((result) => result.backup).filter(Boolean);
  const entry = {
    id: `history-${globalThis.crypto?.randomUUID?.() ?? Date.now()}`,
    createdAt: new Date().toISOString(),
    name: concept.name,
    level: concept.level,
    concept: plain(concept),
    actorUuids: actors.map((actor) => actor.uuid),
    backupUuids: backups.map((actor) => actor.uuid),
    warnings: rows.flatMap((result) => result?.warnings ?? []).slice(0, 30),
  };
  const entries = [entry, ...getRecentHistory(moduleId)].slice(0, 10);
  await game.settings.set(moduleId, SETTINGS.recentHistory, { entries });
  return entry;
}

export function getLastAuditReportMeta(moduleId) {
  return plain(game.settings.get(moduleId, SETTINGS.lastAuditReportMeta));
}

export async function setLastAuditReportMeta(moduleId, value) {
  return game.settings.set(moduleId, SETTINGS.lastAuditReportMeta, plain(value));
}
