export const BUILTIN_PRESETS = {
  guard: {
    label: "Стражник",
    icon: "fa-solid fa-shield-halved",
    description: "Строевой боец с копьём и щитом.",
    values: {
      prompt: "Обученный рядовой стражник, держит строй и прикрывает союзников.",
      level: 2,
      profession: "guard",
      role: "defender",
      armor: "medium",
      weapon: "spearShield",
      quality: "standard",
    },
  },
  bandit: {
    label: "Разбойник",
    icon: "fa-solid fa-mask",
    description: "Подвижный засадный боец.",
    values: {
      prompt: "Опытный деревенский разбойник, предпочитает засаду и грязные приёмы.",
      level: 2,
      profession: "bandit",
      role: "skirmisher",
      armor: "light",
      weapon: "shortsword",
      quality: "standard",
    },
  },
  scout: {
    label: "Разведчик",
    icon: "fa-solid fa-binoculars",
    description: "Наблюдатель, следопыт и лазутчик.",
    values: {
      prompt: "Осторожный разведчик, умеет выслеживать, скрываться и замечать опасность.",
      level: 2,
      profession: "scout",
      role: "skirmisher",
      armor: "light",
      weapon: "shortbow",
      quality: "standard",
    },
  },
  brute: {
    label: "Громила",
    icon: "fa-solid fa-hand-fist",
    description: "Живучий противник с тяжёлыми ударами.",
    values: {
      prompt: "Крупный и выносливый громила, который терпит удары и отвечает огромной силой.",
      level: 3,
      profession: "warrior",
      role: "brute",
      armor: "medium",
      weapon: "greataxe",
      quality: "standard",
    },
  },
  knight: {
    label: "Рыцарь",
    icon: "fa-solid fa-chess-knight",
    description: "Тяжеловооружённый фронтовик.",
    values: {
      prompt: "Дисциплинированный рыцарь в тяжёлых латах, уверенно держит передовую.",
      level: 3,
      profession: "knight",
      role: "defender",
      armor: "heavy",
      weapon: "longswordShield",
      quality: "standard",
    },
  },
  marksman: {
    label: "Стрелок",
    icon: "fa-solid fa-bullseye",
    description: "Опасный боец дальней дистанции.",
    values: {
      prompt: "Терпеливый стрелок, который выбирает выгодную позицию и бьёт издалека.",
      level: 2,
      profession: "hunter",
      role: "sniper",
      armor: "light",
      weapon: "crossbow",
      quality: "standard",
    },
  },
  doctor: {
    label: "Врач",
    icon: "fa-solid fa-kit-medical",
    description: "Специалист по Медицине с настоящими инструментами.",
    values: {
      prompt: "Практикующий врач, уверенно лечит раны и оказывает первую помощь.",
      level: 3,
      profession: "doctor",
      role: "healer",
      armor: "light",
      weapon: "dagger",
      quality: "standard",
    },
  },
  priest: {
    label: "Жрец",
    icon: "fa-solid fa-hands-praying",
    description: "Духовный наставник и лекарь.",
    values: {
      prompt: "Служитель веры, поддерживает союзников знаниями, лечением и твёрдой волей.",
      level: 3,
      profession: "priest",
      role: "healer",
      armor: "medium",
      weapon: "staff",
      quality: "standard",
    },
  },
  mage: {
    label: "Маг",
    icon: "fa-solid fa-wand-sparkles",
    description: "Заклинатель с рабочей магической атакой.",
    values: {
      prompt: "Учёный боевой маг, предпочитает держаться на расстоянии и атаковать огнём.",
      level: 3,
      profession: "mage",
      role: "caster",
      armor: "none",
      weapon: "staff",
      quality: "standard",
    },
  },
  commander: {
    label: "Командир",
    icon: "fa-solid fa-ranking-star",
    description: "Тактик, усиливающий строй.",
    values: {
      prompt: "Опытный командир отряда, читает поле боя и управляет действиями подчинённых.",
      level: 5,
      profession: "guard",
      role: "leader",
      armor: "heavy",
      weapon: "longswordShield",
      quality: "standard",
    },
  },
  miniBoss: {
    label: "Главарь",
    icon: "fa-solid fa-skull",
    description: "Сильный одиночный противник.",
    values: {
      prompt: "Опасный и стойкий главарь, который ведёт остальных и лично вступает в бой.",
      level: 3,
      profession: "warrior",
      role: "soldier",
      armor: "heavy",
      weapon: "greatsword",
      quality: "elite",
    },
  },

  shieldBearer: {
    label: "Щитоносец",
    icon: "fa-solid fa-shield",
    description: "Стоит впереди и прикрывает союзников.",
    values: { prompt: "Щитоносец держит узкий проход и закрывает союзников от атак.", level: 2, profession: "guard", role: "defender", armor: "heavy", weapon: "spearShield", quality: "standard" },
  },
  bodyguard: {
    label: "Телохранитель",
    icon: "fa-solid fa-user-shield",
    description: "Защищает одного важного союзника.",
    values: { prompt: "Телохранитель не отходит от подопечного, перехватывает угрозы и прикрывает отход.", level: 4, profession: "knight", role: "defender", armor: "medium", weapon: "longswordShield", quality: "standard", complexity: "tactical" },
  },
  duelist: {
    label: "Дуэлянт",
    icon: "fa-solid fa-khanda",
    description: "Быстрый одиночный боец.",
    values: { prompt: "Дуэлянт двигается между целями, провоцирует ошибки и быстро отступает.", level: 3, profession: "warrior", role: "skirmisher", armor: "light", weapon: "longsword", quality: "standard", complexity: "tactical" },
  },
  berserker: {
    label: "Берсерк",
    icon: "fa-solid fa-hand-fist",
    description: "Простой опасный боец в ближнем бою.",
    values: { prompt: "Берсерк сразу идёт на самую близкую цель и не отступает после первой раны.", level: 4, profession: "warrior", role: "berserker", armor: "light", weapon: "greataxe", quality: "standard", complexity: "simple" },
  },
  archer: {
    label: "Лучник",
    icon: "fa-solid fa-bullseye",
    description: "Обычный стрелок с луком.",
    values: { prompt: "Лучник держит дистанцию, ищет укрытие и меняет позицию после нескольких выстрелов.", level: 2, profession: "hunter", role: "sniper", armor: "light", weapon: "shortbow", quality: "standard", complexity: "simple" },
  },
  battlefieldMedic: {
    label: "Боевой медик",
    icon: "fa-solid fa-kit-medical",
    description: "Лечит под огнём и умеет отбиться.",
    values: { prompt: "Боевой медик держится за передовой, вытаскивает раненых и оказывает срочную помощь.", level: 4, profession: "doctor", role: "healer", armor: "medium", weapon: "shortsword", quality: "standard", complexity: "tactical", randomConsumables: true },
  },
  fieldPriest: {
    label: "Полевой жрец",
    icon: "fa-solid fa-hands-praying",
    description: "Лечение, защита и простая магия.",
    values: { prompt: "Полевой жрец лечит раненых, укрепляет строй и прикрывает отступление.", level: 4, profession: "priest", role: "support", armor: "medium", weapon: "staff", quality: "standard", randomSpells: true, spellTheme: "healing" },
  },
  alchemistSupport: {
    label: "Алхимик",
    icon: "fa-solid fa-flask",
    description: "Бомбы, лекарства и полезные смеси.",
    values: { prompt: "Алхимик раздаёт полезные смеси, лечит и бросает бомбы по ситуации.", level: 3, profession: "alchemist", role: "support", armor: "light", weapon: "dagger", quality: "standard", randomConsumables: true, complexity: "tactical" },
  },
  iceMage: {
    label: "Маг холода",
    icon: "fa-solid fa-snowflake",
    description: "Замедляет и контролирует поле.",
    values: { prompt: "Маг холода замедляет противников, закрывает проходы и держится вдали.", level: 5, profession: "mage", role: "controller", armor: "none", weapon: "staff", quality: "standard", randomSpells: true, spellTheme: "control", complexity: "tactical" },
  },
  necromancer: {
    label: "Некромант",
    icon: "fa-solid fa-skull",
    description: "Ослабляет врагов и поднимает слуг.",
    values: { prompt: "Некромант остаётся за слугами, ослабляет живых и использует магию смерти.", level: 6, profession: "necromancer", role: "summoner", armor: "none", weapon: "staff", quality: "standard", randomSpells: true, spellTheme: "death", complexity: "tactical" },
  },
  saboteur: {
    label: "Сапёр",
    icon: "fa-solid fa-bomb",
    description: "Ловушки, двери и разрушение объектов.",
    values: { prompt: "Сапёр заранее готовит ловушки, ломает механизмы и открывает путь группе.", level: 4, profession: "trapper", role: "saboteur", armor: "light", weapon: "crossbow", quality: "standard", complexity: "tactical" },
  },
  investigator: {
    label: "Следователь",
    icon: "fa-solid fa-magnifying-glass",
    description: "Ищет улики и замечает ложь.",
    values: { prompt: "Следователь осматривает место, задаёт точные вопросы и замечает несостыковки.", level: 3, profession: "scout", role: "support", armor: "light", weapon: "dagger", quality: "standard", complexity: "standard" },
  },
  merchant: {
    label: "Купец",
    icon: "fa-solid fa-coins",
    description: "Торговля, слухи и полезные товары.",
    values: { prompt: "Купец знает местные цены, слухи и людей, способных достать редкий товар.", level: 1, profession: "merchant", role: "support", armor: "none", weapon: "dagger", quality: "standard", complexity: "simple" },
  },
  smith: {
    label: "Кузнец",
    icon: "fa-solid fa-hammer",
    description: "Ремесленник и мастер ремонта.",
    values: { prompt: "Кузнец оценивает оружие, чинит снаряжение и знает местных поставщиков металла.", level: 2, profession: "warrior", role: "technician", armor: "medium", weapon: "maul", quality: "standard", complexity: "simple" },
  },


  spearman: {
    label: "Копейщик",
    icon: "fa-solid fa-person-military-rifle",
    description: "Простой строевой боец с длинным оружием.",
    values: { prompt: "Копейщик держит строй, встречает приближающихся врагов и прикрывает соседей.", level: 2, profession: "guard", role: "soldier", armor: "medium", weapon: "spear", quality: "standard", complexity: "simple" },
  },
  crossbowman: {
    label: "Арбалетчик",
    icon: "fa-solid fa-crosshairs",
    description: "Понятный дальнобойный противник.",
    values: { prompt: "Арбалетчик стреляет из укрытия, перезаряжается за спинами союзников и отходит при сближении.", level: 2, profession: "guard", role: "sniper", armor: "light", weapon: "crossbow", quality: "standard", complexity: "simple" },
  },
  thiefPreset: {
    label: "Вор",
    icon: "fa-solid fa-user-ninja",
    description: "Карманник, взломщик и скрытный противник.",
    values: { prompt: "Вор вскрывает замки, крадётся по тёмным местам и старается не принимать честный бой.", level: 2, profession: "thief", role: "lurker", armor: "light", weapon: "dagger", quality: "standard", complexity: "standard" },
  },
  hunterPreset: {
    label: "Охотник",
    icon: "fa-solid fa-paw",
    description: "Следы, засады и выживание в дороге.",
    values: { prompt: "Охотник читает следы, готовит засаду и знает повадки местных зверей.", level: 3, profession: "hunter", role: "ambusher", armor: "light", weapon: "shortbow", quality: "standard", complexity: "standard" },
  },
  druidPreset: {
    label: "Друид",
    icon: "fa-solid fa-leaf",
    description: "Природная магия и контроль местности.",
    values: { prompt: "Друид управляет растениями и зверями, закрывает проходы и лечит природной магией.", level: 4, profession: "shaman", role: "controller", armor: "light", weapon: "staff", quality: "standard", randomSpells: true, spellTheme: "nature", complexity: "tactical" },
  },

  goblinRaid: {
    label: "Гоблинский налёт",
    icon: "fa-solid fa-fire-flame-curved",
    description: "Шумная шайка с засадами, огнём и вожаком.",
    values: {
      prompt: "Гоблинская шайка, нападающая из засады и использующая огонь и мусорные ловушки.",
      creatureKind: "monster", monsterFamily: "goblin", ancestry: "goblin",
      level: 1, profession: "raider", role: "ambusher", armor: "light", weapon: "dogslicer",
      quality: "standard", complexity: "standard", count: 5, batchMode: "encounter",
    },
  },
  gnollPack: {
    label: "Стая гноллов",
    icon: "fa-solid fa-paw",
    description: "Стайные охотники, шаман и вожак.",
    values: {
      prompt: "Стая гноллов выслеживает добычу и окружает её перед нападением.",
      creatureKind: "monster", monsterFamily: "gnoll", ancestry: "gnoll",
      level: 3, profession: "packHunter", role: "packHunter", armor: "medium", weapon: "flail",
      quality: "standard", complexity: "standard", count: 5, batchMode: "encounter",
    },
  },
  koboldWarren: {
    label: "Логово кобольдов",
    icon: "fa-solid fa-land-mine-on",
    description: "Ловушки, пращники и драконий шаман.",
    values: {
      prompt: "Кобольды защищают тесное логово ловушками, пращами и путями отступления.",
      creatureKind: "monster", monsterFamily: "kobold", ancestry: "kobold",
      level: 1, profession: "trapper", role: "controller", armor: "light", weapon: "sling",
      quality: "standard", complexity: "tactical", count: 5, batchMode: "encounter",
    },
  },
  hobgoblinPatrol: {
    label: "Патруль хобгоблинов",
    icon: "fa-solid fa-people-group",
    description: "Строевой патруль с командиром и стрелком.",
    values: {
      prompt: "Дисциплинированный патруль хобгоблинов действует строем и по приказам командира.",
      creatureKind: "monster", monsterFamily: "hobgoblin", ancestry: "hobgoblin",
      level: 3, profession: "guard", role: "soldier", armor: "medium", weapon: "spearShield",
      quality: "standard", complexity: "standard", count: 5, batchMode: "encounter",
    },
  },
  bugbearAmbush: {
    label: "Засада багберов",
    icon: "fa-solid fa-eye-slash",
    description: "Тихие тяжёлые охотники для тёмного прохода.",
    values: {
      prompt: "Багберы терпеливо ждут в темноте и начинают бой сокрушительным внезапным ударом.",
      creatureKind: "monster", monsterFamily: "bugbear", ancestry: "bugbear",
      level: 4, profession: "raider", role: "lurker", armor: "light", weapon: "morningstar",
      quality: "standard", complexity: "standard", count: 3, batchMode: "encounter",
    },
  },
  iruxiHunters: {
    label: "Охотники ирукси",
    icon: "fa-solid fa-water",
    description: "Территориальная группа болотных охотников.",
    values: {
      prompt: "Ирукси защищают болото, используют воду, копья и знание местности.",
      creatureKind: "monster", monsterFamily: "lizardfolk", ancestry: "lizardfolk",
      level: 3, profession: "tribalHunter", role: "packHunter", armor: "medium", weapon: "spearShield",
      quality: "standard", complexity: "standard", count: 4, batchMode: "encounter",
    },
  },
  ogreGang: {
    label: "Банда огров",
    icon: "fa-solid fa-hammer",
    description: "Громилы, метатель и жестокий главарь.",
    values: {
      prompt: "Банда огров требует дань и крушит всё, что не может унести.",
      creatureKind: "monster", monsterFamily: "ogre", ancestry: "ogre",
      level: 5, profession: "monster", role: "brute", armor: "light", weapon: "maul",
      quality: "standard", complexity: "simple", count: 4, batchMode: "encounter",
    },
  },
  trollBridge: {
    label: "Тролль у моста",
    icon: "fa-solid fa-bridge",
    description: "Регенерирующий одиночный хищник.",
    values: {
      prompt: "Голодный тролль контролирует переправу, быстро восстанавливается и боится огня.",
      creatureKind: "monster", monsterFamily: "troll", ancestry: "troll",
      level: 6, profession: "monster", role: "berserker", armor: "none", weapon: "claws",
      quality: "elite", complexity: "tactical", count: 1, batchMode: "clones",
    },
  },
  undeadPatrol: {
    label: "Патруль нежити",
    icon: "fa-solid fa-skull-crossbones",
    description: "Скелеты, стрелки и мёртвый командир.",
    values: {
      prompt: "Оживлённые скелеты продолжают древнее патрулирование и подчиняются мёртвому командиру.",
      creatureKind: "undead", monsterFamily: "skeleton", ancestry: "skeleton",
      level: 2, profession: "undead", role: "soldier", armor: "medium", weapon: "spearShield",
      quality: "standard", complexity: "simple", count: 5, batchMode: "encounter",
    },
  },
  wolfPack: {
    label: "Волчья стая",
    icon: "fa-solid fa-dog",
    description: "Быстрые звери, окружающие слабую цель.",
    values: {
      prompt: "Голодная волчья стая выслеживает отставших и сбивает добычу с ног.",
      creatureKind: "beast", monsterFamily: "wolf", ancestry: "wolf",
      level: 1, profession: "beast", role: "packHunter", armor: "none", weapon: "jaws",
      quality: "standard", complexity: "simple", count: 5, batchMode: "encounter",
    },
  },
  spiderNest: {
    label: "Гнездо пауков",
    icon: "fa-solid fa-spider",
    description: "Паутина, яд и скрытые охотники.",
    values: {
      prompt: "Гигантские пауки защищают гнездо, опутывают проходы и утаскивают обездвиженную добычу.",
      creatureKind: "beast", monsterFamily: "giantSpider", ancestry: "giantSpider",
      level: 2, profession: "beast", role: "lurker", armor: "none", weapon: "jaws",
      quality: "standard", complexity: "standard", count: 4, batchMode: "encounter",
    },
  },
  hungryOoze: {
    label: "Голодная слизь",
    icon: "fa-solid fa-droplet",
    description: "Бесформенный поглотитель для подземелья.",
    values: {
      prompt: "Полупрозрачная слизь растворяет органику и почти не реагирует на обычные угрозы.",
      creatureKind: "ooze", monsterFamily: "ooze", ancestry: "ooze",
      level: 4, profession: "monster", role: "brute", armor: "none", weapon: "pseudopod",
      quality: "standard", complexity: "standard", count: 1, batchMode: "clones",
    },
  },
  ancientConstruct: {
    label: "Древний конструкт",
    icon: "fa-solid fa-robot",
    description: "Страж с протоколами и повреждённым приказом.",
    values: {
      prompt: "Древний конструкт охраняет закрытое хранилище и исполняет повреждённый протокол.",
      creatureKind: "construct", monsterFamily: "construct", ancestry: "construct",
      level: 5, profession: "construct", role: "defender", armor: "heavy", weapon: "slam",
      quality: "standard", complexity: "tactical", count: 1, batchMode: "clones",
    },
  },
  blackpowderRanger: {
    label: "Стрелок с мушкетом",
    icon: "fa-solid fa-gun",
    description: "Следопыт с однозарядным ружьём и запасным клинком.",
    values: {
      prompt: "Молчаливый следопыт с однозарядным ружьём, выслеживает одну цель и добивает её вблизи.",
      level: 4, profession: "hunter", role: "sniper", armor: "medium", weapon: "arquebus",
      technology: "blackpowder", contentSource: "pf2e", quality: "standard", complexity: "tactical",
    },
  },
  sfTrooper: {
    label: "Штурмовик",
    icon: "fa-solid fa-gun",
    description: "Обычный боец с лазерной винтовкой.",
    values: { prompt: "Штурмовик двигается с группой, ведёт огонь короткими очередями и занимает укрытия.", level: 3, profession: "mercenary", role: "soldier", armor: "medium", weapon: "laserRifle", technology: "starfinder", contentSource: "sf2e", quality: "standard", complexity: "simple" },
  },
  sfHeavy: {
    label: "Тяжёлый стрелок",
    icon: "fa-solid fa-burst",
    description: "Подавляет группу тяжёлым оружием.",
    values: { prompt: "Тяжёлый стрелок занимает позицию и не даёт противнику свободно перемещаться.", level: 5, profession: "mercenary", role: "gunner", armor: "heavy", weapon: "plasmaCaster", technology: "starfinder", contentSource: "sf2e", quality: "standard", complexity: "tactical" },
  },
  sfGuard: {
    label: "Щитовик",
    icon: "fa-solid fa-shield",
    description: "Держит проход и прикрывает отряд.",
    values: { prompt: "Щитовик идёт первым, закрывает проходы и прикрывает тех, кто работает с терминалом.", level: 4, profession: "mercenary", role: "defender", armor: "heavy", weapon: "plasmaSword", technology: "starfinder", contentSource: "sf2e", quality: "standard", complexity: "standard" },
  },
  sfMedic: {
    label: "Медик",
    icon: "fa-solid fa-kit-medical",
    description: "Гипоспреи, медпластыри и полевая помощь.",
    values: { prompt: "Медик стабилизирует раненых, раздаёт препараты и держится рядом с передовой.", level: 4, profession: "doctor", role: "healer", armor: "light", weapon: "laserPistol", technology: "starfinder", contentSource: "sf2e", quality: "standard", randomConsumables: true, complexity: "tactical" },
  },
  sfOfficer: {
    label: "Командир",
    icon: "fa-solid fa-ranking-star",
    description: "Координирует огонь и перемещение.",
    values: { prompt: "Командир отмечает цели, распределяет позиции и организует отход.", level: 6, profession: "mercenary", role: "leader", armor: "medium", weapon: "laserPistol", technology: "starfinder", contentSource: "sf2e", quality: "standard", complexity: "tactical" },
  },
  sfHacker: {
    label: "Хакер",
    icon: "fa-solid fa-laptop-code",
    description: "Взлом, саботаж и работа с терминалами.",
    values: { prompt: "Хакер отключает камеры, открывает двери и портит вражеские системы.", level: 5, profession: "operative", role: "saboteur", armor: "light", weapon: "semiAutoPistol", technology: "starfinder", contentSource: "sf2e", quality: "standard", complexity: "tactical" },
  },
  sfSniper: {
    label: "Снайпер",
    icon: "fa-solid fa-crosshairs",
    description: "Дальний огонь и смена позиции.",
    values: { prompt: "Снайпер выбирает дальнюю линию огня и меняет позицию после раскрытия.", level: 5, profession: "operative", role: "sniper", armor: "light", weapon: "laserRifle", technology: "starfinder", contentSource: "sf2e", quality: "standard", complexity: "tactical" },
  },
  sfPilot: {
    label: "Пилот",
    icon: "fa-solid fa-shuttle-space",
    description: "Транспорт, манёвры и аварийные действия.",
    values: { prompt: "Пилот управляет транспортом, оценивает маршрут и быстро реагирует на аварии.", level: 4, profession: "pilot", role: "skirmisher", armor: "light", weapon: "laserPistol", technology: "starfinder", contentSource: "sf2e", quality: "standard", complexity: "standard" },
  },


  sfScout: {
    label: "Разведчик",
    icon: "fa-solid fa-binoculars",
    description: "Наблюдение, скрытность и быстрый отход.",
    values: { prompt: "Разведчик проверяет маршрут, отмечает угрозы и не задерживается на одной позиции.", level: 3, profession: "operative", role: "skirmisher", armor: "light", weapon: "laserPistol", technology: "starfinder", contentSource: "sf2e", quality: "standard", complexity: "simple" },
  },
  sfTech: {
    label: "Техник",
    icon: "fa-solid fa-screwdriver-wrench",
    description: "Чинит оборудование и открывает системы.",
    values: { prompt: "Техник ремонтирует устройства, обходит блокировки и поддерживает снаряжение группы.", level: 3, profession: "engineer", role: "technician", armor: "light", weapon: "laserPistol", technology: "starfinder", contentSource: "sf2e", quality: "standard", complexity: "simple" },
  },
  sfBountyHunter: {
    label: "Охотник за целью",
    icon: "fa-solid fa-crosshairs",
    description: "Выслеживает и берёт цель живой или мёртвой.",
    values: { prompt: "Охотник за целью собирает данные, устраивает засаду и не теряет выбранного противника.", level: 5, profession: "operative", role: "sniper", armor: "medium", weapon: "laserRifle", technology: "starfinder", contentSource: "sf2e", quality: "standard", complexity: "tactical" },
  },
  sfSecurity: {
    label: "Охранник",
    icon: "fa-solid fa-shield-halved",
    description: "Простой защитник объекта или прохода.",
    values: { prompt: "Охранник держит пост, вызывает подкрепление и не позволяет пройти к защищаемому объекту.", level: 2, profession: "mercenary", role: "defender", armor: "medium", weapon: "shockTruncheon", technology: "starfinder", contentSource: "sf2e", quality: "standard", complexity: "simple" },
  },
  sfGrenadier: {
    label: "Гренадёр",
    icon: "fa-solid fa-bomb",
    description: "Расходники и площадной урон.",
    values: { prompt: "Гренадёр выкуривает врагов из укрытий, перекрывает проходы и носит запас боевых расходников.", level: 4, profession: "mercenary", role: "artillery", armor: "medium", weapon: "scattergun", technology: "starfinder", contentSource: "sf2e", quality: "standard", randomConsumables: true, complexity: "tactical" },
  },

  starfinderFireteam: {
    label: "Штурмовая группа",
    icon: "fa-solid fa-satellite-dish",
    description: "Согласованный технологический отряд с разными ролями.",
    values: {
      prompt: "Профессиональная штурмовая группа высокотехнологичных наёмников со связью и огневой поддержкой.",
      level: 5, profession: "mercenary", role: "gunner", armor: "medium", weapon: "laserRifle",
      technology: "starfinder", contentSource: "sf2e", quality: "standard", complexity: "standard",
      count: 5, batchMode: "squad", createBriefing: true,
    },
  },
  fieldEngineer: {
    label: "Инженер",
    icon: "fa-solid fa-screwdriver-wrench",
    description: "Ремонтирует устройства, ставит заслоны и поддерживает отряд.",
    values: {
      prompt: "Полевой инженер с ремонтным набором, диагностикой и средствами технической поддержки.",
      level: 4, profession: "engineer", role: "technician", armor: "light", weapon: "laserPistol",
      technology: "starfinder", contentSource: "sf2e", quality: "standard",
    },
  },
  infiltrator: {
    label: "Лазутчик",
    icon: "fa-solid fa-user-secret",
    description: "Проникновение, взлом, скрытая атака и отход.",
    values: {
      prompt: "Тихий оперативник, взламывает системы, проникает в охраняемые зоны и уходит до тревоги.",
      level: 5, profession: "operative", role: "infiltrator", armor: "light", weapon: "semiAutoPistol",
      technology: "starfinder", contentSource: "sf2e", quality: "standard", complexity: "tactical",
    },
  },
  technomancer: {
    label: "Техномант",
    icon: "fa-solid fa-microchip",
    description: "Рабочий список заклинаний SF2e и техническое оружие.",
    values: {
      prompt: "Техномант соединяет арканную магию с вычислениями, управляет машинами и перегружает оружие.",
      level: 7, profession: "technomancer", role: "caster", armor: "light", weapon: "laserPistol",
      technology: "starfinder", contentSource: "sf2e", spellTheme: "tech", quality: "standard", complexity: "tactical",
    },
  },
  mystic: {
    label: "Мистик",
    icon: "fa-solid fa-brain",
    description: "Психическая поддержка, лечение и контроль разума.",
    values: {
      prompt: "Мистик лечит союзников, чувствует чужие мысли и подавляет волю противника.",
      level: 6, profession: "mystic", role: "healer", armor: "light", weapon: "shockTruncheon",
      technology: "starfinder", contentSource: "sf2e", spellTheme: "cosmic", quality: "standard", complexity: "tactical",
    },
  },

  civilian: {
    label: "Обыватель",
    icon: "fa-solid fa-person",
    description: "Не боевой местный житель.",
    values: {
      prompt: "Обычный местный житель, знакомый со своим ремеслом и не ищущий драки.",
      level: 0,
      profession: "merchant",
      role: "support",
      armor: "none",
      weapon: "fists",
      quality: "standard",
    },
  },
};

export const PRESET_GROUPS = Object.freeze({
  assault: { label: "Бойцы", description: "Атакуют, двигаются и наносят урон", icon: "fa-solid fa-burst", tone: "assault", order: 10, open: true },
  defense: { label: "Защита", description: "Держат проход и прикрывают союзников", icon: "fa-solid fa-shield", tone: "defense", order: 20, open: true },
  support: { label: "Поддержка", description: "Лечат, усиливают, командуют и ремонтируют", icon: "fa-solid fa-hand-holding-medical", tone: "support", order: 30, open: true },
  magic: { label: "Магия", description: "Заклинания, контроль и призыв", icon: "fa-solid fa-wand-sparkles", tone: "magic", order: 40, open: false },
  specialist: { label: "Специалисты", description: "Разведка, взлом, ловушки и особые задачи", icon: "fa-solid fa-compass-drafting", tone: "specialist", order: 50, open: false },
  civilian: { label: "Мирные", description: "Ремесло, торговля и разговоры", icon: "fa-solid fa-people-roof", tone: "civilian", order: 60, open: false },
  monsters: { label: "Монстры", description: "Готовые противники и группы", icon: "fa-solid fa-dragon", tone: "monster", order: 70, open: false },
});

const ASSAULT_ROLES = new Set(["brute", "soldier", "skirmisher", "sniper", "artillery", "berserker", "gunner", "ambusher", "packHunter", "lurker"]);
const DEFENSE_ROLES = new Set(["defender"]);
const SUPPORT_ROLES = new Set(["healer", "support", "technician", "leader"]);
const MAGIC_ROLES = new Set(["caster", "controller", "summoner"]);
const SPECIALIST_ROLES = new Set(["saboteur", "infiltrator"]);

const PRESET_GROUP_OVERRIDES = Object.freeze({
  guard: "defense",
  knight: "defense",
  commander: "support",
  miniBoss: "assault",
  blackpowderRanger: "assault",
  starfinderFireteam: "assault",
  fieldEngineer: "support",
  infiltrator: "specialist",
  technomancer: "magic",
  mystic: "support",
  shieldBearer: "defense",
  bodyguard: "defense",
  battlefieldMedic: "support",
  fieldPriest: "support",
  alchemistSupport: "support",
  iceMage: "magic",
  necromancer: "magic",
  merchant: "civilian",
  smith: "civilian",
  sfTrooper: "assault",
  sfHeavy: "assault",
  sfGuard: "defense",
  sfMedic: "support",
  sfOfficer: "support",
  sfHacker: "specialist",
  sfSniper: "specialist",
  sfPilot: "specialist",
  thiefPreset: "specialist",
  hunterPreset: "specialist",
  druidPreset: "magic",
  sfScout: "specialist",
  sfBountyHunter: "specialist",
});

function presetSetting(preset) {
  const values = preset.values ?? {};
  return values.technology === "starfinder" || values.contentSource === "sf2e" ? "starfinder" : "fantasy";
}

function presetGroup(preset, id = "") {
  if (PRESET_GROUP_OVERRIDES[id]) return PRESET_GROUP_OVERRIDES[id];
  const values = preset.values ?? {};
  if (values.monsterFamily && values.monsterFamily !== "none") return "monsters";
  if (values.profession === "merchant" || preset.label === "Обыватель") return "civilian";
  if (SUPPORT_ROLES.has(values.role)) return "support";
  if (DEFENSE_ROLES.has(values.role)) return "defense";
  if (MAGIC_ROLES.has(values.role)) return "magic";
  if (SPECIALIST_ROLES.has(values.role) || ["scout", "thief", "operative", "engineer", "pilot", "trapper"].includes(values.profession)) return "specialist";
  if (ASSAULT_ROLES.has(values.role)) return "assault";
  return "specialist";
}

export function presetOptions() {
  return Object.entries(BUILTIN_PRESETS).map(([id, preset]) => {
    const group = presetGroup(preset, id);
    const setting = presetSetting(preset);
    return {
      id,
      category: group === "monsters" ? "monsters" : "people",
      setting,
      group,
      tone: PRESET_GROUPS[group]?.tone ?? "civilian",
      ...preset,
    };
  });
}

export function safePresetValues(values = {}) {
  const allowed = [
    "prompt",
    "forgeSetting",
    "name",
    "creatureKind",
    "monsterFamily",
    "level",
    "count",
    "ancestry",
    "gender",
    "profession",
    "role",
    "armor",
    "weapon",
    "quality",
    "tier_ac",
    "tier_hp",
    "tier_attack",
    "tier_damage",
    "tier_perception",
    "tier_fortitude",
    "tier_reflex",
    "tier_will",
    "tier_dc",
    "randomSeed",
    "seedPersonality",
    "seedAbilities",
    "seedSpells",
    "seedConsumables",
    "seedToken",
    "randomized",
    "complexity",
    "spellTheme",
    "technology",
    "contentSource",
    "deploymentMode",
    "addToCombat",
    "createBriefing",
    "sendChatSummary",
    "confirmRiskyOperations",
    "adventureMode",
    "includeLootPlan",
    "lootRichness",
    "monsterTemplate",
    "autoCorrect",
    "batchMode",
    "encounterDifficulty",
    "partyLevel",
    "partySize",
    "includeSkillActions",
    "randomAbilities",
    "randomSpells",
    "randomConsumables",
    "randomToken",
    "tokenPath",
    "tokenImage",
    "lockName",
    "lockLevel",
    "lockAncestry",
    "lockProfession",
    "lockRole",
    "lockGear",
  ];
  return Object.fromEntries(
    allowed
      .filter((key) => values[key] !== undefined && values[key] !== null)
      .map((key) => [key, values[key]]),
  );
}

const COMPLETE_PRESET_DEFAULTS = Object.freeze({
  prompt: "",
  forgeSetting: "fantasy",
  name: "",
  creatureKind: "person",
  monsterFamily: "none",
  level: 1,
  ancestry: "human",
  gender: "unspecified",
  profession: "warrior",
  role: "soldier",
  armor: "light",
  weapon: "longsword",
  quality: "standard",
  complexity: "standard",
  spellTheme: "auto",
  includeSkillActions: true,
  randomAbilities: true,
  randomSpells: false,
  randomConsumables: true,
  randomToken: false,
  technology: "fantasy",
  contentSource: "auto",
  adventureMode: "off",
  includeLootPlan: false,
  lootRichness: "normal",
  monsterTemplate: "none",
  batchMode: "clones",
  encounterDifficulty: "none",
  count: 1,
  tokenImage: "",
  randomized: false,
  tier_ac: "auto",
  tier_hp: "auto",
  tier_attack: "auto",
  tier_damage: "auto",
  tier_perception: "auto",
  tier_fortitude: "auto",
  tier_reflex: "auto",
  tier_will: "auto",
  tier_dc: "auto",
});

/**
 * A preset is a complete character concept, not a partial patch. Filling all
 * identity fields prevents a previous monster family, ancestry, prompt or
 * batch mode from leaking into the newly selected preset.
 */
export function completePresetValues(values = {}) {
  const completed = {
    ...COMPLETE_PRESET_DEFAULTS,
    ...safePresetValues(values),
  };
  if (values.forgeSetting === undefined) {
    completed.forgeSetting = completed.technology === "starfinder" || completed.contentSource === "sf2e"
      ? "starfinder"
      : "fantasy";
  }
  if (values.randomSpells === undefined) {
    completed.randomSpells = ["priest", "mage", "shaman", "necromancer", "technomancer", "mystic"].includes(completed.profession)
      || ["caster", "summoner"].includes(completed.role);
  }
  return completed;
}


const CUSTOM_PRESET_EXCLUDED = new Set([
  "deploymentMode",
  "addToCombat",
  "createBriefing",
  "sendChatSummary",
  "confirmRiskyOperations",
]);

export function contentPresetValues(values = {}) {
  return Object.fromEntries(
    Object.entries(safePresetValues(values)).filter(([key]) => !CUSTOM_PRESET_EXCLUDED.has(key)),
  );
}
