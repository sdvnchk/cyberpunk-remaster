const DB_NAME = "pf2e-npc-forge-audit-reports";
const DB_VERSION = 1;
const STORE_NAME = "reports";
const LAST_REPORT_KEY = "last-session-audit";

let memoryRecord = null;

function plain(value) {
  try {
    return JSON.parse(JSON.stringify(value ?? null));
  } catch {
    return value ?? null;
  }
}

function safeStamp(value = new Date().toISOString()) {
  return String(value).replaceAll(":", "-").replaceAll(".", "-");
}

export function auditReportFilename(report = {}) {
  const stamp = safeStamp(report.createdAt || new Date().toISOString());
  return `pf2e-npc-forge-session-audit-${stamp}.json`;
}

export function serializeAuditReport(report) {
  return JSON.stringify(report, null, 2);
}

export function textByteSize(text) {
  if (typeof TextEncoder === "function") return new TextEncoder().encode(String(text)).byteLength;
  return String(text).length;
}

export function formatByteSize(bytes) {
  const value = Math.max(0, Number(bytes) || 0);
  if (value < 1024) return `${value} Б`;
  if (value < 1024 ** 2) return `${(value / 1024).toFixed(1)} КБ`;
  return `${(value / 1024 ** 2).toFixed(2)} МБ`;
}

function openDatabase() {
  return new Promise((resolve, reject) => {
    if (!globalThis.indexedDB) {
      reject(new Error("IndexedDB недоступен в этом клиенте."));
      return;
    }
    const request = globalThis.indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error ?? new Error("Не удалось открыть локальное хранилище отчётов."));
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME, { keyPath: "key" });
    };
    request.onsuccess = () => resolve(request.result);
  });
}

async function idbPut(record) {
  const db = await openDatabase();
  try {
    await new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, "readwrite");
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error("Не удалось записать отчёт в IndexedDB."));
      transaction.objectStore(STORE_NAME).put(record);
    });
  } finally {
    db.close();
  }
}

async function idbGet() {
  const db = await openDatabase();
  try {
    return await new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, "readonly");
      const request = transaction.objectStore(STORE_NAME).get(LAST_REPORT_KEY);
      request.onsuccess = () => resolve(request.result ?? null);
      request.onerror = () => reject(request.error ?? new Error("Не удалось прочитать последний отчёт из IndexedDB."));
    });
  } finally {
    db.close();
  }
}

function filePickerClass() {
  return globalThis.foundry?.applications?.apps?.FilePicker ?? globalThis.FilePicker ?? null;
}

function uploadResponsePath(response) {
  if (!response || typeof response !== "object") return null;
  for (const key of ["path", "url", "src", "file"]) {
    if (typeof response[key] === "string" && response[key]) return response[key];
  }
  if (Array.isArray(response.files) && typeof response.files[0] === "string") return response.files[0];
  if (response.data && typeof response.data === "object") return uploadResponsePath(response.data);
  return null;
}

function makeRecord(report, filename = auditReportFilename(report)) {
  const json = serializeAuditReport(report);
  return {
    key: LAST_REPORT_KEY,
    filename,
    json,
    bytes: textByteSize(json),
    createdAt: report.createdAt ?? new Date().toISOString(),
    savedAt: new Date().toISOString(),
    status: report.status ?? "running",
    ok: report.ok === true,
    summary: plain(report.summary ?? {}),
  };
}

async function updateMeta(saveMeta, record, extra = {}) {
  if (typeof saveMeta !== "function") return;
  await saveMeta({
    filename: record.filename,
    bytes: record.bytes,
    createdAt: record.createdAt,
    savedAt: record.savedAt,
    status: record.status,
    ok: record.ok,
    summary: record.summary,
    ...plain(extra),
  });
}

/**
 * Save an in-progress checkpoint locally. It does not make a browser download and
 * therefore cannot be blocked by the desktop Chromium download manager.
 */
export async function checkpointAuditReport(moduleId, report, { saveMeta = null } = {}) {
  const filename = auditReportFilename(report);
  const record = makeRecord(report, filename);
  memoryRecord = record;
  let indexedDb = { ok: false, error: null };
  try {
    await idbPut(record);
    indexedDb = { ok: true, error: null };
  } catch (error) {
    indexedDb = { ok: false, error: error?.message ?? String(error) };
  }
  await updateMeta(saveMeta, record, {
    moduleId,
    durableLocalCopy: indexedDb.ok,
    persistentStorageCopy: false,
    persistentPath: null,
    checkpoint: true,
  });
  return { record, indexedDb };
}

/**
 * Persist the final report twice: in the desktop/browser profile (IndexedDB) and,
 * when Foundry permits it, in the module's persistent /storage directory.
 */
export async function persistAuditReport(moduleId, report, { saveMeta = null } = {}) {
  const filename = auditReportFilename(report);
  report.delivery = {
    filename,
    preparedAt: new Date().toISOString(),
    automaticDownloadClaimed: false,
    note: "Отчёт сохраняется резервно; загрузка на диск выполняется отдельной кнопкой пользователя.",
  };

  let record = makeRecord(report, filename);
  memoryRecord = record;

  let indexedDb = { ok: false, error: null };
  try {
    await idbPut(record);
    indexedDb.ok = true;
  } catch (error) {
    indexedDb.error = error?.message ?? String(error);
  }

  let persistent = { ok: false, path: null, error: null, response: null };
  const FilePicker = filePickerClass();
  if (FilePicker?.uploadPersistent && typeof File === "function") {
    try {
      const file = new File([record.json], filename, { type: "application/json" });
      const response = await FilePicker.uploadPersistent(moduleId, "", file, {}, { notify: false });
      persistent = {
        ok: true,
        path: uploadResponsePath(response) ?? `modules/${moduleId}/storage/${filename}`,
        error: null,
        response: plain(response),
      };
    } catch (error) {
      persistent.error = error?.message ?? String(error);
    }
  } else {
    persistent.error = "FilePicker.uploadPersistent недоступен.";
  }

  report.delivery = {
    ...report.delivery,
    durableLocalCopy: indexedDb.ok,
    persistentStorageCopy: persistent.ok,
    persistentPath: persistent.path,
    localError: indexedDb.error,
    persistentError: persistent.error,
    finalizedAt: new Date().toISOString(),
  };

  // Keep the final delivery information in the guaranteed local copy and memory.
  record = makeRecord(report, filename);
  memoryRecord = record;
  if (indexedDb.ok) {
    try {
      await idbPut(record);
    } catch (error) {
      indexedDb.ok = false;
      indexedDb.error = error?.message ?? String(error);
      report.delivery.durableLocalCopy = false;
      report.delivery.localError = indexedDb.error;
      record = makeRecord(report, filename);
      memoryRecord = record;
    }
  }

  await updateMeta(saveMeta, record, {
    moduleId,
    durableLocalCopy: indexedDb.ok,
    persistentStorageCopy: persistent.ok,
    persistentPath: persistent.path,
    persistentError: persistent.error,
    checkpoint: false,
  });

  return {
    ok: indexedDb.ok || persistent.ok,
    record,
    indexedDb,
    persistent,
  };
}

async function fetchPersistentRecord(meta) {
  const candidate = meta?.persistentPath;
  if (!candidate || typeof fetch !== "function") return null;
  const paths = [candidate];
  if (!/^(?:https?:)?\/\//u.test(candidate) && !candidate.startsWith("/")) {
    const routed = globalThis.foundry?.utils?.getRoute?.(candidate);
    if (routed && routed !== candidate) paths.push(routed);
  }
  for (const path of paths) {
    try {
      const response = await fetch(path, { cache: "no-store" });
      if (!response.ok) continue;
      const json = await response.text();
      JSON.parse(json);
      return {
        key: LAST_REPORT_KEY,
        filename: meta.filename,
        json,
        bytes: textByteSize(json),
        createdAt: meta.createdAt,
        savedAt: meta.savedAt,
        status: meta.status,
        ok: meta.ok === true,
        summary: plain(meta.summary ?? {}),
      };
    } catch {
      // Try the next possible route.
    }
  }
  return null;
}

export async function getLastAuditReportRecord({ meta = null } = {}) {
  if (memoryRecord?.json) return memoryRecord;
  try {
    const record = await idbGet();
    if (record?.json) {
      memoryRecord = record;
      return record;
    }
  } catch {
    // Server persistence is the next fallback.
  }
  const persistent = await fetchPersistentRecord(meta);
  if (persistent) {
    memoryRecord = persistent;
    return persistent;
  }
  return null;
}

function downloadByAnchor(json, filename) {
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.style.display = "none";
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/**
 * Explicit user action. With File System Access API this confirms a completed
 * write. The fallback can only confirm that a download request was dispatched.
 */
export async function saveAuditRecordAs(record) {
  if (!record?.json) throw new Error("Сохранённый отчёт не найден.");
  if (typeof globalThis.showSaveFilePicker === "function") {
    try {
      const handle = await globalThis.showSaveFilePicker({
        suggestedName: record.filename,
        types: [{ description: "JSON", accept: { "application/json": [".json"] } }],
      });
      const writable = await handle.createWritable();
      await writable.write(record.json);
      await writable.close();
      return { ok: true, confirmed: true, method: "file-system-access", filename: record.filename };
    } catch (error) {
      if (error?.name === "AbortError") return { ok: false, cancelled: true, confirmed: false, method: "file-system-access" };
      // Some Foundry desktop builds expose the method but reject it. Fall through.
    }
  }

  const saveDataToFile = globalThis.foundry?.utils?.saveDataToFile ?? globalThis.saveDataToFile;
  if (typeof saveDataToFile === "function") {
    saveDataToFile(record.json, "application/json", record.filename);
    return { ok: true, confirmed: false, method: "foundry-download-request", filename: record.filename };
  }

  downloadByAnchor(record.json, record.filename);
  return { ok: true, confirmed: false, method: "anchor-download-request", filename: record.filename };
}

export async function copyAuditRecord(record) {
  if (!record?.json) throw new Error("Сохранённый отчёт не найден.");
  if (globalThis.navigator?.clipboard?.writeText) {
    await globalThis.navigator.clipboard.writeText(record.json);
    return { ok: true, method: "clipboard" };
  }
  const textarea = document.createElement("textarea");
  textarea.value = record.json;
  textarea.style.position = "fixed";
  textarea.style.opacity = "0";
  document.body.append(textarea);
  textarea.focus();
  textarea.select();
  const ok = document.execCommand?.("copy") === true;
  textarea.remove();
  if (!ok) throw new Error("Клиент Foundry не разрешил копирование в буфер обмена.");
  return { ok: true, method: "legacy-copy" };
}

export function requestJsonDownload(payload, filename) {
  const json = typeof payload === "string" ? payload : JSON.stringify(payload, null, 2);
  const saveDataToFile = globalThis.foundry?.utils?.saveDataToFile ?? globalThis.saveDataToFile;
  if (typeof saveDataToFile === "function") {
    saveDataToFile(json, "application/json", filename);
    return { ok: true, confirmed: false, method: "foundry-download-request" };
  }
  downloadByAnchor(json, filename);
  return { ok: true, confirmed: false, method: "anchor-download-request" };
}
