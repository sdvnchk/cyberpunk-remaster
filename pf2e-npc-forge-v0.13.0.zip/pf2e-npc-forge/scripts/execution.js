export const EXECUTION_RISK = {
  none: 0,
  persistent: 1,
  scene: 2,
  destructive: 3,
};

function bool(value, fallback = false) {
  if (value === true || value === "true") return true;
  if (value === false || value === "false") return false;
  return fallback;
}

export function normalizeExecutionControls(concept = {}) {
  const normalized = { ...concept };
  const corrections = [];

  normalized.sendChatSummary = bool(normalized.sendChatSummary, false);
  normalized.confirmRiskyOperations = bool(normalized.confirmRiskyOperations, true);
  normalized.includeSkillActions = bool(normalized.includeSkillActions, true);
  normalized.includeLootPlan = bool(normalized.includeLootPlan, false);

  if (normalized.target === "new") {
    normalized.itemPolicy = "generated";
    normalized.backupOriginal = false;
  } else if (normalized.target === "duplicate") {
    normalized.itemPolicy = "generated";
    normalized.backupOriginal = false;
    normalized.count = 1;
  } else if (normalized.target === "selected") {
    normalized.count = 1;
  }

  if (normalized.deploymentMode === "none" && normalized.addToCombat) {
    normalized.addToCombat = false;
    corrections.push("Добавление в бой отключено: сначала нужно выбрать размещение жетонов на сцене.");
  }

  if (normalized.adventureMode === "off" && !normalized.includeLootPlan && normalized.createBriefing) {
    corrections.push("Журнал будет содержать только участников, характер и тактику: мастерский сценарий и план добычи отключены.");
  }

  return { concept: normalized, corrections };
}

function operation(key, label, { enabled = true, risk = "none", detail = "", count = null } = {}) {
  return { key, label, enabled, risk, detail, count };
}

export function buildExecutionPlan(concept = {}, preview = {}, selected = {}) {
  const prepared = normalizeExecutionControls(concept);
  const value = prepared.concept;
  const count = value.target === "new" ? Math.max(1, Number(value.count) || 1) : 1;
  const operations = [];
  const warnings = [...prepared.corrections];
  const blocking = [];

  if (value.target === "new") {
    operations.push(operation("actors-create", `Создать NPC в каталоге: ${count}`, { count }));
  } else if (value.target === "duplicate") {
    operations.push(operation("actor-duplicate", "Создать отдельную копию выбранного NPC", {
      risk: "scene",
      detail: "Выбранный жетон будет переназначен на новый Actor.",
      count: 1,
    }));
    if (!selected.available) blocking.push("Для создания копии выбери ровно один жетон NPC.");
  } else {
    operations.push(operation("actor-update", `Перестроить существующий NPC${selected.actorName ? ` «${selected.actorName}»` : ""}`, {
      risk: "destructive",
      detail: value.itemPolicy === "all"
        ? "Будут заменены все предметы, кроме эффектов и состояний."
        : value.itemPolicy === "keep"
          ? "Существующие предметы сохранятся; возможны дубликаты."
          : "Будут заменены только документы, ранее созданные Кузницей.",
      count: 1,
    }));
    if (!selected.available) blocking.push("Для перестройки выбери ровно один жетон NPC.");
    if (value.backupOriginal) {
      operations.push(operation("backup", "Создать резервную копию оригинала", {
        risk: "persistent",
        detail: "Копия будет сохранена в отдельной папке Actor.",
      }));
    } else {
      warnings.push("Резервная копия отключена: автоматическое восстановление исходного листа будет невозможно.");
    }
    if (value.itemPolicy === "all") {
      warnings.push("Выбран режим полной замены предметов: ручные действия и инвентарь NPC будут удалены после успешной сборки новых документов.");
    }
  }

  operations.push(operation("core", "Создать характеристики, атаки и обязательные особенности", {
    detail: `${preview.strikes?.length ?? 0} атак; базовая особенность роли и особенности семейства создаются независимо от случайного наполнения.`,
  }));
  operations.push(operation("skill-actions", "Добавить рабочие действия навыков", {
    enabled: value.includeSkillActions,
    detail: value.includeSkillActions
      ? "Включая панель проверок навыков и медицинские процедуры для лекарей."
      : "Отключено пользователем; модификаторы навыков Actor сохранятся, но отдельные кнопки не создаются.",
  }));
  const abilityCount = Number(preview.randomCounts?.abilities ?? 0);
  const spellCount = Number(preview.randomCounts?.spells ?? preview.spells?.length ?? 0);
  const consumableCount = Number(preview.randomCounts?.consumables ?? 0);
  operations.push(operation("abilities", "Добавить дополнительные активные и пассивные способности", {
    enabled: Boolean(value.randomAbilities && abilityCount > 0),
    detail: !value.randomAbilities
      ? "Отключено пользователем."
      : abilityCount > 0
        ? `Дополнительных способностей: ${abilityCount}.`
        : "Для выбранного концепта дополнительный набор не требуется.",
  }));
  operations.push(operation("spells", "Создать список заклинаний", {
    enabled: Boolean(value.randomSpells && spellCount > 0),
    detail: !value.randomSpells
      ? "Отключено пользователем; Кузница не включит его обратно автоматически."
      : spellCount > 0
        ? `Заклинаний в предварительном плане: ${spellCount}.`
        : "Настройка разрешена, но выбранный концепт не использует список заклинаний.",
  }));
  operations.push(operation("consumables", "Добавить дополнительные расходники", {
    enabled: Boolean(value.randomConsumables && consumableCount > 0),
    detail: !value.randomConsumables
      ? "Отключено пользователем; Кузница не включит их обратно автоматически."
      : consumableCount > 0
        ? `Дополнительных позиций расходников: ${consumableCount}.`
        : "Настройка разрешена, но для выбранного концепта расходники не подобраны.",
  }));
  operations.push(operation("artwork", "Изменить портрет и прототип жетона", {
    enabled: Boolean(value.tokenImage || value.randomToken),
    risk: value.target === "selected" || value.target === "duplicate" ? "persistent" : "none",
    detail: value.tokenImage
      ? `Использовать точный файл: ${value.tokenImage}`
      : value.randomToken
        ? "Подобрать изображение по доступным путям Foundry."
        : "Отключено; существующее изображение сохраняется при перестройке.",
  }));
  operations.push(operation("adventure", "Добавить мастерский сценарий в заметки NPC", {
    enabled: value.adventureMode !== "off",
    detail: value.adventureMode === "off" ? "Отключено пользователем." : `Режим: ${value.adventureMode}.`,
  }));
  operations.push(operation("loot-plan", "Добавить план тематической добычи", {
    enabled: value.includeLootPlan,
    detail: value.includeLootPlan ? `Насыщенность: ${value.lootRichness}.` : "Отключено пользователем.",
  }));
  operations.push(operation("journal", "Создать отдельный журнал ведущего", {
    enabled: value.createBriefing,
    risk: "persistent",
    detail: value.createBriefing ? "Будет создан новый JournalEntry." : "Отключено пользователем.",
  }));
  operations.push(operation("deployment", "Разместить жетоны на активной сцене", {
    enabled: value.deploymentMode !== "none",
    risk: "scene",
    detail: value.deploymentMode === "none" ? "Отключено пользователем." : `Формация: ${value.deploymentMode}.`,
    count: value.deploymentMode === "none" ? 0 : count,
  }));
  operations.push(operation("combat", "Добавить размещённые жетоны в бой", {
    enabled: value.addToCombat,
    risk: "scene",
    detail: value.addToCombat ? "Будет создан или изменён Combat активной сцены." : "Отключено пользователем.",
  }));
  operations.push(operation("chat", "Отправить личный технический отчёт GM", {
    enabled: value.sendChatSummary,
    risk: "persistent",
    detail: value.sendChatSummary ? "Сообщение увидит только текущий GM, но оно сохранится в истории чата." : "Отключено пользователем.",
  }));
  operations.push(operation("open-sheet", "Открыть лист после сборки", {
    enabled: value.openSheet,
    detail: value.openSheet ? "Интерфейсное действие без изменения данных." : "Отключено пользователем.",
  }));

  if (count >= 10) warnings.push(`Будет создано много Actor одновременно: ${count}.`);

  const enabled = operations.filter((entry) => entry.enabled);
  const highestRisk = enabled.reduce((max, entry) => Math.max(max, EXECUTION_RISK[entry.risk] ?? 0), 0);
  const requiresConfirmation = Boolean(value.confirmRiskyOperations) && (
    highestRisk >= EXECUTION_RISK.scene ||
    count >= 10 ||
    (value.target === "selected" && !value.backupOriginal)
  );

  return {
    concept: value,
    operations,
    enabled,
    warnings,
    blocking,
    highestRisk,
    requiresConfirmation,
    safeToRun: blocking.length === 0,
  };
}
