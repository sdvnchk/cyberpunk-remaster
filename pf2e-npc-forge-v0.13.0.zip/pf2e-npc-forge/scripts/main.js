import {
  ANCESTRIES,
  ARMORS,
  PROFESSIONS,
  ROLES,
  WEAPONS,
} from "./blueprints.js";
import {
  MODULE_ID,
  generateNpc,
  generateNpcBatch,
  getPreview,
  restoreFromHistoryEntry,
  selectedNpcInfo,
  emptySelectedNpcInfo,
  tablesForDebug,
} from "./generator.js";
import { conceptSummary, parseConcept } from "./parser.js";
import { BUILTIN_PRESETS, PRESET_GROUPS, completePresetValues, contentPresetValues, presetOptions, safePresetValues } from "./presets.js";
import {
  addRecentHistory,
  deleteCustomPreset,
  exportCustomPresets,
  getCustomPresets,
  getLastForm,
  getRecentHistory,
  getLastAuditReportMeta,
  importCustomPresets,
  registerForgeSettings,
  saveCustomPreset,
  setLastAuditReportMeta,
  setLastForm,
} from "./storage.js";
import { TIER_LABELS } from "./tables.js";
import { randomFormValues, randomSeed } from "./randomizer.js";
import { CREATURE_KINDS, MONSTER_FAMILIES, monsterFamilyOptions, randomMonsterFormValues } from "./monsters.js";
import { SPELL_THEME_LABELS } from "./random-content.js";
import { diagnosticsHtml, runDiagnostics } from "./diagnostics.js";
import { runSessionAudit, sessionAuditHtml } from "./session-auditor.js";
import {
  checkpointAuditReport,
  copyAuditRecord,
  formatByteSize,
  getLastAuditReportRecord,
  persistAuditReport,
  requestJsonDownload,
  saveAuditRecordAs,
} from "./audit-reports.js";
import { ENCOUNTER_DIFFICULTIES } from "./encounters.js";
import { CONTENT_SOURCES, TECHNOLOGY_LEVELS } from "./catalog.js";
import { DEPLOYMENT_MODES, deployActorsToScene } from "./deployment.js";
import { createEncounterBriefing } from "./briefing.js";
import { ADVENTURE_MODES, LOOT_RICHNESS, MONSTER_TEMPLATES } from "./director.js";
import { buildExecutionPlan } from "./execution.js";

const TEMPLATE = `modules/${MODULE_ID}/templates/generator.hbs`;
const FOOTER_TEMPLATE = `modules/${MODULE_ID}/templates/forge-footer.hbs`;
const WINDOW_SIZE_STORAGE_KEY = `${MODULE_ID}.window-size.v2`;

function storedForgeWindowSize() {
  try {
    const raw = globalThis.localStorage?.getItem?.(WINDOW_SIZE_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return { width: Number(parsed?.width) || undefined, height: Number(parsed?.height) || undefined };
  } catch {
    return {};
  }
}

function persistForgeWindowSize(position = {}) {
  const width = Math.round(Number(position.width) || 0);
  const height = Math.round(Number(position.height) || 0);
  if (width < 1 || height < 1) return;
  try {
    globalThis.localStorage?.setItem?.(WINDOW_SIZE_STORAGE_KEY, JSON.stringify({ width, height }));
  } catch {
    // Размер окна — удобство клиента, его сохранение не должно мешать Кузнице.
  }
}

function executionPlanHtml(plan) {
  if (!plan) return "";
  const rows = plan.operations
    .map((entry) => `<li class="forge-plan-${entry.enabled ? "on" : "off"}">
      <i class="fa-solid ${entry.enabled ? "fa-circle-check" : "fa-circle-minus"}"></i>
      <strong>${escapeHtml(entry.label)}</strong>${entry.detail ? ` — ${escapeHtml(entry.detail)}` : ""}
    </li>`)
    .join("");
  const blocking = plan.blocking.length
    ? `<div class="forge-plan-blocking"><strong>Запуск заблокирован:</strong><ul>${plan.blocking.map((value) => `<li>${escapeHtml(value)}</li>`).join("")}</ul></div>`
    : "";
  const warnings = plan.warnings.length
    ? `<div class="forge-plan-warnings"><strong>Обрати внимание:</strong><ul>${plan.warnings.map((value) => `<li>${escapeHtml(value)}</li>`).join("")}</ul></div>`
    : "";
  return `<section class="forge-execution-plan">
    <div class="forge-coherence-head"><strong>План выполнения</strong><span>${plan.enabled.length} включённых операций</span></div>
    <ul>${rows}</ul>${blocking}${warnings}
    <p class="forge-help">Серые пункты не выполняются. Кузница повторно рассчитывает этот план непосредственно перед запуском.</p>
  </section>`;
}

function executionPlanText(plan) {
  const enabled = plan.enabled.map((entry) => `• ${entry.label}${entry.detail ? ` — ${entry.detail}` : ""}`);
  const warnings = plan.warnings.map((value) => `⚠ ${value}`);
  return [
    "Кузница выполнит:",
    ...enabled,
    ...(warnings.length ? ["", "Предупреждения:", ...warnings] : []),
    "",
    "Продолжить?",
  ].join("\n");
}

async function confirmExecutionPlan(plan) {
  if (!plan.safeToRun) throw new Error(plan.blocking.join(" "));
  if (!plan.requiresConfirmation) return true;
  return globalThis.confirm(executionPlanText(plan));
}

function optionList(record) {
  return Object.entries(record).map(([value, data]) => ({
    value,
    label: data.label,
  }));
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function signed(value) {
  return Number(value) >= 0 ? `+${value}` : String(value);
}

function forgeViewportPosition(current = {}) {
  const viewportWidth = Math.max(240, Number(globalThis.innerWidth) || 1280);
  const viewportHeight = Math.max(240, Number(globalThis.innerHeight) || 900);
  const margin = viewportWidth < 520 ? 8 : 18;
  const availableWidth = Math.max(220, viewportWidth - margin * 2);
  const availableHeight = Math.max(220, viewportHeight - margin * 2);
  const stored = storedForgeWindowSize();
  const requestedWidth = Number(current.width) || stored.width || 920;
  const requestedHeight = Number(current.height) || stored.height || 780;
  const minimumWidth = Math.min(560, availableWidth);
  const minimumHeight = Math.min(500, availableHeight);
  const width = Math.max(minimumWidth, Math.min(requestedWidth, availableWidth));
  const height = Math.max(minimumHeight, Math.min(requestedHeight, availableHeight));
  const result = { width, height };
  if (Number.isFinite(Number(current.left))) result.left = Number(current.left);
  if (Number.isFinite(Number(current.top))) result.top = Number(current.top);
  return result;
}

function visuallyCenterApplication(application) {
  const root = application?.element;
  if (!(root instanceof HTMLElement)) return;
  const rect = root.getBoundingClientRect();
  if (!rect.width || !rect.height) return;
  const desiredLeft = Math.max(8, Math.round((globalThis.innerWidth - rect.width) / 2));
  const desiredTop = Math.max(8, Math.round((globalThis.innerHeight - rect.height) / 2));
  const current = application.position ?? {};
  application.setPosition({
    left: (Number(current.left) || 0) + (desiredLeft - rect.left),
    top: (Number(current.top) || 0) + (desiredTop - rect.top),
  });
}

function keepApplicationVisuallyInsideViewport(application) {
  const root = application?.element;
  if (!(root instanceof HTMLElement)) return;
  const rect = root.getBoundingClientRect();
  const margin = globalThis.innerWidth < 520 ? 6 : 10;
  let dx = 0;
  let dy = 0;
  if (rect.left < margin) dx += margin - rect.left;
  if (rect.right > globalThis.innerWidth - margin) dx -= rect.right - (globalThis.innerWidth - margin);
  if (rect.top < margin) dy += margin - rect.top;
  if (rect.bottom > globalThis.innerHeight - margin) dy -= rect.bottom - (globalThis.innerHeight - margin);
  if (!dx && !dy) return;
  const current = application.position ?? {};
  application.setPosition({
    left: (Number(current.left) || 0) + dx,
    top: (Number(current.top) || 0) + dy,
  });
}

function conceptToForm(concept = {}) {
  const values = {
    ...safePresetValues(concept),
    target: concept.target ?? "new",
    count: concept.count ?? 1,
    itemPolicy: concept.itemPolicy ?? "generated",
    backupOriginal: concept.backupOriginal !== false,
    openSheet: concept.openSheet !== false,
  };
  for (const [key, value] of Object.entries(concept.statTiers ?? {})) {
    values[`tier_${key}`] = value ?? "auto";
  }
  return values;
}

function applyFormValues(root, values = {}, { keepTarget = false } = {}) {
  for (const [name, rawValue] of Object.entries(values)) {
    if (keepTarget && [
      "target",
      "itemPolicy",
      "backupOriginal",
      "deploymentMode",
      "addToCombat",
      "createBriefing",
      "sendChatSummary",
      "confirmRiskyOperations",
    ].includes(name)) {
      continue;
    }
    const input = root.querySelector(`[name="${name}"]`);
    if (!input) continue;
    if (input.type === "checkbox") {
      input.checked = rawValue !== false && rawValue !== "false";
    } else {
      input.value = rawValue ?? "";
    }
  }
}

function customPresetRows() {
  return Object.entries(getCustomPresets(MODULE_ID))
    .map(([id, preset]) => ({ id, ...preset }))
    .sort((left, right) => left.name.localeCompare(right.name, "ru"));
}

function historyRows() {
  return getRecentHistory(MODULE_ID).map((entry) => ({
    ...entry,
    canRestore: Boolean(entry.backupUuids?.length && entry.actorUuids?.length),
    label: `${entry.name}, ${entry.level}-й ур. — ${new Date(
      entry.createdAt,
    ).toLocaleString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    })}`,
  }));
}

function groupedPresetRows(presets, setting) {
  const rows = [];
  for (const [id, meta] of Object.entries(PRESET_GROUPS)) {
    const entries = presets.filter((preset) => preset.setting === setting && preset.group === id);
    if (!entries.length) continue;
    rows.push({ id, ...meta, presets: entries });
  }
  return rows
    .sort((left, right) => left.order - right.order)
    .map((row, index) => ({ ...row, active: index === 0 }));
}

function dialogContext() {
  const presets = presetOptions();
  return {
    creatureKinds: optionList(CREATURE_KINDS),
    monsterFamilies: monsterFamilyOptions(),
    ancestries: optionList(ANCESTRIES),
    professions: optionList(PROFESSIONS),
    roles: optionList(ROLES),
    armors: optionList(ARMORS),
    weapons: optionList(WEAPONS),
    presets,
    peoplePresets: presets.filter((preset) => preset.category === "people"),
    monsterPresets: presets.filter((preset) => preset.category === "monsters"),
    fantasyPresetGroups: groupedPresetRows(presets, "fantasy"),
    starfinderPresetGroups: groupedPresetRows(presets, "starfinder"),
    presetGroupLegend: Object.entries(PRESET_GROUPS)
      .filter(([id]) => id !== "monsters")
      .map(([id, meta]) => ({ id, ...meta }))
      .sort((left, right) => left.order - right.order),
    customPresets: customPresetRows(),
    history: historyRows(),
    // Начальный рендер нового NPC не должен читать выделенные Actor.
    selected: emptySelectedNpcInfo(),
    spellThemes: Object.entries(SPELL_THEME_LABELS).map(([value, label]) => ({ value, label })),
    technologyLevels: optionList(TECHNOLOGY_LEVELS),
    contentSources: optionList(CONTENT_SOURCES),
    deploymentModes: optionList(DEPLOYMENT_MODES),
    encounterDifficulties: Object.entries(ENCOUNTER_DIFFICULTIES).map(([value, data]) => ({ value, label: data.label })),
    adventureModes: optionList(ADVENTURE_MODES),
    lootRichness: optionList(LOOT_RICHNESS),
    monsterTemplates: optionList(MONSTER_TEMPLATES),
    tiers: Object.entries(TIER_LABELS)
      .filter(([value]) => value !== "terrible")
      .map(([value, label]) => ({ value, label })),
  };
}

function userControlValues(values = {}) {
  return {
    forgeSetting: values.forgeSetting ?? (values.technology === "starfinder" ? "starfinder" : "fantasy"),
    includeSkillActions: values.includeSkillActions !== false,
    randomAbilities: values.randomAbilities !== false,
    randomSpells: values.randomSpells !== false,
    randomConsumables: values.randomConsumables !== false,
    randomToken: values.randomToken === true,
    tokenPath: values.tokenPath || "tokens",
    target: values.target ?? "new",
    count: values.count ?? 1,
    itemPolicy: values.itemPolicy ?? "generated",
    backupOriginal: values.backupOriginal !== false,
    openSheet: values.openSheet !== false,
    deploymentMode: values.deploymentMode ?? "none",
    addToCombat: values.addToCombat === true,
    createBriefing: values.createBriefing === true,
    sendChatSummary: values.sendChatSummary === true,
    confirmRiskyOperations: values.confirmRiskyOperations !== false,
    adventureMode: values.adventureMode ?? "off",
    includeLootPlan: values.includeLootPlan === true,
    lootRichness: values.lootRichness ?? "normal",
    monsterTemplate: values.monsterTemplate ?? "none",
    autoCorrect: values.autoCorrect !== false,
    batchMode: values.batchMode ?? "clones",
  };
}

function readDialogForm(dialog) {
  const FormDataExtended =
    foundry.applications?.ux?.FormDataExtended ?? globalThis.FormDataExtended;
  if (FormDataExtended) {
    return new FormDataExtended(dialog.form).object;
  }
  const formData = new FormData(dialog.form);
  const result = Object.fromEntries(formData.entries());
  for (const checkbox of dialog.form.querySelectorAll('input[type="checkbox"]')) {
    result[checkbox.name] = checkbox.checked;
  }
  return result;
}

function listHtml(values, fallback = "нет", limit = 8) {
  if (!values?.length) return `<span class="forge-muted">${fallback}</span>`;
  const visible = values.slice(0, Math.max(1, limit));
  const remaining = Math.max(0, values.length - visible.length);
  return `<ul>${visible.map((value) => `<li>${escapeHtml(value)}</li>`).join("")}${remaining ? `<li class="forge-list-more">ещё ${remaining}…</li>` : ""}</ul>`;
}

function targetText(preview) {
  if (preview.target === "selected") {
    return preview.selected.actorName
      ? `Перестроить оригинал «${escapeHtml(preview.selected.actorName)}»`
      : "Перестроить выбранный оригинал";
  }
  if (preview.target === "duplicate") {
    return preview.selected.actorName
      ? `Создать отдельную копию «${escapeHtml(preview.selected.actorName)}» и назначить жетону`
      : "Создать отдельную копию выбранного NPC";
  }
  return preview.count > 1
    ? `Создать новых NPC: ${preview.count}`
    : "Создать нового NPC в каталоге";
}

function previewRoleGroup(preview) {
  if (preview.monsterLore) return "monster";
  if (["brute", "soldier", "skirmisher", "sniper", "artillery", "berserker", "gunner", "ambusher", "packHunter", "lurker"].includes(preview.role)) return "assault";
  if (["defender"].includes(preview.role)) return "defense";
  if (["healer", "support", "technician", "leader"].includes(preview.role)) return "support";
  if (["caster", "controller", "summoner"].includes(preview.role)) return "magic";
  return "specialist";
}

function previewHtml(preview) {
  const roleGroup = previewRoleGroup(preview);
  const settingLabel = preview.setting === "starfinder" ? "Starfinder" : "Фэнтези PF2e";
  return `
    <div class="forge-preview-heading">
      <div>
        <span class="forge-badge">${escapeHtml(preview.roleLabel || "NPC")}</span>
        <h3>${escapeHtml(preview.name)}</h3>
      </div>
      <strong>${preview.effectiveLevel}-й уровень</strong>
    </div>
    <p class="forge-preview-summary"><strong>${escapeHtml(preview.ancestryLabel)}</strong> · ${escapeHtml(preview.professionLabel)} · ${escapeHtml(settingLabel)}${preview.group ? ` · ${escapeHtml(preview.group)}` : ""}</p>
    <div class="forge-preview-grid">
      <span><strong>КБ</strong>${preview.ac}</span>
      <span><strong>ОЗ</strong>${preview.hp}</span>
      <span><strong>Скорость</strong>${preview.speed} фт.</span>
      <span><strong>Атака</strong>${signed(preview.attack)}</span>
      <span><strong>Урон</strong>${escapeHtml(preview.damage)}</span>
      <span><strong>Восприятие</strong>${signed(preview.perception)}</span>
      <span><strong>Стойкость</strong>${signed(preview.saves.fortitude)}</span>
      <span><strong>Рефлекс</strong>${signed(preview.saves.reflex)}</span>
      <span><strong>Воля</strong>${signed(preview.saves.will)}</span>
      ${preview.dc !== null ? `<span><strong>СС</strong>${preview.dc}</span>` : ""}
    </div>
    <p class="forge-preview-summary"><strong>Ключевые навыки:</strong> ${escapeHtml(preview.skills || "по умолчанию")}</p>
    <div class="forge-preview-lists">
      <div class="forge-tone-assault"><strong><i class="fa-solid fa-swords"></i> Атаки</strong>${listHtml(preview.strikes, "нет", 6)}</div>
      <div class="forge-tone-specialist"><strong><i class="fa-solid fa-bolt"></i> Способности</strong>${listHtml(preview.actions, "нет", 8)}</div>
      <div class="forge-tone-support"><strong><i class="fa-solid fa-backpack"></i> Инвентарь</strong>${listHtml(preview.equipment, "нет", 10)}</div>
      <div class="forge-tone-magic"><strong><i class="fa-solid fa-wand-sparkles"></i> Заклинания</strong>${listHtml(preview.spells, "не добавлены", 8)}</div>
    </div>
    <section class="forge-preview-tactics">
      <strong><i class="fa-solid fa-chess"></i> Как вести в бою</strong>
      <p><strong>Начало:</strong> ${escapeHtml(preview.tactics.opening)}</p>
      <p><strong>Дальше:</strong> ${escapeHtml(preview.tactics.routine)}</p>
    </section>
    ${preview.monsterLore ? `<details class="forge-preview-technical"><summary><i class="fa-solid fa-dragon"></i> Сведения о монстре</summary><p>${escapeHtml(preview.monsterLore.description)}</p><p><strong>Среда:</strong> ${escapeHtml(preview.monsterLore.ecology)}. <strong>Мотив:</strong> ${escapeHtml(preview.monsterLore.motive)}.</p></details>` : ""}
    ${preview.encounter ? `<section class="forge-encounter-budget"><strong>Столкновение: ${escapeHtml(preview.encounter.difficultyLabel)}</strong><p>${preview.encounter.partySize} героев ${preview.encounter.partyLevel}-го уровня; цель ${preview.encounter.budget} XP. ${escapeHtml(preview.encounter.status)}.</p></section>` : ""}
    <p class="forge-target-summary"><strong>Будет выполнено:</strong> ${targetText(preview)}</p>
    ${preview.warnings.length ? `<div class="forge-preview-warnings">${preview.warnings.map((warning) => `<p><i class="fa-solid fa-triangle-exclamation"></i> ${escapeHtml(warning)}</p>`).join("")}</div>` : ""}
    <details class="forge-preview-technical">
      <summary><i class="fa-solid fa-screwdriver-wrench"></i> Техническая проверка и план операций</summary>
      <p><strong>Согласованность:</strong> ${preview.coherence.score}% — ${escapeHtml(preview.coherence.grade)}. <strong>Автоматизация:</strong> ${preview.automation.score}% — ${escapeHtml(preview.automation.grade)}.</p>
      <p><strong>Экономика действий:</strong> ${escapeHtml(preview.actionEconomy.status)}. ${escapeHtml(preview.actionEconomy.routine)}</p>
      ${executionPlanHtml(preview.executionPlan)}
      <details class="forge-preview-tiers"><summary>Ручные шкалы</summary>${escapeHtml(preview.tierDescription)}</details>
    </details>
  `;
}

function refreshCustomPresetSelect(root, selectedId = "") {
  const select = root.querySelector("[data-forge-custom-select]");
  if (!select) return;
  const rows = customPresetRows();
  select.innerHTML = [
    '<option value="">Выбери свою заготовку</option>',
    ...rows.map(
      (preset) =>
        `<option value="${escapeHtml(preset.id)}">${escapeHtml(preset.name)}</option>`,
    ),
  ].join("");
  select.value = rows.some((preset) => preset.id === selectedId) ? selectedId : "";
}

function requestDownloadJson(payload, filename) {
  return requestJsonDownload(payload, filename);
}

async function refreshAuditReportPanel(root) {
  const panel = root?.querySelector("[data-forge-audit-report-panel]");
  if (!panel) return null;
  const status = panel.querySelector("[data-forge-audit-report-status]");
  const saveButton = panel.querySelector("[data-forge-audit-save-last]");
  const copyButton = panel.querySelector("[data-forge-audit-copy-last]");
  const meta = getLastAuditReportMeta(MODULE_ID);
  const record = await getLastAuditReportRecord({ meta });
  const available = Boolean(record?.json);
  if (saveButton) saveButton.disabled = !available;
  if (copyButton) copyButton.disabled = !available;
  if (status) {
    if (!available) {
      status.textContent = "Сохранённого отчёта пока нет. После начала прогона создаются локальные контрольные точки.";
    } else {
      const state = record.status === "running" ? "незавершённый контрольный отчёт" : "последний отчёт";
      const persistent = meta?.persistentStorageCopy ? `; серверная копия: ${meta.persistentPath || "storage модуля"}` : "";
      status.textContent = `${state}: ${record.filename}, ${formatByteSize(record.bytes)}${persistent}`;
    }
  }
  return record;
}


function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function attachApplicationResizeGrip(application, root) {
  const grip = root?.querySelector?.("[data-forge-resize-grip]");
  if (!(grip instanceof HTMLElement) || grip.dataset.forgeResizeAttached === "true") return;
  grip.dataset.forgeResizeAttached = "true";

  const beginResize = (event) => {
    if (event.button !== undefined && event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    const start = {
      x: Number(event.clientX) || 0,
      y: Number(event.clientY) || 0,
      width: Number(application.position?.width) || root.getBoundingClientRect().width,
      height: Number(application.position?.height) || root.getBoundingClientRect().height,
      left: Number(application.position?.left),
      top: Number(application.position?.top),
    };
    grip.classList.add("active");
    root.classList.add("forge-is-resizing");
    grip.setPointerCapture?.(event.pointerId);

    const move = (moveEvent) => {
      const next = forgeViewportPosition({
        width: start.width + ((Number(moveEvent.clientX) || 0) - start.x),
        height: start.height + ((Number(moveEvent.clientY) || 0) - start.y),
        left: start.left,
        top: start.top,
      });
      application.setPosition(next);
    };
    const finish = () => {
      globalThis.removeEventListener?.("pointermove", move);
      globalThis.removeEventListener?.("pointerup", finish);
      globalThis.removeEventListener?.("pointercancel", finish);
      grip.classList.remove("active");
      root.classList.remove("forge-is-resizing");
      persistForgeWindowSize(application.position);
    };
    globalThis.addEventListener?.("pointermove", move, { passive: true });
    globalThis.addEventListener?.("pointerup", finish, { once: true });
    globalThis.addEventListener?.("pointercancel", finish, { once: true });
  };

  grip.addEventListener("pointerdown", beginResize);
  grip.addEventListener("dblclick", () => {
    try { globalThis.localStorage?.removeItem?.(WINDOW_SIZE_STORAGE_KEY); } catch {}
    application.setPosition(forgeViewportPosition({ width: 920, height: 780, left: application.position?.left, top: application.position?.top }));
  });
}

/**
 * Физически нажимает безопасные кнопки текущего окна и проверяет наблюдаемый
 * результат. Содержимое формы полностью восстанавливается после проверки.
 */
export async function runUiControlAudit({ signal = null } = {}) {
  const application = forgeApplicationInstance;
  const root = application?.element instanceof HTMLElement ? application.element : null;
  if (!application?.rendered || !root) throw new Error("Окно Кузницы не открыто.");
  const body = root.querySelector(".pf2e-npc-forge");
  if (!body) throw new Error("Основная часть интерфейса не найдена.");

  const snapshot = readDialogForm(application);
  const previousMode = body.dataset.mode || "quick";
  const previousSetting = body.dataset.setting || "fantasy";
  const results = [];
  const failures = [];
  const checkAbort = () => {
    if (signal?.aborted) {
      const error = new Error("UI-проверка остановлена.");
      error.name = "AbortError";
      throw error;
    }
  };
  const record = (id, ok, detail = "") => {
    const row = { id, ok: Boolean(ok), detail };
    results.push(row);
    if (!row.ok) failures.push(row);
  };
  const click = async (element, waitMs = 140) => {
    checkAbort();
    if (!(element instanceof HTMLElement)) throw new Error("Элемент для нажатия не найден.");
    element.click();
    await sleep(waitMs);
  };

  try {
    for (const button of root.querySelectorAll("[data-forge-mode]")) {
      const mode = button.dataset.forgeMode;
      await click(button, 20);
      record(`mode:${mode}`, body.dataset.mode === mode, `получен mode=${body.dataset.mode ?? ""}`);
    }

    const quickModeButton = root.querySelector('[data-forge-mode="quick"]');
    if (quickModeButton) await click(quickModeButton, 30);

    for (const button of root.querySelectorAll("[data-forge-setting]")) {
      const setting = button.dataset.forgeSetting;
      await click(button, 30);
      const visiblePanel = root.querySelector(`[data-forge-setting-panel="${setting}"]`);
      record(
        `setting:${setting}`,
        body.dataset.setting === setting && visiblePanel?.hidden === false,
        `setting=${body.dataset.setting ?? ""}; panelHidden=${visiblePanel?.hidden}`,
      );
    }
    root.querySelector('[data-forge-setting="fantasy"]')?.click();
    await sleep(30);
    for (const categoryButton of root.querySelectorAll('[data-forge-category-setting="fantasy"]')) {
      await click(categoryButton, 20);
      const groupId = categoryButton.dataset.forgeCategory;
      const group = root.querySelector(`[data-forge-setting-panel="fantasy"] [data-preset-group="${groupId}"]`);
      record(`category:${groupId}`, categoryButton.classList.contains("active") && group?.hidden === false, `hidden=${group?.hidden}`);
    }

    const target = root.querySelector('[name="target"]');
    const prompt = root.querySelector('[name="prompt"]');
    for (const button of root.querySelectorAll("[data-forge-preset]")) {
      checkAbort();
      const setting = button.dataset.forgeSettingValue || "fantasy";
      const settingButton = root.querySelector(`[data-forge-setting="${setting}"]`);
      if (settingButton && body.dataset.setting !== setting) await click(settingButton, 30);
      const groupId = button.dataset.forgeGroup;
      const categoryButton = root.querySelector(`[data-forge-category-setting="${setting}"][data-forge-category="${groupId}"]`);
      if (categoryButton) await click(categoryButton, 20);
      button.scrollIntoView({ block: "center", inline: "nearest" });
      await sleep(35);
      const rect = button.getBoundingClientRect();
      const physicallyVisible =
        !button.hidden &&
        button.offsetParent !== null &&
        rect.width > 0 &&
        rect.height > 0 &&
        rect.bottom > 0 &&
        rect.top < globalThis.innerHeight;
      record(
        `preset-visible:${button.dataset.forgePreset}`,
        physicallyVisible,
        `setting=${setting}; width=${Math.round(rect.width)}; height=${Math.round(rect.height)}`,
      );
      if (target) target.value = "selected";
      if (prompt) prompt.value = `AUDIT-SENTINEL-${button.dataset.forgePreset}`;
      await click(button);
      const promptChanged = !String(prompt?.value ?? "").includes("AUDIT-SENTINEL");
      const targetSafe = target?.value === "new";
      record(
        `preset-button:${button.dataset.forgePreset}`,
        physicallyVisible && promptChanged && targetSafe,
        `visible=${physicallyVisible}; target=${target?.value ?? "?"}; promptChanged=${promptChanged}`,
      );
    }
    root.querySelector('[data-forge-setting="fantasy"]')?.click();
    await sleep(30);

    const migrationSentinel = {
      name: "AUDIT-MIGRATION",
      creatureKind: "person",
      ancestry: "elf",
      level: "7",
      count: "2",
    };
    applyFormValues(root, migrationSentinel);
    const beforeMigration = readDialogForm(application);
    const constructorModeButton = root.querySelector('[data-forge-mode="constructor"]');
    if (constructorModeButton) await click(constructorModeButton, 30);
    const afterMigration = readDialogForm(application);
    record(
      "mode:quick-to-constructor-state",
      Object.entries(migrationSentinel).every(([key, value]) => String(afterMigration[key]) === String(value)) &&
        Object.entries(migrationSentinel).every(([key, value]) => String(beforeMigration[key]) === String(value)),
      `name=${afterMigration.name}; kind=${afterMigration.creatureKind}; ancestry=${afterMigration.ancestry}; level=${afterMigration.level}; count=${afterMigration.count}`,
    );
    if (quickModeButton) await click(quickModeButton, 30);

    const resizeGrip = root.querySelector("[data-forge-resize-grip]");
    record(
      "window:resize-grip",
      resizeGrip instanceof HTMLElement && getComputedStyle(resizeGrip).cursor.includes("resize"),
      resizeGrip ? `cursor=${getComputedStyle(resizeGrip).cursor}` : "ручка отсутствует",
    );

    const countInput = root.querySelector('[name="count"]');
    const groupOptions = root.querySelector("[data-forge-group-options]");
    if (countInput && groupOptions) {
      countInput.value = "1";
      countInput.dispatchEvent(new Event("input", { bubbles: true }));
      await sleep(30);
      const hiddenForOne = groupOptions.hidden;
      countInput.value = "3";
      countInput.dispatchEvent(new Event("input", { bubbles: true }));
      await sleep(30);
      const visibleForMany = !groupOptions.hidden;
      record(
        "dependency:group-options",
        hiddenForOne && visibleForMany,
        `count=1 hidden=${hiddenForOne}; count=3 visible=${visibleForMany}`,
      );
      countInput.value = "1";
      countInput.dispatchEvent(new Event("input", { bubbles: true }));
      await sleep(20);
    }

    const spellToggle = root.querySelector('[name="randomSpells"]');
    const spellOptions = root.querySelector("[data-forge-spell-options]");
    if (spellToggle && spellOptions) {
      spellToggle.checked = false;
      spellToggle.dispatchEvent(new Event("change", { bubbles: true }));
      await sleep(25);
      const hiddenWhenOff = spellOptions.hidden;
      spellToggle.checked = true;
      spellToggle.dispatchEvent(new Event("change", { bubbles: true }));
      await sleep(25);
      const visibleWhenOn = !spellOptions.hidden;
      record(
        "dependency:spell-options",
        hiddenWhenOff && visibleWhenOn,
        `off hidden=${hiddenWhenOff}; on visible=${visibleWhenOn}`,
      );
      spellToggle.checked = false;
      spellToggle.dispatchEvent(new Event("change", { bubbles: true }));
      await sleep(20);
    }

    const toneGroups = ["assault", "defense", "support", "magic", "specialist", "civilian", "monster"]
      .map((tone) => {
        const element = root.querySelector(`.forge-preset-group.forge-tone-${tone}`);
        return element ? [tone, getComputedStyle(element).borderLeftColor] : null;
      })
      .filter(Boolean);
    const distinctColors = new Set(toneGroups.map(([, color]) => color).filter(Boolean));
    record(
      "visual:semantic-category-colors",
      toneGroups.length >= 5 && distinctColors.size >= 5,
      toneGroups.map(([tone, color]) => `${tone}=${color}`).join("; "),
    );

    for (const [selector, id, expectedKind] of [
      ["[data-forge-random]", "random-npc", "person"],
      ["[data-forge-random-monster]", "random-monster", "monster"],
    ]) {
      const button = root.querySelector(selector);
      const before = root.querySelector('[name="randomSeed"]')?.value;
      await click(button);
      const after = root.querySelector('[name="randomSeed"]')?.value;
      const family = root.querySelector('[name="monsterFamily"]')?.value;
      const kind = root.querySelector('[name="creatureKind"]')?.value;
      const kindOk = expectedKind === "person" ? family === "none" : family !== "none" || kind !== "person";
      record(`button:${id}`, before !== after && kindOk, `seedChanged=${before !== after}; kind=${kind}; family=${family}`);
    }

    const rerolls = [
      ["[data-forge-reroll-abilities]", "seedAbilities"],
      ["[data-forge-reroll-spells]", "seedSpells"],
      ["[data-forge-reroll-consumables]", "seedConsumables"],
      ["[data-forge-reroll-token]", "seedToken"],
    ];
    for (const [selector, field] of rerolls) {
      const button = root.querySelector(selector);
      const input = root.querySelector(`[name="${field}"]`);
      const before = input?.value;
      await click(button, 30);
      record(`button:reroll:${field}`, Boolean(input && before !== input.value), `before=${before}; after=${input?.value}`);
    }

    const fullReroll = root.querySelector("[data-forge-reroll-content]");
    const beforeAll = rerolls.map(([, field]) => root.querySelector(`[name="${field}"]`)?.value);
    await click(fullReroll, 30);
    const afterAll = rerolls.map(([, field]) => root.querySelector(`[name="${field}"]`)?.value);
    record("button:reroll-all", beforeAll.some((value, index) => value !== afterAll[index]), "Проверена смена независимых seed.");

    const previewOutput = root.querySelector("[data-forge-preview-output]");
    for (const select of root.querySelectorAll("select[name]")) {
      const original = select.value;
      for (const option of [...select.options]) {
        checkAbort();
        if (option.disabled) continue;
        select.value = option.value;
        select.dispatchEvent(new Event("change", { bubbles: true }));
        await sleep(125);
        const ok = !previewOutput?.classList.contains("forge-error");
        record(`select:${select.name}:${option.value}`, ok, ok ? "change+preview выполнены" : previewOutput?.textContent?.trim());
      }
      select.value = original;
      select.dispatchEvent(new Event("change", { bubbles: true }));
      await sleep(20);
    }

    for (const checkbox of root.querySelectorAll('input[type="checkbox"][name]')) {
      if (checkbox.disabled) {
        record(`checkbox:${checkbox.name}:dependency-disabled`, true, "Элемент корректно отключён текущими зависимостями формы.");
        continue;
      }
      const original = checkbox.checked;
      checkbox.click();
      await sleep(20);
      record(`checkbox:${checkbox.name}`, checkbox.checked !== original, `toggle=${checkbox.checked}`);
      if (checkbox.checked !== original) checkbox.click();
      await sleep(10);
    }

    // addToCombat законно отключён при deploymentMode=none. Проверяем его
    // физически в состоянии, где зависимость разрешает управление.
    const deploymentSelect = root.querySelector('[name="deploymentMode"]');
    const combatCheckbox = root.querySelector('[name="addToCombat"]');
    if (deploymentSelect && combatCheckbox) {
      const originalDeployment = deploymentSelect.value;
      const originalCombat = combatCheckbox.checked;
      deploymentSelect.value = "cluster";
      deploymentSelect.dispatchEvent(new Event("change", { bubbles: true }));
      await sleep(30);
      const enabled = !combatCheckbox.disabled;
      if (enabled) combatCheckbox.click();
      await sleep(20);
      record(
        "dependency:addToCombat",
        enabled && combatCheckbox.checked !== originalCombat,
        `enabled=${enabled}; toggle=${combatCheckbox.checked}`,
      );
      if (enabled && combatCheckbox.checked !== originalCombat) combatCheckbox.click();
      deploymentSelect.value = originalDeployment;
      deploymentSelect.dispatchEvent(new Event("change", { bubbles: true }));
      await sleep(20);
    }

    for (const selector of [
      "[data-forge-diagnostics]",
      "[data-forge-session-audit]",
      "[data-forge-audit-save-last]",
      "[data-forge-audit-copy-last]",
      "[data-forge-submit]",
      "[data-action=close]",
    ]) {
      const element = root.querySelector(selector);
      record(`control-present:${selector}`, element instanceof HTMLElement, element ? "элемент найден" : "элемент отсутствует");
    }

    const interactive = [...root.querySelectorAll("button")];
    const unnamed = interactive.filter((button) => ![
      ...button.attributes,
    ].some((attribute) => attribute.name.startsWith("data-forge-") || attribute.name === "data-action") && button.type !== "submit");
    record("buttons:identified", unnamed.length === 0, unnamed.map((button) => button.textContent?.trim()).filter(Boolean).join(" | "));
  } finally {
    applyFormValues(root, snapshot);
    body.dataset.mode = previousMode;
    body.dataset.setting = previousSetting;
    root.querySelectorAll("[data-forge-mode]").forEach((button) => {
      button.classList.toggle("active", button.dataset.forgeMode === previousMode);
    });
    root.querySelectorAll("[data-forge-setting]").forEach((button) => {
      button.classList.toggle("active", button.dataset.forgeSetting === previousSetting);
    });
    root.querySelectorAll("[data-forge-setting-panel]").forEach((panel) => {
      panel.hidden = panel.dataset.forgeSettingPanel !== previousSetting;
    });
    root.querySelector(".forge-shared-preview")?.toggleAttribute("hidden", previousMode === "library");
    root.querySelector('[name="prompt"]')?.dispatchEvent(new Event("input", { bubbles: true }));
    await sleep(160);
  }

  return { ok: failures.length === 0, total: results.length, failures, results };
}

function attachApplicationListeners(application, initialValues = {}) {
  const dialog = application;
  const root = application?.element instanceof HTMLElement ? application.element : null;
  const output = root?.querySelector("[data-forge-preview-output]");
  if (!root || !output) {
    console.error(`${MODULE_ID} | Окно открылось без ожидаемой формы`, {
      dialog,
      root,
    });
    ui.notifications.error(
      "Кузница: окно открылось, но форма не найдена. Проверь установку модуля.",
    );
    return;
  }

  const contentRoot = root.querySelector(".pf2e-npc-forge") ?? root;
  // ApplicationV2 может заменить только внутреннюю part, сохранив внешний form.
  // Маркер ставится именно на текущую отрисованную part, поэтому новые кнопки
  // всегда получают новые обработчики после любого повторного render.
  if (contentRoot.dataset.pf2eNpcForgeListenersAttached === "true") return;
  contentRoot.dataset.pf2eNpcForgeListenersAttached = "true";
  root.querySelector("[data-forge-reset-window]")?.addEventListener("click", () => {
    try { globalThis.localStorage?.removeItem?.(WINDOW_SIZE_STORAGE_KEY); } catch {}
    application.setPosition(forgeViewportPosition({ width: 920, height: 780 }));
    requestAnimationFrame(() => {
      visuallyCenterApplication(application);
      keepApplicationVisuallyInsideViewport(application);
    });
  });
  applyFormValues(root, initialValues);
  const seedInput = root.querySelector('[name="randomSeed"]');
  if (seedInput && !seedInput.value) seedInput.value = String(randomSeed());
  for (const name of ["seedPersonality", "seedAbilities", "seedSpells", "seedConsumables", "seedToken"]) {
    const input = root.querySelector(`[name="${name}"]`);
    if (input && !input.value) input.value = String(randomSeed());
  }
  contentRoot.dataset.mode = contentRoot.dataset.mode || "quick";

  let timer = null;
  const updatePreview = () => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      try {
        const concept = parseConcept(readDialogForm(dialog));
        const preview = getPreview(concept);
        preview.executionPlan = buildExecutionPlan(concept, preview, preview.selected);
        output.innerHTML = previewHtml(preview);
        output.dataset.roleGroup = previewRoleGroup(preview);
        output.dataset.setting = preview.setting || "fantasy";
        const selectionStatus = root.querySelector(
          "[data-forge-selection-status]",
        );
        if (selectionStatus) {
          selectionStatus.innerHTML = preview.selected.available
            ? `<i class="fa-solid fa-circle-check"></i> Выбран жетон NPC: <strong>${escapeHtml(
                preview.selected.actorName,
              )}</strong>. ${
                preview.selected.linked
                  ? "Он связан с листом в каталоге."
                  : "Он сейчас несвязанный."
              }`
            : '<i class="fa-solid fa-circle-info"></i> Жетон NPC не выбран. Это не мешает создавать новых персонажей.';
        }
        output.classList.remove("forge-error");
      } catch (error) {
        output.textContent = error.message;
        output.classList.add("forge-error");
      }
    }, 100);
  };

  const syncTargetControls = () => {
    const target = root.querySelector('[name="target"]')?.value ?? "new";
    const count = root.querySelector('[name="count"]');
    const batchMode = root.querySelector('[name="batchMode"]');
    const backup = root.querySelector('[name="backupOriginal"]');
    const policy = root.querySelector('[name="itemPolicy"]');
    if (count) {
      count.disabled = target !== "new";
      if (target !== "new") count.value = "1";
    }
    if (batchMode) batchMode.disabled = target !== "new";
    if (backup) backup.disabled = target !== "selected";
    if (policy) policy.disabled = target !== "selected";
  };

  const selectPresetCategory = (setting, groupId = null) => {
    const panel = root.querySelector(`[data-forge-setting-panel="${setting}"]`);
    if (!panel) return;
    const buttons = [...panel.querySelectorAll("[data-forge-category]")];
    const groups = [...panel.querySelectorAll("[data-preset-group]")];
    const available = new Set(groups.map((group) => group.dataset.presetGroup));
    const selected = available.has(groupId) ? groupId : buttons.find((button) => available.has(button.dataset.forgeCategory))?.dataset.forgeCategory;
    for (const button of buttons) {
      const active = button.dataset.forgeCategory === selected;
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", String(active));
    }
    for (const group of groups) group.hidden = group.dataset.presetGroup !== selected;
  };

  const setForgeSetting = (setting, { applyDefaults = false, refresh = true } = {}) => {
    const normalized = setting === "starfinder" ? "starfinder" : "fantasy";
    contentRoot.dataset.setting = normalized;
    const hidden = root.querySelector('[name="forgeSetting"]');
    if (hidden) hidden.value = normalized;
    root.querySelectorAll("[data-forge-setting]").forEach((button) => {
      button.classList.toggle("active", button.dataset.forgeSetting === normalized);
      button.setAttribute("aria-pressed", String(button.dataset.forgeSetting === normalized));
    });
    root.querySelectorAll("[data-forge-setting-panel]").forEach((panel) => {
      panel.hidden = panel.dataset.forgeSettingPanel !== normalized;
    });
    selectPresetCategory(normalized, root.querySelector(`[data-forge-setting-panel="${normalized}"] [data-forge-category].active`)?.dataset.forgeCategory);
    const monsterButton = root.querySelector("[data-forge-random-monster]");
    if (monsterButton) {
      monsterButton.disabled = normalized === "starfinder";
      monsterButton.title = normalized === "starfinder"
        ? "Случайный бестиарий SF2e пока не смешивается с фэнтезийными семействами. Выбери готовую Starfinder-заготовку."
        : "Создать случайного монстра PF2e";
    }
    if (applyDefaults) {
      applyFormValues(root, normalized === "starfinder"
        ? { forgeSetting: normalized, technology: "starfinder", contentSource: "sf2e", monsterFamily: "none", creatureKind: "person" }
        : { forgeSetting: normalized, technology: "fantasy", contentSource: "pf2e", monsterFamily: "none", creatureKind: "person" });
    }
    if (refresh) updatePreview();
  };

  const syncMonsterControls = () => {
    const family = root.querySelector('[name="monsterFamily"]')?.value ?? "none";
    const kind = root.querySelector('[name="creatureKind"]');
    const batchMode = root.querySelector('[name="batchMode"]');
    if (family !== "none" && batchMode?.value === "squad") batchMode.value = "encounter";
    if (family === "none" && batchMode?.value === "encounter") batchMode.value = "clones";
    if (kind && family !== "none") {
      const selectedOption = root.querySelector('[name="monsterFamily"]')?.selectedOptions?.[0];
      kind.value = selectedOption?.dataset?.kind || "monster";
    }
  };

  const syncControlDependencies = () => {
    const deployment = root.querySelector('[name="deploymentMode"]');
    const combat = root.querySelector('[name="addToCombat"]');
    if (combat) {
      const canUseCombat = deployment?.value && deployment.value !== "none";
      combat.disabled = !canUseCombat;
      if (!canUseCombat) combat.checked = false;
    }

    const includeLoot = root.querySelector('[name="includeLootPlan"]');
    const lootRichness = root.querySelector('[name="lootRichness"]');
    if (lootRichness) lootRichness.disabled = !includeLoot?.checked;

    const count = Math.max(1, Number(root.querySelector('[name="count"]')?.value) || 1);
    const target = root.querySelector('[name="target"]')?.value ?? "new";
    const groupOptions = root.querySelector("[data-forge-group-options]");
    if (groupOptions) groupOptions.hidden = !(target === "new" && count > 1);

    const spellsEnabled = root.querySelector('[name="randomSpells"]')?.checked === true;
    const spellOptions = root.querySelector("[data-forge-spell-options]");
    if (spellOptions) spellOptions.hidden = !spellsEnabled;
  };

  const applyPreset = (values, { preserveStoredSeeds = false, forceTarget = null } = {}) => {
    const completed = completePresetValues(values);
    setForgeSetting(completed.forgeSetting ?? (completed.technology === "starfinder" ? "starfinder" : "fantasy"), {
      applyDefaults: false,
      refresh: false,
    });
    if (!preserveStoredSeeds) {
      completed.randomSeed = String(randomSeed());
      completed.seedPersonality = String(randomSeed());
      completed.seedAbilities = String(randomSeed());
      completed.seedSpells = String(randomSeed());
      completed.seedConsumables = String(randomSeed());
      completed.seedToken = String(randomSeed());
    }
    applyFormValues(root, completed, { keepTarget: true });
    if (forceTarget) {
      const target = root.querySelector('[name="target"]');
      if (target) target.value = forceTarget;
    }
    syncTargetControls();
    syncMonsterControls();
    syncControlDependencies();
    updatePreview();
  };

  root.querySelectorAll("[data-forge-category]").forEach((button) => {
    button.addEventListener("click", () => {
      selectPresetCategory(button.dataset.forgeCategorySetting, button.dataset.forgeCategory);
    });
  });

  root.querySelectorAll("[data-forge-setting]").forEach((button) => {
    button.addEventListener("click", () => {
      setForgeSetting(button.dataset.forgeSetting, { applyDefaults: true });
      root.querySelectorAll("[data-forge-preset]").forEach((presetButton) => presetButton.classList.remove("active"));
      syncMonsterControls();
      syncControlDependencies();
    });
  });

  root.querySelector('[name="monsterFamily"]')?.addEventListener("change", (event) => {
    const family = MONSTER_FAMILIES[event.currentTarget.value];
    if (!family || event.currentTarget.value === "none") {
      applyFormValues(root, { creatureKind: "person" });
      return;
    }
    applyFormValues(root, {
      creatureKind: family.kind,
      ancestry: family.ancestry ?? "auto",
      profession: family.defaultProfession ?? "auto",
      role: family.defaultRole ?? "auto",
      armor: family.defaultArmor ?? "auto",
      weapon: family.defaultWeapon ?? "auto",
      batchMode: "encounter",
    });
  });

  root.querySelector('[name="creatureKind"]')?.addEventListener("change", (event) => {
    if (event.currentTarget.value === "person") {
      applyFormValues(root, { monsterFamily: "none", batchMode: "clones" });
    }
  });

  root.querySelectorAll("select, input, textarea").forEach((input) => {
    input.addEventListener("input", (event) => {
      if (event.isTrusted && !["randomSeed", "seedAbilities", "seedSpells", "seedConsumables", "seedToken"].includes(input.name)) {
        root.querySelectorAll("[data-forge-preset]").forEach((button) => button.classList.remove("active"));
      }
      syncTargetControls();
      syncMonsterControls();
      syncControlDependencies();
      updatePreview();
    });
    input.addEventListener("change", () => {
      if (input.name === "technology" || input.name === "contentSource") {
        const technology = root.querySelector('[name="technology"]')?.value;
        const source = root.querySelector('[name="contentSource"]')?.value;
        const inferred = technology === "starfinder" || source === "sf2e" ? "starfinder" : "fantasy";
        setForgeSetting(inferred, { applyDefaults: false, refresh: false });
      }
      syncTargetControls();
      syncMonsterControls();
      syncControlDependencies();
      updatePreview();
    });
  });

  root.querySelector("[data-forge-random]")?.addEventListener("click", () => {
    const current = readDialogForm(dialog);
    const setting = current.forgeSetting === "starfinder" ? "starfinder" : "fantasy";
    const keep = {
      ...userControlValues(current),
      forgeSetting: setting,
      technology: setting === "starfinder" ? "starfinder" : "fantasy",
      contentSource: setting === "starfinder" ? "sf2e" : "pf2e",
    };
    if (current.lockName) keep.name = current.name;
    if (current.lockLevel) keep.level = current.level;
    if (current.lockAncestry) {
      keep.ancestry = current.ancestry;
      keep.gender = current.gender;
    }
    if (current.lockProfession) keep.profession = current.profession;
    if (current.lockRole) keep.role = current.role;
    if (current.lockGear) {
      keep.armor = current.armor;
      keep.weapon = current.weapon;
    }
    const values = randomFormValues({ seed: randomSeed(), keep });
    applyFormValues(root, values);
    setForgeSetting(setting, { applyDefaults: false, refresh: false });
    syncTargetControls();
    syncControlDependencies();
    updatePreview();
  });

  root.querySelector("[data-forge-random-monster]")?.addEventListener("click", () => {
    const current = readDialogForm(dialog);
    if (current.forgeSetting === "starfinder") {
      ui.notifications.warn("Случайные монстры сейчас доступны только для PF2e-фэнтези, чтобы не смешивать сеттинги. Для Starfinder выбери готовую роль.");
      return;
    }
    const keep = {
      ...userControlValues(current),
      batchMode: "encounter",
      monsterFamily: current.lockAncestry && current.monsterFamily !== "none" ? current.monsterFamily : undefined,
    };
    if (current.lockName) keep.name = current.name;
    if (current.lockLevel) keep.level = current.level;
    if (current.lockProfession) keep.profession = current.profession;
    if (current.lockRole) keep.role = current.role;
    if (current.lockGear) {
      keep.armor = current.armor;
      keep.weapon = current.weapon;
    }
    const values = randomMonsterFormValues(randomSeed(), keep);
    applyFormValues(root, values);
    syncTargetControls();
    syncMonsterControls();
    syncControlDependencies();
    updatePreview();
  });


  root.querySelector("[data-forge-reroll-content]")?.addEventListener("click", () => {
    for (const field of [
      "randomSeed",
      "seedPersonality",
      "seedAbilities",
      "seedSpells",
      "seedConsumables",
      "seedToken",
    ]) {
      const input = root.querySelector(`[name="${field}"]`);
      if (input) input.value = String(randomSeed());
    }
    const image = root.querySelector('[name="tokenImage"]');
    if (image) image.value = "";
    const randomized = root.querySelector('[name="randomized"]');
    if (randomized) randomized.value = "true";
    updatePreview();
  });

  const rerollSeed = (field) => {
    const input = root.querySelector(`[name="${field}"]`);
    if (input) input.value = String(randomSeed());
    const randomized = root.querySelector('[name="randomized"]');
    if (randomized) randomized.value = "true";
    updatePreview();
  };

  root.querySelector("[data-forge-reroll-abilities]")?.addEventListener("click", () => rerollSeed("seedAbilities"));
  root.querySelector("[data-forge-reroll-spells]")?.addEventListener("click", () => rerollSeed("seedSpells"));
  root.querySelector("[data-forge-reroll-consumables]")?.addEventListener("click", () => rerollSeed("seedConsumables"));
  root.querySelector("[data-forge-reroll-token]")?.addEventListener("click", () => {
    const image = root.querySelector('[name="tokenImage"]');
    if (image) image.value = "";
    rerollSeed("seedToken");
  });

  root.querySelector("[data-forge-reroll-gear]")?.addEventListener("click", () => {
    const current = readDialogForm(dialog);
    const roller = current.monsterFamily && current.monsterFamily !== "none"
      ? (options) => randomMonsterFormValues(options.seed, options.keep)
      : randomFormValues;
    const rolled = roller({
      seed: randomSeed(),
      keep: {
        name: current.name,
        level: current.level,
        creatureKind: current.creatureKind,
        monsterFamily: current.monsterFamily,
        ancestry: current.ancestry,
        gender: current.gender,
        profession: current.profession,
        role: current.role,
        quality: current.quality,
        complexity: current.complexity,
        spellTheme: current.spellTheme,
        target: current.target,
        count: current.count,
        tokenPath: current.tokenPath,
        randomToken: current.randomToken,
      },
    });
    applyFormValues(root, { armor: rolled.armor, weapon: rolled.weapon });
    updatePreview();
  });

  root.querySelectorAll("[data-forge-mode]").forEach((button) => {
    button.addEventListener("click", () => {
      const mode = button.dataset.forgeMode || "quick";
      contentRoot.dataset.mode = mode;
      root.querySelectorAll("[data-forge-mode]").forEach((candidate) =>
        candidate.classList.toggle("active", candidate === button),
      );
      root.querySelector(".forge-shared-preview")?.toggleAttribute("hidden", mode === "library");
    });
  });

  root.querySelector("[data-forge-balance-encounter]")?.addEventListener("click", () => {
    try {
      const preview = getPreview(parseConcept(readDialogForm(dialog)));
      if (!preview.encounter?.recommendedCount) {
        ui.notifications.warn("Для этого сочетания уровней нельзя предложить стандартное количество существ.");
        return;
      }
      const count = root.querySelector('[name="count"]');
      if (count) count.value = String(preview.encounter.recommendedCount);
      if (preview.monsterLore) {
        const mode = root.querySelector('[name="batchMode"]');
        if (mode) mode.value = "encounter";
      }
      updatePreview();
    } catch (error) {
      ui.notifications.error(`Расчёт столкновения: ${error.message}`);
    }
  });

  root.querySelector("[data-forge-diagnostics]")?.addEventListener("click", async () => {
    try {
      const report = await runDiagnostics();
      output.innerHTML = diagnosticsHtml(report);
      output.classList.remove("forge-error");
      requestDownloadJson(report, "pf2e-npc-forge-diagnostics.json");
      ui.notifications[report.ok ? "info" : "warn"](
        report.ok ? "Диагностика пройдена; запрос на сохранение отчёта отправлен." : "Диагностика нашла проблемы; запрос на сохранение отчёта отправлен.",
      );
    } catch (error) {
      ui.notifications.error(`Диагностика: ${error.message}`);
    }
  });

  refreshAuditReportPanel(root).catch((error) => {
    console.warn(`${MODULE_ID} | Не удалось показать последний отчёт`, error);
  });

  root.querySelector("[data-forge-audit-save-last]")?.addEventListener("click", async (event) => {
    const button = event.currentTarget;
    button.disabled = true;
    try {
      const record = await getLastAuditReportRecord({ meta: getLastAuditReportMeta(MODULE_ID) });
      if (!record) throw new Error("Последний отчёт не найден. Запусти полный прогон ещё раз.");
      const result = await saveAuditRecordAs(record);
      if (result.cancelled) {
        ui.notifications.warn("Сохранение отчёта отменено пользователем.");
      } else if (result.confirmed) {
        ui.notifications.info(`Отчёт точно сохранён: ${record.filename}`);
      } else {
        ui.notifications.warn(
          `Foundry отправил запрос на загрузку ${record.filename}. Проверь папку «Загрузки». Резервная копия остаётся внутри Кузницы.`,
          { permanent: true },
        );
      }
    } catch (error) {
      ui.notifications.error(`Сохранение отчёта: ${error.message}`, { permanent: true });
    } finally {
      button.disabled = false;
    }
  });

  root.querySelector("[data-forge-audit-copy-last]")?.addEventListener("click", async (event) => {
    const button = event.currentTarget;
    button.disabled = true;
    try {
      const record = await getLastAuditReportRecord({ meta: getLastAuditReportMeta(MODULE_ID) });
      if (!record) throw new Error("Последний отчёт не найден.");
      await copyAuditRecord(record);
      ui.notifications.info(`JSON скопирован в буфер обмена (${formatByteSize(record.bytes)}).`);
    } catch (error) {
      ui.notifications.error(`Копирование отчёта: ${error.message}`, { permanent: true });
    } finally {
      button.disabled = false;
    }
  });

  root.querySelector("[data-forge-session-audit]")?.addEventListener("click", async (event) => {
    const button = event.currentTarget;
    if (sessionAuditController) {
      sessionAuditController.abort();
      button.disabled = true;
      button.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Останавливаю…';
      return;
    }

    const confirmed = globalThis.confirm(
      "Запустить полный прогон Кузницы в этой сессии?\n\n" +
      "Проверка создаст и затем удалит временные NPC, Journal, Scene, Token, Combat и Macro, " +
      "прогонит все встроенные пресеты, пакетную сборку, Actor мира и рабочие компендиумы. " +
      "Она может занять несколько минут. Во время прогона эту же кнопку можно нажать для остановки."
    );
    if (!confirmed) return;

    sessionAuditController = new AbortController();
    const originalHtml = button.innerHTML;
    button.classList.add("forge-audit-running");
    button.innerHTML = '<i class="fa-solid fa-stop"></i> Остановить проверку';
    output.classList.remove("forge-error");
    output.innerHTML = '<div class="forge-diagnostics"><h3>Полная проверка запущена</h3><p data-forge-audit-progress>Подготовка среды…</p><p>Не закрывай мир до автоматической очистки временных документов.</p></div>';
    const progress = output.querySelector("[data-forge-audit-progress]");
    let lastCheckpointAt = 0;

    try {
      const report = await runSessionAudit(
        { deepCompendiumScan: true, maxDocumentsPerPack: 0 },
        {
          signal: sessionAuditController.signal,
          onProgress: ({ label, completed, total, report: progressReport }) => {
            if (progress) progress.textContent = `${label}${Number.isFinite(total) ? ` — ${completed}/${total}` : ""}`;
            const current = Date.now();
            if (progressReport && current - lastCheckpointAt >= 5000) {
              lastCheckpointAt = current;
              checkpointAuditReport(MODULE_ID, progressReport, {
                saveMeta: (meta) => setLastAuditReportMeta(MODULE_ID, meta),
              }).then(() => refreshAuditReportPanel(root)).catch((error) => {
                console.warn(`${MODULE_ID} | Не удалось сохранить контрольную точку аудита`, error);
              });
            }
          },
        },
      );
      const persistence = await persistAuditReport(MODULE_ID, report, {
        saveMeta: (meta) => setLastAuditReportMeta(MODULE_ID, meta),
      });
      output.innerHTML = sessionAuditHtml(report);
      await refreshAuditReportPanel(root);
      const method = report.ok ? "info" : report.status === "cancelled" ? "warn" : "error";
      const savedWhere = persistence.persistent.ok
        ? `Резервная копия сохранена в storage модуля: ${persistence.persistent.path}.`
        : persistence.indexedDb.ok
          ? "Резервная копия сохранена в локальном хранилище клиента Foundry."
          : "Резервное сохранение не удалось; отчёт остаётся только в памяти до закрытия приложения.";
      ui.notifications[method](
        `${report.ok ? "Полная проверка пройдена." : report.status === "cancelled" ? "Проверка остановлена; частичный отчёт сохранён." : "Проверка завершена с проблемами."} ${savedWhere} Нажми «Сохранить отчёт как…», чтобы получить файл.`,
        { permanent: !persistence.ok || (!report.ok && report.status !== "cancelled") },
      );
    } catch (error) {
      output.classList.add("forge-error");
      output.innerHTML = `<div class="forge-diagnostics"><h3>Проверка аварийно остановлена</h3><p>${escapeHtml(error.message)}</p></div>`;
      ui.notifications.error(`Полная проверка: ${error.message}`, { permanent: true });
    } finally {
      sessionAuditController = null;
      button.disabled = false;
      button.classList.remove("forge-audit-running");
      button.innerHTML = originalHtml;
    }
  });

  root.querySelectorAll("[data-forge-preset]").forEach((button) => {
    button.addEventListener("click", () => {
      const preset = BUILTIN_PRESETS[button.dataset.forgePreset];
      if (!preset) return;
      // Быстрая заготовка всегда начинает безопасную операцию создания нового
      // NPC. Перестройку существующего листа мастер выбирает уже после пресета.
      applyPreset(preset.values, { forceTarget: "new" });
      root.querySelectorAll("[data-forge-preset]").forEach((candidate) => candidate.classList.toggle("active", candidate === button));
    });
  });

  root.querySelector("[data-forge-custom-load]")?.addEventListener("click", () => {
    const id = root.querySelector("[data-forge-custom-select]")?.value;
    const preset = getCustomPresets(MODULE_ID)[id];
    if (!preset) {
      ui.notifications.warn("Сначала выбери сохранённую заготовку.");
      return;
    }
    applyPreset(preset.values, { preserveStoredSeeds: true, forceTarget: "new" });
  });

  root.querySelector("[data-forge-custom-save]")?.addEventListener("click", async () => {
    const current = readDialogForm(dialog);
    const suggested = String(current.name || "Новая заготовка");
    const name = globalThis.prompt("Название заготовки:", suggested);
    if (!name) return;
    try {
      const id = await saveCustomPreset(MODULE_ID, name, current);
      refreshCustomPresetSelect(root, id);
      ui.notifications.info(`Заготовка «${name.trim()}» сохранена для этого мира.`);
    } catch (error) {
      ui.notifications.error(`Кузница: ${error.message}`);
    }
  });

  root.querySelector("[data-forge-custom-delete]")?.addEventListener("click", async () => {
    const select = root.querySelector("[data-forge-custom-select]");
    const id = select?.value;
    const preset = getCustomPresets(MODULE_ID)[id];
    if (!preset) {
      ui.notifications.warn("Сначала выбери сохранённую заготовку.");
      return;
    }
    if (!globalThis.confirm(`Удалить заготовку «${preset.name}»?`)) return;
    await deleteCustomPreset(MODULE_ID, id);
    refreshCustomPresetSelect(root);
    ui.notifications.info("Заготовка удалена.");
  });

  root.querySelector("[data-forge-custom-export]")?.addEventListener("click", () => {
    downloadJson(exportCustomPresets(MODULE_ID), "pf2e-npc-forge-presets.json");
  });

  const importInput = root.querySelector("[data-forge-custom-import-input]");
  root.querySelector("[data-forge-custom-import]")?.addEventListener("click", () => {
    importInput?.click();
  });
  importInput?.addEventListener("change", async () => {
    const file = importInput.files?.[0];
    if (!file) return;
    try {
      const count = await importCustomPresets(MODULE_ID, await file.text());
      refreshCustomPresetSelect(root);
      ui.notifications.info(`Импортировано заготовок: ${count}.`);
    } catch (error) {
      ui.notifications.error(`Кузница: ${error.message}`);
    } finally {
      importInput.value = "";
    }
  });

  root.querySelector("[data-forge-create-launcher]")?.addEventListener("click", async () => {
    try {
      const macro = await createLauncherMacro();
      ui.notifications.info(`Макрос запуска «${macro?.name ?? "Открыть кузницу NPC"}» создан или обновлён.`);
    } catch (error) {
      console.warn(`${MODULE_ID} | Не удалось создать макрос запуска`, error);
      ui.notifications.error(`Макрос запуска: ${error.message}`);
    }
  });

  root.querySelector("[data-forge-history-load]")?.addEventListener("click", () => {
    const id = root.querySelector("[data-forge-history-select]")?.value;
    const entry = getRecentHistory(MODULE_ID).find((candidate) => candidate.id === id);
    if (!entry) {
      ui.notifications.warn("Сначала выбери запись из истории.");
      return;
    }
    applyPreset(contentPresetValues(conceptToForm(entry.concept)), { preserveStoredSeeds: true, forceTarget: "new" });
  });

  root.querySelector("[data-forge-history-open]")?.addEventListener("click", async () => {
    const id = root.querySelector("[data-forge-history-select]")?.value;
    const entry = getRecentHistory(MODULE_ID).find((candidate) => candidate.id === id);
    const uuid = entry?.actorUuids?.[0];
    if (!uuid) {
      ui.notifications.warn("У этой записи нет сохранённого листа.");
      return;
    }
    const resolver = globalThis.fromUuid ?? foundry.utils?.fromUuid;
    const actor = resolver ? await resolver(uuid) : null;
    if (!actor) {
      ui.notifications.warn("Лист из этой записи уже не найден.");
      return;
    }
    actor.sheet?.render(true);
  });

  root.querySelector("[data-forge-history-restore]")?.addEventListener("click", async () => {
    const id = root.querySelector("[data-forge-history-select]")?.value;
    const entry = getRecentHistory(MODULE_ID).find((candidate) => candidate.id === id);
    if (!entry?.backupUuids?.length) {
      ui.notifications.warn("У этой записи нет резервной копии для восстановления.");
      return;
    }
    if (!globalThis.confirm("Восстановить перестроенный NPC из резервной копии? Перед восстановлением будет создана ещё одна страховочная копия текущего состояния.")) return;
    try {
      const result = await restoreFromHistoryEntry(entry);
      ui.notifications.info(`NPC «${result.actor.name}» восстановлен. Страховочная копия сохранена.`);
    } catch (error) {
      ui.notifications.error(`Восстановление: ${error.message}`);
    }
  });

  root
    .querySelector("[data-forge-preview]")
    ?.addEventListener("click", updatePreview);
  const initialSetting = initialValues.forgeSetting
    ?? (initialValues.technology === "starfinder" || initialValues.contentSource === "sf2e" ? "starfinder" : "fantasy");
  setForgeSetting(initialSetting, { applyDefaults: false, refresh: false });
  syncTargetControls();
  syncMonsterControls();
  syncControlDependencies();
  updatePreview();
}

function initialForgeValues(options = {}) {
  const values = {
    randomAbilities: true,
    randomSpells: false,
    randomConsumables: true,
    randomToken: false,
    tokenPath: "tokens",
    tokenImage: "",
    complexity: "standard",
    spellTheme: "auto",
    technology: "fantasy",
    contentSource: "auto",
    deploymentMode: "none",
    addToCombat: false,
    createBriefing: false,
    sendChatSummary: false,
    confirmRiskyOperations: true,
    includeSkillActions: true,
    adventureMode: "off",
    includeLootPlan: false,
    autoCorrect: true,
    batchMode: "clones",
    creatureKind: "person",
    monsterFamily: "none",
    encounterDifficulty: "none",
    partyLevel: 1,
    partySize: 4,
    randomSeed: String(randomSeed()),
    seedPersonality: String(randomSeed()),
    seedAbilities: String(randomSeed()),
    seedSpells: String(randomSeed()),
    seedConsumables: String(randomSeed()),
    seedToken: String(randomSeed()),
    randomized: false,
    ...getLastForm(MODULE_ID),
    ...conceptToForm(options.concept),
    ...(options.target ? { target: options.target } : {}),
  };
  if (!options.target && !options.concept?.target) values.target = "new";
  return values;
}

async function executeGeneration(form) {
  try {
    const parsedConcept = parseConcept(form);
    const preflightPreview = getPreview(parsedConcept);
    const executionPlan = buildExecutionPlan(parsedConcept, preflightPreview, preflightPreview.selected);
    const concept = executionPlan.concept;
    if (!(await confirmExecutionPlan(executionPlan))) {
      ui.notifications.info("Кузница: операция отменена до изменения данных.");
      return null;
    }
    try {
      await setLastForm(MODULE_ID, form);
    } catch (error) {
      console.warn(`${MODULE_ID} | Не удалось сохранить параметры формы`, error);
      ui.notifications.warn("Кузница продолжит работу, но не смогла запомнить параметры формы.");
    }
    ui.notifications.info(
      concept.count > 1
        ? `Кузница: создаю персонажей мастера — ${concept.count}.`
        : "Кузница: собираю лист персонажа мастера и настоящие предметы.",
    );
    const results = await generateNpcBatch(concept);
    const deployment = await deployActorsToScene(results, concept);
    const briefing = await createEncounterBriefing(results, concept);
    for (const warning of [...deployment.warnings, ...briefing.warnings]) {
      if (results[0]) results[0].warnings ??= [], results[0].warnings.push(warning);
    }
    try {
      await addRecentHistory(MODULE_ID, concept, results);
    } catch (error) {
      console.warn(`${MODULE_ID} | Не удалось сохранить историю`, error);
      if (results[0]) {
        results[0].warnings ??= [];
        results[0].warnings.push(`NPC создан, но запись в истории не сохранена: ${error.message}`);
      }
    }

    const links = results
      .map(
        (result) =>
          `<li>@UUID[${result.actor.uuid}]{${escapeHtml(result.actor.name)}} — предметов и действий: ${result.itemCount}</li>`,
      )
      .join("");
    const backups = results
      .filter((result) => result.backup)
      .map(
        (result) =>
          `<p><strong>Резервная копия:</strong> @UUID[${result.backup.uuid}]{${escapeHtml(
            result.backup.name,
          )}}</p>`,
      )
      .join("");
    const tacticalCards = results
      .map((result) => {
        const intelligence = result.intelligence;
        if (!intelligence) return "";
        return `<details><summary><strong>${escapeHtml(result.actor.name)}</strong> — готовая шпаргалка</summary>
          <p><strong>Цельность:</strong> ${intelligence.coherence.score}% — ${escapeHtml(intelligence.coherence.grade)}.</p>
          <p><strong>Первый ход:</strong> ${escapeHtml(intelligence.tactics.opening)}</p>
          <p><strong>Обычный цикл:</strong> ${escapeHtml(intelligence.tactics.routine)}</p>
          <p><strong>Отступление:</strong> ${escapeHtml(intelligence.tactics.retreat)}</p>
        </details>`;
      })
      .join("");
    const warnings = results.flatMap((result) => result.warnings ?? []);

    if (concept.sendChatSummary && typeof globalThis.ChatMessage?.create === "function") {
      try {
        await ChatMessage.create({
          speaker: { alias: "Кузница персонажей мастера" },
          content: `
            <h3>Кузница завершила работу</h3>
            <p>${escapeHtml(conceptSummary(concept))}</p>
            <ul>${links}</ul>
            ${backups}
            ${deployment.tokens.length ? `<p><strong>Размещено жетонов на сцене:</strong> ${deployment.tokens.length}${deployment.combat ? "; добавлены в бой" : ""}.</p>` : ""}
            ${briefing.journal ? `<p><strong>Мастерская сводка:</strong> @UUID[${briefing.journal.uuid}]{${escapeHtml(briefing.journal.name)}}.</p>` : ""}
            ${tacticalCards}
            ${
              warnings.length
                ? `<p><strong>Нужно проверить:</strong> ${warnings
                    .map(escapeHtml)
                    .join(" ")}</p>`
                : ""
            }
          `,
          whisper: [game.user.id],
        });
      } catch (error) {
        console.warn(`${MODULE_ID} | Не удалось создать отчёт в чате`, error);
        ui.notifications.warn("NPC создан, но личный отчёт в чате сохранить не удалось.");
      }
    }

    const verb =
      concept.target === "selected"
        ? "перестроен"
        : results.length > 1
          ? `созданы (${results.length})`
          : "создан";
    ui.notifications.info(`NPC ${verb}. Результат сохранён в каталоге персонажей.`);
    return results.length === 1 ? results[0] : results;
  } catch (error) {
    console.error(`${MODULE_ID} | Ошибка генерации`, error);
    ui.notifications.error(`Кузница: ${error.message}`);
    return null;
  }
}

let ForgeApplicationClass = null;
let forgeApplicationInstance = null;
let sessionAuditController = null;

function getForgeApplicationClass() {
  if (ForgeApplicationClass) return ForgeApplicationClass;
  const ApplicationV2 = foundry.applications?.api?.ApplicationV2;
  const HandlebarsApplicationMixin = foundry.applications?.api?.HandlebarsApplicationMixin;
  if (!ApplicationV2 || typeof HandlebarsApplicationMixin !== "function") {
    throw new Error("В этой сборке Foundry недоступен ApplicationV2 с HandlebarsApplicationMixin. Нужна Foundry VTT 14.");
  }

  ForgeApplicationClass = class Pf2eNpcForgeApplication extends HandlebarsApplicationMixin(ApplicationV2) {
    static DEFAULT_OPTIONS = {
      id: "pf2e-npc-forge-application",
      tag: "form",
      classes: ["pf2e-npc-forge-application"],
      position: { width: 920, height: 780 },
      window: {
        title: "Кузница персонажей мастера PF2e",
        icon: "fa-solid fa-hammer",
        resizable: true,
        minimizable: true,
        contentClasses: ["pf2e-npc-forge-content"],
      },
      form: {
        closeOnSubmit: false,
        submitOnChange: false,
        handler: async function (_event, _form, _formData) {
          return this.submitForge();
        },
      },
      actions: {
        close: function () {
          return this.close();
        },
      },
    };

    static PARTS = {
      main: {
        template: TEMPLATE,
        scrollable: [".forge-app-body"],
      },
      footer: {
        template: FOOTER_TEMPLATE,
      },
    };

    constructor(options = {}, forgeOptions = {}) {
      super({
        ...options,
        position: forgeViewportPosition(options.position),
      });
      this.initialValues = initialForgeValues(forgeOptions);
      this._forgePendingValues = this.initialValues;
      this._forgeBusy = false;
      this._forgeResizeAttached = false;
      this._forgeResizeHandler = () => this.keepInsideViewport();
    }

    async _prepareContext(options) {
      const context = await super._prepareContext(options);
      return { ...context, ...dialogContext() };
    }

    async _preRender(context, options) {
      if (this.rendered && this.form) {
        try { this._forgePendingValues = readDialogForm(this); }
        catch { this._forgePendingValues = this._forgePendingValues ?? this.initialValues; }
      }
      return super._preRender(context, options);
    }

    async _onRender(context, options) {
      await super._onRender(context, options);
      attachApplicationListeners(this, this._forgePendingValues ?? this.initialValues);
      attachApplicationResizeGrip(this, this.element);
      this._forgePendingValues = null;
      if (!this._forgeResizeAttached) {
        globalThis.addEventListener?.("resize", this._forgeResizeHandler, { passive: true });
        this._forgeResizeAttached = true;
      }
      if (!this._forgeWasVisuallyCentered) {
        requestAnimationFrame(() => {
          visuallyCenterApplication(this);
          keepApplicationVisuallyInsideViewport(this);
        });
        this._forgeWasVisuallyCentered = true;
      } else {
        this.keepInsideViewport();
      }
    }

    _onClose(options) {
      globalThis.removeEventListener?.("resize", this._forgeResizeHandler);
      this._forgeResizeAttached = false;
      persistForgeWindowSize(this.position);
      forgeApplicationInstance = null;
      return super._onClose(options);
    }

    keepInsideViewport() {
      if (!this.rendered) return;
      const size = forgeViewportPosition(this.position);
      const current = this.position ?? {};
      if (size.width !== current.width || size.height !== current.height) this.setPosition(size);
      requestAnimationFrame(() => keepApplicationVisuallyInsideViewport(this));
    }

    setBusy(busy) {
      this._forgeBusy = Boolean(busy);
      const submit = this.element?.querySelector?.("[data-forge-submit]");
      const close = this.element?.querySelector?.("[data-action=close]");
      const status = this.element?.querySelector?.("[data-forge-footer-status]");
      if (submit) {
        submit.disabled = this._forgeBusy;
        submit.innerHTML = this._forgeBusy
          ? '<i class="fa-solid fa-spinner fa-spin"></i> Создаю NPC…'
          : '<i class="fa-solid fa-hammer"></i> Создать NPC';
      }
      if (close) close.disabled = this._forgeBusy;
      if (status) status.textContent = this._forgeBusy
        ? "Не закрывай окно: Кузница выполняет подтверждённый план."
        : "Перед запуском ещё раз проверяется точный план операций.";
      this.element?.setAttribute?.("aria-busy", String(this._forgeBusy));
    }

    async submitForge() {
      if (this._forgeBusy) return null;
      this.setBusy(true);
      try {
        const form = readDialogForm(this);
        const result = await executeGeneration(form);
        if (result) await this.close();
        return result;
      } finally {
        if (this.rendered) this.setBusy(false);
      }
    }
  };

  return ForgeApplicationClass;
}

export async function openGenerator(options = {}) {
  try {
    if (game.system.id !== "pf2e") {
      ui.notifications.error("Кузница работает только в Pathfinder 2e.");
      return null;
    }
    if (!game.user.isGM) {
      ui.notifications.error("Открыть кузницу может только ведущий.");
      return null;
    }

    if (forgeApplicationInstance?.rendered) {
      forgeApplicationInstance.bringToFront();
      return forgeApplicationInstance;
    }

    const ForgeApplication = getForgeApplicationClass();
    forgeApplicationInstance = new ForgeApplication(
      { position: forgeViewportPosition() },
      options,
    );
    await forgeApplicationInstance.render(true);
    return forgeApplicationInstance;
  } catch (error) {
    console.error(`${MODULE_ID} | Не удалось открыть окно Кузницы`, error);
    ui.notifications.error(
      `Кузница не открылась: ${error?.message ?? String(error)}`,
      { permanent: true },
    );
    return null;
  }
}

export async function createLauncherMacro() {
  if (!game.user.isGM) return;
  let macro = game.macros.find(
    (candidate) => candidate.getFlag(MODULE_ID, "launcher") === true,
  );
  const data = {
    name: "Открыть кузницу NPC",
    type: "script",
    scope: "global",
    img: "icons/tools/smithing/hammer-sledge-steel-grey.webp",
    command: `game.modules.get("${MODULE_ID}")?.api?.openGenerator();`,
    flags: { [MODULE_ID]: { launcher: true } },
  };
  if (macro) {
    await macro.update(data);
  } else {
    const created = await Macro.create(data);
    macro = Array.isArray(created) ? created[0] : created;
  }
  return macro;
}

function actorDirectoryRoot(app, html) {
  if (html instanceof HTMLElement) return html;
  if (html?.[0] instanceof HTMLElement) return html[0];
  if (app?.element instanceof HTMLElement) return app.element;
  if (app?.element?.[0] instanceof HTMLElement) return app.element[0];
  return null;
}

function addActorDirectoryButton(app, html) {
  if (!game.user.isGM) return;
  const root = actorDirectoryRoot(app, html);
  if (!root || root.querySelector("[data-pf2e-npc-forge]")) return;
  const host =
    root.querySelector(".header-actions") ??
    root.querySelector(".directory-header") ??
    root.querySelector("header");
  if (!host) return;

  const button = document.createElement("button");
  button.type = "button";
  button.dataset.pf2eNpcForge = "true";
  button.className = "pf2e-npc-forge-launcher";
  button.innerHTML = '<i class="fa-solid fa-hammer"></i> Кузница NPC';
  button.addEventListener("click", async (event) => {
    event.preventDefault();
    event.stopPropagation();
    button.disabled = true;
    try {
      await openGenerator();
    } catch (error) {
      console.error(`${MODULE_ID} | Ошибка обработчика кнопки`, error);
      ui.notifications.error(
        `Кузница не открылась: ${error?.message ?? String(error)}`,
        { permanent: true },
      );
    } finally {
      button.disabled = false;
    }
  });
  host.append(button);
}

Hooks.once("init", () => {
  registerForgeSettings(MODULE_ID);
  const module = game.modules.get(MODULE_ID);
  if (!module) return;
  module.api = {
    openGenerator,
    parseConcept,
    generateNpc,
    generateNpcBatch,
    getPreview,
    restoreFromHistoryEntry,
    runDiagnostics,
    runSessionAudit,
    runUiControlAudit,
    getLastAuditReport: () => getLastAuditReportRecord({ meta: getLastAuditReportMeta(MODULE_ID) }),
    saveLastAuditReportAs: async () => {
      const record = await getLastAuditReportRecord({ meta: getLastAuditReportMeta(MODULE_ID) });
      if (!record) throw new Error("Последний отчёт не найден.");
      return saveAuditRecordAs(record);
    },
    copyLastAuditReport: async () => {
      const record = await getLastAuditReportRecord({ meta: getLastAuditReportMeta(MODULE_ID) });
      if (!record) throw new Error("Последний отчёт не найден.");
      return copyAuditRecord(record);
    },
    deployActorsToScene,
    createEncounterBriefing,
    createLauncherMacro,
    selectedNpcInfo,
  emptySelectedNpcInfo,
    tables: tablesForDebug,
    randomFormValues,
    randomMonsterFormValues,
  };
  console.log(`${MODULE_ID} | Модуль готов.`);
});

Hooks.on("renderActorDirectory", addActorDirectoryButton);
