import { ANCESTRIES, PROFESSIONS, ROLES, WEAPONS } from "./blueprints.js";

const PERSON_ANCESTRIES = [
  "human", "elf", "halfElf", "dwarf", "orc", "goblin", "halfling", "tiefling", "kitsune", "catfolk",
];
const PERSON_PROFESSIONS = [
  "warrior", "knight", "guard", "scout", "doctor", "alchemist", "priest", "mage", "thief", "bandit", "merchant", "hunter",
];
const TECH_PROFESSIONS = [
  "mercenary", "engineer", "operative", "technomancer", "mystic", "pilot",
];

const FEMALE_NAMES = [
  "Аделина", "Агата", "Айлин", "Алиса", "Амалия", "Ариана", "Беатрис", "Валерия", "Велена", "Верена",
  "Виола", "Гвинет", "Дария", "Делия", "Зара", "Илона", "Ириса", "Кассандра", "Катрина", "Кира",
  "Лавиния", "Лиара", "Лорена", "Люция", "Майра", "Мелисса", "Мирабель", "Моргана", "Навра", "Нерия",
  "Оливия", "Равена", "Руми", "Сабрина", "Селена", "Сиена", "Талия", "Тереза", "Фрейя", "Шелла",
  "Эвелин", "Элира", "Эстель", "Юна", "Ясмин", "Аска", "Хината", "Мэй", "Наоми", "Рейка",
  "Сора", "Эйко", "Кайла", "Найра", "Тесс", "Веспа", "Корин", "Мара", "Сильва", "Фиона",
];
const MALE_NAMES = [
  "Альрик", "Арден", "Арманд", "Бран", "Валлен", "Варен", "Гаррет", "Гектор", "Дамир", "Дариан",
  "Дейн", "Дориан", "Кайден", "Коэн", "Корвин", "Леон", "Лоркан", "Маркел", "Меррик", "Нолан",
  "Орен", "Рейнар", "Родерик", "Сайрус", "Северин", "Теодор", "Торен", "Тристан", "Фарен", "Харакон",
  "Эдрик", "Элиас", "Эммер", "Юстас", "Яромир", "Акира", "Дайти", "Кэнто", "Рэн", "Рюдзи",
  "Синдзи", "Такахиро", "Хару", "Юто", "Лунь", "Борин", "Грим", "Дорн", "Краг", "Малек",
  "Неро", "Роуэн", "Сорен", "Тарек", "Флинт", "Касс", "Оррик", "Вейлан", "Тален", "Ивар",
];
const NEUTRAL_NAMES = [
  "Аш", "Вейр", "Кай", "Рин", "Сай", "Тир", "Ноа", "Эйр", "Ари", "Вэл", "Джен", "Иви",
  "Кесс", "Лекс", "Мер", "Никс", "Орн", "Рэй", "Сол", "Тэй", "Фен", "Шай", "Эл", "Юн",
  "Зен", "Кио", "Лин", "Мо", "Пакс", "Рук", "Сен", "Тор", "Умбра", "Флоу", "Крис", "Адан",
];

const FANTASY_NAME_PARTS = {
  human: {
    starts: ["Аль", "Бе", "Вар", "Гве", "Да", "Эл", "Ир", "Ка", "Ле", "Ма", "Нор", "Ро", "Се", "Та", "Фе", "Яр"],
    ends: ["рик", "рен", "лия", "вин", "дар", "ана", "ис", "ор", "ена", "ель", "ан", "ия", "имир", "ет", "она", "слав"],
  },
  elf: {
    starts: ["Аэ", "Эли", "Лиа", "Саэ", "Ти", "Ваэ", "Най", "Ири", "Фаэ", "Кэл", "Миэ", "Руэ"],
    ends: ["лин", "риэль", "вен", "лана", "дор", "тиэль", "мир", "лис", "ра", "ниэль", "сар", "виан"],
  },
  halfElf: {
    starts: ["Ари", "Эли", "Кай", "Лор", "Мира", "Тал", "Рей", "Си", "Вэ", "Нор"],
    ends: ["эн", "эль", "ин", "ара", "ор", "иан", "ис", "вен", "ир", "аэль"],
  },
  dwarf: {
    starts: ["Бар", "Бро", "Дор", "Гим", "Гран", "Каз", "Кор", "Тор", "Хар", "Брин", "Мор", "Рун"],
    ends: ["дин", "грим", "рик", "гар", "дис", "ра", "мунд", "вальд", "ни", "бор", "дра", "кель"],
  },
  orc: {
    starts: ["Гар", "Гру", "Краг", "Мог", "Раш", "Тар", "Ур", "Хар", "Ша", "Браг", "Дур", "Зог"],
    ends: ["ак", "уг", "аш", "гар", "ог", "ра", "мак", "дур", "нак", "ша", "гул", "рак"],
  },
  goblin: {
    starts: ["Бик", "Гиз", "Крак", "Мип", "Ник", "Пок", "Рик", "Сни", "Тик", "Физ", "Чик", "Зип"],
    ends: ["си", "зик", "рак", "пик", "ник", "ка", "рик", "шик", "ток", "би", "кса", "гит"],
  },
  halfling: {
    starts: ["Бел", "Джо", "Кори", "Лили", "Мило", "Нел", "Пип", "Рози", "Тоби", "Фин", "Хол", "Эм"],
    ends: ["вин", "бел", "рик", "ла", "ло", "ли", "пин", "зи", "би", "нан", "лиа", "мет"],
  },
  tiefling: {
    starts: ["Аз", "Вел", "Зар", "Кси", "Мал", "Най", "Рав", "Сар", "Тэз", "Фер", "Шел", "Эз"],
    ends: ["ари", "ира", "ион", "ет", "аз", "иэль", "рак", "тис", "вен", "ора", "ла", "рин"],
  },
  kitsune: {
    starts: ["Аки", "Хана", "Кио", "Мэй", "Нао", "Рей", "Рин", "Сора", "Таки", "Юки", "Касу", "Миц"],
    ends: ["ра", "ко", "ми", "то", "на", "ка", "ши", "ё", "ри", "дзэ", "ки", "хэ"],
  },
  catfolk: {
    starts: ["Амар", "Баст", "Зира", "Каир", "Лума", "Мау", "Нара", "Саф", "Таби", "Фари", "Шани", "Яра"],
    ends: ["ра", "ир", "са", "ан", "и", "у", "эль", "та", "ри", "ша", "ма", "ка"],
  },
};

const FANTASY_SURNAMES = [
  "Эшфорд", "Блэквуд", "Вейл", "Ривермарк", "Стоун", "Фарроу", "Грей", "Торн", "Винтерс", "Холт",
  "Редвейн", "Кроу", "Марш", "Дейн", "Фелл", "Харт", "Брайар", "Локк", "Морроу", "Роуэн",
  "Айронвуд", "Сильвер", "Вест", "Норт", "Келлен", "Варден", "Фрост", "Эмбер", "Голд", "Старк",
  "Лис", "Ворон", "Дубров", "Ратник", "Озерный", "Каменев", "Яров", "Берест", "Ветров", "Север",
  "Тихий", "Зорин", "Ланской", "Речной", "Клинок", "Щит", "Лунный", "Рассвет", "Сумрак", "Пепел",
];

const TECH_NAME_PREFIXES = ["Астра", "Вектор", "Кварк", "Неон", "Нова", "Оникс", "Пульсар", "Реликт", "Сигма", "Терра", "Фотон", "Эхо", "Зеро", "Люмен", "Орбита", "Кобальт"];
const TECH_NAME_SUFFIXES = ["-3", "-7", "-9", "-12", " Прайм", " Вега", " Кассини", " Нокс", " Рэй", " Вольт", " Кейн", " Сато", " Кросс", " Вейл", " Куинн", " Морроу"];
const TECH_CALLSIGNS = ["Фантом", "Спектр", "Комета", "Дельта", "Геликс", "Блик", "Резонанс", "Шрам", "Стилет", "Меридиан", "Искра", "Нимб", "Порог", "Гравий", "Каскад", "Тень", "Радар", "Тритон", "Шёпот", "Молот"];


const ADJECTIVES = [
  "осторожный", "угрюмый", "деловитый", "молчаливый", "опытный", "нервный",
  "самоуверенный", "внимательный", "изобретательный", "суровый", "учтивый",
  "потрёпанный дорогой", "неожиданно опасный", "хладнокровный",
];

const PROFESSION_DETAILS = {
  warrior: ["ветеран наёмных отрядов", "дуэлянт без хозяина", "профессиональный телохранитель"],
  knight: ["странствующий латник", "обедневший дворянин", "рыцарь пограничья"],
  guard: ["городской дозорный", "караульный склада", "опытный привратник"],
  scout: ["проводник", "лазутчик", "дальний разведчик"],
  doctor: ["полевой хирург", "аптекарь", "странствующий лекарь"],
  alchemist: ["варщик эликсиров", "подрывник", "лабораторный ремесленник"],
  priest: ["служитель небольшого храма", "паломник", "боевой капеллан"],
  mage: ["учёный маг", "бродячий чародей", "исследователь руин"],
  thief: ["взломщик", "карманник", "специалист по тайным проходам"],
  bandit: ["налётчик", "дорожный разбойник", "главарь маленькой шайки"],
  merchant: ["караванный торговец", "лавочник", "оценщик редкостей"],
  hunter: ["егерь", "охотник за головами", "следопыт-одиночка"],
  mercenary: ["контрактник с винтовкой", "охранник колонии", "ветеран корпоративной войны"],
  engineer: ["полевой инженер", "ремонтник автоматонов", "специалист по энергосистемам"],
  operative: ["разведчик-оперативник", "диверсант", "агент под прикрытием"],
  technomancer: ["техномант", "исследователь магических сетей", "боевой программист"],
  mystic: ["полевой мистик", "психический целитель", "проводник коллективного разума"],
  pilot: ["пилот-наёмник", "водитель боевой машины", "звёздный курьер"],
  raider: ["налётчик племени", "разведчик логова", "собиратель трофеев"],
  packHunter: ["загонщик", "старший охотник", "следопыт стаи"],
  trapper: ["мастер ловушек", "хранитель проходов", "сапёр логова"],
  shaman: ["толкователь духов", "хранитель костей", "заклинатель племени"],
  chieftain: ["военный вождь", "старейшина", "предводитель охоты"],
  tribalHunter: ["болотный охотник", "защитник кладки", "следопыт племени"],
};

const ROLE_ALTERNATIVES = {
  brute: ["brute", "soldier"],
  soldier: ["soldier", "controller", "brute"],
  skirmisher: ["skirmisher", "sniper"],
  sniper: ["sniper", "skirmisher"],
  controller: ["controller", "support", "soldier"],
  support: ["support", "controller", "healer"],
  healer: ["healer", "support", "caster"],
  caster: ["caster", "controller", "support", "summoner"],
  ambusher: ["ambusher", "lurker", "skirmisher"],
  packHunter: ["packHunter", "ambusher", "berserker"],
  defender: ["defender", "soldier", "controller"],
  artillery: ["artillery", "sniper", "controller"],
  leader: ["leader", "controller", "soldier"],
  berserker: ["berserker", "brute", "packHunter"],
  lurker: ["lurker", "ambusher", "skirmisher"],
  summoner: ["summoner", "caster", "controller"],
  gunner: ["gunner", "artillery", "sniper", "soldier"],
  saboteur: ["saboteur", "infiltrator", "ambusher", "controller"],
  technician: ["technician", "support", "healer", "controller"],
  infiltrator: ["infiltrator", "ambusher", "skirmisher", "saboteur"],
};

const ROLE_WEAPONS = {
  brute: ["greataxe", "greatsword", "fists"],
  soldier: ["longswordShield", "spearShield", "halberd", "longsword"],
  skirmisher: ["shortsword", "dagger", "shortbow", "spear"],
  sniper: ["shortbow", "crossbow"],
  controller: ["spearShield", "staff", "longswordShield"],
  support: ["dagger", "staff", "fists"],
  healer: ["dagger", "staff", "fists"],
  caster: ["staff", "dagger"],
  ambusher: ["dagger", "shortsword", "dogslicer", "shortbow"],
  packHunter: ["jaws", "spear", "flail", "shortbow"],
  defender: ["longswordShield", "spearShield", "slam"],
  artillery: ["crossbow", "shortbow", "sling", "acidSpit"],
  leader: ["longswordShield", "spearShield", "flail", "greatsword"],
  berserker: ["claws", "greataxe", "greatsword", "maul"],
  lurker: ["claws", "jaws", "dagger", "morningstar"],
  summoner: ["staff", "dagger"],
  gunner: ["laserRifle", "arcRifle", "plasmaCaster", "scattergun", "arquebus"],
  saboteur: ["semiAutoPistol", "laserPistol", "scattergun", "dagger"],
  technician: ["laserPistol", "shockTruncheon", "staff"],
  infiltrator: ["laserPistol", "semiAutoPistol", "plasmaSword", "dagger"],
};

export function hashSeed(value) {
  const text = String(value ?? "forge");
  let hash = 2166136261;
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

export function deriveSeed(seed, salt = "") {
  return hashSeed(`${seed}:${salt}`);
}

export function createRng(seed) {
  let state = hashSeed(seed) || 0x6d2b79f5;
  return () => {
    state += 0x6d2b79f5;
    let value = state;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

export function randomSeed() {
  const cryptoValue = globalThis.crypto?.getRandomValues
    ? globalThis.crypto.getRandomValues(new Uint32Array(1))[0]
    : Math.floor(Math.random() * 0xffffffff);
  return cryptoValue >>> 0;
}

export function pick(values, rng) {
  if (!values?.length) return null;
  return values[Math.floor(rng() * values.length)];
}

export function sample(values, count, rng) {
  const source = [...new Set(values ?? [])];
  const result = [];
  while (source.length && result.length < count) {
    result.push(source.splice(Math.floor(rng() * source.length), 1)[0]);
  }
  return result;
}

export function randomNameForGender(gender, seed, { ancestry = "human", technology = "fantasy" } = {}) {
  const rng = createRng(deriveSeed(seed, `name:${ancestry}:${technology}`));
  if (technology === "starfinder" || technology === "magitech") {
    if (rng() < 0.42) return `«${pick(TECH_CALLSIGNS, rng)}-${1 + Math.floor(rng() * 99)}»`;
    return `${pick(TECH_NAME_PREFIXES, rng)}${pick(TECH_NAME_SUFFIXES, rng)}`;
  }
  const parts = FANTASY_NAME_PARTS[ancestry];
  let firstName = null;
  if (parts && rng() < 0.76) firstName = `${pick(parts.starts, rng)}${pick(parts.ends, rng)}`;
  const source = gender === "female"
    ? FEMALE_NAMES
    : gender === "male"
      ? MALE_NAMES
      : NEUTRAL_NAMES;
  firstName ||= pick(source, rng);
  return rng() < 0.38 ? `${firstName} ${pick(FANTASY_SURNAMES, rng)}` : firstName;
}

function randomLevel(rng) {
  const weighted = [0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 5, 5, 6, 7, 8, 9, 10];
  return pick(weighted, rng);
}

function armorForRole(role, rng) {
  const preferred = ROLES[role]?.defaultArmor ?? "light";
  const alternatives = {
    none: ["none", "light"],
    light: ["light", "light", "none", "medium"],
    medium: ["medium", "medium", "light", "heavy"],
    heavy: ["heavy", "heavy", "medium"],
  };
  return pick(alternatives[preferred] ?? [preferred], rng);
}

export function randomFormValues({ seed = randomSeed(), keep = {} } = {}) {
  const rng = createRng(seed);
  const kept = (key) => keep[key] !== undefined && keep[key] !== null && keep[key] !== "";
  const gender = kept("gender") ? keep.gender : pick(["female", "male", "unspecified"], rng);
  const ancestry = kept("ancestry") ? keep.ancestry : pick(PERSON_ANCESTRIES.filter((id) => ANCESTRIES[id]), rng);
  const technology = kept("technology")
    ? keep.technology
    : pick(["fantasy", "fantasy", "fantasy", "blackpowder", "magitech", "starfinder"], rng);
  const professionPool = ["magitech", "starfinder"].includes(technology)
    ? [...PERSON_PROFESSIONS, ...TECH_PROFESSIONS, ...TECH_PROFESSIONS]
    : PERSON_PROFESSIONS;
  const profession = kept("profession") ? keep.profession : pick(professionPool.filter((id) => PROFESSIONS[id]), rng);
  const contentSource = kept("contentSource")
    ? keep.contentSource
    : technology === "starfinder"
      ? "sf2e"
      : technology === "magitech"
        ? "mixed"
        : "pf2e";
  const baseRole = PROFESSIONS[profession]?.role ?? "soldier";
  const rolledRole = rng() < 0.75
    ? baseRole
    : pick(ROLE_ALTERNATIVES[baseRole] ?? [baseRole], rng);
  const role = kept("role") ? keep.role : rolledRole;
  const weaponChoices = (ROLE_WEAPONS[role] ?? [ROLES[role]?.defaultWeapon])
    .filter((value) => WEAPONS[value]);
  const weapon = kept("weapon")
    ? keep.weapon
    : pick(weaponChoices, rng) ?? ROLES[role]?.defaultWeapon ?? "longsword";
  const level = kept("level") ? Number(keep.level) : randomLevel(rng);
  const quality = kept("quality")
    ? keep.quality
    : level >= 3 && rng() < 0.14
      ? "elite"
      : "standard";
  const adjective = pick(ADJECTIVES, rng);
  const detail = pick(PROFESSION_DETAILS[profession] ?? [PROFESSIONS[profession].label], rng);
  const name = kept("name") ? keep.name : randomNameForGender(gender, seed, { ancestry, technology });
  const complexity = kept("complexity")
    ? keep.complexity
    : pick(["simple", "standard", "standard", "standard", "tactical"], rng);

  return {
    forgeSetting: technology === "starfinder" ? "starfinder" : "fantasy",
    creatureKind: keep.creatureKind ?? "person",
    monsterFamily: keep.monsterFamily ?? "none",
    prompt: kept("prompt")
      ? keep.prompt
      : `${adjective} ${detail}; снаряжение, характер и манера боя должны соответствовать профессии`,
    name,
    level,
    ancestry,
    gender,
    profession,
    role,
    armor: kept("armor") ? keep.armor : armorForRole(role, rng),
    weapon,
    quality,
    technology,
    contentSource,
    complexity,
    spellTheme: kept("spellTheme") ? keep.spellTheme : "auto",
    autoCorrect: keep.autoCorrect !== false,
    batchMode: keep.batchMode ?? "clones",
    randomSeed: String(seed),
    seedPersonality: String(deriveSeed(seed, "personality")),
    seedAbilities: String(deriveSeed(seed, "abilities")),
    seedSpells: String(deriveSeed(seed, "spells")),
    seedConsumables: String(deriveSeed(seed, "consumables")),
    seedToken: String(deriveSeed(seed, "token")),
    randomized: true,
    includeSkillActions: keep.includeSkillActions !== false,
    randomAbilities: keep.randomAbilities !== false,
    randomSpells: keep.randomSpells !== false,
    randomConsumables: keep.randomConsumables !== false,
    randomToken: keep.randomToken === true,
    tokenPath: keep.tokenPath ?? "tokens",
    tokenImage: "",
    target: keep.target ?? "new",
    itemPolicy: keep.itemPolicy ?? "generated",
    backupOriginal: keep.backupOriginal !== false,
    openSheet: keep.openSheet !== false,
    deploymentMode: keep.deploymentMode ?? "none",
    addToCombat: keep.addToCombat === true,
    createBriefing: keep.createBriefing === true,
    sendChatSummary: keep.sendChatSummary === true,
    confirmRiskyOperations: keep.confirmRiskyOperations !== false,
    adventureMode: keep.adventureMode ?? "off",
    includeLootPlan: keep.includeLootPlan === true,
    lootRichness: keep.lootRichness ?? "normal",
    monsterTemplate: keep.monsterTemplate ?? "none",
    count: (keep.target ?? "new") === "new" ? Number(keep.count) || 1 : 1,
  };
}

const SQUAD_SLOTS = [
  { profession: "guard", role: "controller", weapon: "longswordShield", armor: "heavy", label: "командир" },
  { profession: "guard", role: "soldier", weapon: "spearShield", armor: "heavy", label: "щитовой боец" },
  { profession: "hunter", role: "sniper", weapon: "crossbow", armor: "light", label: "стрелок" },
  { profession: "doctor", role: "healer", weapon: "dagger", armor: "light", label: "полевой лекарь" },
  { profession: "scout", role: "skirmisher", weapon: "shortsword", armor: "light", label: "разведчик" },
  { profession: "warrior", role: "brute", weapon: "greatsword", armor: "medium", label: "тяжёлый боец" },
];

const TECH_SQUAD_SLOTS = [
  { profession: "mercenary", role: "leader", weapon: "laserRifle", armor: "medium", label: "командир огневой группы" },
  { profession: "mercenary", role: "gunner", weapon: "plasmaCaster", armor: "medium", label: "тяжёлый стрелок" },
  { profession: "operative", role: "infiltrator", weapon: "laserPistol", armor: "light", label: "оперативник" },
  { profession: "engineer", role: "technician", weapon: "shockTruncheon", armor: "light", label: "полевой инженер" },
  { profession: "mystic", role: "healer", weapon: "laserPistol", armor: "light", label: "мистик поддержки" },
  { profession: "pilot", role: "skirmisher", weapon: "semiAutoPistol", armor: "light", label: "мобильный стрелок" },
];

export function squadMemberConcept(base, index) {
  const seed = String(deriveSeed(base.randomSeed, `squad-${index}`));
  const squadSlots = ["magitech", "starfinder"].includes(base.technology)
    ? TECH_SQUAD_SLOTS
    : SQUAD_SLOTS;
  const slot = squadSlots[index % squadSlots.length];
  const leader = index === 0;
  return {
    ...base,
    count: 1,
    target: "new",
    randomSeed: seed,
    seedPersonality: String(deriveSeed(seed, "personality")),
    seedAbilities: String(deriveSeed(seed, "abilities")),
    seedSpells: String(deriveSeed(seed, "spells")),
    seedConsumables: String(deriveSeed(seed, "consumables")),
    seedToken: String(deriveSeed(seed, "token")),
    name: randomNameForGender(base.gender, seed, { ancestry: base.ancestry, technology: base.technology }),
    profession: slot.profession,
    role: slot.role,
    weapon: slot.weapon,
    armor: slot.armor,
    quality: leader ? base.quality : "standard",
    complexity: leader && base.complexity === "simple" ? "standard" : base.complexity,
    prompt: `${base.prompt ? `${base.prompt}; ` : ""}${slot.label} одного согласованного отряда`,
    randomized: true,
    openSheet: false,
  };
}
