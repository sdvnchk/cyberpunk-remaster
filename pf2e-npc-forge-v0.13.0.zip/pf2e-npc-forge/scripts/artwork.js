import { createRng, deriveSeed } from "./randomizer.js";

const IMAGE_PATTERN = /\.(?:avif|gif|jpe?g|png|svg|webp)$/iu;
const MAX_IMAGES = 3000;
const MAX_DEPTH = 3;
const CACHE_TTL = 5 * 60 * 1000;
const imageCache = new Map();

function filePickerImplementation() {
  return (
    foundry.applications?.apps?.FilePicker?.implementation ??
    foundry.applications?.apps?.FilePicker ??
    globalThis.FilePicker
  );
}

async function browseData(path) {
  const Picker = filePickerImplementation();
  const browse = Picker?.browse ?? Picker?.implementation?.browse;
  if (typeof browse !== "function") {
    throw new Error("Foundry не предоставил API просмотра файлов.");
  }
  return browse.call(Picker, "data", path, { wildcard: false });
}

function normalizePath(value) {
  return String(value ?? "")
    .trim()
    .replaceAll("\\", "/")
    .replace(/^\/+|\/+$/gu, "");
}

async function collectImages(root, warnings) {
  const normalizedRoot = normalizePath(root);
  const cached = imageCache.get(normalizedRoot);
  if (cached && Date.now() - cached.createdAt < CACHE_TTL) {
    return [...cached.images];
  }
  const queue = [{ path: normalizedRoot, depth: 0 }];
  const visited = new Set();
  const images = [];
  while (queue.length && images.length < MAX_IMAGES) {
    const current = queue.shift();
    if (!current || visited.has(current.path)) continue;
    visited.add(current.path);
    let result;
    try {
      result = await browseData(current.path);
    } catch (error) {
      if (current.depth === 0) warnings.push(`Папка «${current.path || "/"}» недоступна.`);
      continue;
    }
    for (const file of result?.files ?? []) {
      if (IMAGE_PATTERN.test(file)) images.push(file);
      if (images.length >= MAX_IMAGES) break;
    }
    if (current.depth >= MAX_DEPTH) continue;
    for (const directory of result?.dirs ?? []) {
      queue.push({ path: directory, depth: current.depth + 1 });
    }
  }
  if (images.length) {
    imageCache.set(normalizedRoot, {
      createdAt: Date.now(),
      images: [...images],
    });
  }
  return images;
}

export function clearArtworkCache() {
  imageCache.clear();
}

const KEYWORDS = {
  ancestry: {
    human: ["human", "человек"], elf: ["elf", "эльф"], halfElf: ["half-elf", "halfelf", "полуэльф"],
    dwarf: ["dwarf", "дворф"], orc: ["orc", "орк"], goblin: ["goblin", "гоблин"],
    halfling: ["halfling", "полурослик"], tiefling: ["tiefling", "тифлинг", "devil"],
    kitsune: ["kitsune", "fox", "кицунэ", "лиса"], catfolk: ["catfolk", "cat", "амуррун", "кот"],
    gnoll: ["gnoll", "kholo", "гнолл", "холо"], kobold: ["kobold", "кобольд"],
    hobgoblin: ["hobgoblin", "хобгоблин"], bugbear: ["bugbear", "багбер"],
    lizardfolk: ["lizardfolk", "iruxi", "ящер", "ирукси"], ogre: ["ogre", "огр"],
    troll: ["troll", "тролл"], skeleton: ["skeleton", "скелет"], zombie: ["zombie", "зомби"],
    ghoul: ["ghoul", "гуль"], wolf: ["wolf", "волк"], warg: ["warg", "варг"],
    giantSpider: ["spider", "паук"], ooze: ["ooze", "slime", "слиз", "желе"],
    construct: ["construct", "golem", "automaton", "конструкт", "голем"],
  },
  gender: {
    female: ["female", "woman", "girl", "жен", "девуш"],
    male: ["male", "man", "boy", "муж", "парень"],
    unspecified: [],
  },
  profession: {
    warrior: ["warrior", "fighter", "воин"], knight: ["knight", "рыцар"], guard: ["guard", "soldier", "страж"],
    scout: ["scout", "ranger", "развед"], doctor: ["doctor", "medic", "healer", "врач"],
    alchemist: ["alchemist", "алхим"], priest: ["priest", "cleric", "жрец"], mage: ["mage", "wizard", "witch", "маг"],
    thief: ["thief", "rogue", "вор"], bandit: ["bandit", "raider", "разбой"], merchant: ["merchant", "trader", "торгов"],
    hunter: ["hunter", "ranger", "archer", "охот"],
    raider: ["raider", "marauder", "налет", "налёт"], packHunter: ["pack", "hunter", "стая", "охот"],
    trapper: ["trapper", "snare", "ловуш"], shaman: ["shaman", "шаман"],
    chieftain: ["chief", "chieftain", "boss", "вожак"], tribalHunter: ["tribal", "hunter", "племенн"],
    beast: ["beast", "animal", "звер"], undead: ["undead", "нежит"],
    necromancer: ["necromancer", "некромант"], monster: ["monster", "creature", "монстр"],
    construct: ["construct", "golem", "конструкт"],
  },
  role: {
    brute: ["brute", "heavy"], soldier: ["soldier", "guard"], skirmisher: ["rogue", "duelist"],
    sniper: ["archer", "sniper", "ranged"], controller: ["commander", "captain"], support: ["support", "civilian"],
    healer: ["healer", "medic"], caster: ["mage", "caster", "wizard"],
    ambusher: ["ambush", "assassin", "засад"], packHunter: ["pack", "стая"],
    defender: ["defender", "guardian", "защит", "страж"], artillery: ["artillery", "gunner", "стрел"],
    leader: ["leader", "chief", "captain", "вожак"], berserker: ["berserk", "rage", "берсерк"],
    lurker: ["lurker", "stalker", "скрыт", "хищник"], summoner: ["summoner", "призыв"],
  },
  family: {
    goblin: ["goblin", "гоблин"], gnoll: ["gnoll", "kholo", "гнолл"], kobold: ["kobold", "кобольд"],
    hobgoblin: ["hobgoblin", "хобгоблин"], bugbear: ["bugbear", "багбер"], lizardfolk: ["lizardfolk", "iruxi", "ящер"],
    ogre: ["ogre", "огр"], troll: ["troll", "тролл"], skeleton: ["skeleton", "скелет"], zombie: ["zombie", "зомби"],
    ghoul: ["ghoul", "гуль"], wolf: ["wolf", "волк"], warg: ["warg", "варг"], giantSpider: ["spider", "паук"],
    ooze: ["ooze", "slime", "слиз"], construct: ["construct", "golem", "automaton", "конструкт"],
  },
};

function pathScore(path, concept) {
  const value = decodeURIComponent(path).toLowerCase();
  let score = 0;
  for (const word of KEYWORDS.ancestry[concept.ancestry] ?? []) if (value.includes(word)) score += 6;
  for (const word of KEYWORDS.gender[concept.gender] ?? []) if (value.includes(word)) score += 2;
  for (const word of KEYWORDS.profession[concept.profession] ?? []) if (value.includes(word)) score += 5;
  for (const word of KEYWORDS.role[concept.role] ?? []) if (value.includes(word)) score += 3;
  for (const word of KEYWORDS.family[concept.monsterFamily] ?? []) if (value.includes(word)) score += 8;
  if (concept.monsterFamily && concept.monsterFamily !== "none" && /monster|creature|beast|undead|construct|монстр|звер|нежит/iu.test(value)) score += 2;
  if (value.includes("token")) score += 2;
  if (value.includes("portrait")) score += 1;
  if (/background|map|scene|battlemap|tile|icon/iu.test(value)) score -= 5;
  return score;
}

export async function randomArtwork(concept) {
  if (!concept.randomToken) return { path: null, score: null, warnings: [] };
  const warnings = [];
  const explicit = normalizePath(concept.tokenPath);
  const commonRoots = [
    "tokens",
    "art",
    "images",
    "assets",
    `worlds/${game.world?.id ?? ""}`,
  ].filter(Boolean);
  const roots = explicit
    ? [explicit, ...(explicit === "tokens" ? commonRoots.filter((root) => root !== explicit) : [])]
    : commonRoots;
  let images = [];
  for (const root of roots) {
    images = await collectImages(root, warnings);
    if (images.length) break;
  }
  if (!images.length) {
    warnings.push("Подходящие изображения не найдены; оставлен стандартный портрет.");
    return { path: null, score: null, warnings };
  }

  const ranked = images
    .map((path) => ({ path, score: pathScore(path, concept) }))
    .sort((left, right) => right.score - left.score);
  const bestScore = ranked[0]?.score ?? 0;
  const candidates = ranked
    .filter((entry) => entry.score >= Math.max(0, bestScore - 2))
    .slice(0, 40);
  const rng = createRng(deriveSeed(concept.seedToken ?? concept.randomSeed, "artwork"));
  const selected = candidates[Math.floor(rng() * candidates.length)] ?? ranked[0];
  if (bestScore <= 0) warnings.push("Точное совпадение по имени файла не найдено; выбран случайный портрет из указанной папки.");
  return { path: selected?.path ?? null, score: selected?.score ?? null, warnings };
}

export function artworkData(path, name) {
  if (!path) return {};
  return {
    img: path,
    prototypeToken: {
      actorLink: true,
      name,
      texture: { src: path },
    },
  };
}
