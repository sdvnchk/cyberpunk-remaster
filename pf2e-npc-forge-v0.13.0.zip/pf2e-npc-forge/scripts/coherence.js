import { ARMORS, PROFESSIONS, ROLES, WEAPONS } from "./blueprints.js";
import { familyForConcept } from "./monsters.js";
import { normalizeExecutionControls } from "./execution.js";

const SEVERITY_PENALTY = { info: 0, warning: 8, error: 20 };

function weaponTags(weaponId) {
  const weapon = WEAPONS[weaponId] ?? {};
  const tags = new Set();
  if (Number.isFinite(weapon.range)) tags.add("ranged");
  else tags.add("melee");
  if ((weapon.extraGear ?? []).includes("steel-shield")) tags.add("shield");
  if ((weapon.traits ?? []).some((trait) => String(trait).startsWith("reload-"))) {
    tags.add("reload");
  }
  if (
    ["greatsword", "greataxe", "halberd", "staff", "shortbow", "crossbow", "arquebus", "laserRifle", "arcRifle", "plasmaCaster", "scattergun"].includes(
      weaponId,
    )
  ) {
    tags.add("two-handed");
  }
  return tags;
}

function roleTags(roleId) {
  const tags = new Set();
  if (["brute", "soldier", "skirmisher", "ambusher", "packHunter", "defender", "berserker", "lurker", "leader"].includes(roleId)) tags.add("melee");
  if (["sniper", "artillery", "gunner"].includes(roleId)) tags.add("ranged");
  if (["support", "healer", "controller", "leader", "summoner", "technician"].includes(roleId)) tags.add("support");
  if (["caster", "summoner"].includes(roleId)) tags.add("magic");
  if (["skirmisher", "sniper", "ambusher", "packHunter", "lurker", "infiltrator"].includes(roleId)) tags.add("mobile");
  if (["gunner", "saboteur", "technician", "infiltrator"].includes(roleId)) tags.add("tech");
  return tags;
}

function professionTags(professionId) {
  const tags = new Set();
  if (["mage", "priest", "shaman", "necromancer", "technomancer", "mystic"].includes(professionId)) tags.add("magic");
  if (["mercenary", "engineer", "operative", "technomancer", "mystic", "pilot"].includes(professionId)) tags.add("tech");
  if (["doctor", "priest", "shaman", "mystic"].includes(professionId)) tags.add("healing");
  if (["hunter", "scout", "thief", "bandit", "raider", "packHunter", "trapper", "tribalHunter", "beast"].includes(professionId)) {
    tags.add("stealth");
  }
  if (professionId === "merchant") tags.add("social");
  return tags;
}

function weakestSave(concept) {
  const tiers = ROLES[concept.role]?.tiers ?? {};
  const rows = [
    ["Стойкость", tiers.fortitude],
    ["Рефлекс", tiers.reflex],
    ["Воля", tiers.will],
  ];
  const order = { terrible: 0, low: 1, moderate: 2, high: 3, extreme: 4 };
  rows.sort((left, right) => (order[left[1]] ?? 2) - (order[right[1]] ?? 2));
  return rows[0]?.[0] ?? "не определена";
}

export function analyzeConcept(concept) {
  const issues = [];
  const add = (severity, code, message, suggestion = null) => {
    issues.push({ severity, code, message, suggestion });
  };

  const weapon = WEAPONS[concept.weapon];
  const armor = ARMORS[concept.armor];
  const profession = PROFESSIONS[concept.profession];
  const weaponSet = weaponTags(concept.weapon);
  const roleSet = roleTags(concept.role);
  const professionSet = professionTags(concept.profession);
  const tags = new Set([...weaponSet, ...roleSet, ...professionSet]);
  const family = familyForConcept(concept);

  if (["sniper", "artillery", "gunner"].includes(concept.role) && !weaponSet.has("ranged")) {
    add(
      "error",
      "sniper-without-ranged",
      "Дальнобойная роль выбрана без дальнобойного оружия.",
      "Выбери лук, арбалет, огнестрельное или технологическое оружие.",
    );
  }

  if (family && family.allowedRoles?.length && !family.allowedRoles.includes(concept.role)) {
    add(
      "warning",
      "family-role-mismatch",
      `Роль «${ROLES[concept.role]?.label ?? concept.role}» нетипична для семейства «${family.label}».`,
      `Обычные варианты: ${family.allowedRoles.map((id) => ROLES[id]?.label ?? id).join(", ")}.`,
    );
  }
  if (["beast", "ooze"].includes(concept.creatureKind) && concept.armor !== "none") {
    add(
      "warning",
      "natural-creature-armor",
      "Зверь или слизь получили обычный носимый доспех.",
      "Оставь доспех только для бронированного, обученного или искусственно модифицированного варианта.",
    );
  }
  if (concept.creatureKind === "ooze" && !["pseudopod", "acidSpit"].includes(concept.weapon)) {
    add("warning", "ooze-weapon", "Слизь использует обычное изготовленное оружие.", "Выбери ложноножку или кислотный плевок.");
  }
  if (["undead", "construct", "ooze", "beast"].includes(concept.creatureKind) && concept.gender !== "unspecified") {
    add("info", "nonperson-gender", "Для этого типа существа пол обычно не влияет на статблок.");
  }
  if (concept.role === "brute" && weaponSet.has("ranged")) {
    add(
      "warning",
      "brute-ranged",
      "Громила с дальнобойным оружием теряет основную боевую идею.",
      "Для тяжёлого стрелка лучше роль стрелка или солдата.",
    );
  }
  if (concept.role === "caster" && concept.armor === "heavy") {
    add(
      "warning",
      "caster-heavy-armor",
      "Тяжёлый доспех плохо согласуется с базовой дорожной картой заклинателя.",
      "Оставь его только для боевого мага или смени на лёгкий доспех.",
    );
  }
  if (
    ["mage", "priest", "technomancer", "mystic"].includes(concept.profession) &&
    !concept.randomSpells
  ) {
    add(
      "error",
      "spellcaster-without-spells",
      "Профессия заклинателя выбрана, но создание заклинаний отключено.",
      "Включи тематический список заклинаний.",
    );
  }
  if (concept.profession === "doctor" && !concept.randomConsumables) {
    add(
      "warning",
      "doctor-without-supplies",
      "Врач создаётся без профессионального запаса лекарств.",
      "Включи расходники профессии.",
    );
  }
  if (concept.profession === "doctor" && !["healer", "support"].includes(concept.role)) {
    add(
      "warning",
      "doctor-combat-role",
      "Боевая роль врача не связана с лечением или поддержкой.",
      "Это допустимо для боевого медика, но стоит проверить способности.",
    );
  }
  if (concept.profession === "merchant" && !["support", "controller"].includes(concept.role)) {
    add(
      "info",
      "merchant-combat-role",
      "Торговец имеет необычную боевую роль; социальные навыки всё равно сохранятся.",
    );
  }
  if (professionSet.has("tech") && concept.technology === "fantasy") {
    add(
      "warning",
      "tech-profession-fantasy-source",
      "Технологическая профессия выбрана в чисто фэнтезийном режиме.",
      "Выбери магитех или SF2e, либо оставь это как намеренную аномалию мира.",
    );
  }
  if (concept.technology === "starfinder" && concept.contentSource === "pf2e") {
    add(
      "warning",
      "starfinder-without-sf2e",
      "Высокотехнологический концепт ограничен только классическим PF2e-контентом.",
      "Разреши смешанный режим или приоритет SF2e Anachronism.",
    );
  }
  if (weaponSet.has("two-handed") && weaponSet.has("shield")) {
    add(
      "error",
      "two-handed-shield",
      "Комплект одновременно требует двуручного оружия и щита.",
      "Оставь одно из двух.",
    );
  }
  if (weaponSet.has("shield") && concept.armor === "none") {
    add(
      "info",
      "shield-no-armor",
      "Щит без доспеха допустим, но создаёт заметно более хрупкого защитника.",
    );
  }
  if (concept.complexity === "tactical" && concept.level < 2) {
    add(
      "warning",
      "complexity-low-level",
      "Тактический режим на низком уровне может перегрузить второстепенного NPC.",
      "Для обычного статиста лучше простая или стандартная сложность.",
    );
  }
  if (concept.target === "selected" && !concept.backupOriginal) {
    add(
      "warning",
      "rebuild-without-backup",
      "Оригинальный NPC будет перестроен без автоматической резервной копии.",
      "Включи резервную копию.",
    );
  }

  const extremeCount = Object.values(concept.statTiers ?? {}).filter(
    (tier) => tier === "extreme",
  ).length;
  if (extremeCount > 2) {
    add(
      "warning",
      "too-many-extremes",
      "Больше двух предельных шкал делают NPC заметно сильнее обычной дорожной карты.",
      "Оставь предельными только главные стороны персонажа.",
    );
  }

  const score = Math.max(
    0,
    100 - issues.reduce((sum, issue) => sum + SEVERITY_PENALTY[issue.severity], 0),
  );
  const grade = score >= 90 ? "цельный" : score >= 75 ? "хороший" : score >= 55 ? "требует проверки" : "противоречивый";

  const strengths = [];
  if (roleSet.has("ranged") && weaponSet.has("ranged")) strengths.push("уверенная дальняя линия");
  if (roleSet.has("melee") && weaponSet.has("melee")) strengths.push("понятный ближний бой");
  if (professionSet.has("healing")) strengths.push("лечение и спасение союзников");
  if (professionSet.has("social")) strengths.push("социальное давление и торговля");
  if (professionSet.has("magic") || roleSet.has("magic")) strengths.push("магическая универсальность");
  if (weaponSet.has("shield")) strengths.push("повышенная защита");
  if (!strengths.length) strengths.push(profession?.summary?.toLowerCase() ?? "универсальный профиль");

  return {
    score,
    grade,
    issues,
    tags: [...tags],
    strengths: [...new Set(strengths)].slice(0, 3),
    weakness: `${weakestSave(concept)} и ${armor?.label ?? "неизвестная защита"}`,
    weaponLabel: weapon?.label ?? concept.weapon,
  };
}

export function normalizeConcept(concept) {
  const execution = normalizeExecutionControls(concept);
  const normalized = {
    ...execution.concept,
    statTiers: { ...(execution.concept.statTiers ?? {}) },
    abilityTiers: { ...(execution.concept.abilityTiers ?? {}) },
    skillTiers: { ...(execution.concept.skillTiers ?? {}) },
    elements: [...(execution.concept.elements ?? [])],
  };
  const corrections = [...execution.corrections];
  if (!normalized.autoCorrect) return { concept: normalized, corrections };

  if (["sniper", "artillery", "gunner"].includes(normalized.role) && !Number.isFinite(WEAPONS[normalized.weapon]?.range)) {
    normalized.weapon = normalized.role === "gunner"
      ? (normalized.technology === "starfinder" ? "laserRifle" : "arquebus")
      : normalized.role === "artillery"
        ? "crossbow"
        : normalized.profession === "hunter" ? "crossbow" : "shortbow";
    corrections.push("Для роли стрелка автоматически выбрано дальнобойное оружие.");
  }
  // Явно отключённые пользователем категории наполнения никогда не включаются
  // автокоррекцией. Такие решения отображаются как предупреждения согласованности,
  // но остаются под полным контролем ведущего.
  if (normalized.role === "caster" && normalized.weapon === "fists") {
    normalized.weapon = "staff";
    corrections.push("Заклинателю автоматически выдан посох как резервное оружие.");
  }
  if (normalized.role === "brute" && Number.isFinite(WEAPONS[normalized.weapon]?.range)) {
    normalized.weapon = "greataxe";
    corrections.push("Громиле автоматически подобрано тяжёлое оружие ближнего боя.");
  }

  const family = familyForConcept(normalized);
  if (family) {
    if (family.allowedRoles?.length && !family.allowedRoles.includes(normalized.role)) {
      normalized.role = family.defaultRole;
      corrections.push(`Для семейства «${family.label}» автоматически выбрана роль «${ROLES[normalized.role]?.label ?? normalized.role}».`);
    }
    if (["beast", "ooze"].includes(family.kind) && normalized.armor !== "none") {
      normalized.armor = family.defaultArmor ?? "none";
      corrections.push(`Для семейства «${family.label}» обычный носимый доспех заменён естественной защитой.`);
    }
    if (normalized.monsterFamily !== "none") {
      normalized.creatureKind = family.kind;
      normalized.ancestry = family.ancestry;
    }
  }

  return { concept: normalized, corrections };
}
