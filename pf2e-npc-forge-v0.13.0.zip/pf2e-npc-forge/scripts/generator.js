import {
  ANCESTRIES,
  ARMORS,
  GEAR_NAMES,
  PROFESSIONS,
  ROLES,
  SKILL_LABELS,
  WEAPONS,
} from "./blueprints.js";
import {
  CREATURE_TABLES,
  TIER_LABELS,
  eliteHpAdjustment,
  valueAt,
} from "./tables.js";
import { conceptSummary, genderLabel, validateConcept } from "./parser.js";
import { artworkData, randomArtwork } from "./artwork.js";
import { randomContentPlan } from "./random-content.js";
import { analyzeConcept, normalizeConcept } from "./coherence.js";
import { personalityPlan, tacticsPlan } from "./personality.js";
import { deriveSeed, randomNameForGender, squadMemberConcept } from "./randomizer.js";
import {
  familyForConcept,
  monsterEncounterMemberConcept,
  monsterFeaturePlan,
  monsterLorePlan,
  monsterStrikePlan,
  monsterSystemProfile,
} from "./monsters.js";
import { encounterPlan } from "./encounters.js";
import { DEPLOYMENT_MODES } from "./deployment.js";
import {
  actionEconomyPlan,
  auditAutomation,
  inlineSkillCheck,
  medicalProcedureSpec,
  skillCheckPanelSpec,
} from "./automation.js";
import { adventurePlan, lootInventoryPlan, monsterTemplatePlan } from "./director.js";
import {
  CATALOG_PACKS,
  CONTENT_SOURCES,
  TECHNOLOGY_LEVELS,
  cloneCatalogDocument,
  supportedEmbeddedType,
} from "./catalog.js";
import {
  normalizeActionCategory,
  sanitizeNpcSystem,
  sanitizePf2eItemSources,
} from "./schema-guard.js";

export const MODULE_ID = "pf2e-npc-forge";
export const MODULE_VERSION = "0.13.0";


const PUBLICATION = {
  authors: "Велес и ChatGPT",
  license: "ORC",
  remaster: true,
  title: "Кузница персонажей PF2e",
};

function replaceDocumentData(data) {
  return typeof globalThis._replace === "function"
    ? globalThis._replace(data)
    : data;
}

const ACTIONS_BY_PROFESSION = {
  warrior: ["grapple", "shove"],
  knight: ["demoralize", "grapple"],
  guard: ["grapple", "seek"],
  scout: ["hide", "sneak"],
  doctor: ["treat-wounds", "administer-first-aid"],
  alchemist: ["recall-knowledge", "aid"],
  priest: ["aid", "recall-knowledge"],
  mage: ["recall-knowledge", "seek"],
  thief: ["hide", "sneak"],
  bandit: ["demoralize", "hide"],
  merchant: ["make-an-impression", "sense-motive"],
  hunter: ["track", "seek"],
  raider: ["demoralize", "hide"],
  packHunter: ["track", "seek"],
  trapper: ["hide", "sneak"],
  shaman: ["recall-knowledge", "aid"],
  chieftain: ["demoralize", "aid"],
  tribalHunter: ["track", "seek"],
  beast: ["track", "seek"],
  undead: ["demoralize"],
  necromancer: ["recall-knowledge", "seek"],
  monster: ["grapple", "shove"],
  construct: ["seek", "grapple"],
  mercenary: ["demoralize", "seek"],
  engineer: ["recall-knowledge", "aid"],
  operative: ["hide", "sneak"],
  technomancer: ["recall-knowledge", "seek"],
  mystic: ["aid", "sense-motive"],
  pilot: ["seek", "aid"],
};

const ACTION_NAMES = {
  "administer-first-aid": "Оказать первую помощь",
  aid: "Помочь",
  demoralize: "Деморализовать",
  grapple: "Схватить",
  hide: "Спрятаться",
  "make-an-impression": "Произвести впечатление",
  "recall-knowledge": "Вспомнить сведения",
  seek: "Искать",
  "sense-motive": "Понять намерения",
  shove: "Толкнуть",
  sneak: "Красться",
  track: "Выслеживать",
  "treat-wounds": "Лечить раны",
};

const ROLE_FEATURE_NAMES = {
  brute: "Могучая хватка",
  soldier: "Защитная стойка",
  skirmisher: "Лёгкий шаг",
  sniper: "Прицеливание",
  controller: "Командный голос",
  support: "Всегда готов помочь",
  healer: "Уверенная рука",
  caster: "Сосредоточенный разум",
  ambusher: "Преимущество засады",
  packHunter: "Стайное давление",
  defender: "Живая преграда",
  artillery: "Подготовленная позиция",
  leader: "Центр строя",
  berserker: "Неистовая ярость",
  lurker: "Терпеливый хищник",
  summoner: "Власть над прислужниками",
  gunner: "Огневая дисциплина",
  saboteur: "Подготовленный заряд",
  technician: "Полевой ремонт",
  infiltrator: "Беззвучное проникновение",
};

const ELEMENT_ATTACKS = {
  fire: {
    name: "Огненный сгусток",
    burstName: "Огненная вспышка",
    damageType: "fire",
    description: "Сгусток обжигающего пламени.",
  },
  water: {
    name: "Ударная струя",
    burstName: "Сокрушающая волна",
    damageType: "bludgeoning",
    description: "Сжатая струя воды сбивает дыхание.",
  },
  electricity: {
    name: "Электрическая дуга",
    burstName: "Грозовой разряд",
    damageType: "electricity",
    description: "Узкая дуга электрического разряда.",
  },
  cold: {
    name: "Морозный осколок",
    burstName: "Морозная вспышка",
    damageType: "cold",
    description: "Осколок пронизывающего холода.",
  },
  force: {
    name: "Силовой разряд",
    burstName: "Силовой выброс",
    damageType: "force",
    description: "Сгусток чистой магической силы.",
  },
};

function elementForConcept(concept) {
  const element =
    concept.elements[0] ??
    (concept.ancestry === "tiefling" ? "fire" : "force");
  return { element, data: ELEMENT_ATTACKS[element] ?? ELEMENT_ATTACKS.force };
}

const GEAR_DESCRIPTIONS = {
  "alchemists-toolkit": "Набор инструментов и реактивов для алхимической работы.",
  backpack: "Прочный дорожный рюкзак.",
  bedroll: "Свёрнутый дорожный спальный мешок.",
  "healers-toolkit": "Полный набор бинтов, игл, зажимов и лекарских принадлежностей.",
  rope: "Прочная верёвка для путешествий и работы.",
  "religious-symbol-wooden": "Деревянный знак веры.",
  "scholarly-journal": "Записи, формулы и наблюдения владельца.",
  "steel-shield": "Надёжный стальной щит.",
  "thieves-toolkit": "Набор отмычек и тонких инструментов.",
  "comm-unit": "Персональное устройство защищённой связи.",
  "medpatch-commercial": "Серийный медицинский пластырь первой помощи.",
  "medkit-commercial": "Высокотехнологичный медицинский комплект.",
  "repair-toolkit-commercial": "Серийный набор для ремонта техники.",
  "makers-toolkit-commercial": "Серийный набор инженера и изготовителя.",
  "hacking-toolkit-commercial": "Серийный набор для работы с защищёнными системами.",
  "infiltrators-toolkit-commercial": "Серийный комплект скрытого проникновения.",
  "data-chip": "Универсальный защищённый носитель данных.",
  "battery-commercial": "Серийная батарея для энергетического оружия.",
  "projectile-ammo": "Стандартные боеприпасы для стрелкового оружия.",
  "medics-armband": "Понятный знак медика, помогающий союзникам быстро найти лекаря.",
  "yarrow-root-bandage": "Готовая перевязка для остановки крови и полевой помощи.",
  soap: "Простой, но важный предмет для гигиены и обработки рук перед лечением.",
  waterskin: "Запас чистой воды для пути, лечения и разведения составов.",
  "holy-water": "Освящённая вода для ритуалов и борьбы с нечистью.",
  "book-of-warding-prayers": "Сборник коротких защитных молитв и обрядов.",
  "formula-book-blank": "Книга для формул, рецептов и заметок о реактивах.",
  "spellbook-blank": "Книга для магических записей и подготовленных формул.",
  "writing-set": "Чернила, перо и бумага для приказов, карт и медицинских записей.",
  chalk: "Мел для отметок, схем, кругов и обозначения безопасного пути.",
  compass: "Надёжный компас для разведки и путешествий.",
  "climbing-kit": "Ремни, крюки и крепления для безопасного подъёма.",
  "grappling-hook": "Крюк для подъёма, закрепления верёвки и преодоления преград.",
  "lantern-hooded": "Фонарь с заслонкой для управляемого света.",
  rations: "Небольшой запас еды для дежурства или дороги.",
  "signal-whistle": "Свисток для тревоги, построения и передачи простых сигналов.",
  "magnifying-glass": "Инструмент для осмотра ран, следов, документов и мелких деталей.",
  crowbar: "Прочный рычаг для дверей, ящиков и аварийных работ.",
  "basic-crafters-book": "Практический справочник с базовыми схемами и рецептами.",
  "antidote-lesser": "Запас противоядия для оказания помощи при отравлении.",
  "antiplague-lesser": "Профилактическое средство для работы с инфекциями и больными.",
  "flashlight-commercial": "Надёжный серийный источник направленного света.",
  "filtered-rebreather-commercial": "Защищает от дыма, пыли и части опасной атмосферы.",
  datapad: "Полевой терминал для карт, записей, схем и инструкций.",
  "fire-extinguisher-commercial": "Средство аварийного тушения пожара и технических возгораний.",
  "field-scientists-toolkit-commercial": "Датчики и инструменты для анализа среды и образцов.",
  "holoskin-commercial": "Устройство визуальной маскировки и смены внешнего вида.",
  "climbing-kit-commercial": "Технологический комплект для подъёма и страховки.",
};

const PROFESSION_FLAVOR_GEAR = Object.freeze({
  warrior: [{ slug: "rations" }, { slug: "waterskin" }],
  knight: [{ slug: "signal-whistle" }, { slug: "rations" }],
  guard: [{ slug: "signal-whistle" }, { slug: "lantern-hooded" }],
  scout: [{ slug: "compass" }, { slug: "climbing-kit" }, { slug: "grappling-hook" }, { slug: "rations" }],
  doctor: [{ slug: "medics-armband" }, { slug: "yarrow-root-bandage", quantity: 2 }, { slug: "soap" }, { slug: "waterskin" }, { slug: "writing-set" }],
  alchemist: [{ slug: "formula-book-blank" }, { slug: "chalk", quantity: 5 }, { slug: "waterskin" }, { slug: "soap" }],
  priest: [{ slug: "holy-water", quantity: 2 }, { slug: "book-of-warding-prayers" }, { slug: "healers-toolkit" }],
  mage: [{ slug: "spellbook-blank" }, { slug: "writing-set" }, { slug: "chalk", quantity: 5 }, { slug: "magnifying-glass" }],
  thief: [{ slug: "crowbar" }, { slug: "chalk", quantity: 5 }, { slug: "grappling-hook" }],
  bandit: [{ slug: "rations" }, { slug: "waterskin" }, { slug: "crowbar" }],
  merchant: [{ slug: "writing-set" }, { slug: "magnifying-glass" }, { slug: "soap" }, { slug: "rations" }],
  hunter: [{ slug: "compass" }, { slug: "climbing-kit" }, { slug: "rations" }, { slug: "waterskin" }],
  trapper: [{ slug: "chalk", quantity: 5 }, { slug: "grappling-hook" }, { slug: "lantern-hooded" }],
  shaman: [{ slug: "healers-toolkit" }, { slug: "holy-water" }, { slug: "waterskin" }],
  necromancer: [{ slug: "spellbook-blank" }, { slug: "writing-set" }, { slug: "lantern-hooded" }],
  mercenary: [{ slug: "flashlight-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e }, { slug: "filtered-rebreather-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e }, { slug: "medpatch-commercial", quantity: 2, preferredPack: CATALOG_PACKS.equipment.sf2e }],
  engineer: [{ slug: "datapad", preferredPack: CATALOG_PACKS.equipment.sf2e }, { slug: "flashlight-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e }, { slug: "fire-extinguisher-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e }, { slug: "field-scientists-toolkit-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e }],
  operative: [{ slug: "datapad", preferredPack: CATALOG_PACKS.equipment.sf2e }, { slug: "flashlight-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e }, { slug: "holoskin-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e }],
  technomancer: [{ slug: "datapad", preferredPack: CATALOG_PACKS.equipment.sf2e }, { slug: "field-scientists-toolkit-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e }, { slug: "flashlight-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e }],
  mystic: [{ slug: "medpatch-commercial", quantity: 3, preferredPack: CATALOG_PACKS.equipment.sf2e }, { slug: "filtered-rebreather-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e }, { slug: "datapad", preferredPack: CATALOG_PACKS.equipment.sf2e }],
  pilot: [{ slug: "flashlight-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e }, { slug: "filtered-rebreather-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e }, { slug: "climbing-kit-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e }],
});

const TECH_PROFESSION_FLAVOR_GEAR = Object.freeze({
  doctor: [
    { slug: "medkit-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "comm-unit", preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "datapad", preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "medpatch-commercial", quantity: 3, preferredPack: CATALOG_PACKS.equipment.sf2e },
  ],
  mercenary: [
    { slug: "comm-unit", preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "battery-commercial", quantity: 2, preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "filtered-rebreather-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
  ],
  engineer: [
    { slug: "repair-toolkit-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "makers-toolkit-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "comm-unit", preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "data-chip", quantity: 2, preferredPack: CATALOG_PACKS.equipment.sf2e },
  ],
  operative: [
    { slug: "hacking-toolkit-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "infiltrators-toolkit-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "comm-unit", preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "data-chip", preferredPack: CATALOG_PACKS.equipment.sf2e },
  ],
  technomancer: [
    { slug: "datapad", preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "data-chip", quantity: 2, preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "battery-commercial", quantity: 2, preferredPack: CATALOG_PACKS.equipment.sf2e },
  ],
  mystic: [
    { slug: "medpatch-commercial", quantity: 3, preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "comm-unit", preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "datapad", preferredPack: CATALOG_PACKS.equipment.sf2e },
  ],
  pilot: [
    { slug: "comm-unit", preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "datapad", preferredPack: CATALOG_PACKS.equipment.sf2e },
    { slug: "filtered-rebreather-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
  ],
});

function professionFlavorGear(concept) {
  const starfinder = concept.technology === "starfinder" || concept.contentSource === "sf2e";
  if (starfinder && TECH_PROFESSION_FLAVOR_GEAR[concept.profession]) return TECH_PROFESSION_FLAVOR_GEAR[concept.profession];
  return PROFESSION_FLAVOR_GEAR[concept.profession] ?? [];
}

const ROLE_FLAVOR_GEAR = Object.freeze({
  defender: {
    fantasy: [
      { slug: "signal-whistle" },
      { slug: "rope" },
      { slug: "rations" },
    ],
    starfinder: [
      { slug: "comm-unit", preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "battery-commercial", quantity: 2, preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "medpatch-commercial", quantity: 2, preferredPack: CATALOG_PACKS.equipment.sf2e },
    ],
  },
  sniper: {
    fantasy: [
      { slug: "compass" },
      { slug: "climbing-kit" },
      { slug: "grappling-hook" },
    ],
    starfinder: [
      { slug: "datapad", preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "climbing-kit-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "battery-commercial", quantity: 3, preferredPack: CATALOG_PACKS.equipment.sf2e },
    ],
  },
  leader: {
    fantasy: [
      { slug: "signal-whistle" },
      { slug: "writing-set" },
      { slug: "compass" },
    ],
    starfinder: [
      { slug: "comm-unit", preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "datapad", preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "data-chip", preferredPack: CATALOG_PACKS.equipment.sf2e },
    ],
  },
  saboteur: {
    fantasy: [
      { slug: "crowbar" },
      { slug: "chalk", quantity: 5 },
      { slug: "rope" },
    ],
    starfinder: [
      { slug: "hacking-toolkit-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "data-chip", quantity: 2, preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "flashlight-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
    ],
  },
  gunner: {
    starfinder: [
      { slug: "battery-commercial", quantity: 4, preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "comm-unit", preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "filtered-rebreather-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
    ],
  },
  healer: {
    fantasy: [
      { slug: "healers-toolkit" },
      { slug: "yarrow-root-bandage", quantity: 2 },
      { slug: "antidote-lesser", quantity: 2 },
      { slug: "antiplague-lesser", quantity: 2 },
    ],
    starfinder: [
      { slug: "medpatch-commercial", quantity: 3, preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "field-scientists-toolkit-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "filtered-rebreather-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
    ],
  },
  support: {
    fantasy: [
      { slug: "signal-whistle" },
      { slug: "writing-set" },
      { slug: "rations" },
    ],
    starfinder: [
      { slug: "comm-unit", preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "datapad", preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "medpatch-commercial", quantity: 2, preferredPack: CATALOG_PACKS.equipment.sf2e },
    ],
  },
  technician: {
    fantasy: [
      { slug: "basic-crafters-book" },
      { slug: "crowbar" },
      { slug: "chalk", quantity: 5 },
    ],
    starfinder: [
      { slug: "repair-toolkit-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "makers-toolkit-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "datapad", preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "flashlight-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
    ],
  },
  infiltrator: {
    starfinder: [
      { slug: "infiltrators-toolkit-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "hacking-toolkit-commercial", preferredPack: CATALOG_PACKS.equipment.sf2e },
      { slug: "datapad", preferredPack: CATALOG_PACKS.equipment.sf2e },
    ],
  },
});

function roleFlavorGear(concept) {
  const setting = concept.technology === "starfinder" || concept.contentSource === "sf2e"
    ? "starfinder"
    : "fantasy";
  return ROLE_FLAVOR_GEAR[concept.role]?.[setting] ?? [];
}

function contentContext(concept, tiers = resolveTiers(concept), adjustment = 0) {
  const dc =
    valueAt(
      "dc",
      concept.level,
      normalizeCombatTier("dc", tiers.dc),
      "moderate",
    ) + adjustment;
  const damage = addDamageBonus(
    valueAt("damage", concept.level, "moderate", "moderate"),
    adjustment ? 2 : 0,
  );
  return { dc, damage };
}

const NATURAL_WEAPON_MATCHERS = {
  jaws: /челюст|укус/iu,
  claws: /когт/iu,
  pseudopod: /ложнонож|щупальц/iu,
  acidSpit: /плевок|кислотн.*стру/iu,
  slam: /удар|таран|кулак/iu,
};

function familyPrimaryStrike(concept, weapon) {
  const matcher = NATURAL_WEAPON_MATCHERS[concept.weapon];
  if (!matcher) return null;
  return monsterStrikePlan(concept).find((entry) => matcher.test(entry.name)) ?? null;
}

function plannedItems(concept) {
  const armor = ARMORS[concept.armor];
  const weapon = WEAPONS[concept.weapon];
  const profession = PROFESSIONS[concept.profession];
  const tiers = resolveTiers(concept);
  const adjustment = concept.quality === "elite" ? 2 : 0;
  const random = randomContentPlan(concept, contentContext(concept, tiers, adjustment));
  const allMonsterStrikes = monsterStrikePlan(concept);
  const primaryMonsterStrike = familyPrimaryStrike(concept, weapon);
  const monsterStrikes = allMonsterStrikes.filter((entry) => entry.slug !== primaryMonsterStrike?.slug);
  const monsterFeatures = monsterFeaturePlan(concept, contentContext(concept, tiers, adjustment));
  const template = monsterTemplatePlan(concept);
  const skills = resolveSkills(concept, adjustment);
  const supportFeatures = concept.includeSkillActions
    ? [skillCheckPanelSpec(concept, skills), medicalProcedureSpec(concept, skills)].filter(Boolean)
    : [];
  const equipment = [
    armor.slug ? armor.name : null,
    weapon.itemSlug ? weapon.itemName : null,
    ...(weapon.extraGear ?? []).map((slug) => GEAR_NAMES[slug] ?? slug),
    ...(profession.gear ?? []).map((slug) => GEAR_NAMES[slug] ?? slug),
    ...professionFlavorGear(concept).map((entry) => {
      const spec = typeof entry === "string" ? { slug: entry } : entry;
      return `${GEAR_NAMES[spec.slug] ?? spec.slug}${Number(spec.quantity) > 1 ? ` ×${spec.quantity}` : ""}`;
    }),
    ...roleFlavorGear(concept).map((entry) => {
      const spec = typeof entry === "string" ? { slug: entry } : entry;
      return `${GEAR_NAMES[spec.slug] ?? spec.slug}${Number(spec.quantity) > 1 ? ` ×${spec.quantity}` : ""}`;
    }),
    ...random.consumables.map((item) => `${item.name}${item.quantity > 1 ? ` ×${item.quantity}` : ""}`),
    ...lootInventoryPlan(concept).map((item) => `${item.name}${item.quantity > 1 ? ` ×${item.quantity}` : ""}`),
  ].filter(Boolean);
  const actions = [
    ROLE_FEATURE_NAMES[concept.role],
    ...random.features.map((feature) => feature.name),
    ...monsterFeatures.map((feature) => feature.name),
    ...template.features.map((feature) => feature.name),
    ...supportFeatures.map((feature) => feature.name),
    ...(concept.includeSkillActions ? (ACTIONS_BY_PROFESSION[concept.profession] ?? []) : []).map(
      (slug) => ACTION_NAMES[slug] ?? slug,
    ),
  ];
  if (concept.role === "caster" || concept.elements.length) {
    actions.push(elementForConcept(concept).data.burstName);
  }
  const strikes = [primaryMonsterStrike?.name ?? weapon.strikeName, ...monsterStrikes.map((entry) => entry.name)];
  if (concept.role === "caster" || concept.elements.length) {
    strikes.push(elementForConcept(concept).data.name);
  }
  return {
    equipment: [...new Set(equipment)],
    actions: [...new Set(actions)],
    strikes: [...new Set(strikes)],
    spells: random.spells?.spells.map((spell) => `${spell.name} (${spell.rank === 0 ? "чары" : `${spell.rank}-й ранг`})`) ?? [],
  };
}

function itemFlag(extra = {}) {
  return {
    [MODULE_ID]: {
      generated: true,
      version: MODULE_VERSION,
      ...extra,
    },
  };
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function slugify(value) {
  const slug = String(value ?? "")
    .normalize("NFKD")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, "-")
    .replace(/^-+|-+$/gu, "");
  return slug || "generated";
}

function normalizeHpTier(tier) {
  if (tier === "terrible") return "low";
  if (tier === "extreme") return "high";
  return tier;
}

function normalizeCombatTier(table, tier) {
  if (tier === "terrible") return "low";
  if (table === "dc" && tier === "low") return "moderate";
  return tier;
}

function addDamageBonus(formula, bonus) {
  return bonus > 0 ? `${formula}+${bonus}` : formula;
}

function resolveTiers(concept) {
  const role = ROLES[concept.role];
  return Object.fromEntries(
    Object.entries(role.tiers).map(([key, value]) => [
      key,
      concept.statTiers[key] ?? value,
    ]),
  );
}

function resolveAbilities(concept) {
  const roleAbilities = ROLES[concept.role].abilities;
  return Object.fromEntries(
    Object.entries(roleAbilities).map(([key, tier]) => [
      key,
      {
        mod:
          concept.abilityTiers[key] === "terrible"
            ? -5
            : valueAt(
                "ability",
                concept.level,
                normalizeCombatTier(
                  "ability",
                  concept.abilityTiers[key] ?? tier,
                ),
              ),
      },
    ]),
  );
}

function resolveSkills(concept, qualityAdjustment) {
  const roleSkills = ROLES[concept.role].skills;
  const professionSkills = PROFESSIONS[concept.profession].skills;
  const merged = { ...roleSkills, ...professionSkills };
  return Object.fromEntries(
    Object.entries(merged).map(([skill, tier]) => [
      skill,
      {
        base:
          valueAt(
            "skill",
            concept.level,
            normalizeCombatTier(
              "skill",
              concept.skillTiers?.[skill] ?? tier,
            ),
          ) + qualityAdjustment,
      },
    ]),
  );
}

function tierListHtml(tiers) {
  const rows = [
    ["КБ", tiers.ac],
    ["ОЗ", tiers.hp],
    ["Атака", tiers.attack],
    ["Урон", tiers.damage],
    ["Восприятие", tiers.perception],
    ["Стойкость", tiers.fortitude],
    ["Рефлекс", tiers.reflex],
    ["Воля", tiers.will],
  ];
  return rows
    .map(([label, tier]) => `${label}: ${TIER_LABELS[tier] ?? tier}`)
    .join("; ");
}

function buildActorSystem(concept) {
  const ancestry = monsterSystemProfile(concept, ANCESTRIES[concept.ancestry]);
  const family = familyForConcept(concept);
  const lore = monsterLorePlan(concept);
  const profession = PROFESSIONS[concept.profession];
  const role = ROLES[concept.role];
  const armor = ARMORS[concept.armor];
  const tiers = resolveTiers(concept);
  const elite = concept.quality === "elite";
  const adjustment = elite ? 2 : 0;
  const hpBase = valueAt(
    "hp",
    concept.level,
    normalizeHpTier(tiers.hp),
  );
  const hp = hpBase + (elite ? eliteHpAdjustment(concept.level) : 0);
  const generatedContent = randomContentPlan(
    concept,
    contentContext(concept, tiers, adjustment),
  );
  const personality = personalityPlan(concept);
  const tactics = tacticsPlan(concept, generatedContent.spells);
  const coherence = analyzeConcept(concept);
  const skills = resolveSkills(concept, adjustment);
  const template = monsterTemplatePlan(concept);
  const supportFeatures = concept.includeSkillActions
    ? [skillCheckPanelSpec(concept, skills), medicalProcedureSpec(concept, skills)].filter(Boolean)
    : [];
  const automation = auditAutomation({
    concept,
    skills,
    featureSpecs: [roleFeature(concept), ...generatedContent.features, ...template.features, ...supportFeatures],
  });
  const actionEconomy = actionEconomyPlan(concept, generatedContent.features);
  const adventure = adventurePlan(concept, { dc: contentContext(concept, tiers, adjustment).dc });
  const prompt = concept.prompt
    ? `<p><strong>Исходное описание:</strong> ${escapeHtml(concept.prompt)}</p>`
    : "";

  const publicNotes = [
    `<p><strong>${escapeHtml(concept.name)}</strong> — ${escapeHtml(
      ancestry.description.toLowerCase(),
    )}, ${escapeHtml(genderLabel(concept.gender))}. ${escapeHtml(
      profession.summary,
    )}</p>`,
    `<p><strong>Боевая роль:</strong> ${escapeHtml(role.label)}. ${escapeHtml(
      role.description,
    )}</p>`,
    lore
      ? `<p><strong>Семейство:</strong> ${escapeHtml(lore.label)}. ${escapeHtml(lore.description)}</p>`
      : "",
    template.id !== "none" ? `<p><strong>Преобразование:</strong> ${escapeHtml(template.label)}.</p>` : "",
    prompt,
  ].join("");

  const issueHtml = coherence.issues.length
    ? `<ul>${coherence.issues
        .map(
          (issue) =>
            `<li><strong>${escapeHtml(issue.severity)}:</strong> ${escapeHtml(
              issue.message,
            )}${issue.suggestion ? ` ${escapeHtml(issue.suggestion)}` : ""}</li>`,
        )
        .join("")}</ul>`
    : "<p>Критических противоречий не найдено.</p>";

  const privateNotes = [
    `<p><strong>Сводка конструктора:</strong> ${escapeHtml(
      conceptSummary(concept),
    )}.</p>`,
    `<p><strong>Согласованность:</strong> ${coherence.score}% — ${escapeHtml(
      coherence.grade,
    )}. Сильные стороны: ${escapeHtml(coherence.strengths.join(", "))}. Уязвимость: ${escapeHtml(
      coherence.weakness,
    )}.</p>`,
    issueHtml,
    lore ? `<h3>Экология и логово</h3>` : "",
    lore ? `<p><strong>Где встречается:</strong> ${escapeHtml(lore.ecology)}.</p>` : "",
    lore ? `<p><strong>Мотивация:</strong> ${escapeHtml(lore.motive)}.</p>` : "",
    lore ? `<p><strong>Как избежать боя:</strong> ${escapeHtml(lore.negotiation)}.</p>` : "",
    lore ? `<p><strong>Что находится в логове:</strong> ${escapeHtml(lore.lair)}.</p>` : "",
    lore ? `<p><strong>Улика:</strong> ${escapeHtml(lore.clue)}.</p>` : "",
    lore ? `<p><strong>Осложнение:</strong> ${escapeHtml(lore.complication)}.</p>` : "",
    `<h3>Готовая тактика</h3>`,
    `<p><strong>До боя:</strong> ${escapeHtml(tactics.before)}</p>`,
    `<p><strong>Первый ход:</strong> ${escapeHtml(tactics.opening)}</p>`,
    `<p><strong>Обычный цикл:</strong> ${escapeHtml(tactics.routine)}</p>`,
    `<p><strong>При половине ОЗ:</strong> ${escapeHtml(tactics.bloodied)}</p>`,
    `<p><strong>Отступление:</strong> ${escapeHtml(tactics.retreat)}.</p>`,
    `<p><strong>Контригра:</strong> ${escapeHtml(tactics.weakness)}.</p>`,
    `<p><strong>Шкалы:</strong> ${escapeHtml(tierListHtml(tiers))}.</p>`,
    `<h3>Проверка автоматизации</h3>`,
    `<p><strong>Оценка:</strong> ${automation.score}% — ${escapeHtml(automation.grade)}. Полностью поддерживаемых элементов: ${automation.counts.full}; частичных: ${automation.counts.partial}; ручных: ${automation.counts.manual}.</p>`,
    automation.findings.length ? `<ul>${automation.findings.map((finding) => `<li><strong>${escapeHtml(finding.severity)}:</strong> ${escapeHtml(finding.message)}</li>`).join("")}</ul>` : `<p>Разрывов между описанием и рабочими проверками не найдено.</p>`,
    `<h3>Экономика действий</h3>`,
    `<p><strong>Первый ход:</strong> ${escapeHtml(actionEconomy.firstTurn)}.</p>`,
    `<p><strong>Обычный цикл:</strong> ${escapeHtml(actionEconomy.routine)}.</p>`,
    actionEconomy.issues.length ? `<ul>${actionEconomy.issues.map((issue) => `<li>${escapeHtml(issue)}</li>`).join("")}</ul>` : `<p>Основной цикл укладывается в три действия.</p>`,
    adventure.director ? `<h3>${escapeHtml(adventure.director.title)}</h3>` : "",
    adventure.director?.objective ? `<p><strong>Цель противников:</strong> ${escapeHtml(adventure.director.objective)}.</p>` : "",
    adventure.director?.playerObjective ? `<p><strong>Цель героев:</strong> ${escapeHtml(adventure.director.playerObjective)}.</p>` : "",
    adventure.director?.stake ? `<p><strong>Ставка сцены:</strong> ${escapeHtml(adventure.director.stake)}.</p>` : "",
    adventure.director?.crime ? `<p><strong>Расследуемое событие:</strong> ${escapeHtml(adventure.director.crime)}.</p>` : "",
    adventure.loot ? `<p><strong>План добычи:</strong> ${escapeHtml(adventure.loot.label)}; ${escapeHtml(adventure.loot.coins)}; расходников: ${adventure.loot.consumableCount}; постоянных предметов: ${adventure.loot.permanentCount}. Сюжетный предмет: ${escapeHtml(adventure.loot.storyItem)}.</p>` : "",
    generatedContent.spells?.themeLabel
      ? `<p><strong>Магическая специализация:</strong> ${escapeHtml(
          generatedContent.spells.themeLabel,
        )}.</p>`
      : "",
    elite
      ? `<p><strong>Элитная надстройка:</strong> +2 к КБ, проверкам, атакам, спасброскам и СС; +2 к урону ударов и неограниченных атакующих способностей; ОЗ увеличены по правилам элитной корректировки. Для бюджета столкновения существо считается на ${
          concept.level <= 0 ? "2 уровня" : "1 уровень"
        } выше.</p>`
      : "",
  ].join("");

  return {
    system: {
      abilities: resolveAbilities(concept),
      attributes: {
        adjustment: null,
        ac: {
          details: armor.description,
          value:
            valueAt(
              "ac",
              concept.level,
              normalizeCombatTier("ac", tiers.ac),
            ) + adjustment,
        },
        allSaves: { value: "" },
        hp: {
          details: role.description,
          max: Math.max(1, Math.round(hp * template.hpMultiplier)),
          temp: 0,
          value: Math.max(1, Math.round(hp * template.hpMultiplier)),
        },
        immunities: template.immunities,
        resistances: template.resistances,
        speed: { details: family?.description ?? "", otherSpeeds: ancestry.otherSpeeds ?? [], value: Math.max(5, ancestry.speed + template.speedAdjustment) },
        weaknesses: template.weaknesses,
      },
      details: {
        blurb: `${ancestry.description}, ${family ? `семейство «${family.label}», ` : ""}${profession.label}, роль «${role.label}»`,
        languages: { details: "", value: ancestry.languages },
        level: { value: concept.level },
        publication: PUBLICATION,
        publicNotes,
        privateNotes,
      },
      initiative: {
        statistic: ["scout", "thief", "bandit", "hunter"].includes(
          concept.profession,
        ) || ["ambusher", "lurker", "packHunter"].includes(concept.role)
          ? "stealth"
          : "perception",
      },
      perception: {
        details: "",
        mod: valueAt("perception", concept.level, tiers.perception) + adjustment,
        senses: ancestry.senses,
        vision: true,
      },
      saves: {
        fortitude: {
          saveDetail: "",
          value:
            valueAt("perception", concept.level, tiers.fortitude) + adjustment,
        },
        reflex: {
          saveDetail: "",
          value: valueAt("perception", concept.level, tiers.reflex) + adjustment,
        },
        will: {
          saveDetail: "",
          value: valueAt("perception", concept.level, tiers.will) + adjustment,
        },
      },
      skills,
      traits: {
        rarity: "common",
        size: { value: template.size ?? ancestry.size },
        value: [...new Set([...(ancestry.traits ?? []), ...(template.traits ?? [])])],
      },
    },
    tiers,
    adjustment,
    intelligence: {
      coherence,
      personality,
      tactics,
      automation,
      actionEconomy,
      adventure,
      monsterTemplate: template,
      spellTheme: generatedContent.spells?.themeLabel ?? null,
    },
  };
}

function makeStrike(concept, tiers, adjustment, weapon, options = {}) {
  const ranged = Number.isFinite(options.range ?? weapon.range);
  const range = options.range ?? weapon.range;
  const slug =
    options.slug ?? `forge-${weapon.itemSlug ?? slugify(weapon.strikeName)}`;
  const damageTier =
    options.damageTier ??
    (ranged && tiers.damage === "extreme" ? "high" : tiers.damage);

  return {
    name: options.name ?? weapon.strikeName,
    type: "melee",
    img: "systems/pf2e/icons/actions/OneAction.webp",
    flags: itemFlag({ kind: "strike" }),
    system: {
      action: "strike",
      attackEffects: { value: [] },
      bonus: {
        value:
          valueAt(
            "attack",
            concept.level,
            normalizeCombatTier(
              "attack",
              options.attackTier ?? tiers.attack,
            ),
          ) + adjustment,
      },
      damageRolls: {
        main: {
          category: null,
          damage: addDamageBonus(
            options.damage ??
              valueAt(
                "damage",
                concept.level,
                normalizeCombatTier("damage", damageTier),
                "moderate",
              ),
            adjustment ? 2 : 0,
          ),
          damageType: options.damageType ?? weapon.damageType,
        },
      },
      description: {
        gm: "",
        value: `<p>${escapeHtml(options.description ?? weapon.description)}</p>`,
      },
      publication: PUBLICATION,
      range: ranged ? { increment: range, max: null } : null,
      rules: [],
      slug,
      traits: {
        value: options.traits ?? weapon.traits,
        otherTags: [],
        config: {},
      },
      area: null,
      subjectToMAP: true,
    },
  };
}

function roleFeature(concept) {
  const common = {
    type: "action",
    img: "systems/pf2e/icons/actions/Passive.webp",
    flags: itemFlag({ kind: "role-feature" }),
    system: {
      actionType: { value: "passive" },
      actions: { value: null },
      category: "interaction",
      publication: PUBLICATION,
      traits: { value: [], otherTags: [] },
    },
  };

  const features = {
    brute: {
      name: "Могучая хватка",
      slug: "forge-mighty-grip",
      description:
        "<p>Массивное сложение помогает удерживать противника. Существо получает обстоятельственный бонус +1 к Атлетике.</p>",
      rules: [
        {
          key: "FlatModifier",
          selector: "athletics",
          type: "circumstance",
          value: 1,
        },
      ],
    },
    soldier: {
      name: "Защитная стойка",
      slug: "forge-guarded-stance",
      description:
        "<p>Переключаемая стойка даёт обстоятельственный бонус +1 к КБ. Включи переключатель этого умения на листе, когда боец принимает защитную стойку.</p>",
      rules: [
        {
          key: "RollOption",
          domain: "all",
          label: "Защитная стойка",
          option: "forge:guarded-stance",
          toggleable: true,
        },
        {
          key: "FlatModifier",
          predicate: ["forge:guarded-stance"],
          selector: "ac",
          type: "circumstance",
          value: 1,
        },
      ],
    },
    skirmisher: {
      name: "Лёгкий шаг",
      slug: "forge-light-step",
      description:
        "<p>Существо получает бонус состояния +5 футов к наземной Скорости.</p>",
      rules: [
        {
          key: "FlatModifier",
          selector: "land-speed",
          type: "status",
          value: 5,
        },
      ],
    },
    sniper: {
      name: "Прицеливание",
      slug: "forge-aim",
      description:
        "<p>Переключаемое прицеливание даёт обстоятельственный бонус +1 к броскам атак дальнобойным оружием.</p>",
      rules: [
        {
          key: "RollOption",
          domain: "all",
          label: "Прицеливание",
          option: "forge:aiming",
          toggleable: true,
        },
        {
          key: "FlatModifier",
          predicate: ["forge:aiming", "item:ranged"],
          selector: "attack-roll",
          type: "circumstance",
          value: 1,
        },
      ],
    },
    controller: {
      name: "Командный голос",
      slug: "forge-commanding-voice",
      description:
        "<p>Существо получает обстоятельственный бонус +1 к Дипломатии и Запугиванию.</p>",
      rules: [
        {
          key: "FlatModifier",
          selector: ["diplomacy", "intimidation"],
          type: "circumstance",
          value: 1,
        },
      ],
    },
    support: {
      name: "Всегда готов помочь",
      slug: "forge-ready-to-aid",
      description:
        "<p>Существо получает обстоятельственный бонус +1 к проверкам Дипломатии и Общества: оно внимательно слушает, объясняет и подхватывает чужую работу.</p>",
      rules: [
        {
          key: "FlatModifier",
          selector: ["diplomacy", "society"],
          type: "circumstance",
          value: 1,
        },
      ],
    },
    healer: {
      name: "Уверенная рука",
      slug: "forge-steady-hand",
      description:
        "<p>Существо получает обстоятельственный бонус +1 ко всем проверкам Медицины.</p>",
      rules: [
        {
          key: "FlatModifier",
          selector: "medicine",
          type: "circumstance",
          value: 1,
        },
      ],
    },
    caster: {
      name: "Сосредоточенный разум",
      slug: "forge-focused-mind",
      description:
        "<p>Существо получает обстоятельственный бонус +1 к проверкам Арканы и Оккультизма для распознавания магии.</p>",
      rules: [
        {
          key: "FlatModifier",
          selector: ["arcana", "occultism"],
          type: "circumstance",
          value: 1,
        },
      ],
    },
    ambusher: {
      name: "Преимущество засады",
      slug: "forge-ambush-advantage",
      description: "<p>Первый Удар по существу, для которого засадник был незамеченным, наносит дополнительно 1d6 точного урона.</p>",
      rules: [],
    },
    packHunter: {
      name: "Стайное давление",
      slug: "forge-pack-pressure",
      description: "<p>Когда цель соседствует хотя бы с двумя врагами, первый успешный Удар стайного охотника за раунд наносит дополнительно 1d4 точного урона.</p>",
      rules: [],
    },
    defender: {
      name: "Живая преграда",
      slug: "forge-living-bulwark",
      description: "<p>Существо получает обстоятельственный бонус +1 к КС Стойкости против принудительного перемещения и может считать свою клетку сложной местностью для врагов.</p>",
      rules: [],
    },
    artillery: {
      name: "Подготовленная позиция",
      slug: "forge-prepared-firing-position",
      description: "<p>Если существо не двигалось с начала своего прошлого хода, первая дальнобойная атака получает обстоятельственный бонус +1.</p>",
      rules: [],
    },
    leader: {
      name: "Центр строя",
      slug: "forge-center-of-formation",
      description: "<p>Союзники в пределах 15 футов получают обстоятельственный бонус +1 к спасброскам против страха.</p>",
      rules: [],
    },
    berserker: {
      name: "Неистовая ярость",
      slug: "forge-ferocious-rage",
      description: "<p>Переключатель ярости даёт +2 к урону Ударов и штраф −1 к КБ.</p>",
      rules: [],
    },
    lurker: {
      name: "Терпеливый хищник",
      slug: "forge-patient-lurker",
      description: "<p>Существо получает обстоятельственный бонус +1 к Скрытности, когда остаётся неподвижным, и +1 к инициативе Скрытности.</p>",
      rules: [{ key: "FlatModifier", selector: "stealth", type: "circumstance", value: 1 }],
    },
    summoner: {
      name: "Власть над прислужниками",
      slug: "forge-minion-mastery",
      description: "<p>Один раз за раунд, когда прислужник выполняет приказ призывателя, он получает обстоятельственный бонус +1 к первой проверке или атаке этого действия.</p>",
      rules: [],
    },
    gunner: {
      name: "Огневая дисциплина",
      slug: "forge-fire-discipline",
      description: "<p>Если стрелок не двигался в этом ходу, он получает обстоятельственный бонус +1 к первой атаке технологическим или огнестрельным оружием.</p>",
      rules: [],
    },
    saboteur: {
      name: "Подготовленный заряд",
      slug: "forge-prepared-charge",
      description: "<p>Саботёр получает обстоятельственный бонус +1 к Ремеслу и Воровству для установки, поиска и обезвреживания ловушек, гранат и зарядов.</p>",
      rules: [{ key: "FlatModifier", selector: ["crafting", "thievery"], type: "circumstance", value: 1 }],
    },
    technician: {
      name: "Полевой ремонт",
      slug: "forge-field-repair",
      description: "<p>Техник получает обстоятельственный бонус +1 к Ремеслу и Компьютерам при ремонте, диагностике и управлении устройствами.</p>",
      rules: [{ key: "FlatModifier", selector: ["crafting", "computers"], type: "circumstance", value: 1 }],
    },
    infiltrator: {
      name: "Беззвучное проникновение",
      slug: "forge-silent-infiltration",
      description: "<p>Лазутчик получает обстоятельственный бонус +1 к Скрытности и Воровству при проникновении в охраняемую область.</p>",
      rules: [{ key: "FlatModifier", selector: ["stealth", "thievery"], type: "circumstance", value: 1 }],
    },
  };

  const selected = features[concept.role] ?? features.soldier;
  return {
    ...common,
    name: selected.name,
    system: {
      ...common.system,
      description: { gm: "", value: selected.description },
      rules: selected.rules,
      slug: selected.slug,
    },
  };
}

export { normalizeActionCategory } from "./schema-guard.js";

function fallbackReferenceAction(name, description, { kind = "fallback-reference", originalType = null } = {}) {
  return {
    name,
    type: "action",
    img: "systems/pf2e/icons/actions/Passive.webp",
    flags: itemFlag({ kind, originalType }),
    system: {
      actionType: { value: "passive" },
      actions: { value: null },
      category: "interaction",
      description: { gm: "", value: `<p>${escapeHtml(description)}</p>` },
      publication: PUBLICATION,
      rules: [],
      slug: `forge-fallback-${slugify(name)}`,
      traits: { value: [], otherTags: [] },
    },
  };
}

function featureItem(spec) {
  const icon = spec.actionType === "reaction"
    ? "systems/pf2e/icons/actions/Reaction.webp"
    : spec.actionType === "passive"
      ? "systems/pf2e/icons/actions/Passive.webp"
      : spec.actions === 2
        ? "systems/pf2e/icons/actions/TwoActions.webp"
        : "systems/pf2e/icons/actions/OneAction.webp";
  return {
    name: spec.name,
    type: "action",
    img: icon,
    flags: itemFlag({ kind: "random-feature" }),
    system: {
      actionType: { value: spec.actionType },
      actions: { value: spec.actionType === "action" ? (spec.actions ?? 1) : null },
      category: normalizeActionCategory(spec.category),
      description: { gm: "", value: spec.description },
      publication: PUBLICATION,
      rules: spec.rules ?? [],
      slug: spec.slug,
      traits: { value: spec.traits ?? [], otherTags: [] },
    },
  };
}

function magicStrike(concept, tiers, adjustment) {
  const { element, data } = elementForConcept(concept);

  return makeStrike(
    concept,
    tiers,
    adjustment,
    {
      strikeName: data.name,
      traits: ["magical"],
      damageType: data.damageType,
      range: 60,
      description: data.description,
    },
    {
      name: data.name,
      slug: `forge-magic-${element}`,
      range: 60,
      attackTier: tiers.attack,
      damageTier: "moderate",
      damageType: data.damageType,
      traits: ["magical"],
      description: data.description,
    },
  );
}

function magicSaveAction(concept, tiers, adjustment) {
  const { element, data } = elementForConcept(concept);
  const dc =
    valueAt(
      "dc",
      concept.level,
      normalizeCombatTier("dc", tiers.dc),
      "moderate",
    ) + adjustment;
  const damage = valueAt("areaDamage", concept.level, "moderate");
  const adjustedDamage = addDamageBonus(damage, adjustment ? 2 : 0);
  return {
    name: data.burstName,
    type: "action",
    img: "systems/pf2e/icons/actions/TwoActions.webp",
    flags: itemFlag({ kind: "save-ability" }),
    system: {
      actionType: { value: "action" },
      actions: { value: 2 },
      category: "offensive",
      description: {
        gm: "",
        value:
          `<p>Существо создаёт @Template[type:burst|distance:10] с центром в пределах 60 футов. ` +
          `Все существа в области получают @Damage[${adjustedDamage}[${data.damageType}]|options:area-damage] урона ` +
          `с @Check[reflex|dc:${dc}|basic] базовым спасброском Рефлекса.</p>`,
      },
      publication: PUBLICATION,
      rules: [],
      slug: `forge-elemental-burst-${element}`,
      traits: { value: ["concentrate", "magical"], otherTags: [] },
    },
  };
}


function levelRunes(item, level) {
  if (item.type === "weapon") {
    item.system.runes ??= { potency: 0, property: [], striking: 0 };
    item.system.runes.potency = level >= 16 ? 3 : level >= 10 ? 2 : level >= 2 ? 1 : 0;
    item.system.runes.striking =
      level >= 19 ? 3 : level >= 12 ? 2 : level >= 4 ? 1 : 0;
  }
  if (item.type === "armor") {
    item.system.runes ??= { potency: 0, property: [], resilient: 0 };
    item.system.runes.potency = level >= 18 ? 3 : level >= 11 ? 2 : level >= 5 ? 1 : 0;
    item.system.runes.resilient =
      level >= 20 ? 3 : level >= 14 ? 2 : level >= 8 ? 1 : 0;
  }
}

function prepareEquipment(item, slug, name, description, level) {
  delete item._forgeSourceUuid;
  if (!supportedEmbeddedType(item.type)) return null;
  item.name = name || item.name;
  const sourcePack = item._forgeSourcePack ?? null;
  item.flags = {
    ...(item.flags ?? {}),
    ...itemFlag({ kind: "equipment", sourceSlug: slug, sourcePack, catalogClone: true }),
  };
  const sourceDescription = item.system.description?.value ?? "";
  item.system.description = {
    value: `<p><em>${escapeHtml(description)}</em></p>${sourceDescription}`,
  };
  item.system.slug ||= slug;

  if (item.type === "armor") {
    item.system.equipped = {
      ...(item.system.equipped ?? {}),
      carryType: "worn",
      inSlot: true,
      invested: Boolean(item.system.equipped?.invested),
    };
  } else if (item.type === "weapon" || item.type === "shield") {
    const usage = String(item.system?.usage?.value ?? "");
    const twoHanded = usage.includes("two-hands") || [
      "crossbow",
      "greataxe",
      "greatsword",
      "halberd",
      "maul",
      "shortbow",
      "staff",
      "arquebus",
      "laser-rifle",
      "arc-rifle",
      "plasma-caster",
      "scattergun",
    ].includes(slug);
    item.system.equipped = {
      ...(item.system.equipped ?? {}),
      carryType: "held",
      handsHeld: twoHanded ? 2 : 1,
      invested: Boolean(item.system.equipped?.invested),
    };
  }
  delete item._forgeSourcePack;
  levelRunes(item, level);
  return item;
}

async function equipmentFromSlug(
  slug,
  name,
  description,
  level,
  concept,
  {
    required = true,
    quantity = 1,
    preferredPack = null,
    allowedTypes = ["weapon", "armor", "shield", "equipment", "consumable", "ammo", "backpack", "treasure"],
  } = {},
) {
  const source = await cloneCatalogDocument(
    "equipment",
    [slug, name],
    concept,
    { allowedTypes, required, preferredPack },
  );
  if (!source) return null;
  const prepared = prepareEquipment(source, slug, name, description, level);
  if (!prepared) {
    if (required) {
      throw new Error(`Предмет «${name}» имеет неподдерживаемый для NPC тип ${source.type}.`);
    }
    return null;
  }
  if (prepared.system && Number.isFinite(Number(quantity))) {
    prepared.system.quantity = Math.max(1, Number(quantity));
  }
  return prepared;
}

async function actionFromSlug(slug, concept) {
  const source = await cloneCatalogDocument(
    "actions",
    [slug, ACTION_NAMES[slug]],
    concept,
    { allowedTypes: "action", required: false },
  );
  if (!source) return null;
  delete source._forgeSourceUuid;
  const sourcePack = source._forgeSourcePack ?? null;
  delete source._forgeSourcePack;
  source.name = ACTION_NAMES[slug] ?? source.name;
  source.flags = {
    ...(source.flags ?? {}),
    ...itemFlag({ kind: "standard-action", sourceSlug: slug, sourcePack, catalogClone: true }),
  };
  source.system ??= {};
  source.system.category ||= "interaction";
  if (["treat-wounds", "administer-first-aid"].includes(slug)) {
    const medicine = resolveSkills(concept, concept.quality === "elite" ? 2 : 0).medicine?.base;
    if (Number.isFinite(Number(medicine))) {
      const label = `${ACTION_NAMES[slug]}: Медицина ${Number(medicine) >= 0 ? "+" : ""}${Number(medicine)}`;
      const working = inlineSkillCheck("medicine", label, {
        dc: 15,
        name: `${concept.name}: ${ACTION_NAMES[slug]}`,
        traits: ["healing", "manipulate"],
      });
      source.system.description ??= { gm: "", value: "" };
      source.system.description.value = `<p><strong>Рабочая проверка этого NPC:</strong> ${working}. Полная таблица КС и лечения находится в действии «Медицинские процедуры — рабочие броски».</p>${source.system.description.value ?? ""}`;
    }
  }
  return source;
}

async function buildEmbeddedItems(concept, tiers, adjustment) {
  const armor = ARMORS[concept.armor];
  const weapon = WEAPONS[concept.weapon];
  const profession = PROFESSIONS[concept.profession];
  const random = randomContentPlan(
    concept,
    contentContext(concept, tiers, adjustment),
  );
  const primaryMonsterStrike = familyPrimaryStrike(concept, weapon);
  const primaryStrike = primaryMonsterStrike
    ? makeStrike(
        concept,
        tiers,
        adjustment,
        weapon,
        {
          name: primaryMonsterStrike.name,
          slug: primaryMonsterStrike.slug,
          attackTier: primaryMonsterStrike.attackTier ?? tiers.attack,
          damageTier: primaryMonsterStrike.damageTier ?? tiers.damage,
          range: primaryMonsterStrike.range,
          damageType: primaryMonsterStrike.damageType,
          traits: primaryMonsterStrike.traits,
          description: primaryMonsterStrike.description,
        },
      )
    : makeStrike(concept, tiers, adjustment, weapon);
  const naturalStrikes = monsterStrikePlan(concept)
    .filter((spec) => spec.slug !== primaryMonsterStrike?.slug)
    .map((spec) => makeStrike(
      concept,
      tiers,
      adjustment,
      {
        itemSlug: null,
        strikeName: spec.name,
        traits: spec.traits,
        damageType: spec.damageType,
        range: spec.range,
        description: spec.description,
      },
      {
        name: spec.name,
        slug: spec.slug,
        attackTier: spec.attackTier ?? tiers.attack,
        damageTier: spec.damageTier ?? tiers.damage,
        range: spec.range,
        damageType: spec.damageType,
        traits: spec.traits,
        description: spec.description,
      },
    ));
  const familyFeatures = monsterFeaturePlan(
    concept,
    contentContext(concept, tiers, adjustment),
  ).map((spec) => {
    const item = featureItem(spec);
    item.flags = itemFlag({ kind: "monster-feature", monsterFamily: concept.monsterFamily });
    return item;
  });
  const template = monsterTemplatePlan(concept);
  const skills = resolveSkills(concept, adjustment);
  const supportFeatures = concept.includeSkillActions
    ? [skillCheckPanelSpec(concept, skills), medicalProcedureSpec(concept, skills)]
      .filter(Boolean)
      .map(featureItem)
    : [];
  const coreItems = [
    primaryStrike,
    ...naturalStrikes,
    roleFeature(concept),
    ...familyFeatures,
    ...template.features.map((spec) => {
      const item = featureItem(spec);
      item.flags = itemFlag({ kind: "monster-template-feature", monsterTemplate: template.id });
      return item;
    }),
    ...supportFeatures,
    ...random.features.map(featureItem),
  ];
  const optionalItems = [];
  const warnings = [];

  if (concept.role === "caster" || concept.elements.length) {
    coreItems.push(magicStrike(concept, tiers, adjustment));
    coreItems.push(magicSaveAction(concept, tiers, adjustment));
  }

  if (armor.slug) {
    const armorItem = await equipmentFromSlug(
      armor.slug,
      armor.name,
      armor.description,
      concept.level,
      concept,
      { required: false },
    );
    if (armorItem) coreItems.push(armorItem);
    else {
      warnings.push(`Броня «${armor.name}» не прочитана из компендиума; добавлена безопасная памятка.`);
      coreItems.push(fallbackReferenceAction(
        `Снаряжение: ${armor.name}`,
        `${armor.description} Числовой КБ NPC уже рассчитан независимо от физического предмета.`,
        { kind: "equipment-fallback", originalType: "armor" },
      ));
    }
  }

  if (weapon.itemSlug) {
    const weaponItem = await equipmentFromSlug(
      weapon.itemSlug,
      weapon.itemName,
      weapon.description,
      concept.level,
      concept,
      { required: false, preferredPack: weapon.sourcePack ?? null },
    );
    if (weaponItem) coreItems.push(weaponItem);
    else {
      warnings.push(`Оружие «${weapon.itemName}» не прочитано из компендиума; добавлена безопасная памятка.`);
      coreItems.push(fallbackReferenceAction(
        `Снаряжение: ${weapon.itemName}`,
        `${weapon.description} Рабочий удар NPC уже создан отдельно и остаётся доступен.`,
        { kind: "equipment-fallback", originalType: "weapon" },
      ));
    }
  }

  if (weapon.ammoSlug) {
    const ammo = await equipmentFromSlug(
      weapon.ammoSlug,
      GEAR_NAMES[weapon.ammoSlug] ?? weapon.ammoSlug,
      "Боеприпасы, совместимые с выбранным оружием.",
      concept.level,
      concept,
      {
        required: false,
        quantity: Math.max(2, Math.min(10, 2 + Math.ceil(concept.level / 3))),
        preferredPack: weapon.sourcePack ?? CATALOG_PACKS.equipment.sf2e,
        allowedTypes: ["ammo", "consumable", "equipment"],
      },
    );
    if (ammo) optionalItems.push(ammo);
    else warnings.push(`Боеприпасы «${GEAR_NAMES[weapon.ammoSlug] ?? weapon.ammoSlug}» не найдены.`);
  }

  const rawGear = [
    ...(weapon.extraGear ?? []),
    ...(profession.gear ?? []),
    ...professionFlavorGear(concept),
    ...roleFlavorGear(concept),
  ];
  const gearSpecs = [];
  const seenGear = new Set();
  for (const raw of rawGear) {
    const spec = typeof raw === "string" ? { slug: raw } : raw;
    if (!spec?.slug || seenGear.has(spec.slug)) continue;
    if (Number.isFinite(Number(spec.minLevel)) && concept.level < Number(spec.minLevel)) continue;
    seenGear.add(spec.slug);
    gearSpecs.push(spec);
  }
  for (const spec of gearSpecs) {
    const item = await equipmentFromSlug(
      spec.slug,
      GEAR_NAMES[spec.slug] ?? spec.slug,
      spec.description ?? GEAR_DESCRIPTIONS[spec.slug] ?? "Предмет снаряжения.",
      concept.level,
      concept,
      {
        required: false,
        quantity: spec.quantity ?? 1,
        preferredPack: spec.preferredPack ?? null,
      },
    );
    if (item) optionalItems.push(item);
    else warnings.push(`Не удалось добавить необязательный предмет «${GEAR_NAMES[spec.slug] ?? spec.slug}».`);
  }

  if (concept.includeSkillActions) {
    for (const slug of ACTIONS_BY_PROFESSION[concept.profession] ?? []) {
      const standardAction = await actionFromSlug(slug, concept);
      if (standardAction) optionalItems.push(standardAction);
      else warnings.push(`Не найдено стандартное действие «${ACTION_NAMES[slug] ?? slug}».`);
    }
  }

  for (const consumable of random.consumables) {
    const item = await equipmentFromSlug(
      consumable.slug,
      consumable.name,
      `Полезный расходник, подобранный для профессии «${profession.label}».`,
      concept.level,
      concept,
      {
        required: false,
        quantity: consumable.quantity,
        preferredPack: consumable.source === "sf2e" ? CATALOG_PACKS.equipment.sf2e : null,
      },
    );
    if (item) {
      item.flags = {
        ...(item.flags ?? {}),
        [MODULE_ID]: {
          ...(item.flags?.[MODULE_ID] ?? {}),
          ...itemFlag({ kind: "random-consumable", sourceSlug: consumable.slug })[MODULE_ID],
        },
      };
      optionalItems.push(item);
    } else {
      warnings.push(`Расходник «${consumable.name}» не найден в системном сборнике.`);
    }
  }

  for (const loot of lootInventoryPlan(concept)) {
    const item = await equipmentFromSlug(
      loot.slug,
      loot.name,
      loot.description ?? "Предмет из выбранного набора добычи.",
      concept.level,
      concept,
      {
        required: false,
        quantity: loot.quantity ?? 1,
        preferredPack: loot.source === "sf2e" ? CATALOG_PACKS.equipment.sf2e : null,
        allowedTypes: ["treasure", "equipment", "consumable", "ammo", "backpack"],
      },
    );
    if (item) {
      item.flags = {
        ...(item.flags ?? {}),
        [MODULE_ID]: {
          ...(item.flags?.[MODULE_ID] ?? {}),
          ...itemFlag({ kind: "loot", sourceSlug: loot.slug, richness: concept.lootRichness })[MODULE_ID],
        },
      };
      optionalItems.push(item);
    } else {
      warnings.push(`Добыча «${loot.name}» не найдена в сборнике.`);
    }
  }

  return {
    coreItems: coreItems.filter(Boolean),
    optionalItems: optionalItems.filter(Boolean),
    spellPlan: random.spells,
    warnings,
  };
}

function spellSlots(plan, preparedIdsByRank = new Map()) {
  const result = {};
  for (let rank = 0; rank <= 11; rank += 1) {
    const maximum = rank === 0 ? 0 : Number(plan.slots?.[rank] ?? 0);
    const prepared = plan.prepared === "prepared"
      ? (preparedIdsByRank.get(rank) ?? []).slice(0, Math.max(0, maximum)).map((id) => ({ id }))
      : [];
    result[`slot${rank}`] = {
      prepared,
      value: plan.prepared === "prepared" ? 0 : maximum,
      max: maximum,
    };
  }
  return result;
}

function spellcastingEntrySource(plan, dc) {
  return {
    name: plan.name,
    type: "spellcastingEntry",
    img: "systems/pf2e/icons/default-icons/spellcastingEntry.svg",
    flags: itemFlag({
      kind: "spellcasting-entry",
      tradition: plan.tradition,
      contentSource: plan.source,
    }),
    system: {
      description: {
        gm: "",
        value: `<p>Рабочий список заклинаний NPC, подобранный Кузницей под профессию, уровень и тему «${escapeHtml(plan.themeLabel ?? plan.theme)}». СС заклинаний: ${dc}.</p>`,
      },
      rules: [],
      slug: `forge-${plan.tradition}-spellcasting`,
      traits: { otherTags: [] },
      publication: PUBLICATION,
      ability: { value: plan.ability },
      spelldc: { value: Math.max(0, dc - 8), dc, mod: 0 },
      tradition: { value: plan.tradition },
      prepared: { value: plan.prepared, flexible: false },
      showSlotlessLevels: { value: false },
      proficiency: { value: 0 },
      slots: spellSlots(plan),
      autoHeightenLevel: { value: Math.max(1, Number(plan.maxRank) || 1) },
    },
  };
}

function fallbackSpellAction(spell, sourceUuid = null) {
  const link = sourceUuid ? `<p>@UUID[${sourceUuid}]{Открыть исходное заклинание}</p>` : "";
  return {
    name: `${spell.name} — ${spell.rank === 0 ? "чары" : `${spell.rank}-й ранг`}`,
    type: "action",
    img: "systems/pf2e/icons/actions/CastASpell.webp",
    flags: itemFlag({ kind: "spell-fallback", sourceSlug: spell.slug }),
    system: {
      actionType: { value: "action" },
      actions: { value: 2 },
      category: "offensive",
      description: {
        gm: "",
        value: `<p><strong>Заклинание из списка NPC.</strong> Исходный документ не удалось безопасно встроить, поэтому оставлена памятка.</p>${link}`,
      },
      publication: PUBLICATION,
      rules: [],
      slug: `forge-spell-fallback-${spell.slug}-${spell.rank}`,
      traits: { value: ["concentrate", "magical"], otherTags: [] },
    },
  };
}

function prepareSpell(source, spell, entryId) {
  const sourceUuid = source._forgeSourceUuid;
  const sourcePack = source._forgeSourcePack ?? null;
  delete source._forgeSourceUuid;
  delete source._forgeSourcePack;
  if (source.type !== "spell") return { item: null, sourceUuid };
  source.flags = {
    ...(source.flags ?? {}),
    ...itemFlag({
      kind: "random-spell",
      sourceSlug: spell.slug,
      sourcePack,
      catalogClone: true,
      spellRank: spell.rank,
    }),
  };
  source.system ??= {};
  source.system.location = {
    ...(source.system.location ?? {}),
    value: entryId,
  };
  if (spell.rank > 0) source.system.location.heightenedLevel = spell.rank;
  else delete source.system.location.heightenedLevel;
  return { item: source, sourceUuid };
}

async function createCoreItems(actor, items, warnings, { deleteActorOnTotalFailure = false, allowFallback = true } = {}) {
  let createdCount = 0;
  for (const item of items) {
    try {
      const created = await safelyCreateItems(actor, [item], { correctionSink: warnings });
      createdCount += created?.length ?? 1;
      continue;
    } catch (error) {
      if (!allowFallback) throw error;
      const fallback = fallbackReferenceAction(
        `${item?.name ?? "Документ"} — безопасная памятка`,
        `PF2e отклонила исходный документ типа «${item?.type ?? "неизвестно"}». Кузница сохранила описание вместо остановки всей сборки. Причина: ${error?.message ?? String(error)}`,
        { kind: "schema-fallback", originalType: item?.type ?? null },
      );
      warnings.push(`Основной документ «${item?.name ?? "без имени"}» отклонён схемой PF2e и заменён безопасной памяткой.`);
      console.warn(`${MODULE_ID} | Основной документ заменён памяткой`, item, error);
      try {
        const created = await safelyCreateItems(actor, [fallback], { correctionSink: warnings });
        createdCount += created?.length ?? 1;
      } catch (fallbackError) {
        if (deleteActorOnTotalFailure && actor?.delete) {
          try { await actor.delete(); } catch (cleanupError) {
            console.warn(`${MODULE_ID} | Не удалось удалить лист после критической ошибки`, cleanupError);
          }
        }
        throw new Error(`PF2e отклонила и документ «${item?.name ?? "без имени"}», и его безопасную памятку. ${fallbackError.message}`);
      }
    }
  }
  return createdCount;
}

async function createOptionalItems(actor, items, warnings) {
  let createdCount = 0;
  for (const item of items) {
    try {
      const created = await safelyCreateItems(actor, [item], { correctionSink: warnings });
      createdCount += created?.length ?? 1;
    } catch (error) {
      warnings.push(`Необязательный документ «${item.name}» пропущен: ${error.message}`);
      console.warn(`${MODULE_ID} | Не удалось добавить необязательный документ`, item, error);
    }
  }
  return createdCount;
}

async function updateEmbeddedItem(actor, item, update) {
  const id = item?.id ?? item?._id;
  if (!id) return false;
  if (typeof item.update === "function") {
    await item.update(update);
    return true;
  }
  if (typeof actor.updateEmbeddedDocuments === "function") {
    await actor.updateEmbeddedDocuments("Item", [{ _id: id, ...update }]);
    return true;
  }
  return false;
}

async function createSpellLoadout(actor, plan, dc, warnings) {
  if (!plan?.spells?.length) return 0;
  let entry;
  try {
    const created = await safelyCreateItems(actor, [spellcastingEntrySource(plan, dc)], { correctionSink: warnings });
    entry = created?.[0] ?? null;
  } catch (error) {
    warnings.push(
      `Запись заклинателя не принята схемой PF2e; список создан как действия-памятки. ${error.message}`,
    );
    return createOptionalItems(
      actor,
      plan.spells.map((spell) => fallbackSpellAction(spell)),
      warnings,
    );
  }
  if (!entry) return 0;

  let count = 1;
  const preparedIdsByRank = new Map();
  for (const spell of plan.spells) {
    let source = null;
    const preferredPack = spell.source === "sf2e"
      ? CATALOG_PACKS.spells.sf2e
      : CATALOG_PACKS.spells.pf2e;
    try {
      source = await cloneCatalogDocument(
        "spells",
        [spell.slug, spell.name],
        { ...plan, contentSource: spell.source === "sf2e" ? "sf2e" : "pf2e" },
        { allowedTypes: "spell", required: false, preferredPack },
      );
    } catch (error) {
      warnings.push(`Не удалось прочитать заклинание «${spell.name}»: ${error.message}`);
    }
    if (!source) {
      warnings.push(`Заклинание «${spell.name}» (${spell.slug}) не найдено; добавлена памятка.`);
      count += await createOptionalItems(actor, [fallbackSpellAction(spell)], warnings);
      continue;
    }
    const prepared = prepareSpell(source, spell, entry.id);
    if (!prepared.item) {
      warnings.push(`Документ «${spell.name}» имеет тип ${source.type}, а не spell; добавлена памятка.`);
      count += await createOptionalItems(actor, [fallbackSpellAction(spell, prepared.sourceUuid)], warnings);
      continue;
    }
    try {
      const created = await safelyCreateItems(actor, [prepared.item], { correctionSink: warnings });
      const spellItem = created?.[0];
      count += created?.length ?? 1;
      if (spell.rank > 0 && spellItem?.id) {
        const list = preparedIdsByRank.get(spell.rank) ?? [];
        list.push(spellItem.id);
        preparedIdsByRank.set(spell.rank, list);
      }
    } catch (error) {
      warnings.push(`Заклинание «${spell.name}» не встроено; добавлена памятка.`);
      count += await createOptionalItems(actor, [fallbackSpellAction(spell, prepared.sourceUuid)], warnings);
    }
  }

  if (plan.prepared === "prepared") {
    try {
      const updated = await updateEmbeddedItem(actor, entry, {
        "system.slots": spellSlots(plan, preparedIdsByRank),
      });
      if (!updated) warnings.push("Заклинания добавлены, но подготовленные ячейки не удалось заполнить автоматически.");
    } catch (error) {
      warnings.push(`Заклинания добавлены, но подготовленные ячейки не обновлены: ${error.message}`);
    }
  }
  return count;
}

async function getOrCreateActorFolder(name) {
  let folder = game.folders.find(
    (candidate) =>
      candidate.type === "Actor" && candidate.name === name,
  );
  if (folder) return folder;
  const created = await Folder.create({
    name,
    type: "Actor",
    sorting: "a",
  });
  folder = Array.isArray(created) ? created[0] : created;
  return folder;
}

async function getOrCreateFolder() {
  return getOrCreateActorFolder("Кузница персонажей");
}

async function getOrCreateBackupFolder() {
  return getOrCreateActorFolder("Резервные копии Кузницы");
}

export function emptySelectedNpcInfo() {
  return {
    available: false,
    actorId: null,
    actorName: null,
    linked: null,
  };
}

function selectedActorTarget({ strict = true } = {}) {
  const tokens = globalThis.canvas?.tokens?.controlled ?? [];
  if (tokens.length !== 1) {
    if (strict) {
      throw new Error("Для этого режима выбери ровно один жетон существа.");
    }
    return null;
  }
  const token = tokens[0];
  // Не обращаемся к token.actor для неподходящего жетона: сторонние модули
  // перевода могут лениво обходить все embedded items персонажа уже при таком
  // чтении. Для Кузницы достаточно базового Actor из документа жетона.
  const actorId = token.document?.actorId ?? null;
  // Читаем только документ из каталога по actorId. Не используем baseActor и
  // token.actor: сторонние переводчики могут лениво обходить embedded items
  // уже при доступе к этим свойствам.
  const actor = actorId ? game.actors.get(actorId) : null;
  if (!actor || actor.type !== "npc") {
    if (strict) {
      throw new Error("Выбранный жетон должен принадлежать персонажу мастера.");
    }
    return null;
  }
  return { actor, token };
}

export function selectedNpcInfo() {
  const selected = selectedActorTarget({ strict: false });
  if (!selected) return emptySelectedNpcInfo();
  return {
    available: true,
    actorId: selected.actor.id,
    actorName: selected.actor.name,
    linked: selected.token.document.actorLink !== false,
  };
}

function generatedActorFlags(concept, extra = {}) {
  return {
    [MODULE_ID]: {
      generated: true,
      version: MODULE_VERSION,
      concept,
      ...extra,
    },
  };
}

function sourceArtwork(actor, name) {
  if (!actor?.toObject) return {};
  const source = actor.toObject();
  const prototypeToken = source.prototypeToken
    ? structuredClone(source.prototypeToken)
    : null;
  if (prototypeToken) {
    delete prototypeToken._id;
    delete prototypeToken.actorId;
    prototypeToken.actorLink = true;
    prototypeToken.delta = {};
    prototypeToken.name = name;
  }
  return {
    ...(source.img ? { img: source.img } : {}),
    ...(prototypeToken ? { prototypeToken } : {}),
  };
}

async function createBackup(actor) {
  if (!actor?.toObject) {
    throw new Error("Foundry не смог прочитать исходный лист для резервной копии.");
  }
  const folder = await getOrCreateBackupFolder();
  const data = actor.toObject();
  delete data._id;
  delete data._stats;
  data.name = `${actor.name} — резерв ${new Date().toLocaleString("ru-RU")}`;
  data.folder = folder?.id ?? null;
  data.flags = {
    ...(data.flags ?? {}),
    [MODULE_ID]: {
      backup: true,
      sourceActorId: actor.id,
      sourceActorName: actor.name,
      sourceForgeFlags: structuredClone(actor.flags?.[MODULE_ID] ?? null),
      createdAt: new Date().toISOString(),
      version: MODULE_VERSION,
    },
  };
  const created = await Actor.create(data);
  return Array.isArray(created) ? created[0] : created;
}

function itemIdsForPolicy(actor, policy) {
  const removable = actor.items.filter(
    (item) => !["condition", "effect"].includes(item.type),
  );
  if (policy === "all") return removable.map((item) => item.id);
  if (policy === "generated") {
    return removable
      .filter(
        (item) =>
          item.flags?.[MODULE_ID]?.generated === true ||
          item.getFlag?.(MODULE_ID, "generated") === true,
      )
      .map((item) => item.id);
  }
  return [];
}

async function createFreshActor(concept, built, artwork = {}) {
  const folder = await getOrCreateFolder();
  const checked = sanitizeNpcSystem(built.system);
  const created = await Actor.create({
    name: concept.name,
    type: "npc",
    folder: folder?.id ?? null,
    flags: generatedActorFlags(concept),
    system: checked.system,
    ...artwork,
  });
  return Array.isArray(created) ? created[0] : created;
}

async function safelyCreateItems(actor, items, { deleteActorOnFailure = false, correctionSink = null } = {}) {
  const existingIds = new Set(actor.items.map((item) => item.id));
  const checked = sanitizePf2eItemSources(items);
  if (Array.isArray(correctionSink)) correctionSink.push(...checked.corrections);
  try {
    return await actor.createEmbeddedDocuments("Item", checked.sources);
  } catch (error) {
    const partialIds = actor.items
      .filter((item) => item.id && !existingIds.has(item.id))
      .map((item) => item.id);
    if (partialIds.length && actor.deleteEmbeddedDocuments) {
      try {
        await actor.deleteEmbeddedDocuments("Item", partialIds);
      } catch (cleanupError) {
        console.warn(
          `${MODULE_ID} | Не удалось удалить частично созданные предметы`,
          cleanupError,
        );
      }
    }
    if (deleteActorOnFailure && actor.delete) {
      try {
        await actor.delete();
      } catch (cleanupError) {
        console.warn(`${MODULE_ID} | Не удалось удалить неполный лист`, cleanupError);
      }
    }
    throw error;
  }
}

export async function generateNpc(concept) {
  const normalized = normalizeConcept(concept);
  concept = normalized.concept;
  if (game.system.id !== "pf2e") {
    throw new Error("Кузница работает только в мире Pathfinder 2e.");
  }
  if (!game.user.isGM) {
    throw new Error("Создавать и обновлять персонажей может только ведущий.");
  }
  validateConcept(concept);

  const built = buildActorSystem(concept);
  const builtItems = await buildEmbeddedItems(
    concept,
    built.tiers,
    built.adjustment,
  );
  const spellDc = contentContext(concept, built.tiers, built.adjustment).dc;
  const actorSchema = sanitizeNpcSystem(built.system);
  built.system = actorSchema.system;
  let actor;
  let token = null;
  let backup = null;
  let oldItemIds = [];
  let created = false;
  let itemCount = 0;
  let chosenArtwork = null;
  const warnings = [
    ...normalized.corrections,
    ...(builtItems.warnings ?? []),
    ...actorSchema.corrections,
  ];

  async function resolveArtwork(sourceActor = null) {
    if (concept.tokenImage) {
      chosenArtwork = concept.tokenImage;
      const inherited = sourceArtwork(sourceActor, concept.name);
      const selected = artworkData(concept.tokenImage, concept.name);
      return {
        ...inherited,
        ...selected,
        prototypeToken: {
          ...(inherited.prototypeToken ?? {}),
          ...(selected.prototypeToken ?? {}),
          texture: {
            ...(inherited.prototypeToken?.texture ?? {}),
            ...(selected.prototypeToken?.texture ?? {}),
          },
        },
      };
    }
    if (concept.randomToken) {
      const result = await randomArtwork(concept);
      warnings.push(...result.warnings);
      const inherited = sourceArtwork(sourceActor, concept.name);
      if (sourceActor && result.path && Number(result.score ?? 0) <= 0 && inherited.img) {
        warnings.push(
          "Случайный файл не совпал с концептом по имени; сохранён существующий портрет выбранного NPC.",
        );
        chosenArtwork = inherited.img;
        return inherited;
      }
      chosenArtwork = result.path;
      const generated = artworkData(result.path, concept.name);
      if (!generated.prototypeToken) return generated;
      return {
        ...inherited,
        ...generated,
        prototypeToken: {
          ...(inherited.prototypeToken ?? {}),
          ...generated.prototypeToken,
          texture: {
            ...(inherited.prototypeToken?.texture ?? {}),
            ...(generated.prototypeToken.texture ?? {}),
          },
        },
      };
    }
    return sourceArtwork(sourceActor, concept.name);
  }

  async function createContent(targetActor, { deleteActorOnFailure = false, allowCoreFallback = true } = {}) {
    itemCount += await createCoreItems(
      targetActor,
      builtItems.coreItems,
      warnings,
      { deleteActorOnTotalFailure: deleteActorOnFailure, allowFallback: allowCoreFallback },
    );
    itemCount += await createOptionalItems(
      targetActor,
      builtItems.optionalItems,
      warnings,
    );
    itemCount += await createSpellLoadout(
      targetActor,
      builtItems.spellPlan,
      spellDc,
      warnings,
    );
  }

  if (concept.target === "selected") {
    ({ actor, token } = selectedActorTarget());
    oldItemIds = itemIdsForPolicy(actor, concept.itemPolicy);
    if (concept.backupOriginal) backup = await createBackup(actor);

    const actorSource = actor.toObject?.();
    const original = actorSource
      ? {
          name: actor.name,
          system: structuredClone(actorSource.system),
          img: actorSource.img,
          prototypeToken: structuredClone(actorSource.prototypeToken),
          forgeFlag: actor.flags?.[MODULE_ID]
            ? structuredClone(actor.flags[MODULE_ID])
            : null,
        }
      : null;
    const artwork = await resolveArtwork(actor);
    const update = {
      name: concept.name,
      system: replaceDocumentData(built.system),
      [`flags.${MODULE_ID}`]: generatedActorFlags(concept)[MODULE_ID],
    };
    if ((concept.randomToken || concept.tokenImage) && artwork.img) {
      update.img = artwork.img;
      update.prototypeToken = artwork.prototypeToken;
    }
    await actor.update(update);

    try {
      await createContent(actor, { allowCoreFallback: false });
    } catch (error) {
      if (original) {
        try {
          await actor.update({
            name: original.name,
            system: replaceDocumentData(original.system),
            img: original.img,
            prototypeToken: original.prototypeToken,
            [`flags.${MODULE_ID}`]: original.forgeFlag,
          });
        } catch (rollbackError) {
          console.error(`${MODULE_ID} | Ошибка отката листа`, rollbackError);
        }
      }
      throw new Error(
        `Основные атаки и способности не созданы; исходный лист восстановлен${backup ? " и сохранён в резервной копии" : ""}. ${error.message}`,
      );
    }

    if (oldItemIds.length) {
      try {
        await actor.deleteEmbeddedDocuments("Item", oldItemIds);
      } catch (error) {
        warnings.push(
          "Новые документы добавлены, но часть старых удалить не удалось. Проверь инвентарь.",
        );
        console.warn(`${MODULE_ID} | Ошибка удаления старых предметов`, error);
      }
    }
  } else if (concept.target === "duplicate") {
    const source = selectedActorTarget();
    token = source.token;
    const artwork = await resolveArtwork(source.actor);
    actor = await createFreshActor(concept, built, artwork);
    if (!actor) throw new Error("Foundry не вернул созданную копию персонажа.");
    created = true;
    await createContent(actor, { deleteActorOnFailure: true });
  } else {
    const artwork = await resolveArtwork(null);
    actor = await createFreshActor(concept, built, artwork);
    if (!actor) throw new Error("Foundry не вернул созданного персонажа.");
    created = true;
    await createContent(actor, { deleteActorOnFailure: true });
  }

  if (!actor) throw new Error("Foundry не вернул созданного персонажа.");

  if (token) {
    try {
      const tokenUpdate = { name: concept.name };
      if (concept.target === "duplicate") {
        tokenUpdate.actorId = actor.id;
        tokenUpdate.actorLink = true;
        tokenUpdate.delta = replaceDocumentData({});
      } else if (token.document.actorLink === false) {
        tokenUpdate.actorLink = true;
        tokenUpdate.delta = replaceDocumentData({});
      }
      if (chosenArtwork) tokenUpdate.texture = { src: chosenArtwork };
      await token.document.update(tokenUpdate);
    } catch (error) {
      warnings.push(
        "Лист в каталоге готов, но выбранный жетон не удалось автоматически обновить.",
      );
      console.warn(`${MODULE_ID} | Ошибка обновления жетона`, error);
    }
  }

  if (concept.openSheet) {
    try {
      actor.sheet?.render(true);
    } catch (error) {
      warnings.push(`Лист создан, но открыть его автоматически не удалось: ${error.message}`);
      console.warn(`${MODULE_ID} | Ошибка открытия листа`, error);
    }
  }
  return {
    actor,
    backup,
    created,
    target: concept.target,
    itemCount,
    artwork: chosenArtwork,
    summary: conceptSummary(concept),
    intelligence: built.intelligence,
    warnings: [...new Set(warnings)],
  };
}

export async function generateNpcBatch(concept) {
  const count = Math.max(1, Math.min(20, Number(concept.count) || 1));
  if (count > 1 && concept.target !== "new") {
    throw new Error("Пакетно можно создавать только новых персонажей.");
  }
  const results = [];
  try {
    for (let index = 0; index < count; index += 1) {
      const entrySeed = String(deriveSeed(concept.randomSeed, `batch-${index}`));
      const encounterEntry =
        count > 1 && concept.batchMode === "encounter"
          ? monsterEncounterMemberConcept(concept, index)
          : null;
      const entry = encounterEntry
        ? { ...encounterEntry, openSheet: false }
        : count > 1 && concept.batchMode === "squad"
          ? {
              ...squadMemberConcept(concept, index),
              openSheet: false,
            }
          : {
              ...concept,
              count: 1,
              randomSeed: entrySeed,
              seedPersonality: String(deriveSeed(entrySeed, "personality")),
              seedAbilities: String(deriveSeed(entrySeed, "abilities")),
              seedSpells: String(deriveSeed(entrySeed, "spells")),
              seedConsumables: String(deriveSeed(entrySeed, "consumables")),
              seedToken: String(deriveSeed(entrySeed, "token")),
              name:
                count === 1
                  ? concept.name
                  : concept.randomized
                    ? randomNameForGender(concept.gender, entrySeed, { ancestry: concept.ancestry, technology: concept.technology })
                    : `${concept.name} ${index + 1}`,
              openSheet: count === 1 && concept.openSheet,
            };
      if (count > 1 && index > 0) entry.includeLootPlan = false;
      results.push(await generateNpc(entry));
    }
  } catch (error) {
    if (count > 1) {
      for (const result of results.reverse()) {
        try {
          await result.actor?.delete?.();
        } catch (cleanupError) {
          console.warn(`${MODULE_ID} | Ошибка очистки неполной группы`, cleanupError);
        }
      }
      throw new Error(
        `Пакетная сборка остановлена и уже созданные листы удалены. ${error.message}`,
      );
    }
    throw error;
  }
  return results;
}

export function getPreview(concept) {
  const normalized = normalizeConcept(concept);
  concept = normalized.concept;
  const built = buildActorSystem(concept);
  const { system, tiers, adjustment } = built;
  const skillRows = Object.entries(system.skills)
    .map(([slug, data]) => `${SKILL_LABELS[slug] ?? slug} +${data.base}`)
    .join(", ");
  const plans = plannedItems(concept);
  const random = randomContentPlan(
    concept,
    contentContext(concept, tiers, adjustment),
  );
  const coherence = analyzeConcept(concept);
  const personality = personalityPlan(concept);
  const tactics = tacticsPlan(concept, random.spells);
  const monsterLore = monsterLorePlan(concept);
  const encounter = encounterPlan(concept);
  const automation = built.intelligence.automation;
  const actionEconomy = built.intelligence.actionEconomy;
  const adventure = built.intelligence.adventure;
  const monsterTemplate = built.intelligence.monsterTemplate;
  const extremeCount = Object.values(tiers).filter(
    (tier) => tier === "extreme",
  ).length;
  const warnings = [
    ...normalized.corrections,
    ...coherence.issues.map((issue) =>
      `${issue.message}${issue.suggestion ? ` ${issue.suggestion}` : ""}`,
    ),
  ];
  if (extremeCount > 2 && !coherence.issues.some((issue) => issue.code === "too-many-extremes")) {
    warnings.push(
      "Выбрано больше двух предельных показателей: такой NPC заметно опаснее обычной дорожной карты.",
    );
  }
  if (concept.count > 1 && concept.target !== "new") {
    warnings.push("Пакетное создание доступно только для новых NPC.");
  }
  // При создании нового NPC вообще не читаем выделенный Actor. Это исключает
  // побочные вызовы сторонних переводчиков на чужих character-листах.
  const selected = concept.target === "new" ? emptySelectedNpcInfo() : selectedNpcInfo();
  if (concept.target !== "new" && !selected.available) {
    warnings.push("Для выбранного режима нужен ровно один выделенный жетон NPC.");
  }
  if (encounter?.warnings?.length) warnings.push(...encounter.warnings);
  if (concept.target === "selected") {
    warnings.push(
      `Будет перестроен оригинал${selected.actorName ? ` «${selected.actorName}»` : ""}. Резервная копия ${concept.backupOriginal ? "будет создана" : "отключена"}.`,
    );
  }
  const weapon = WEAPONS[concept.weapon];
  const previewDamageTier =
    Number.isFinite(weapon.range) && tiers.damage === "extreme"
      ? "high"
      : tiers.damage;
  const usesDc =
    concept.role === "caster" ||
    concept.elements.length > 0 ||
    plans.spells.length > 0;
  return {
    name: concept.name,
    summary: conceptSummary(concept),
    setting: concept.technology === "starfinder" || concept.contentSource === "sf2e" ? "starfinder" : "fantasy",
    ancestryLabel: ANCESTRIES[concept.ancestry]?.label ?? concept.ancestry,
    professionLabel: PROFESSIONS[concept.profession]?.label ?? concept.profession,
    role: concept.role,
    roleLabel: ROLES[concept.role]?.label ?? concept.role,
    ac: system.attributes.ac.value,
    hp: system.attributes.hp.max,
    perception: system.perception.mod,
    saves: {
      fortitude: system.saves.fortitude.value,
      reflex: system.saves.reflex.value,
      will: system.saves.will.value,
    },
    attack:
      valueAt(
        "attack",
        concept.level,
        normalizeCombatTier("attack", tiers.attack),
      ) + adjustment,
    damage: addDamageBonus(
      valueAt(
        "damage",
        concept.level,
        normalizeCombatTier("damage", previewDamageTier),
        "moderate",
      ),
      adjustment ? 2 : 0,
    ),
    dc: usesDc
      ? valueAt(
          "dc",
          concept.level,
          normalizeCombatTier("dc", tiers.dc),
          "moderate",
        ) + adjustment
      : null,
    skills: skillRows,
    tierDescription: tierListHtml(tiers),
    effectiveLevel:
      concept.level +
      (concept.quality === "elite" ? (concept.level <= 0 ? 2 : 1) : 0),
    speed:
      system.attributes.speed.value + (["skirmisher", "ambusher", "lurker"].includes(concept.role) ? 5 : 0),
    equipment: plans.equipment,
    actions: plans.actions,
    strikes: plans.strikes,
    spells: plans.spells,
    randomCounts: {
      abilities: random.features.length,
      spells: random.spells?.spells.length ?? 0,
      consumables: random.consumables.length,
    },
    spellTheme: random.spells?.themeLabel ?? null,
    technologyLabel: TECHNOLOGY_LEVELS[concept.technology]?.label ?? concept.technology,
    contentSourceLabel: CONTENT_SOURCES[concept.contentSource]?.label ?? concept.contentSource,
    deploymentLabel: DEPLOYMENT_MODES[concept.deploymentMode]?.label ?? null,
    complexity: concept.complexity,
    coherence,
    personality,
    tactics,
    monsterLore,
    encounter,
    automation,
    actionEconomy,
    adventure,
    monsterTemplate,
    group:
      concept.count > 1
        ? concept.batchMode === "squad"
          ? `согласованный отряд из ${concept.count} разных ролей`
          : concept.batchMode === "encounter"
            ? `тематическое столкновение «${familyForConcept(concept)?.label ?? "монстры"}» из ${concept.count} существ`
            : `${concept.count} вариантов одной заготовки`
        : null,
    artwork: concept.tokenImage
      ? concept.tokenImage
      : concept.randomToken
        ? `случайный подходящий файл из «${concept.tokenPath || "автоматического поиска"}»`
        : null,
    target: concept.target,
    count: concept.count,
    selected,
    warnings,
  };
}

export async function restoreFromHistoryEntry(entry, { openSheet = true } = {}) {
  if (!game.user.isGM) throw new Error("Восстановление доступно только ведущему.");
  const targetUuid = entry?.actorUuids?.[0];
  const backupUuid = entry?.backupUuids?.[0];
  if (!targetUuid || !backupUuid) {
    throw new Error("У этой записи истории нет пары оригинала и резервной копии.");
  }
  const resolver = globalThis.fromUuid ?? foundry.utils?.fromUuid;
  const target = resolver ? await resolver(targetUuid) : null;
  const backup = resolver ? await resolver(backupUuid) : null;
  if (!target || target.type !== "npc") throw new Error("Перестроенный NPC больше не найден.");
  if (!backup || backup.type !== "npc") throw new Error("Резервная копия больше не найдена.");

  const safetyBackup = await createBackup(target);
  const source = backup.toObject();
  const oldIds = target.items
    .filter((item) => !["condition", "effect"].includes(item.type))
    .map((item) => item.id);
  const restoredItems = (source.items ?? [])
    .filter((item) => !["condition", "effect"].includes(item.type))
    .map((item) => {
      const copy = structuredClone(item);
      delete copy._id;
      return copy;
    });

  await target.update({
    name:
      source.flags?.[MODULE_ID]?.sourceActorName ??
      source.name.replace(/ — резерв .*$/u, ""),
    img: source.img,
    prototypeToken: source.prototypeToken,
    system: replaceDocumentData(source.system),
    [`flags.${MODULE_ID}`]:
      source.flags?.[MODULE_ID]?.sourceForgeFlags ?? null,
  });
  if (restoredItems.length) await safelyCreateItems(target, restoredItems);
  if (oldIds.length) await target.deleteEmbeddedDocuments("Item", oldIds);
  if (openSheet) target.sheet?.render(true);
  return { actor: target, safetyBackup };
}

export function tablesForDebug() {
  return CREATURE_TABLES;
}
