import { createRng, deriveSeed, pick } from "./randomizer.js";
import { normalizeActionCategory } from "./schema-guard.js";

const action = (name, slug, actions, description, traits = [], category = "offensive") => ({
  name,
  slug,
  actionType: "action",
  actions,
  traits,
  category: normalizeActionCategory(category),
  description,
});
const passive = (name, slug, description, rules = []) => ({
  name,
  slug,
  actionType: "passive",
  actions: null,
  traits: [],
  category: "defensive",
  description,
  rules,
});
const reaction = (name, slug, description, traits = [], category = "offensive") => ({
  name,
  slug,
  actionType: "reaction",
  actions: null,
  traits,
  category: normalizeActionCategory(category),
  description,
});

const strike = (
  name,
  slug,
  damageType,
  traits,
  { attackTier = null, damageTier = null, range = null, description = "" } = {},
) => ({ name, slug, damageType, traits, attackTier, damageTier, range, description });

export const CREATURE_KINDS = {
  person: { label: "Обычный разумный NPC", description: "Профессия, снаряжение и социальная роль." },
  monster: { label: "Монстр или племенное существо", description: "Семейство, природные атаки, логово и повадки." },
  undead: { label: "Нежить", description: "Мёртвые тела, голод, проклятия и некромантия." },
  beast: { label: "Зверь", description: "Инстинкты, стая, территория и естественное оружие." },
  construct: { label: "Конструкт", description: "Приказы, корпус, встроенное оружие и сбои." },
  ooze: { label: "Слизь", description: "Бесформенность, поглощение и необычные защиты." },
};

/**
 * Семейства намеренно описывают не готовые официальные статблоки, а дорожные карты
 * оригинальных NPC. Цифры по-прежнему берутся из таблиц создания существ PF2e.
 */
export const MONSTER_FAMILIES = {
  none: {
    label: "Нет — обычный NPC",
    kind: "person",
    description: "Использовать происхождение и профессию как раньше.",
  },
  goblin: {
    label: "Гоблины",
    kind: "monster",
    ancestry: "goblin",
    aliases: /гоблин/iu,
    description: "Маленькие, шумные и изобретательно опасные налётчики.",
    ecology: "селятся в руинах, пещерах, старых шахтах и на окраинах больших поселений",
    motive: "ищут еду, блестящие вещи, горючее и повод доказать свою смелость",
    negotiation: "отступают перед убедительной демонстрацией силы, подарками и обещанием более лёгкой добычи",
    lair: "ловушки из мусора, запас горючего, клетки с мелкими зверями и тайный запас вожака",
    defaultProfession: "raider",
    defaultRole: "ambusher",
    defaultArmor: "light",
    defaultWeapon: "dogslicer",
    allowedRoles: ["ambusher", "artillery", "skirmisher", "controller", "leader", "caster"],
    naturalStrikes: [],
    features: ({ dc }) => [
      reaction("Гоблинская суета", "forge-goblin-scuttle", "<p><strong>Триггер:</strong> противник заканчивает действие перемещения рядом с гоблином или промахивается по нему. Гоблин делает Шаг, стараясь оказаться за укрытием или рядом с союзником.</p>"),
      action("Поджечь всё", "forge-goblin-burn-it", 1, `<p>Гоблин поджигает соседний ничейный предмет или подготовленную горючую поверхность. Существо, входящее в огонь, получает @Damage[1d6[fire]] урона; простой @Check[reflex|dc:${dc}] уменьшает его вдвое.</p>`, ["fire", "manipulate"]),
    ],
    roster: [
      ["ambusher", "raider", "dogslicer", "light", "лазутчик"],
      ["artillery", "trapper", "sling", "light", "пращник"],
      ["controller", "trapper", "spear", "light", "ловушечник"],
      ["caster", "shaman", "staff", "none", "пироман"],
      ["leader", "chieftain", "dogslicer", "medium", "вожак"],
    ],
  },
  gnoll: {
    label: "Гноллы / холо",
    kind: "monster",
    ancestry: "gnoll",
    aliases: /гнолл|холо(?=$|[\s,.;:])/iu,
    description: "Выносливые стайные охотники, способные быть как налётчиками, так и строгими хранителями территории.",
    ecology: "устраивают лагеря на открытой местности, в каньонах и около караванных путей",
    motive: "защищают стаю, охотничьи земли и запасы либо преследуют отмеченную добычу",
    negotiation: "уважают прямоту, обмен полезными сведениями и тех, кто не показывает страха",
    lair: "разделанные туши, трофеи охоты, сигнальные костры и хорошо охраняемая семейная святыня",
    defaultProfession: "packHunter",
    defaultRole: "packHunter",
    defaultArmor: "medium",
    defaultWeapon: "flail",
    allowedRoles: ["packHunter", "berserker", "artillery", "leader", "caster", "controller"],
    naturalStrikes: [
      strike("Челюсти", "forge-gnoll-jaws", "piercing", ["unarmed"], {
        attackTier: "moderate",
        damageTier: "moderate",
        description: "Мощный укус, которым гнолл удерживает добычу рядом со стаей.",
      }),
    ],
    features: ({ dc }) => [
      passive("Стайная расправа", "forge-gnoll-pack", "<p>Когда цель находится рядом хотя бы с двумя врагами-гноллами, первый успешный Удар этого существа за раунд наносит дополнительно 1d6 точного урона.</p>"),
      action("Глумливый хохот", "forge-gnoll-laugh", 1, `<p>Один противник в пределах 30 футов проходит @Check[will|dc:${dc}]. При провале он становится напуган 1; при критическом провале — напуган 2. Существо временно невосприимчиво на 10 минут.</p>`, ["auditory", "emotion", "mental"]),
    ],
    roster: [
      ["packHunter", "packHunter", "flail", "medium", "охотник"],
      ["artillery", "hunter", "shortbow", "light", "следопыт"],
      ["berserker", "raider", "greataxe", "medium", "костолом"],
      ["caster", "shaman", "staff", "light", "костяной шаман"],
      ["leader", "chieftain", "spearShield", "medium", "вожак стаи"],
    ],
  },
  kobold: {
    label: "Кобольды",
    kind: "monster",
    ancestry: "kobold",
    aliases: /кобольд/iu,
    description: "Осторожные драконопочитатели, компенсирующие слабость инженерией и ловушками.",
    ecology: "занимают шахты, канализации, вулканические туннели и места, связанные с драконами",
    motive: "охраняют кладку, идола, драгоценный минерал или территорию своего покровителя",
    negotiation: "охотно торгуются за безопасность племени и реагируют на знание драконьих обычаев",
    lair: "низкие проходы, ложные двери, растяжки, дымоходы и пути отступления размером с кобольда",
    defaultProfession: "trapper",
    defaultRole: "controller",
    defaultArmor: "light",
    defaultWeapon: "sling",
    allowedRoles: ["ambusher", "artillery", "controller", "support", "caster", "leader"],
    naturalStrikes: [
      strike("Челюсти", "forge-kobold-jaws", "piercing", ["agile", "finesse", "unarmed"], {
        attackTier: "low",
        damageTier: "low",
        description: "Последнее средство загнанного в угол кобольда.",
      }),
    ],
    features: ({ dc }) => [
      action("Ловушка под ногами", "forge-kobold-snare", 1, `<p>Кобольд активирует заранее подготовленную ловушку в соседней клетке. Существо в ней проходит @Check[reflex|dc:${dc}]. При провале оно падает ничком или становится обездвижено до конца своего следующего хода — выбор делается при создании сцены.</p>`, ["manipulate"]),
      reaction("Жалкая уловка", "forge-kobold-cringe", "<p><strong>Триггер:</strong> враг объявляет атаку по кобольду. Кобольд получает обстоятельственный бонус +1 к КБ против этой атаки, после чего становится застигнут врасплох до начала своего следующего хода.</p>", ["emotion", "mental"]),
    ],
    roster: [
      ["ambusher", "raider", "spear", "light", "копейщик"],
      ["artillery", "trapper", "sling", "light", "пращник"],
      ["controller", "trapper", "crossbow", "light", "ловушечник"],
      ["caster", "shaman", "staff", "none", "драконий шаман"],
      ["leader", "chieftain", "spearShield", "medium", "чешуйчатый вождь"],
    ],
  },
  hobgoblin: {
    label: "Хобгоблины",
    kind: "monster",
    ancestry: "hobgoblin",
    aliases: /хобгоблин/iu,
    description: "Дисциплинированные солдаты, строящие силу на приказах и совместных действиях.",
    ecology: "создают укреплённые лагеря, заставы и военные поселения с чётким распорядком",
    motive: "выполняют приказ, расширяют территорию или проверяют оборону будущего противника",
    negotiation: "принимают формальные переговоры, обмен пленными и чётко сформулированные условия",
    lair: "карты, запасы строевого оружия, сигналы тревоги, списки караулов и дисциплинарная площадка",
    defaultProfession: "guard",
    defaultRole: "soldier",
    defaultArmor: "medium",
    defaultWeapon: "longswordShield",
    allowedRoles: ["soldier", "defender", "artillery", "controller", "leader", "caster"],
    naturalStrikes: [],
    features: () => [
      passive("Строевая дисциплина", "forge-hobgoblin-discipline", "<p>Пока хобгоблин находится рядом с союзником, он получает обстоятельственный бонус +1 к спасброскам против страха и эффектов эмоций.</p>"),
      reaction("Сомкнуть строй", "forge-hobgoblin-close-ranks", "<p><strong>Триггер:</strong> союзник в пределах 10 футов получает урон. Хобгоблин делает Шаг к союзнику; если после этого они соседние, союзник получает обстоятельственный бонус +1 к КБ до начала своего следующего хода.</p>"),
    ],
    roster: [
      ["soldier", "guard", "spearShield", "medium", "легионер"],
      ["defender", "guard", "longswordShield", "heavy", "щитовой"],
      ["artillery", "hunter", "crossbow", "light", "арбалетчик"],
      ["controller", "chieftain", "halberd", "medium", "сержант"],
      ["leader", "chieftain", "longswordShield", "heavy", "капитан"],
    ],
  },
  bugbear: {
    label: "Багберы",
    kind: "monster",
    ancestry: "bugbear",
    aliases: /багбер|бугбер/iu,
    description: "Крупные скрытные хищники, пугающе тихие для своего размера.",
    ecology: "живут в заброшенных башнях, лесных логовах и на окраинах владений более многочисленных гоблиноидов",
    motive: "охотятся из засады, вымогают дань или устраняют цель по заказу",
    negotiation: "предпочитают сделки, оставляющие им преимущество, и редко рискуют ради абстрактной верности",
    lair: "наблюдательные щели, подвешенные трофеи, тёмные проходы и отдельная камера для пленников",
    defaultProfession: "raider",
    defaultRole: "lurker",
    defaultArmor: "medium",
    defaultWeapon: "morningstar",
    allowedRoles: ["lurker", "ambusher", "brute", "berserker", "leader"],
    naturalStrikes: [],
    features: () => [
      passive("Невероятно тихий", "forge-bugbear-quiet", "<p>Багбер не получает штрафа к Скрытности из-за крупного оружия или среднего доспеха и получает обстоятельственный бонус +1 к инициативе Скрытности.</p>"),
      passive("Удар из темноты", "forge-bugbear-dark-strike", "<p>Первый Удар багбера по существу, для которого он был незамеченным, наносит дополнительно 1d6 точного урона.</p>"),
    ],
    roster: [
      ["lurker", "raider", "morningstar", "medium", "душитель"],
      ["ambusher", "hunter", "shortbow", "light", "охотник"],
      ["brute", "raider", "maul", "medium", "ломатель"],
      ["leader", "chieftain", "morningstar", "medium", "старший охотник"],
    ],
  },
  lizardfolk: {
    label: "Ирукси / ящеролюды",
    kind: "monster",
    ancestry: "lizardfolk",
    aliases: /ящеролюд|ирукси/iu,
    description: "Терпеливые жители болот и побережий, сочетающие ремесло, традиции и природное оружие.",
    ecology: "строят поселения на болотных островах, у рек, мангровых лесов и тёплых руин",
    motive: "защищают кладки, священные воды, охотничьи территории и память предков",
    negotiation: "ценят практичные дары, уважение к обычаям и помощь против общей угрозы",
    lair: "подводные входы, плетёные мостки, сушильни, идолы предков и запасы лекарственных трав",
    defaultProfession: "tribalHunter",
    defaultRole: "defender",
    defaultArmor: "medium",
    defaultWeapon: "spearShield",
    allowedRoles: ["defender", "packHunter", "ambusher", "controller", "caster", "leader"],
    otherSpeeds: [{ type: "swim", value: 20 }],
    naturalStrikes: [
      strike("Челюсти", "forge-iruxi-jaws", "piercing", ["unarmed"], {
        attackTier: "moderate", damageTier: "moderate", description: "Сильный укус ящеролюда.",
      }),
      strike("Хвост", "forge-iruxi-tail", "bludgeoning", ["agile", "unarmed"], {
        attackTier: "moderate", damageTier: "low", description: "Быстрый удар тяжёлым хвостом.",
      }),
    ],
    features: () => [
      passive("Болотная устойчивость", "forge-iruxi-marsh", "<p>Ирукси игнорирует обычную сложную местность от мелкой воды, грязи и болотной растительности.</p>"),
      reaction("Удар хвостом", "forge-iruxi-tail-reaction", "<p><strong>Триггер:</strong> соседний враг делает Шаг или встаёт. Ирукси наносит Удар хвостом со штрафом −2.</p>"),
    ],
    roster: [
      ["defender", "tribalHunter", "spearShield", "medium", "страж кладки"],
      ["packHunter", "hunter", "spear", "light", "охотник"],
      ["ambusher", "trapper", "javelin", "light", "болотный метатель"],
      ["caster", "shaman", "staff", "none", "хранитель предков"],
      ["leader", "chieftain", "spearShield", "medium", "старейшина-воин"],
    ],
  },
  ogre: {
    label: "Огры",
    kind: "monster",
    ancestry: "ogre",
    aliases: /огр(?=$|[\s,.;:])/iu,
    description: "Огромные, прямолинейные и разрушительные хищники с простыми желаниями.",
    ecology: "занимают пещеры, разрушенные фермы и ущелья рядом с источником пищи",
    motive: "ищут еду, лёгкую добычу, громкое развлечение или исполняют приказ более умного хозяина",
    negotiation: "понимают простые сделки, большие порции еды и угрозы немедленной понятной расплатой",
    lair: "груды костей, примитивные трофеи, украденные инструменты и неожиданно ценная вещь среди мусора",
    defaultProfession: "monster",
    defaultRole: "brute",
    defaultArmor: "none",
    defaultWeapon: "maul",
    allowedRoles: ["brute", "berserker", "artillery", "defender", "leader"],
    naturalStrikes: [
      strike("Кулак", "forge-ogre-fist", "bludgeoning", ["unarmed"], {
        attackTier: "moderate", damageTier: "high", description: "Удар огромным кулаком.",
      }),
    ],
    features: ({ dc, damage }) => [
      action("Раздавить", "forge-ogre-crush", 2, `<p>Огр наносит тяжёлый Удар. При попадании цель проходит @Check[fortitude|dc:${dc}]. При провале она падает ничком; при критическом провале также получает @Damage[${damage}[bludgeoning]] дополнительного урона.</p>`, ["flourish"]),
      passive("Грубая сила", "forge-ogre-bulk", "<p>Огр считается на один размер больше для определения существ, которых он может Схватить, Толкнуть или Опрокинуть.</p>"),
    ],
    roster: [
      ["brute", "monster", "maul", "none", "дуболом"],
      ["artillery", "monster", "javelin", "none", "метатель"],
      ["berserker", "raider", "greataxe", "light", "мясник"],
      ["leader", "chieftain", "greatsword", "medium", "главарь"],
    ],
  },
  troll: {
    label: "Тролли",
    kind: "monster",
    ancestry: "troll",
    aliases: /тролл/iu,
    description: "Регенерирующие великаны, которые уверенно идут на размен ударами.",
    ecology: "держатся около мостов, пещер, болот и мест, где легко перехватывать добычу",
    motive: "охраняют кормовую территорию, требуют плату или следуют примитивной мести",
    negotiation: "могут принять регулярную дань, указание на более богатую добычу или доказательство наличия огня и кислоты",
    lair: "кости, остатки неудачных засад, камни для метания и защищённое от солнца место отдыха",
    defaultProfession: "monster",
    defaultRole: "berserker",
    defaultArmor: "none",
    defaultWeapon: "claws",
    allowedRoles: ["berserker", "brute", "packHunter", "defender"],
    naturalStrikes: [
      strike("Челюсти", "forge-troll-jaws", "piercing", ["unarmed"], { attackTier: "high", damageTier: "high", description: "Голодный укус тролля." }),
      strike("Когти", "forge-troll-claws", "slashing", ["agile", "unarmed"], { attackTier: "high", damageTier: "moderate", description: "Длинные рвущие когти." }),
    ],
    features: () => [
      passive("Регенерация тролля", "forge-troll-regeneration", "<p>В начале своего хода тролль восстанавливает ОЗ в размере примерно своего уровня + 5. Получение урона огнём или кислотой подавляет восстановление до конца следующего хода. Значение можно увеличить для важного одиночного тролля.</p>"),
      action("Рвать и кусать", "forge-troll-rend", 2, "<p>Тролль наносит два Удара когтями. Если оба попадают по одной цели, он наносит ей дополнительный урон, равный одной кости основного Удара.</p>", ["flourish"]),
    ],
    roster: [
      ["berserker", "monster", "claws", "none", "голодный тролль"],
      ["brute", "monster", "maul", "none", "каменнолом"],
      ["defender", "monster", "claws", "none", "страж логова"],
    ],
  },
  skeleton: {
    label: "Скелеты",
    kind: "undead",
    ancestry: "skeleton",
    aliases: /скелет/iu,
    description: "Кости, удерживаемые некромантией, приказом или остатком навязчивой воли.",
    ecology: "стоят в гробницах, на древних полях боя и в хранилищах некромантов",
    motive: "исполняют последний приказ, повторяют старый ритуал или защищают место смерти",
    negotiation: "обычно невозможны переговоры, но разумные скелеты реагируют на знаки прежней власти и память о жизни",
    lair: "сухие останки, погребальное оружие, таблички с приказами и источник некромантии",
    defaultProfession: "undead",
    defaultRole: "soldier",
    defaultArmor: "medium",
    defaultWeapon: "longswordShield",
    allowedRoles: ["soldier", "defender", "artillery", "leader", "caster"],
    naturalStrikes: [strike("Костяная рука", "forge-skeleton-claw", "slashing", ["agile", "unarmed"], { attackTier: "low", damageTier: "low", description: "Царапающие костяные пальцы." })],
    features: () => [
      passive("Скелетная природа", "forge-skeleton-nature", "<p>Скелет не дышит, не ест и не спит. Обычно он невосприимчив к кровотечению, болезням, параличу, яду и эффектам сна. Дробящий урон особенно хорошо разрушает его сочленения; ведущий может представить это слабостью или отключением защитной реакции.</p>"),
      reaction("Рассыпаться", "forge-skeleton-collapse", "<p><strong>Триггер:</strong> скелет становится целью критического попадания. Он частично рассыпается, получая обстоятельственный бонус +2 к КБ против подтверждающей части эффекта, затем падает ничком.</p>"),
    ],
    roster: [
      ["soldier", "undead", "longswordShield", "medium", "костяной страж"],
      ["artillery", "undead", "shortbow", "light", "мёртвый лучник"],
      ["defender", "undead", "spearShield", "heavy", "гробничный щит"],
      ["caster", "necromancer", "staff", "none", "черепной маг"],
      ["leader", "chieftain", "greatsword", "heavy", "костяной капитан"],
    ],
  },
  zombie: {
    label: "Зомби",
    kind: "undead",
    ancestry: "zombie",
    aliases: /зомби|ходяч.*мертв/iu,
    description: "Медленные трупы, опасные массой, захватами и неестественной стойкостью.",
    ecology: "бродят возле мест массовой смерти, чумных ям и источников некромантии",
    motive: "движимы голодом, зовом создателя или последней привычкой тела",
    negotiation: "почти всегда невозможно; иногда их можно отвлечь запахом, шумом или воздействием на управляющий источник",
    lair: "следы волочения, остатки одежды, заражённая вода и предмет, связывающий мёртвых с создателем",
    defaultProfession: "undead",
    defaultRole: "brute",
    defaultArmor: "none",
    defaultWeapon: "fists",
    allowedRoles: ["brute", "berserker", "defender"],
    naturalStrikes: [
      strike("Челюсти", "forge-zombie-jaws", "piercing", ["unarmed"], { attackTier: "moderate", damageTier: "moderate", description: "Гнилой, но сильный укус." }),
    ],
    features: ({ dc }) => [
      passive("Медленный", "forge-zombie-slow", "<p>Зомби обычно получает только 2 действия в свой ход и не может использовать реакции, если особая способность не говорит обратного.</p>"),
      action("Вцепиться", "forge-zombie-grab", 1, `<p><strong>Требования:</strong> последний Удар зомби попал по соседней цели. Цель проходит @Check[fortitude|dc:${dc}]. При провале она схвачена до конца следующего хода зомби.</p>`, ["attack"]),
    ],
    roster: [
      ["brute", "undead", "fists", "none", "ходячий труп"],
      ["defender", "undead", "fists", "medium", "бронированный мертвец"],
      ["berserker", "undead", "claws", "none", "голодный зомби"],
    ],
  },
  ghoul: {
    label: "Гули",
    kind: "undead",
    ancestry: "ghoul",
    aliases: /гул(?=$|[\s,.;:])|упыр/iu,
    description: "Разумные или полудикие пожиратели плоти, быстрые и опасные в тесноте.",
    ecology: "прячутся в катакомбах, подвалах, кладбищах и тоннелях под городами",
    motive: "ищут свежую плоть, защищают кормовую территорию или служат более сильной нежити",
    negotiation: "разумных гулей можно подкупить безопасной пищей, сведениями о трупах или обещанием скрыть их логово",
    lair: "обглоданные кости, украденные украшения, лаз в канализацию и следы прежней разумной жизни",
    defaultProfession: "undead",
    defaultRole: "lurker",
    defaultArmor: "none",
    defaultWeapon: "claws",
    allowedRoles: ["lurker", "packHunter", "ambusher", "leader", "caster"],
    naturalStrikes: [
      strike("Челюсти", "forge-ghoul-jaws", "piercing", ["unarmed"], { attackTier: "high", damageTier: "moderate", description: "Заражённый укус гуля." }),
      strike("Когти", "forge-ghoul-claws", "slashing", ["agile", "finesse", "unarmed"], { attackTier: "high", damageTier: "low", description: "Быстрые цепляющие когти." }),
    ],
    features: ({ dc }) => [
      passive("Парализующие когти", "forge-ghoul-paralysis", `<p>Живое существо, получившее урон от когтей, проходит @Check[fortitude|dc:${dc}]. При провале оно становится замедлено 1 на 1 раунд; при критическом провале — парализовано до конца следующего хода гуля. После спасброска цель временно невосприимчива на 1 минуту.</p>`),
      action("Рывок к упавшему", "forge-ghoul-feast", 1, "<p>Гуль Перемещается на расстояние до половины Скорости к лежащему ничком, умирающему или схваченному существу. Это движение не провоцирует реакции от такой цели.</p>", ["move"]),
    ],
    roster: [
      ["lurker", "undead", "claws", "none", "могильный гуль"],
      ["packHunter", "undead", "jaws", "none", "пожиратель"],
      ["ambusher", "thief", "claws", "light", "катакомбный лазутчик"],
      ["leader", "chieftain", "claws", "light", "король падальщиков"],
    ],
  },
  wolf: {
    label: "Волки",
    kind: "beast",
    ancestry: "wolf",
    aliases: /волк|волчиц/iu,
    description: "Территориальные стайные хищники, предпочитающие окружение и опрокидывание.",
    ecology: "держатся в лесах, степях, горах и рядом с мигрирующей добычей",
    motive: "защищают логово, охотятся, следуют за более опасным хищником или страдают от магического голода",
    negotiation: "обычные переговоры невозможны, но пища, Запугивание, Природа и устранение угрозы логову могут остановить нападение",
    lair: "кости добычи, шерсть, узкие звериные тропы и щенки либо раненый член стаи",
    defaultProfession: "beast",
    defaultRole: "packHunter",
    defaultArmor: "none",
    defaultWeapon: "jaws",
    allowedRoles: ["packHunter", "ambusher", "lurker", "leader"],
    naturalStrikes: [strike("Челюсти", "forge-wolf-jaws", "piercing", ["unarmed"], { attackTier: "high", damageTier: "moderate", description: "Укус, направленный в ноги и горло." })],
    features: ({ dc }) => [
      passive("Стайная охота", "forge-wolf-pack", "<p>Первый раз за раунд, когда волк попадает по цели, соседней с другим союзником волка, он наносит дополнительно 1d4 точного урона.</p>"),
      action("Сбить с ног", "forge-wolf-knockdown", 1, `<p><strong>Требования:</strong> последний Удар челюстями попал. Цель проходит @Check[reflex|dc:${dc}]. При провале она падает ничком.</p>`, ["attack"]),
    ],
    roster: [
      ["packHunter", "beast", "jaws", "none", "охотник стаи"],
      ["ambusher", "beast", "jaws", "none", "серый загонщик"],
      ["lurker", "beast", "jaws", "none", "тихий волк"],
      ["leader", "beast", "jaws", "none", "вожак"],
    ],
  },
  warg: {
    label: "Варги",
    kind: "beast",
    ancestry: "warg",
    aliases: /варг/iu,
    description: "Разумные чудовищные волки, сочетающие стайную тактику и жестокие переговоры.",
    ecology: "занимают холмы, лесные дороги и территории рядом с гоблинскими племенами",
    motive: "ищут добычу, требуют плату за проход или выполняют соглашение с союзным племенем",
    negotiation: "понимают речь, способны торговаться и всегда оценивают, кого проще съесть, а с кем выгоднее договориться",
    lair: "кости, следы гоблинских сёдел, наблюдательные позиции и спрятанные трофеи разумных жертв",
    defaultProfession: "beast",
    defaultRole: "packHunter",
    defaultArmor: "none",
    defaultWeapon: "jaws",
    allowedRoles: ["packHunter", "ambusher", "leader", "berserker"],
    naturalStrikes: [strike("Челюсти", "forge-warg-jaws", "piercing", ["unarmed"], { attackTier: "high", damageTier: "high", description: "Массивные челюсти разумного хищника." })],
    features: ({ dc }) => [
      action("Зловещая речь", "forge-warg-threat", 1, `<p>Варг Деморализует одно существо в пределах 30 футов, используя естественно пугающую речь. При критическом провале @Check[will|dc:${dc}] цель также застигнута врасплох для варгов до начала своего следующего хода.</p>`, ["auditory", "emotion", "linguistic", "mental"]),
      passive("Разумный загонщик", "forge-warg-hunter", "<p>Варг может Помогать союзнику в Выслеживании и Запугивании без подготовки, если цель видима или её след свежий.</p>"),
    ],
    roster: [
      ["packHunter", "beast", "jaws", "none", "варг-охотник"],
      ["ambusher", "beast", "jaws", "none", "ночной загонщик"],
      ["berserker", "beast", "jaws", "none", "кровавый варг"],
      ["leader", "beast", "jaws", "none", "говорящий вожак"],
    ],
  },
  giantSpider: {
    label: "Гигантские пауки",
    kind: "beast",
    ancestry: "giantSpider",
    aliases: /гигантск.*паук|огромн.*паук|паучих/iu,
    description: "Лазящие по стенам засадные хищники, контролирующие пространство паутиной.",
    ecology: "оплетают пещеры, лесные овраги, руины и заброшенные здания",
    motive: "защищают кладку, ждут добычу или подчиняются дрессировщику и магии",
    negotiation: "обычно невозможно; Природа, огонь, вибрации паутины и отвлекающая добыча позволяют избежать схватки",
    lair: "коконы с добычей, кладка яиц, сухие безопасные тропы и предметы прежних жертв",
    defaultProfession: "beast",
    defaultRole: "lurker",
    defaultArmor: "none",
    defaultWeapon: "jaws",
    allowedRoles: ["lurker", "ambusher", "controller", "artillery", "leader"],
    otherSpeeds: [{ type: "climb", value: 25 }],
    naturalStrikes: [strike("Челюсти", "forge-spider-jaws", "piercing", ["finesse", "unarmed"], { attackTier: "high", damageTier: "moderate", description: "Ядовитые паучьи челюсти." })],
    features: ({ dc }) => [
      action("Плевок паутиной", "forge-spider-web", 1, `<p>Дальнобойная атака паутиной по существу в пределах 30 футов. Вместо броска атаки цель проходит @Check[reflex|dc:${dc}]. При провале она становится обездвижена; Вырваться можно против этой же СС.</p>`, ["attack"]),
      passive("Чувство паутины", "forge-spider-websense", "<p>Паук автоматически замечает существ, касающихся его паутины в пределах 60 футов, если они не движутся настолько осторожно, что успешно преодолевают его КС Восприятия.</p>"),
    ],
    roster: [
      ["lurker", "beast", "jaws", "none", "паук-засадник"],
      ["controller", "beast", "jaws", "none", "паук-ткач"],
      ["artillery", "beast", "jaws", "none", "паук-плевун"],
      ["leader", "beast", "jaws", "none", "матка"],
    ],
  },
  ooze: {
    label: "Слизи",
    kind: "ooze",
    ancestry: "ooze",
    aliases: /слиз|желе|студен|ам[её]б/iu,
    description: "Бесформенные поглотители, чьи способности зависят от среды и материала тела.",
    ecology: "скапливаются в канализациях, алхимических отходах, пещерах и древних хранилищах",
    motive: "поглощают органику, тепло, металл или магию в зависимости от разновидности",
    negotiation: "невозможно без магического контроля; их можно увести приманкой или направить потоком жидкости",
    lair: "частично растворённые предметы, чистые от органики поверхности и источник вещества, породившего слизь",
    defaultProfession: "monster",
    defaultRole: "brute",
    defaultArmor: "none",
    defaultWeapon: "pseudopod",
    allowedRoles: ["brute", "controller", "lurker", "artillery", "defender"],
    naturalStrikes: [strike("Ложноножка", "forge-ooze-pseudopod", "acid", ["unarmed"], { attackTier: "moderate", damageTier: "high", description: "Кислотный удар бесформенной конечностью." })],
    features: ({ dc }) => [
      passive("Бесформенный разум", "forge-ooze-mindless", "<p>Обычная слизь не видит привычным способом и обычно невосприимчива к эффектам с признаками auditory, emotion, linguistic, mental и visual, а также к точному урону. Применяй этот список с учётом конкретной разновидности.</p>"),
      action("Поглотить", "forge-ooze-engulf", 2, `<p>Слизь Перемещается на расстояние до Скорости через клетки существ не крупнее неё. Каждая цель проходит @Check[reflex|dc:${dc}]. При провале она оказывается внутри слизи: схвачена, получает кислотный урон в конце хода и может Вырваться против той же СС.</p>`, ["attack", "move"]),
    ],
    roster: [
      ["brute", "monster", "pseudopod", "none", "кислотная слизь"],
      ["controller", "monster", "pseudopod", "none", "липкое желе"],
      ["lurker", "monster", "pseudopod", "none", "прозрачный студень"],
      ["artillery", "monster", "acidSpit", "none", "плюющаяся слизь"],
    ],
  },
  construct: {
    label: "Конструкты",
    kind: "construct",
    ancestry: "construct",
    aliases: /конструкт|голем|автоматон|механическ.*страж/iu,
    description: "Созданные существа, чьи возможности определяются приказом, корпусом и встроенными модулями.",
    ecology: "охраняют мастерские, дворцы, хранилища и давно заброшенные комплексы",
    motive: "выполняют приказ буквально, поддерживают протокол безопасности или действуют из-за повреждённой директивы",
    negotiation: "возможны через пароль, полномочия, правильную формулировку приказа или ремонт управляющего узла",
    lair: "зарядные ниши, инструменты обслуживания, запасные детали и журнал приказов создателя",
    defaultProfession: "construct",
    defaultRole: "defender",
    defaultArmor: "heavy",
    defaultWeapon: "slam",
    allowedRoles: ["defender", "soldier", "artillery", "controller", "leader", "brute"],
    naturalStrikes: [strike("Встроенный ударник", "forge-construct-slam", "bludgeoning", ["unarmed"], { attackTier: "high", damageTier: "moderate", description: "Удар усиленной конечностью или встроенным молотом." })],
    features: ({ dc }) => [
      passive("Конструкт", "forge-construct-nature", "<p>Конструкт обычно не дышит, не ест и не спит и невосприимчив к кровотечению, болезням, эффектам смерти, исцелению живых существ, яду и сну. Точный перечень зависит от корпуса.</p>"),
      action("Аварийный протокол", "forge-construct-protocol", 1, `<p>Конструкт переключает режим до начала следующего хода: <strong>охрана</strong> даёт +1 к КБ; <strong>преследование</strong> даёт +10 футов к Скорости; <strong>подавление</strong> даёт +1 к следующей атаке, но −1 к КБ. Изменение режима имеет признак concentrate. СС вмешательства в протокол: ${dc}.</p>`, ["concentrate"]),
    ],
    roster: [
      ["defender", "construct", "slam", "heavy", "страж"],
      ["soldier", "construct", "halberd", "heavy", "часовой"],
      ["artillery", "construct", "crossbow", "medium", "турель"],
      ["controller", "construct", "spearShield", "heavy", "подавитель"],
      ["leader", "construct", "longswordShield", "heavy", "центурион"],
    ],
  },
};

export function monsterFamilyOptions() {
  return Object.entries(MONSTER_FAMILIES).map(([value, family]) => ({
    value,
    label: family.label,
    kind: family.kind,
  }));
}

export function detectMonsterFamily(text) {
  const source = String(text ?? "");
  return Object.entries(MONSTER_FAMILIES)
    .filter(([id]) => id !== "none")
    .find(([, family]) => family.aliases?.test(source))?.[0] ?? null;
}

export function familyForConcept(concept) {
  const id = concept?.monsterFamily;
  return id && id !== "none" ? MONSTER_FAMILIES[id] ?? null : null;
}

export function monsterLorePlan(concept) {
  const family = familyForConcept(concept);
  if (!family) return null;
  const rng = createRng(deriveSeed(concept.seedPersonality ?? concept.randomSeed, "monster-lore"));
  const complications = [
    "в логове есть пленник, которого чудовища пока не убили",
    "существами манипулирует третья сторона",
    "их агрессия вызвана голодом или потерей территории",
    "среди трофеев лежит предмет, за которым скоро придут другие",
    "вожак скрывает слабость от остальных",
    "племя расколото между осторожной и воинственной группами",
  ];
  const clues = [
    "следы показывают, что часть группы заметно меньше или слабее остальных",
    "на маршруте есть повторяющиеся знаки предупреждения",
    "добычу не всегда убивают — иногда её уносят",
    "местность подготовлена под конкретную тактику семейства",
    "один путь явно оставлен свободным как маршрут отступления",
    "среди следов заметны признаки внешнего снабжения",
  ];
  return {
    familyId: concept.monsterFamily,
    label: family.label,
    description: family.description,
    ecology: family.ecology,
    motive: family.motive,
    negotiation: family.negotiation,
    lair: family.lair,
    complication: pick(complications, rng),
    clue: pick(clues, rng),
  };
}

export function monsterStrikePlan(concept) {
  const family = familyForConcept(concept);
  return family?.naturalStrikes ?? [];
}

export function monsterFeaturePlan(concept, context) {
  const family = familyForConcept(concept);
  if (!family?.features) return [];
  const features = family.features(context) ?? [];
  const complexity = concept.complexity ?? "standard";
  if (complexity === "simple") return features.slice(0, 1);
  return complexity === "tactical" ? features : features.slice(0, 2);
}

export function monsterSystemProfile(concept, ancestry) {
  const family = familyForConcept(concept);
  if (!family) return {
    ...ancestry,
    otherSpeeds: [],
    familyLabel: null,
  };
  return {
    ...ancestry,
    otherSpeeds: family.otherSpeeds ?? ancestry.otherSpeeds ?? [],
    familyLabel: family.label,
    familyDescription: family.description,
  };
}

export function monsterEncounterMemberConcept(base, index) {
  const family = familyForConcept(base);
  if (!family?.roster?.length) return null;
  const row = family.roster[index % family.roster.length];
  const [role, profession, weapon, armor, title] = row;
  const seed = String(deriveSeed(base.randomSeed, `monster-encounter-${index}`));
  const levelOffset = index === family.roster.length - 1 && role === "leader" ? 1 : 0;
  return {
    ...base,
    count: 1,
    target: "new",
    role,
    profession,
    weapon,
    armor,
    level: Math.min(20, base.level + levelOffset),
    quality: role === "leader" && base.quality === "elite" ? "elite" : "standard",
    name: `${family.label.replace(/ы$/u, "")} — ${title}`,
    randomSeed: seed,
    seedPersonality: String(deriveSeed(seed, "personality")),
    seedAbilities: String(deriveSeed(seed, "abilities")),
    seedSpells: String(deriveSeed(seed, "spells")),
    seedConsumables: String(deriveSeed(seed, "consumables")),
    seedToken: String(deriveSeed(seed, "token")),
    randomized: true,
  };
}

export function randomMonsterFormValues(seed, keep = {}) {
  const rng = createRng(deriveSeed(seed, "random-monster"));
  const ids = Object.keys(MONSTER_FAMILIES).filter((id) => id !== "none");
  const monsterFamily = keep.monsterFamily && keep.monsterFamily !== "none"
    ? keep.monsterFamily
    : pick(ids, rng);
  const family = MONSTER_FAMILIES[monsterFamily];
  const role = keep.role && keep.role !== "auto"
    ? keep.role
    : pick(family.allowedRoles ?? [family.defaultRole], rng);
  const rosterMatch = family.roster?.find(([candidateRole]) => candidateRole === role);
  const profession = keep.profession && keep.profession !== "auto"
    ? keep.profession
    : rosterMatch?.[1] ?? family.defaultProfession;
  const weapon = keep.weapon && keep.weapon !== "auto"
    ? keep.weapon
    : rosterMatch?.[2] ?? family.defaultWeapon;
  const armor = keep.armor && keep.armor !== "auto"
    ? keep.armor
    : rosterMatch?.[3] ?? family.defaultArmor;
  const level = keep.level !== undefined && keep.level !== ""
    ? keep.level
    : Math.floor(rng() * 9) - 1;
  const title = rosterMatch?.[4] ?? family.label;
  return {
    ...keep,
    forgeSetting: "fantasy",
    technology: keep.technology ?? "fantasy",
    contentSource: keep.contentSource ?? "pf2e",
    creatureKind: family.kind,
    monsterFamily,
    ancestry: family.ancestry,
    gender: ["beast", "ooze", "construct", "undead"].includes(family.kind)
      ? "unspecified"
      : keep.gender ?? pick(["female", "male", "unspecified"], rng),
    profession,
    role,
    weapon,
    armor,
    level,
    name: keep.name || `${family.label} — ${title}`,
    prompt: `${family.description} ${family.motive}.`,
    complexity: keep.complexity ?? (role === "leader" || role === "caster" ? "tactical" : "standard"),
    quality: keep.quality ?? (rng() < 0.16 ? "elite" : "standard"),
    batchMode: keep.batchMode ?? "encounter",
    randomized: true,
    randomSeed: String(seed),
    seedPersonality: String(deriveSeed(seed, "personality")),
    seedAbilities: String(deriveSeed(seed, "abilities")),
    seedSpells: String(deriveSeed(seed, "spells")),
    seedConsumables: String(deriveSeed(seed, "consumables")),
    seedToken: String(deriveSeed(seed, "token")),
  };
}
