import { familyForConcept } from "./monsters.js";

export const ENCOUNTER_DIFFICULTIES = {
  none: { label: "Не рассчитывать", budget: 0, adjustment: 0 },
  trivial: { label: "Тривиальное", budget: 40, adjustment: 10 },
  low: { label: "Низкое", budget: 60, adjustment: 15 },
  moderate: { label: "Умеренное", budget: 80, adjustment: 20 },
  severe: { label: "Тяжёлое", budget: 120, adjustment: 30 },
  extreme: { label: "Экстремальное", budget: 160, adjustment: 40 },
};

const XP_BY_RELATIVE_LEVEL = new Map([
  [-4, 10],
  [-3, 15],
  [-2, 20],
  [-1, 30],
  [0, 40],
  [1, 60],
  [2, 80],
  [3, 120],
  [4, 160],
]);

export function creatureXp(creatureLevel, partyLevel) {
  const difference = Number(creatureLevel) - Number(partyLevel);
  if (difference < -4) return 0;
  if (difference > 4) return Infinity;
  return XP_BY_RELATIVE_LEVEL.get(difference) ?? 0;
}

export function adjustedEncounterBudget(difficulty, partySize = 4) {
  const row = ENCOUNTER_DIFFICULTIES[difficulty] ?? ENCOUNTER_DIFFICULTIES.none;
  if (difficulty === "none") return 0;
  const size = Math.max(1, Math.min(8, Number(partySize) || 4));
  return Math.max(row.adjustment, row.budget + (size - 4) * row.adjustment);
}

function encounterMemberLevels(concept) {
  const count = Math.max(1, Math.min(20, Number(concept.count) || 1));
  const family = familyForConcept(concept);
  return Array.from({ length: count }, (_, index) => {
    if (concept.batchMode !== "encounter" || !family?.roster?.length) {
      const eliteOffset = concept.quality === "elite" ? (concept.level <= 0 ? 2 : 1) : 0;
      return Math.min(20, concept.level + eliteOffset);
    }
    const [role] = family.roster[index % family.roster.length];
    const isRosterLeader = index % family.roster.length === family.roster.length - 1 && role === "leader";
    const roleLevel = Math.min(20, concept.level + (isRosterLeader ? 1 : 0));
    const eliteOffset = isRosterLeader && concept.quality === "elite" ? (roleLevel <= 0 ? 2 : 1) : 0;
    return Math.min(20, roleLevel + eliteOffset);
  });
}

function difficultyForXp(xp, budget) {
  if (!Number.isFinite(xp)) return "выше допустимого диапазона";
  if (budget <= 0) return "не рассчитана";
  const ratio = xp / budget;
  if (ratio < 0.55) return "значительно легче цели";
  if (ratio < 0.85) return "немного легче цели";
  if (ratio <= 1.15) return "соответствует цели";
  if (ratio <= 1.45) return "немного тяжелее цели";
  return "значительно тяжелее цели";
}

export function encounterPlan(concept) {
  const difficulty = concept.encounterDifficulty ?? "none";
  if (difficulty === "none") return null;
  const partyLevel = Math.max(1, Math.min(20, Number(concept.partyLevel) || Math.max(1, concept.level)));
  const partySize = Math.max(1, Math.min(8, Number(concept.partySize) || 4));
  const budget = adjustedEncounterBudget(difficulty, partySize);
  const levels = encounterMemberLevels(concept);
  const memberXp = levels.map((level) => creatureXp(level, partyLevel));
  const xp = memberXp.some((value) => !Number.isFinite(value))
    ? Infinity
    : memberXp.reduce((sum, value) => sum + value, 0);
  const target = ENCOUNTER_DIFFICULTIES[difficulty];
  const baseCreatureXp = creatureXp(concept.level, partyLevel);
  const recommendedCount = !Number.isFinite(baseCreatureXp) || baseCreatureXp <= 0
    ? null
    : Math.max(1, Math.min(20, Math.round(budget / baseCreatureXp)));
  const warnings = [];
  if (!Number.isFinite(xp)) {
    warnings.push("Хотя бы одно существо более чем на 4 уровня выше группы: такое столкновение выходит за стандартную таблицу бюджета.");
  }
  if (memberXp.every((value) => value === 0)) {
    warnings.push("Все существа более чем на 4 уровня ниже группы и почти не влияют на стандартный бюджет опыта.");
  }
  return {
    difficulty,
    difficultyLabel: target.label,
    partyLevel,
    partySize,
    budget,
    xp,
    status: difficultyForXp(xp, budget),
    recommendedCount,
    memberLevels: levels,
    warnings,
  };
}
