from pathlib import Path
import re
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
CSS = (ROOT / "styles" / "forge.css").read_text(encoding="utf-8")
BODY = (ROOT / "templates" / "generator.hbs").read_text(encoding="utf-8")
FOOTER = (ROOT / "templates" / "forge-footer.hbs").read_text(encoding="utf-8")

# Для теста геометрии оставляем по одному представителю каждого Handlebars-цикла.
def fixture_markup(source: str) -> str:
    source = re.sub(r"{{[#/]\s*(?:each|if|unless|with)[^}]*}}", "", source)
    source = re.sub(r"{{else}}", "", source)
    source = re.sub(r"{{{[^}]+}}}", "Тест", source)
    source = re.sub(r"{{[^}]+}}", "Тест", source)
    return source

body = fixture_markup(BODY)
footer = fixture_markup(FOOTER)
html = f"""<!doctype html>
<html lang='ru'>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<style>
html, body {{ width: 100%; height: 100%; margin: 0; overflow: hidden; background: #1d1d22; color: #ddd; font: 14px Arial, sans-serif; }}
button, input, select, textarea {{ font: inherit; }}
button {{ border: 1px solid #777; border-radius: 4px; background: #29272d; color: #eee; padding: .3rem .45rem; }}
input, select, textarea {{ box-sizing: border-box; background: #302c34; border: 1px solid #777; color: #eee; min-height: 2rem; }}
#forge-window {{ position: fixed; inset: 8px; display: grid; grid-template-rows: 34px minmax(0, 1fr); border: 1px solid #777; border-radius: 7px; overflow: hidden; background: #17171b; }}
.window-header {{ display: flex; align-items: center; padding: 0 .65rem; border-bottom: 1px solid #777; font-weight: 700; }}
.pf2e-npc-forge-content {{ height: 100%; }}
{CSS}
</style>
</head>
<body>
<form id='forge-window' class='pf2e-npc-forge-application' aria-busy='false'>
  <header class='window-header'>Кузница персонажей мастера PF2e</header>
  <div class='pf2e-npc-forge-content'>{body}{footer}</div>
</form>
<script>document.querySelector('form').addEventListener('submit', event => event.preventDefault());</script>
</body>
</html>"""

viewports = [
    (1920, 1080),
    (1366, 768),
    (1024, 600),
    (768, 1024),
    (480, 800),
    (360, 640),
    (320, 568),
]

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path="/usr/bin/chromium", args=["--no-sandbox"])
    page = browser.new_page()
    for width, height in viewports:
        page.set_viewport_size({"width": width, "height": height})
        page.set_content(html, wait_until="load")
        window = page.locator("#forge-window")
        main = page.locator(".forge-app-body")
        footer_loc = page.locator(".forge-app-footer")
        submit = page.locator("[data-forge-submit]")
        group_options = page.locator("[data-forge-group-options]")
        spell_options = page.locator("[data-forge-spell-options]")
        starfinder_panel = page.locator('[data-forge-setting-panel="starfinder"]')
        resize_grip = page.locator('[data-forge-resize-grip]')
        shared_build = page.locator('[data-forge-shared-build]')

        assert window.is_visible(), f"Окно не видно при {width}x{height}"
        assert main.is_visible(), f"Основная область не видна при {width}x{height}"
        assert footer_loc.is_visible(), f"Footer не виден при {width}x{height}"
        assert submit.is_visible(), f"Кнопка создания не видна при {width}x{height}"
        assert group_options.is_hidden(), f"Групповые настройки видны для одного NPC при {width}x{height}"
        assert spell_options.is_hidden(), f"Настройки магии видны без включённых заклинаний при {width}x{height}"
        assert starfinder_panel.is_hidden(), f"Starfinder-заготовки смешались с фэнтези при {width}x{height}"
        assert resize_grip.is_visible(), f"Ручка изменения размера не видна при {width}x{height}"
        assert shared_build.is_visible(), f"Общие параметры не видны в быстрой сборке при {width}x{height}"
        assert page.locator('[name="creatureKind"]').count() == 1, "Тип существа продублирован вместо общего поля"
        assert page.locator('[name="ancestry"]').count() == 1, "Раса продублирована вместо общего поля"
        assert "resize" in resize_grip.evaluate("el => getComputedStyle(el).cursor"), "У resize-ручки нет корректного курсора"

        page.locator('.pf2e-npc-forge').evaluate("el => el.dataset.mode = 'constructor'")
        assert shared_build.is_visible(), f"Общие параметры исчезли в точной настройке при {width}x{height}"
        assert page.locator('.forge-shared-sync-note').is_visible(), f"Нет пояснения единой сборки при {width}x{height}"
        page.locator('.pf2e-npc-forge').evaluate("el => el.dataset.mode = 'quick'")

        tones = main.evaluate("""el => {
          const style = getComputedStyle(el);
          return ["assault", "defense", "support", "magic", "specialist", "civilian", "monster"]
            .map(name => style.getPropertyValue(`--forge-${name}`).trim());
        }""")
        assert len(set(tones)) == 7 and all(tones), f"Категории не имеют разных смысловых цветов при {width}x{height}: {tones}"

        boxes = {name: loc.bounding_box() for name, loc in {
            "window": window, "main": main, "footer": footer_loc, "submit": submit
        }.items()}
        for name, box in boxes.items():
            assert box is not None, f"Нет геометрии {name} при {width}x{height}"
            assert box["x"] >= -1 and box["y"] >= -1, f"{name} ушёл за верх/лево при {width}x{height}: {box}"
            assert box["x"] + box["width"] <= width + 1, f"{name} ушёл вправо при {width}x{height}: {box}"
            assert box["y"] + box["height"] <= height + 1, f"{name} ушёл вниз при {width}x{height}: {box}"

        metrics = main.evaluate("el => ({clientHeight: el.clientHeight, scrollHeight: el.scrollHeight, clientWidth: el.clientWidth, scrollWidth: el.scrollWidth, overflowY: getComputedStyle(el).overflowY})")
        assert metrics["overflowY"] in ("auto", "scroll"), f"Нет вертикального scroll при {width}x{height}: {metrics}"
        assert metrics["scrollHeight"] > metrics["clientHeight"], f"Длинная форма не прокручивается при {width}x{height}: {metrics}"
        assert metrics["scrollWidth"] <= metrics["clientWidth"] + 2, f"Есть горизонтальный overflow при {width}x{height}: {metrics}"

        footer_y_before = boxes["footer"]["y"]
        main.evaluate("el => { el.scrollTop = el.scrollHeight; }")
        page.wait_for_timeout(20)
        footer_y_after = footer_loc.bounding_box()["y"]
        assert abs(footer_y_before - footer_y_after) < 1, f"Footer прокручивается вместе с формой при {width}x{height}"
        assert submit.is_visible(), f"Кнопка исчезла после прокрутки при {width}x{height}"

        page_doc = page.evaluate("() => ({sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, sh: document.documentElement.scrollHeight, ch: document.documentElement.clientHeight})")
        assert page_doc["sw"] <= page_doc["cw"] + 1, f"Страница получила горизонтальную прокрутку при {width}x{height}: {page_doc}"
        assert page_doc["sh"] <= page_doc["ch"] + 1, f"Прокручивается вся страница вместо центральной области при {width}x{height}: {page_doc}"

        submit.click()
    browser.close()

print("Браузерная геометрия пройдена для 1920x1080, 1366x768, 1024x600, 768x1024, 480x800, 360x640 и 320x568.")
