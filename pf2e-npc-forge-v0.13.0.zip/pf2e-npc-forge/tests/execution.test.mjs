import {
  buildExecutionPlan,
  normalizeExecutionControls,
} from "../scripts/execution.js";

const normalized = normalizeExecutionControls({
  target: "new",
  count: 3,
  itemPolicy: "all",
  backupOriginal: true,
  deploymentMode: "none",
  addToCombat: true,
  sendChatSummary: false,
  confirmRiskyOperations: true,
  includeSkillActions: false,
  includeLootPlan: false,
});
if (
  normalized.concept.itemPolicy !== "generated" ||
  normalized.concept.backupOriginal !== false ||
  normalized.concept.addToCombat !== false
) {
  throw new Error("Зависимости безопасного запуска не были нормализованы.");
}
if (!normalized.corrections.some((value) => value.includes("Добавление в бой отключено"))) {
  throw new Error("Нормализация не объяснила отключение невозможной операции.");
}

const safe = buildExecutionPlan(
  {
    ...normalized.concept,
    randomAbilities: false,
    randomSpells: false,
    randomConsumables: false,
    randomToken: false,
    tokenImage: "",
    adventureMode: "off",
    createBriefing: false,
    sendChatSummary: false,
    openSheet: false,
  },
  { strikes: ["Удар"], actions: [], spells: [] },
  { available: false },
);
if (!safe.safeToRun || safe.requiresConfirmation) {
  throw new Error("Обычное создание новых NPC ошибочно признано рискованным.");
}
for (const key of ["skill-actions", "abilities", "spells", "consumables", "artwork", "journal", "deployment", "combat", "chat"]) {
  const entry = safe.operations.find((candidate) => candidate.key === key);
  if (!entry || entry.enabled) {
    throw new Error(`Отключённая операция ${key} отсутствует в плане или ошибочно включена.`);
  }
}

const destructive = buildExecutionPlan(
  {
    target: "selected",
    count: 1,
    itemPolicy: "all",
    backupOriginal: false,
    includeSkillActions: true,
    randomAbilities: true,
    randomSpells: true,
    randomConsumables: true,
    randomToken: false,
    tokenImage: "",
    adventureMode: "off",
    includeLootPlan: false,
    createBriefing: false,
    deploymentMode: "none",
    addToCombat: false,
    sendChatSummary: false,
    confirmRiskyOperations: true,
    openSheet: true,
  },
  { strikes: ["Удар"], actions: ["Способность"], spells: [] },
  { available: true, actorName: "Тестовый NPC" },
);
if (!destructive.safeToRun || !destructive.requiresConfirmation) {
  throw new Error("Перестройка существующего NPC не потребовала подтверждения.");
}
if (!destructive.warnings.some((value) => value.includes("Резервная копия отключена"))) {
  throw new Error("План не предупредил об отключённой резервной копии.");
}
if (!destructive.warnings.some((value) => value.includes("полной замены предметов"))) {
  throw new Error("План не предупредил об удалении ручных предметов.");
}

const missingSelection = buildExecutionPlan(
  { ...destructive.concept, target: "duplicate" },
  { strikes: [], actions: [], spells: [] },
  { available: false },
);
if (missingSelection.safeToRun || !missingSelection.blocking.length) {
  throw new Error("Создание копии без выбранного жетона не было заблокировано.");
}

console.log("План выполнения, зависимости настроек и подтверждение рисков проверены.");
