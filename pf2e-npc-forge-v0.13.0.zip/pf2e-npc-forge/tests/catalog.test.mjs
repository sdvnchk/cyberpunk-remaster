import {
  CATALOG_PACKS,
  catalogPackOrder,
  clearCatalogCaches,
  cloneCatalogDocument,
  supportedEmbeddedType,
} from "../scripts/catalog.js";

function pack(slug, { fail = false, type = "weapon" } = {}) {
  return {
    async getIndex() {
      return [{ _id: slug, name: slug, type, system: { slug } }];
    },
    async getDocument() {
      if (fail) throw new Error("Ошибка Babele на одном документе");
      return {
        toObject: () => ({
          _id: "source-id",
          _stats: { systemVersion: "8.3.0" },
          folder: "source-folder",
          ownership: { default: 0 },
          sort: 100,
          name: slug,
          type,
          flags: { babele: { translated: true }, retained: { value: true } },
          system: { slug, description: { gm: "", value: "" } },
        }),
      };
    },
  };
}

globalThis.game = {
  packs: new Map([
    [CATALOG_PACKS.equipment.sf2e, pack("laser-rifle", { fail: true })],
    [CATALOG_PACKS.equipment.pf2e, pack("laser-rifle")],
  ]),
};
clearCatalogCaches();
const order = catalogPackOrder("equipment", { technology: "starfinder", contentSource: "auto" });
if (order[0] !== CATALOG_PACKS.equipment.sf2e) {
  throw new Error("Технологический концепт не предпочитает SF2e.");
}
const fallback = await cloneCatalogDocument(
  "equipment",
  "laser-rifle",
  { technology: "starfinder", contentSource: "auto" },
  { allowedTypes: "weapon", required: true },
);
if (fallback._forgeSourcePack !== CATALOG_PACKS.equipment.pf2e) {
  throw new Error("Ошибка переводчика не вызвала переход к запасному компендиуму.");
}
if (fallback.flags?.babele || fallback._id || fallback._stats || fallback.folder || fallback.ownership) {
  throw new Error("Клон компендиума сохранил опасные служебные данные или флаги Babele.");
}
if (!fallback.flags?.retained?.value) throw new Error("Безопасные сторонние флаги были удалены без причины.");
if (supportedEmbeddedType("kit") || !supportedEmbeddedType("weapon")) {
  throw new Error("Фильтр типов встроенных предметов работает неверно.");
}
console.log("Единый каталог PF2e/SF2e и обход ошибок Babele проверены.");
