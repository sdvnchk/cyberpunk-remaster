import { execFileSync } from "node:child_process";
import { existsSync, readFileSync, readdirSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const moduleManifest = JSON.parse(readFileSync(join(root, "module.json"), "utf8"));
const packageManifest = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));

if (moduleManifest.id !== "pf2e-npc-forge") {
  throw new Error("Неверный id модуля в module.json.");
}
if (moduleManifest.type !== "module") {
  throw new Error("В module.json отсутствует обязательный тип пакета module.");
}
if (!Array.isArray(moduleManifest.media)) {
  throw new Error("В module.json отсутствует обязательный массив media для Foundry VTT 14.");
}
if (moduleManifest.persistentStorage !== true) {
  throw new Error("В module.json не включено persistentStorage для устойчивого runtime-отчёта.");
}
if (!moduleManifest.compatibility?.minimum || !moduleManifest.compatibility?.verified) {
  throw new Error("В module.json неполно описана совместимость с Foundry.");
}
if (!moduleManifest.relationships?.systems?.some((entry) => entry.id === "pf2e" && entry.type === "system")) {
  throw new Error("В module.json отсутствует корректная связь с системой pf2e.");
}
if (Object.hasOwn(moduleManifest, "system")) {
  throw new Error("В module.json осталось устаревшее поле system; используйте relationships.systems.");
}
if (moduleManifest.version !== packageManifest.version) {
  throw new Error("Версии module.json и package.json не совпадают.");
}
const generatorSource = readFileSync(join(root, "scripts/generator.js"), "utf8");
if (!generatorSource.includes(`const MODULE_VERSION = "${moduleManifest.version}"`)) {
  throw new Error("Версия генератора не совпадает с module.json.");
}
for (const relative of [
  ...(moduleManifest.esmodules ?? []),
  ...(moduleManifest.styles ?? []),
  moduleManifest.readme,
  moduleManifest.license,
  "templates/generator.hbs",
  "templates/forge-footer.hbs",
  "BESTIARY.md",
  "LIVE-SCHEMA.md",
  "USER-GUIDE.md",
  "TECHNICAL-AUDIT.md",
  "SESSION-AUDIT.md",
  "scripts/catalog.js",
  "scripts/deployment.js",
  "scripts/briefing.js",
  "scripts/automation.js",
  "scripts/director.js",
  "scripts/execution.js",
  "scripts/schema-guard.js",
  "scripts/session-auditor.js",
  "scripts/audit-reports.js",
  "storage/README.txt",
  "tests/fixtures/pf2e-8.3-choices.json",
]) {
  if (!relative || !existsSync(join(root, relative))) {
    throw new Error(`В релизе отсутствует файл: ${relative}`);
  }
}

const template = readFileSync(join(root, "templates/generator.hbs"), "utf8");
for (const marker of [
  "data-forge-random",
  "data-forge-random-monster",
  "name=\"monsterFamily\"",
  "value=\"encounter\"",
  "data-forge-diagnostics",
  "data-forge-session-audit",
  "data-forge-audit-save-last",
  "data-forge-audit-copy-last",
  "data-forge-history-restore",
  "data-forge-setting=\"fantasy\"",
  "data-forge-setting=\"starfinder\"",
  "forge-category-legend",
  "name=\"randomSpells\"",
  "data-forge-reroll-token",
  "name=\"technology\"",
  "name=\"contentSource\"",
  "name=\"deploymentMode\"",
  "name=\"createBriefing\"",
]) {
  if (!template.includes(marker)) throw new Error(`В интерфейсе отсутствует ${marker}.`);
}


const mainSource = readFileSync(join(root, "scripts/main.js"), "utf8");
if (/Hooks\.once\("ready"[\s\S]{0,500}createLauncherMacro/u.test(mainSource)) {
  throw new Error("Модуль снова создаёт глобальный макрос запуска без явного действия пользователя.");
}

for (const file of readdirSync(join(root, "scripts")).filter((name) => name.endsWith(".js"))) {
  execFileSync(process.execPath, ["--check", join(root, "scripts", file)], {
    stdio: "pipe",
  });
}

console.log(`Релиз ${moduleManifest.version}: манифест, файлы, интерфейс и синтаксис проверены.`);
