import {
  addRecentHistory,
  deleteCustomPreset,
  exportCustomPresets,
  getCustomPresets,
  getLastAuditReportMeta,
  getLastForm,
  getRecentHistory,
  importCustomPresets,
  registerForgeSettings,
  saveCustomPreset,
  setLastAuditReportMeta,
  setLastForm,
} from "../scripts/storage.js";

const MODULE_ID = "pf2e-npc-forge";
const registry = new Map();
const values = new Map();

globalThis.game = {
  settings: {
    register(namespace, key, config) {
      const id = `${namespace}.${key}`;
      registry.set(id, config);
      values.set(id, structuredClone(config.default));
    },
    get(namespace, key) {
      return structuredClone(values.get(`${namespace}.${key}`));
    },
    async set(namespace, key, value) {
      values.set(`${namespace}.${key}`, structuredClone(value));
      return value;
    },
  },
};

registerForgeSettings(MODULE_ID);
if (registry.size !== 4) {
  throw new Error("Скрытые настройки Кузницы зарегистрированы не полностью.");
}

await setLastForm(MODULE_ID, {
  prompt: "Стражник",
  target: "selected",
  count: 7,
  itemPolicy: "generated",
  backupOriginal: true,
  openSheet: false,
  deploymentMode: "wedge",
  addToCombat: true,
  createBriefing: true,
  sendChatSummary: true,
  confirmRiskyOperations: false,
});
const last = getLastForm(MODULE_ID);
if (
  last.target !== "new" ||
  last.count !== 7 ||
  last.openSheet !== false ||
  last.deploymentMode !== "none" ||
  last.addToCombat !== false ||
  last.createBriefing !== false ||
  last.sendChatSummary !== false ||
  last.confirmRiskyOperations !== true
) {
  throw new Error("Память формы не сбросила временные побочные действия в безопасное состояние.");
}

const presetId = await saveCustomPreset(MODULE_ID, "Мой стражник", {
  prompt: "Стражник с копьём",
  level: 3,
  target: "selected",
  deploymentMode: "ring",
  addToCombat: true,
  createBriefing: true,
  sendChatSummary: true,
});
const presetValues = getCustomPresets(MODULE_ID)[presetId]?.values ?? {};
if (
  presetValues.target !== undefined ||
  presetValues.level !== 3 ||
  presetValues.deploymentMode !== undefined ||
  presetValues.addToCombat !== undefined ||
  presetValues.createBriefing !== undefined ||
  presetValues.sendChatSummary !== undefined
) {
  throw new Error("Пользовательская заготовка сохранила цель или побочные действия операции.");
}

const exported = exportCustomPresets(MODULE_ID);
await deleteCustomPreset(MODULE_ID, presetId);
if (getCustomPresets(MODULE_ID)[presetId]) {
  throw new Error("Заготовка не удалилась.");
}
const imported = await importCustomPresets(MODULE_ID, JSON.stringify(exported));
if (imported !== 1 || Object.keys(getCustomPresets(MODULE_ID)).length !== 1) {
  throw new Error("Выгрузка и загрузка заготовок не прошли круговой тест.");
}

const concept = {
  name: "Стражник",
  level: 3,
  ancestry: "human",
  profession: "guard",
  role: "soldier",
};
for (let index = 0; index < 12; index += 1) {
  await addRecentHistory(MODULE_ID, concept, {
    actor: { uuid: `Actor.${index}` },
  });
}
if (
  getRecentHistory(MODULE_ID).length !== 10 ||
  getRecentHistory(MODULE_ID)[0].actorUuids[0] !== "Actor.11"
) {
  throw new Error("История не ограничилась десятью последними сборками.");
}

await setLastAuditReportMeta(MODULE_ID, { filename: "audit.json", bytes: 42 });
const auditMeta = getLastAuditReportMeta(MODULE_ID);
if (auditMeta.filename !== "audit.json" || auditMeta.bytes !== 42) {
  throw new Error("Метаданные последнего runtime-отчёта не прошли круговой тест.");
}

console.log("Память формы, свои заготовки, JSON, история и метаданные аудита проверены.");
