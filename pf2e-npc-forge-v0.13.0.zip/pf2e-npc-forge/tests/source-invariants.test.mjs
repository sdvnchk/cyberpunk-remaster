import { PROFESSIONS, ROLES } from "../scripts/blueprints.js";
import { MONSTER_FAMILIES, monsterFeaturePlan } from "../scripts/monsters.js";
import { randomContentPlan } from "../scripts/random-content.js";

const allowedCategories = new Set(["interaction", "defensive", "offensive", "familiar"]);
globalThis.CONFIG = {
  PF2E: {
    actionCategories: Object.fromEntries([...allowedCategories].map((key) => [key, key])),
  },
};

const context = { dc: 24, damage: "2d8+6" };
for (const role of Object.keys(ROLES)) {
  for (const profession of Object.keys(PROFESSIONS)) {
    for (let seed = 0; seed < 8; seed += 1) {
      const plan = randomContentPlan({
        name: "Проверка",
        level: 10,
        role,
        profession,
        complexity: "tactical",
        randomAbilities: true,
        randomSpells: false,
        randomConsumables: false,
        randomSeed: `source-${role}-${profession}-${seed}`,
        seedAbilities: `source-features-${role}-${profession}-${seed}`,
        elements: [],
        spellTheme: "auto",
        technology: "fantasy",
        contentSource: "pf2e",
      }, context);
      for (const feature of plan.features) {
        if (!allowedCategories.has(feature.category)) {
          throw new Error(`Сырая способность ${feature.name} сохранила невалидную категорию ${feature.category}.`);
        }
      }
    }
  }
}

for (const monsterFamily of Object.keys(MONSTER_FAMILIES)) {
  const features = monsterFeaturePlan({
    monsterFamily,
    complexity: "tactical",
    randomSeed: `family-${monsterFamily}`,
  }, context);
  for (const feature of features) {
    if (!allowedCategories.has(feature.category)) {
      throw new Error(`Семейство ${monsterFamily}: способность ${feature.name} сохранила категорию ${feature.category}.`);
    }
  }
}

console.log("Исходные способности всех ролей, профессий и семейств не содержат внутренних категорий PF2e.");

const randomContentSource = await import("node:fs").then(({ readFileSync }) =>
  readFileSync(new URL("../scripts/random-content.js", import.meta.url), "utf8"));
for (const legacySlug of [
  "freedom-of-movement", "meteor-swarm", "plane-shift", "resurrection",
  "shadow-walk", "shapechange", "sound-burst", "time-stop", "true-seeing",
  '"antidote"', '"antiplague"', "smokestick-lesser", "silversheen",
]) {
  if (randomContentSource.includes(legacySlug)) {
    throw new Error(`В пуле случайного контента остался отсутствующий в живом PF2e 8.3.0 slug: ${legacySlug}.`);
  }
}
for (const currentSlug of [
  "unfettered-movement", "falling-stars", "interplanar-teleport", "resurrect",
  "shadow-jump", "metamorphosis", "noise-blast", "freeze-time", "truesight",
  "antidote-lesser", "antiplague-lesser", "smoke-ball-lesser", "silver-salve",
]) {
  if (!randomContentSource.includes(currentSlug)) {
    throw new Error(`В пуле случайного контента отсутствует актуальный slug: ${currentSlug}.`);
  }
}
console.log("Пулы заклинаний и расходников используют актуальные slug живого PF2e 8.3.0.");

const directorSource = await import("node:fs").then(({ readFileSync }) =>
  readFileSync(new URL("../scripts/director.js", import.meta.url), "utf8"));
for (const lootSlug of [
  "silver-pieces", "gold-pieces", "agate", "silver-statuette-of-a-raven",
  "illustrated-book", "engraved-copper-ring", "healing-potion-lesser",
  "antidote-lesser", "smoke-ball-lesser", "battery-commercial", "data-chip",
  "battery-tactical", "medpatch-commercial", "frag-grenade-commercial",
  "smoke-grenade-commercial",
]) {
  if (!directorSource.includes(`slug: "${lootSlug}"`)) {
    throw new Error(`В физическом плане добычи отсутствует проверенный slug ${lootSlug}.`);
  }
}
console.log("Физические наборы добычи используют проверенные slug PF2e/SF2e.");
