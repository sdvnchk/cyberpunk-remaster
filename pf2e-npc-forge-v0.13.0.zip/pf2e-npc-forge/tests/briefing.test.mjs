import { buildEncounterBriefing, createEncounterBriefing } from "../scripts/briefing.js";

const results = [
  {
    actor: { uuid: "Actor.one", name: "Вожак" },
    intelligence: {
      personality: { speech: "говорит короткими приказами" },
      tactics: {
        opening: "занимает центр строя",
        routine: "отдаёт приказ и атакует",
        bloodied: "прикрывает отход",
        retreat: "уходит с последним бойцом",
      },
    },
  },
  {
    actor: { uuid: "Actor.two", name: "Стрелок" },
    intelligence: {
      tactics: {
        opening: "ищет укрытие",
        routine: "стреляет по уязвимой цели",
        bloodied: "меняет позицию",
        retreat: "отступает к вожаку",
      },
    },
  },
];
const concept = {
  name: "Патруль",
  level: 4,
  count: 2,
  batchMode: "squad",
  randomSeed: "briefing-test",
  createBriefing: true,
};
const plan = buildEncounterBriefing(results, concept);
if (!plan.content.includes("@UUID[Actor.one]") || !plan.content.includes("Мирное решение")) {
  throw new Error("Мастерская сводка не содержит участников или небоевой путь.");
}
globalThis.JournalEntry = {
  async create(data) {
    return { ...data, id: "journal-1", uuid: "JournalEntry.journal-1" };
  },
};
const created = await createEncounterBriefing(results, concept);
if (!created.journal || !created.journal.pages?.[0]?.text?.content.includes("Осложнение")) {
  throw new Error("Сводка не была сохранена как JournalEntry V14.");
}
console.log("Мастерская сводка столкновения и журнал проверены.");
