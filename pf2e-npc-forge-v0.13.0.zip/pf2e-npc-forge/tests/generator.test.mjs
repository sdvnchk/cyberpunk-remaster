import { readFileSync } from "node:fs";
import {
  generateNpc,
  generateNpcBatch,
  restoreFromHistoryEntry,
  normalizeActionCategory,
  getPreview,
  selectedNpcInfo,
} from "../scripts/generator.js";
import { parseConcept } from "../scripts/parser.js";
import { randomSpellPlan } from "../scripts/random-content.js";
import { BUILTIN_PRESETS, completePresetValues } from "../scripts/presets.js";

const weaponSlugs = new Set([
  "crossbow",
  "dagger",
  "greataxe",
  "greatsword",
  "halberd",
  "longsword",
  "shortbow",
  "shortsword",
  "spear",
  "staff",
  "arquebus",
  "dueling-pistol",
  "dogslicer",
  "sling",
  "javelin",
  "flail",
  "morningstar",
  "maul",
]);
const armorSlugs = new Set([
  "breastplate",
  "full-plate",
  "studded-leather-armor",
]);
const consumableSlugs = new Set([
  "healing-potion-minor",
  "healing-potion-lesser",
  "healing-potion-moderate",
  "healing-potion-greater",
  "healing-potion-major",
  "elixir-of-life-minor",
  "elixir-of-life-lesser",
  "elixir-of-life-moderate",
  "elixir-of-life-greater",
  "elixir-of-life-major",
  "antidote-lesser",
  "antiplague-lesser",
  "smoke-ball-lesser",
  "silver-salve",
  "alchemists-fire-lesser",
  "acid-flask-lesser",
  "bottled-lightning-lesser",
  "frost-vial-lesser",
]);
const spellSlugs = new Set();

const sfWeaponSlugs = new Set([
  "laser-pistol", "laser-rifle", "arc-rifle", "plasma-caster",
  "scattergun", "semi-auto-pistol", "plasma-sword", "shock-truncheon",
]);
const sfAmmoSlugs = new Set(["battery-commercial", "projectile-ammo"]);
const sfGearSlugs = new Set([
  "comm-unit", "medpatch-commercial", "medkit-commercial",
  "repair-toolkit-commercial", "makers-toolkit-commercial",
  "hacking-toolkit-commercial", "infiltrators-toolkit-commercial", "data-chip",
  "hypopen-commercial", "sprayflesh", "frag-grenade-commercial",
  "smoke-grenade-commercial", "flash-grenade-commercial",
  "electromag-grenade-commercial", "incendiary-grenade-commercial",
  "flashlight-commercial", "filtered-rebreather-commercial", "datapad",
  "fire-extinguisher-commercial", "field-scientists-toolkit-commercial",
  "holoskin-commercial", "climbing-kit-commercial",
]);
const sfSpellSlugs = new Set();

function sourceFor(slug, packId) {
  if (packId === "pf2e.spells-srd" || packId === "sf2e-anachronism.spells") {
    return {
      name: slug,
      type: "spell",
      system: {
        description: { value: "<p>Проверочное заклинание.</p>" },
        level: { value: 1 },
        location: { value: null },
        rules: [],
        slug,
        traits: { value: ["magical"] },
      },
    };
  }
  if (packId === "pf2e.actionspf2e") {
    return {
      name: slug,
      type: "action",
      system: {
        actionType: { value: "action" },
        actions: { value: 1 },
        category: "interaction",
        description: { value: "<p>Проверочное стандартное действие.</p>" },
        publication: {},
        rules: [],
        slug,
        traits: { value: [] },
      },
    };
  }
  if (packId === "sf2e-anachronism.equipment") {
    const type = sfWeaponSlugs.has(slug)
      ? "weapon"
      : sfAmmoSlugs.has(slug)
        ? "ammo"
        : slug.includes("grenade") || slug.includes("medpatch") || slug.includes("hypopen") || slug === "sprayflesh"
          ? "consumable"
          : "equipment";
    return {
      name: slug,
      type,
      system: {
        description: { gm: "", value: "<p>Проверочный документ SF2e.</p>" },
        slug,
        quantity: 1,
        equipped: {},
        usage: { value: sfWeaponSlugs.has(slug) && !["laser-pistol", "semi-auto-pistol", "shock-truncheon"].includes(slug) ? "held-in-two-hands" : "held-in-one-hand" },
        traits: { value: slug === "hypopen-commercial" ? ["nanite"] : ["tech"], rarity: "common" },
        rules: slug === "hypopen-commercial" ? [{ key: "Note", selector: "medicine", text: "Проверочная заметка SF2e" }] : [],
        damage: sfWeaponSlugs.has(slug) ? { dice: 1, die: "d8", damageType: "fire" } : undefined,
        range: sfWeaponSlugs.has(slug) ? 100 : undefined,
        reload: sfWeaponSlugs.has(slug) ? { value: "1" } : undefined,
        ammunition: sfWeaponSlugs.has(slug) ? { baseType: "battery", builtIn: false, capacity: 1 } : undefined,
        runes: { potency: 0, property: [], striking: 0 },
      },
    };
  }
  const type = armorSlugs.has(slug)
    ? "armor"
    : weaponSlugs.has(slug)
      ? "weapon"
      : slug === "steel-shield"
        ? "shield"
        : consumableSlugs.has(slug)
          ? "consumable"
          : slug === "backpack"
            ? "kit"
            : "equipment";
  return {
    name: slug,
    type,
    system: {
      description: { value: "" },
      equipped: {},
      rules: ["frost-vial-lesser", "bottled-lightning-lesser"].includes(slug)
        ? [{ key: "Note", selector: "attack-roll", text: "Проверочная алхимическая заметка" }]
        : [],
      traits: { value: [] },
      runes:
        type === "armor"
          ? { potency: 0, property: [], resilient: 0 }
          : { potency: 0, property: [], striking: 0 },
      slug,
    },
  };
}

function fakePack(packId) {
  const slugs =
    packId === "pf2e.spells-srd"
      ? [...spellSlugs]
      : packId === "sf2e-anachronism.spells"
        ? [...sfSpellSlugs]
        : packId === "sf2e-anachronism.equipment"
          ? [...sfWeaponSlugs, ...sfAmmoSlugs, ...sfGearSlugs]
      : packId === "pf2e.actionspf2e"
        ? [
          "administer-first-aid",
          "aid",
          "demoralize",
          "grapple",
          "hide",
          "make-an-impression",
          "recall-knowledge",
          "seek",
          "sense-motive",
          "shove",
          "sneak",
          "track",
          "treat-wounds",
        ]
        : [
          ...weaponSlugs,
          ...armorSlugs,
          "alchemists-toolkit",
          "backpack",
          "bedroll",
          "healers-toolkit",
          "religious-symbol-wooden",
          "rope",
          "scholarly-journal",
          "steel-shield",
          "thieves-toolkit",
          "medics-armband",
          "yarrow-root-bandage",
          "soap",
          "waterskin",
          "holy-water",
          "book-of-warding-prayers",
          "formula-book-blank",
          "spellbook-blank",
          "writing-set",
          "chalk",
          "compass",
          "climbing-kit",
          "grappling-hook",
          "lantern-hooded",
          "rations",
          "signal-whistle",
          "magnifying-glass",
          "crowbar",
          "basic-crafters-book",
          ...consumableSlugs,
        ];
  return {
    async getIndex() {
      const current = packId === "pf2e.spells-srd"
        ? [...spellSlugs]
        : packId === "sf2e-anachronism.spells"
          ? [...sfSpellSlugs]
          : slugs;
      return current.map((slug) => ({ _id: slug, system: { slug } }));
    },
    async getDocument(id) {
      return { toObject: () => structuredClone(sourceFor(id, packId)) };
    },
  };
}

const schemaChoices = JSON.parse(
  readFileSync(new URL("./fixtures/pf2e-8.3-choices.json", import.meta.url), "utf8"),
);
globalThis.CONFIG = {
  PF2E: Object.fromEntries(
    Object.entries(schemaChoices).map(([key, values]) => [
      key,
      Object.fromEntries(values.map((value) => [value, value])),
    ]),
  ),
};

class MockActor {
  constructor(data) {
    this.id = crypto.randomUUID();
    this.uuid = `Actor.${this.id}`;
    this.name = data.name;
    this.type = data.type;
    this.system = structuredClone(data.system);
    this.flags = structuredClone(data.flags ?? {});
    this.img = data.img ?? "icons/svg/mystery-man.svg";
    this.prototypeToken = structuredClone(data.prototypeToken ?? {});
    this.items = (data.items ?? []).map((item) => ({
      ...structuredClone(item),
      id: item.id ?? item._id ?? crypto.randomUUID(),
    }));
    this.sheet = { render: () => undefined };
  }

  async update(data) {
    this.name = data.name ?? this.name;
    this.system = data.system ? structuredClone(data.system) : this.system;
    this.img = data.img ?? this.img;
    this.prototypeToken = data.prototypeToken
      ? structuredClone(data.prototypeToken)
      : this.prototypeToken;
    const forgeFlag = data["flags.pf2e-npc-forge"];
    if (forgeFlag !== undefined) {
      this.flags["pf2e-npc-forge"] = structuredClone(forgeFlag);
    }
  }

  async createEmbeddedDocuments(_type, items) {
    const validActionCategories = new Set(schemaChoices.actionCategories);
    const validActionTypes = new Set(schemaChoices.actionTypes);
    const validActionCounts = new Set(schemaChoices.actionsNumber.map(Number));
    const validActionTraits = new Set(schemaChoices.actionTraits);
    const validAttackTraits = new Set(schemaChoices.npcAttackTraits);
    const validDamageTypes = new Set(schemaChoices.damageTypes);
    const validDamageCategories = new Set(schemaChoices.damageCategories);
    const validTraditions = new Set(schemaChoices.magicTraditions);
    for (const item of items) {
      if (item.type === "action") {
        if (!validActionCategories.has(item.system?.category)) throw new Error(`Невалидная категория PF2e action: ${item.system?.category}`);
        if (!validActionTypes.has(item.system?.actionType?.value)) throw new Error(`Невалидный тип PF2e action: ${item.system?.actionType?.value}`);
        if (item.system?.actionType?.value === "action" && !validActionCounts.has(item.system?.actions?.value)) throw new Error(`Невалидная стоимость PF2e action: ${item.system?.actions?.value}`);
        if (item.system?.actionType?.value !== "action" && item.system?.actions?.value !== null) throw new Error("Не-action документ сохранил стоимость действий.");
        for (const trait of item.system?.traits?.value ?? []) {
          if (!validActionTraits.has(trait)) throw new Error(`Невалидный action trait: ${trait}`);
        }
      }
      if (item.type === "melee") {
        if (item.system?.action !== "strike") throw new Error(`Невалидное поле melee.action: ${item.system?.action}`);
        for (const trait of item.system?.traits?.value ?? []) {
          if (!validAttackTraits.has(trait)) throw new Error(`Невалидный npcAttack trait: ${trait}`);
        }
        for (const roll of Object.values(item.system?.damageRolls ?? {})) {
          if (!validDamageTypes.has(roll.damageType)) throw new Error(`Невалидный тип урона melee: ${roll.damageType}`);
          if (roll.category !== null && !validDamageCategories.has(roll.category)) throw new Error(`Невалидная категория урона melee: ${roll.category}`);
        }
      }
      if (item.type === "spellcastingEntry") {
        if (!validTraditions.has(item.system?.tradition?.value)) throw new Error(`Невалидная традиция: ${item.system?.tradition?.value}`);
        if (!["prepared", "spontaneous", "innate", "focus", "items"].includes(item.system?.prepared?.value)) throw new Error(`Невалидная подготовка: ${item.system?.prepared?.value}`);
        if (!["str", "dex", "con", "int", "wis", "cha"].includes(item.system?.ability?.value)) throw new Error(`Невалидная характеристика магии: ${item.system?.ability?.value}`);
      }
    }
    if (items.some((item) => item.type === "kit")) {
      throw new Error("Предметы типа kit нельзя добавить к NPC");
    }
    if (this.failNextCreate) {
      this.failNextCreate = false;
      this.items.push({
        ...structuredClone(items[0]),
        id: crypto.randomUUID(),
      });
      throw new Error("Искусственная ошибка создания предметов");
    }
    const created = items.map((item) => ({
        ...item,
        id: crypto.randomUUID(),
      }));
    this.items.push(...created);
    return created;
  }

  async updateEmbeddedDocuments(_type, updates) {
    for (const update of updates) {
      const item = this.items.find((candidate) => candidate.id === update._id);
      if (!item) continue;
      if (update["system.slots"] !== undefined) {
        item.system.slots = structuredClone(update["system.slots"]);
      }
      for (const [key, value] of Object.entries(update)) {
        if (key === "_id" || key === "system.slots") continue;
        item[key] = structuredClone(value);
      }
    }
    return updates.map((update) => this.items.find((item) => item.id === update._id)).filter(Boolean);
  }

  async deleteEmbeddedDocuments(_type, ids) {
    this.items = this.items.filter((item) => !ids.includes(item.id));
  }

  toObject() {
    return {
      _id: this.id,
      name: this.name,
      type: this.type,
      system: structuredClone(this.system),
      flags: structuredClone(this.flags),
      img: this.img,
      prototypeToken: structuredClone(this.prototypeToken),
      items: structuredClone(this.items),
    };
  }

  async delete() {
    const index = actors.indexOf(this);
    if (index >= 0) actors.splice(index, 1);
  }
}

const actors = [];
globalThis.game = {
  system: { id: "pf2e" },
  user: { isGM: true },
  actors: {
    get: (id) => actors.find((actor) => actor.id === id),
  },
  folders: [],
  packs: new Map([
    ["pf2e.actionspf2e", fakePack("pf2e.actionspf2e")],
    ["pf2e.equipment-srd", fakePack("pf2e.equipment-srd")],
    ["pf2e.spells-srd", fakePack("pf2e.spells-srd")],
    ["sf2e-anachronism.equipment", fakePack("sf2e-anachronism.equipment")],
    ["sf2e-anachronism.spells", fakePack("sf2e-anachronism.spells")],
  ]),
};
globalThis.Folder = {
  async create(data) {
    const folder = { ...data, id: crypto.randomUUID() };
    game.folders.push(folder);
    return folder;
  },
};
globalThis.Actor = {
  async create(data) {
    const actor = new MockActor(data);
    actors.push(actor);
    return actor;
  },
};
globalThis.canvas = { tokens: { controlled: [] } };
globalThis.fromUuid = async (uuid) =>
  actors.find((actor) => actor.uuid === uuid) ?? null;

// Новый NPC и быстрые пресеты не должны даже читать выделенный игровой
// character: это защищает от ленивых обходов embedded items сторонними
// переводчиками вроде Babele.
let selectedActorLookupCount = 0;
const originalActorGet = game.actors.get;
game.actors.get = () => {
  selectedActorLookupCount += 1;
  throw new Error("Новый NPC попытался прочитать выделенного character");
};
canvas.tokens.controlled = [{
  document: {
    actorId: "player-character",
    actorLink: true,
    baseActor: null,
  },
  get actor() {
    throw new Error("Кузница обратилась к token.actor игрового персонажа");
  },
}];
const isolatedPreview = getPreview(parseConcept({
  prompt: "Обычный стражник 2 уровня",
  name: "Изолированный стражник",
  level: 2,
  ancestry: "human",
  gender: "unspecified",
  profession: "guard",
  role: "soldier",
  armor: "medium",
  weapon: "spear",
  quality: "standard",
  target: "new",
  randomAbilities: false,
  randomSpells: false,
  randomConsumables: false,
}));
if (selectedActorLookupCount !== 0 || isolatedPreview.selected.available) {
  throw new Error("Предпросмотр нового NPC не изолирован от выделенного character.");
}
game.actors.get = originalActorGet;
const foreignActor = { id: "foreign", name: "Игровой персонаж", type: "character" };
canvas.tokens.controlled = [{
  document: { actorId: foreignActor.id, actorLink: true, baseActor: foreignActor },
  get actor() {
    throw new Error("Проверка NPC не должна читать token.actor игрового персонажа");
  },
}];
if (selectedNpcInfo().available) {
  throw new Error("Игровой character ошибочно принят за NPC Кузницы.");
}
canvas.tokens.controlled = [];

const prompts = [
  "Тифлинг женщина 5 уровень, врач, лёгкий доспех, кинжал, огонь",
  "Орк мужчина 3 уровень, элитный рыцарь, тяжёлый доспех, меч и щит",
  "Кицунэ маг 12 уровень, вода и огонь, посох, без доспеха",
];

const promptConcepts = prompts.map((prompt) => ({
  prompt,
  concept: parseConcept({
    prompt,
    ancestry: "auto",
    gender: "auto",
    profession: "auto",
    role: "auto",
    armor: "auto",
    weapon: "auto",
    quality: "auto",
    target: "new",
  }),
}));
for (const { concept } of promptConcepts) {
  for (const spell of randomSpellPlan(concept)?.spells ?? []) {
    (spell.source === "sf2e" ? sfSpellSlugs : spellSlugs).add(spell.slug);
  }
}

for (const { prompt, concept } of promptConcepts) {
  const result = await generateNpc(concept);
  if (!result.actor.items.some((item) => item.type === "melee")) {
    throw new Error("Не создан рабочий удар.");
  }
  if (
    result.actor.items.some(
      (item) => item.type === "melee" && "attack" in item.system,
    )
  ) {
    throw new Error("Удар содержит поле, отсутствующее в схеме melee PF2e.");
  }
  if (!result.actor.items.some((item) => item.flags?.["pf2e-npc-forge"])) {
    throw new Error("На предметах нет метки генератора.");
  }
  if (
    /огонь|вода/u.test(prompt) &&
    !result.actor.items.some(
      (item) =>
        item.flags?.["pf2e-npc-forge"]?.kind === "save-ability" &&
        item.system.description.value.includes("@Check[") &&
        item.system.description.value.includes("@Damage["),
    )
  ) {
    throw new Error("Стихийная способность не получила рабочие ссылки бросков.");
  }
  if (
    concept.level === 5 &&
    !result.actor.items.some(
      (item) =>
        item.flags?.["pf2e-npc-forge"]?.kind === "save-ability" &&
        item.system.description.value.includes("@Damage[2d10["),
    )
  ) {
    throw new Error("Площадная способность не использует таблицу площадного урона.");
  }
  if (concept.profession === "doctor") {
    const medical = result.actor.items.find(
      (item) => item.system?.slug === "forge-working-medicine-procedures",
    );
    const skillPanel = result.actor.items.find(
      (item) => item.system?.slug === "forge-working-skill-checks",
    );
    const steadyHand = result.actor.items.find(
      (item) => item.system?.slug === "forge-steady-hand",
    );
    if (!medical || !skillPanel) {
      throw new Error("Лекарь не получил рабочие кнопки Медицины.");
    }
    if (
      !medical.system.description.value.includes("@Check[medicine|dc:15") ||
      !medical.system.description.value.includes("2d8+10") ||
      !skillPanel.system.description.value.includes("Медицина +")
    ) {
      throw new Error("Кнопка Медицины не использует модификатор Actor и таблицу Лечить раны.");
    }
    if (!steadyHand?.system?.rules?.some(
      (rule) => rule.key === "FlatModifier" && rule.selector === "medicine",
    )) {
      throw new Error("Роль лекаря не получила рабочий FlatModifier Медицины.");
    }
    const treatWounds = result.actor.items.find(
      (item) => item.flags?.["pf2e-npc-forge"]?.sourceSlug === "treat-wounds",
    );
    if (!treatWounds?.system?.description?.value?.includes("@Check[medicine|dc:15")) {
      throw new Error("Стандартное действие Лечить раны осталось декоративной справкой без броска Actor.");
    }
  }
  if (concept.profession === "mage") {
    if (!result.actor.items.some((item) => item.type === "spellcastingEntry")) {
      throw new Error("Маг не получил запись заклинателя.");
    }
    const entry = result.actor.items.find((item) => item.type === "spellcastingEntry");
    const spells = result.actor.items.filter((item) => item.type === "spell");
    if (!spells.length) {
      throw new Error("Маг не получил реальные документы заклинаний.");
    }
    if (!spells.every((spell) => spell.system.location?.value === entry.id)) {
      throw new Error("Заклинания не связаны с записью заклинателя через system.location.value.");
    }
    if (entry.system.prepared?.value === "prepared") {
      const preparedIds = Object.values(entry.system.slots ?? {})
        .flatMap((slot) => slot.prepared ?? [])
        .map((slot) => slot.id);
      if (!preparedIds.length || !preparedIds.every((id) => spells.some((spell) => spell.id === id))) {
        throw new Error("Подготовленные ячейки не содержат ID встроенных заклинаний.");
      }
    }
    if (entry.system.showSlotlessLevels?.value !== false || entry.system.autoHeightenLevel?.value == null) {
      throw new Error("Запись заклинателя не соответствует живой схеме PF2e 8.3.0.");
    }
  }
  console.log(
    `${result.actor.name}: создано документов ${result.actor.items.length}`,
  );
}


const noSkillActionsConcept = parseConcept({
  prompt: "Врач 3 уровня без рабочих кнопок навыков",
  name: "Врач без панели",
  level: 3,
  ancestry: "human",
  gender: "female",
  profession: "doctor",
  role: "healer",
  armor: "light",
  weapon: "dagger",
  quality: "standard",
  target: "new",
  includeSkillActions: false,
  randomAbilities: false,
  randomSpells: false,
  randomConsumables: false,
  openSheet: false,
});
const noSkillActionsResult = await generateNpc(noSkillActionsConcept);
if (noSkillActionsResult.actor.items.some((item) =>
  ["Рабочие проверки навыков", "Медицинские процедуры — рабочие броски"].includes(item.name) ||
  item.flags?.["pf2e-npc-forge"]?.kind === "standard-action"
)) {
  throw new Error("Отключённые рабочие действия навыков всё равно были созданы.");
}

const techConcept = parseConcept({
  prompt: "Техномант 6 уровня с лазерной винтовкой и батареями",
  name: "Тестовый техномант",
  level: 6,
  ancestry: "human",
  gender: "unspecified",
  profession: "technomancer",
  role: "gunner",
  armor: "light",
  weapon: "laserRifle",
  technology: "starfinder",
  contentSource: "sf2e",
  target: "new",
  randomSeed: "sf2e-test",
  randomSpells: true,
});
for (const spell of randomSpellPlan(techConcept)?.spells ?? []) sfSpellSlugs.add(spell.slug);
const techResult = await generateNpc(techConcept);
if (!techResult.actor.items.some((item) => item.type === "weapon" && item.system.slug === "laser-rifle")) {
  throw new Error("Технический NPC не получил настоящее оружие SF2e.");
}
if (!techResult.actor.items.some((item) => item.type === "ammo" && item.system.slug === "battery-commercial")) {
  throw new Error("Лазерная винтовка не получила совместимую батарею SF2e.");
}
if (!techResult.actor.items.some((item) => item.type === "spell" && item.flags?.["pf2e-npc-forge"]?.sourcePack === "sf2e-anachronism.spells")) {
  throw new Error("Техномант не получил заклинания из SF2e Anachronism.");
}
console.log("Живые схемы заклинателя, техники SF2e и боеприпасов проверены.");

const merchantConcept = parseConcept({
  prompt: "Торговец 2 уровня с кинжалом, рюкзаком и случайным товаром",
  name: "Проверка набора",
  ancestry: "auto",
  gender: "auto",
  profession: "auto",
  role: "auto",
  armor: "auto",
  weapon: "auto",
  quality: "auto",
  target: "new",
  randomSeed: "merchant-kit-test",
});
const merchantResult = await generateNpc(merchantConcept);
if (!merchantResult.actor.items.some((item) => item.type === "melee")) {
  throw new Error("Необязательный kit уничтожил боевые документы торговца.");
}
if (merchantResult.actor.items.some((item) => item.type === "kit")) {
  throw new Error("Неподдерживаемый kit был встроен в NPC.");
}
console.log("Неподдерживаемые наборы безопасно пропускаются.");

const selected = actors[0];
selected.items.push({ id: "old-item", type: "weapon" });
const tokenDocument = {
  actorId: selected.id,
  actorLink: false,
  baseActor: selected,
  async update(data) {
    Object.assign(this, data);
  },
};
canvas.tokens.controlled = [{ document: tokenDocument, actor: selected }];
const updateConcept = parseConcept({
  prompt: "Эльф разведчик 2 уровень, короткий лук, лёгкий доспех",
  ancestry: "auto",
  gender: "auto",
  profession: "auto",
  role: "auto",
  armor: "auto",
  weapon: "auto",
  quality: "auto",
  target: "selected",
  replaceItems: true,
});
const updated = await generateNpc(updateConcept);
if (updated.created || selected.items.some((item) => item.id === "old-item")) {
  throw new Error("Обновление выбранного персонажа не заменило старые предметы.");
}
if (!tokenDocument.actorLink) {
  throw new Error("Несвязанный жетон не был связан с базовым персонажем.");
}
if (!updated.backup || updated.backup.items.length === 0) {
  throw new Error("Перед перестройкой не создана полная резервная копия.");
}
if (
  updated.backup.flags?.["pf2e-npc-forge"]?.sourceActorName == null ||
  !("sourceForgeFlags" in updated.backup.flags["pf2e-npc-forge"])
) {
  throw new Error("Резервная копия не сохранила имя и исходные флаги Кузницы.");
}
console.log("Обновление выбранного персонажа проверено.");

selected.items.push({ id: "manual-item", type: "equipment", flags: {} });
const generatedBefore = selected.items.filter(
  (item) => item.flags?.["pf2e-npc-forge"]?.generated,
).length;
const safeUpdateConcept = parseConcept({
  prompt: "Эльф разведчик 2 уровень, короткий лук, лёгкий доспех",
  name: "Безопасно обновлённый",
  ancestry: "auto",
  gender: "auto",
  profession: "auto",
  role: "auto",
  armor: "auto",
  weapon: "auto",
  quality: "auto",
  target: "selected",
  itemPolicy: "generated",
  backupOriginal: false,
});
await generateNpc(safeUpdateConcept);
const generatedAfter = selected.items.filter(
  (item) => item.flags?.["pf2e-npc-forge"]?.generated,
).length;
if (!selected.items.some((item) => item.id === "manual-item")) {
  throw new Error("Безопасная перестройка удалила ручной предмет.");
}
if (generatedAfter !== generatedBefore) {
  throw new Error("Безопасная перестройка оставила дубликаты предметов Кузницы.");
}
console.log("Политика замены только предметов Кузницы проверена.");

const restored = await restoreFromHistoryEntry({
  actorUuids: [selected.uuid],
  backupUuids: [updated.backup.uuid],
});
if (
  restored.actor !== selected ||
  selected.name !== updated.backup.flags["pf2e-npc-forge"].sourceActorName ||
  !restored.safetyBackup
) {
  throw new Error("Восстановление из истории не вернуло исходный NPC безопасно.");
}
console.log("Восстановление из истории проверено.");

tokenDocument.baseActor = selected;
const duplicateConcept = parseConcept({
  prompt: "Рыцарь 3 уровня, тяжёлый доспех, меч и щит",
  name: "Отдельная копия",
  ancestry: "auto",
  gender: "auto",
  profession: "auto",
  role: "auto",
  armor: "auto",
  weapon: "auto",
  quality: "auto",
  target: "duplicate",
});
const duplicated = await generateNpc(duplicateConcept);
if (
  !duplicated.created ||
  duplicated.actor.id === selected.id ||
  tokenDocument.actorId !== duplicated.actor.id
) {
  throw new Error("Безопасная копия не создала отдельного Actor и не назначила его жетону.");
}
console.log("Создание безопасной копии выбранного NPC проверено.");

canvas.tokens.controlled = [];
const batchConcept = parseConcept({
  prompt: "Стражник 2 уровня, копьё и щит, средний доспех",
  name: "Стражник",
  ancestry: "auto",
  gender: "auto",
  profession: "auto",
  role: "auto",
  armor: "auto",
  weapon: "auto",
  quality: "auto",
  target: "new",
  count: 3,
});
const batch = await generateNpcBatch(batchConcept);
if (
  batch.length !== 3 ||
  batch.some((result, index) => result.actor.name !== `Стражник ${index + 1}`)
) {
  throw new Error("Пакетное создание не создало три правильно названных NPC.");
}
console.log("Пакетное создание проверено.");

const squadConcept = parseConcept({
  prompt: "Согласованный городской патруль 3 уровня",
  name: "Патруль",
  ancestry: "human",
  gender: "unspecified",
  profession: "guard",
  role: "soldier",
  armor: "medium",
  weapon: "spearShield",
  quality: "standard",
  target: "new",
  count: 5,
  batchMode: "squad",
  randomSeed: "squad-test",
});
const squad = await generateNpcBatch(squadConcept);
const squadRoles = new Set(squad.map((result) => result.actor.flags["pf2e-npc-forge"]?.concept?.role));
if (squad.length !== 5 || squadRoles.size < 4) {
  throw new Error("Режим отряда не создал разнообразные согласованные роли.");
}
console.log("Генерация согласованного отряда проверена.");

const wolfConcept = parseConcept({
  prompt: "Голодный волк 2 уровня, стайный охотник",
  creatureKind: "beast",
  monsterFamily: "wolf",
  ancestry: "wolf",
  gender: "unspecified",
  profession: "beast",
  role: "packHunter",
  armor: "none",
  weapon: "jaws",
  quality: "standard",
  target: "new",
  complexity: "standard",
  randomSeed: "wolf-test",
  monsterTemplate: "fire",
});
const wolfResult = await generateNpc(wolfConcept);
const wolfJaws = wolfResult.actor.items.filter(
  (item) => item.type === "melee" && /jaws/u.test(item.system.slug),
);
if (wolfJaws.length !== 1) {
  throw new Error(`Волк получил ${wolfJaws.length} дублирующихся атак челюстями.`);
}
if (!wolfResult.actor.items.some(
  (item) => item.flags?.["pf2e-npc-forge"]?.kind === "monster-feature",
)) {
  throw new Error("Монстр не получил семейную способность.");
}
if (!wolfResult.actor.system.details.privateNotes.includes("Экология и логово")) {
  throw new Error("Монстр не получил мастерские заметки об экологии и логове.");
}
if (
  !wolfResult.actor.system.traits.value.includes("fire") ||
  !wolfResult.actor.system.attributes.resistances.some((entry) => entry.type === "fire") ||
  !wolfResult.actor.system.attributes.weaknesses.some((entry) => entry.type === "cold") ||
  !wolfResult.actor.items.some((item) => item.system?.slug === "forge-template-burning-body")
) {
  throw new Error("Огненный шаблон не был применён к реальному Actor и встроенным особенностям.");
}
console.log("Естественные атаки, семейные способности, шаблон и экология монстров проверены.");

const goblinEncounterConcept = parseConcept({
  prompt: "Гоблинская шайка 1 уровня",
  creatureKind: "monster",
  monsterFamily: "goblin",
  ancestry: "goblin",
  gender: "unspecified",
  profession: "raider",
  role: "ambusher",
  armor: "light",
  weapon: "dogslicer",
  quality: "standard",
  target: "new",
  count: 5,
  batchMode: "encounter",
  randomSeed: "goblin-encounter-test",
});
const goblinEncounter = await generateNpcBatch(goblinEncounterConcept);
const goblinRoles = new Set(goblinEncounter.map(
  (result) => result.actor.flags["pf2e-npc-forge"]?.concept?.role,
));
if (goblinEncounter.length !== 5 || goblinRoles.size < 4) {
  throw new Error("Тематическое столкновение гоблинов не создало разнообразный состав.");
}
if (goblinEncounter.some(
  (result) => result.actor.flags["pf2e-npc-forge"]?.concept?.monsterFamily !== "goblin",
)) {
  throw new Error("Член тематического столкновения потерял семейство монстров.");
}
console.log("Генерация тематического столкновения монстров проверена.");

const crossbowConcept = parseConcept({
  prompt: "Стрелок 3 уровня с арбалетом и лёгким доспехом",
  name: "Арбалетчик",
  ancestry: "auto",
  gender: "auto",
  profession: "auto",
  role: "auto",
  armor: "auto",
  weapon: "auto",
  quality: "auto",
  target: "new",
});
const crossbowResult = await generateNpc(crossbowConcept);
const crossbowStrike = crossbowResult.actor.items.find(
  (item) => item.type === "melee" && item.system.slug === "forge-crossbow",
);
if (!crossbowStrike || crossbowStrike.system.range.max !== null) {
  throw new Error("Дальность арбалета нарушает ограничение схемы PF2e.");
}
console.log("Схема дальнобойного удара проверена.");

for (const [input, expected] of [
  ["support", "interaction"],
  ["healing", "interaction"],
  ["utility", "interaction"],
  ["control", "offensive"],
  ["offensive", "offensive"],
  ["defensive", "defensive"],
  ["interaction", "interaction"],
  ["unknown-category", "interaction"],
]) {
  if (normalizeActionCategory(input) !== expected) {
    throw new Error(`Нормализация категории ${input} вернула неверное значение.`);
  }
}
console.log("Нормализация категорий action PF2e проверена.");

const specialPresetResults = new Map();
for (const presetId of ["doctor", "priest", "fieldEngineer"]) {
  const preset = BUILTIN_PRESETS[presetId];
  const concept = parseConcept({
    ...completePresetValues(preset.values),
    target: "new",
    openSheet: false,
    randomSeed: `special-${presetId}`,
    seedAbilities: `special-abilities-${presetId}`,
    seedSpells: `special-spells-${presetId}`,
    seedConsumables: `special-consumables-${presetId}`,
  });
  const spellPlan = randomSpellPlan(concept);
  if (["doctor", "fieldEngineer"].includes(presetId) && spellPlan !== null) {
    throw new Error(`Пресет ${presetId} неожиданно создаёт заклинания.`);
  }
  if (presetId === "priest" && (!spellPlan?.spells?.length || spellPlan.spells.some((spell) => spell.source !== "pf2e"))) {
    throw new Error("Жрец должен читать заклинания только из классического PF2e-пака.");
  }
  for (const spell of spellPlan?.spells ?? []) spellSlugs.add(spell.slug);
  const result = await generateNpc(concept);
  if (!result.actor || result.actor.type !== "npc") throw new Error(`Спецпресет ${presetId} не создал NPC.`);
  specialPresetResults.set(presetId, result);
  if (result.warnings.some((warning) => /неподдерживаем|заменено на|удал[её]н/u.test(warning))) {
    throw new Error(`Спецпресет ${presetId} потребовал исправления схемы: ${result.warnings.join(" | ")}`);
  }
}
console.log("Жрец, врач и полевой инженер отдельно проверены без доступа к выбранному character.");

const doctorPreview = getPreview(parseConcept({
  ...completePresetValues(BUILTIN_PRESETS.doctor.values),
  target: "new",
  randomConsumables: true,
  randomSeed: "doctor-rich-inventory",
}));
for (const required of ["Нарукавная повязка медика", "Набор лекаря", "Бинт с корнем тысячелистника ×2", "Противоядие (малое) ×2"]) {
  if (!doctorPreview.equipment.includes(required)) throw new Error(`В инвентаре врача отсутствует ${required}.`);
}
if (doctorPreview.equipment.length < 9) throw new Error("Инвентарь врача всё ещё слишком бедный.");
const doctorItemSlugs = new Set(specialPresetResults.get("doctor")?.actor?.items?.map((item) => item.system?.slug).filter(Boolean));
for (const requiredSlug of ["healers-toolkit", "medics-armband", "yarrow-root-bandage", "antidote-lesser", "antiplague-lesser"]) {
  if (!doctorItemSlugs.has(requiredSlug)) throw new Error(`Физически созданный врач не получил ${requiredSlug}.`);
}

const engineerPreview = getPreview(parseConcept({
  ...completePresetValues(BUILTIN_PRESETS.fieldEngineer.values),
  target: "new",
  randomSeed: "engineer-rich-inventory",
}));
for (const required of ["Набор для ремонта", "Набор создателя", "Датапад", "Серийный фонарик"]) {
  if (!engineerPreview.equipment.includes(required)) throw new Error(`В инвентаре инженера отсутствует ${required}.`);
}
const engineerItemSlugs = new Set(specialPresetResults.get("fieldEngineer")?.actor?.items?.map((item) => item.system?.slug).filter(Boolean));
for (const requiredSlug of ["repair-toolkit-commercial", "makers-toolkit-commercial", "datapad", "flashlight-commercial"]) {
  if (!engineerItemSlugs.has(requiredSlug)) throw new Error(`Физически созданный инженер не получил ${requiredSlug}.`);
}
console.log("Лекари и инженеры получили расширенный полезный и флейворный инвентарь.");

for (const [label, values, expected] of [
  [
    "алхимик",
    { ...completePresetValues(BUILTIN_PRESETS.guard.values), profession: "alchemist", randomSeed: "pf2e-npc-forge-session-audit:matrix:profession:alchemist", randomConsumables: true },
    (item) => item.system?.rules?.some?.((rule) => rule.key === "Note"),
  ],
  [
    "наёмник SF2e",
    { ...completePresetValues(BUILTIN_PRESETS.starfinderFireteam.values), count: 1, batchMode: "clones", randomSeed: "pf2e-npc-forge-session-audit:matrix:profession:mercenary", randomConsumables: true },
    (item) => item.system?.traits?.value?.includes?.("nanite") || item.system?.rules?.some?.((rule) => rule.key === "Note"),
  ],
]) {
  const result = await generateNpc(parseConcept({ ...values, target: "new", openSheet: false }));
  if (result.warnings.some((warning) => /Rule Element|nanite|неподдерживаемый признак/u.test(warning))) {
    throw new Error(`${label}: доверенный документ компендиума потерял механику: ${result.warnings.join(" | ")}`);
  }
  if (!result.actor.items.some(expected)) {
    throw new Error(`${label}: проверочная механика доверенного документа не сохранилась.`);
  }
}
console.log("Rule Elements и признаки случайных расходников из доверенных компендиумов сохранены.");

for (const [presetId, preset] of Object.entries(BUILTIN_PRESETS)) {
  const form = {
    ...completePresetValues(preset.values),
    target: "new",
    openSheet: false,
    randomSeed: `preset-${presetId}`,
  };
  const concept = parseConcept(form);
  for (const spell of randomSpellPlan(concept)?.spells ?? []) {
    (spell.source === "sf2e" ? sfSpellSlugs : spellSlugs).add(spell.slug);
  }
  const generated = await generateNpcBatch(concept);
  if (!generated.length) throw new Error(`Пресет ${presetId} не создал ни одного NPC.`);
  const schemaWarnings = generated.flatMap((result) => result.warnings ?? []).filter((warning) =>
    /неподдерживаем|заменено на|удал[её]н/u.test(warning),
  );
  if (schemaWarnings.length) {
    throw new Error(`Пресет ${presetId} потребовал исправления схемы: ${schemaWarnings.join(" | ")}`);
  }
}
console.log("Все встроенные пресеты созданы и приняты снимком схемы PF2e 8.3.0 без исправлений.");

const actorCountBeforeMissingPack = actors.length;
const equipmentPack = game.packs.get("pf2e.equipment-srd");
game.packs.delete("pf2e.equipment-srd");
let missingPackResult = null;
try {
  const missingPackConcept = parseConcept({
    prompt: "Алхимик 3 уровня с кинжалом и лёгким доспехом",
    name: "Проверка сборника",
    ancestry: "auto",
    gender: "auto",
    profession: "auto",
    role: "auto",
    armor: "auto",
    weapon: "auto",
    quality: "auto",
    target: "new",
  });
  missingPackResult = await generateNpc(missingPackConcept);
} finally {
  game.packs.set("pf2e.equipment-srd", equipmentPack);
}
if (!missingPackResult?.actor || actors.length !== actorCountBeforeMissingPack + 1) {
  throw new Error("Недоступный компендиум должен давать рабочий NPC с безопасными памятками.");
}
if (!(missingPackResult.warnings ?? []).some((warning) => /безопасная памятка/u.test(warning))) {
  throw new Error("Недоступный компендиум не был явно отражён в предупреждениях.");
}
console.log("Безопасная деградация при недоступном сборнике проверена.");

const originalActorCreateForFallback = Actor.create;
Actor.create = async (data) => {
  const actor = await originalActorCreateForFallback(data);
  if (data.name === "Проверка живого fallback") actor.failNextCreate = true;
  return actor;
};
let liveFallbackResult;
const originalConsoleWarnForFallback = console.warn;
console.warn = () => {};
try {
  liveFallbackResult = await generateNpc(parseConcept({
    prompt: "Стражник 2 уровня с копьём",
    name: "Проверка живого fallback",
    level: 2,
    ancestry: "human",
    gender: "unspecified",
    profession: "guard",
    role: "soldier",
    armor: "medium",
    weapon: "spear",
    quality: "standard",
    target: "new",
    randomAbilities: false,
    randomSpells: false,
    randomConsumables: false,
  }));
} finally {
  Actor.create = originalActorCreateForFallback;
  console.warn = originalConsoleWarnForFallback;
}
if (!liveFallbackResult?.actor || !(liveFallbackResult.warnings ?? []).some((warning) => /заменён безопасной памяткой/u.test(warning))) {
  throw new Error("Одиночная ошибка схемы Item должна сохранять нового NPC через безопасную памятку.");
}
if (!liveFallbackResult.actor.items.some((item) => item.flags?.["pf2e-npc-forge"]?.kind === "schema-fallback")) {
  throw new Error("Безопасная памятка после живой ошибки Item не была создана.");
}
console.log("Живая ошибка одного Item не останавливает создание нового NPC.");

tokenDocument.actorId = selected.id;
canvas.tokens.controlled = [{ document: tokenDocument, actor: selected }];
tokenDocument.baseActor = selected;
const rollbackName = selected.name;
const rollbackSystem = structuredClone(selected.system);
const rollbackItems = structuredClone(selected.items);
selected.failNextCreate = true;
let rollbackRejected = false;
try {
  const rollbackConcept = parseConcept({
    prompt: "Громила 3 уровня с двуручным топором и средним доспехом",
    name: "Не должен сохраниться",
    ancestry: "auto",
    gender: "auto",
    profession: "auto",
    role: "auto",
    armor: "auto",
    weapon: "auto",
    quality: "auto",
    target: "selected",
    itemPolicy: "generated",
    backupOriginal: false,
  });
  await generateNpc(rollbackConcept);
} catch {
  rollbackRejected = true;
}
if (
  !rollbackRejected ||
  selected.name !== rollbackName ||
  JSON.stringify(selected.system) !== JSON.stringify(rollbackSystem) ||
  JSON.stringify(selected.items) !== JSON.stringify(rollbackItems)
) {
  throw new Error("Ошибка создания предметов не откатила перестройку оригинала.");
}
console.log("Откат при ошибке создания предметов проверен.");
