import { BUILTIN_PRESETS, completePresetValues, presetOptions } from "../scripts/presets.js";

const oldMonsterState = {
  prompt: "Старый тролль 16 уровня",
  name: "Старый тролль",
  creatureKind: "monster",
  monsterFamily: "troll",
  ancestry: "troll",
  profession: "monster",
  role: "brute",
  armor: "none",
  weapon: "claws",
  count: 5,
  batchMode: "encounter",
  technology: "starfinder",
  monsterTemplate: "fire",
  tier_ac: "extreme",
};
const guard = { ...oldMonsterState, ...completePresetValues(BUILTIN_PRESETS.guard.values) };
if (guard.prompt !== BUILTIN_PRESETS.guard.values.prompt) throw new Error("Пресет не заменил старое описание.");
if (guard.name !== "") throw new Error("Пресет сохранил старое имя.");
if (guard.creatureKind !== "person" || guard.monsterFamily !== "none") {
  throw new Error("Человеческий пресет сохранил старое семейство монстра.");
}
if (guard.ancestry !== "human") throw new Error("Человеческий пресет сохранил старое происхождение.");
if (guard.count !== 1 || guard.batchMode !== "clones") throw new Error("Одиночный пресет сохранил старый групповой режим.");
if (guard.technology !== "fantasy" || guard.monsterTemplate !== "none") {
  throw new Error("Пресет сохранил старую технологию или шаблон монстра.");
}
if (guard.tier_ac !== "auto") throw new Error("Пресет сохранил старую ручную шкалу.");

const goblins = completePresetValues(BUILTIN_PRESETS.goblinRaid.values);
if (goblins.count !== 5 || goblins.batchMode !== "encounter" || goblins.monsterFamily !== "goblin") {
  throw new Error("Групповой пресет потерял количество, режим или семейство.");
}

const starfinderEngineer = completePresetValues(BUILTIN_PRESETS.fieldEngineer.values);
if (starfinderEngineer.forgeSetting !== "starfinder" || starfinderEngineer.contentSource !== "sf2e") {
  throw new Error("Starfinder-пресет не переключил отдельный сеттинг.");
}
const presetRows = Object.fromEntries(presetOptions().map((entry) => [entry.id, entry]));
if (presetRows.commander.group !== "support") throw new Error("Командир не попал в понятную категорию поддержки.");
if (presetRows.guard.group !== "defense" || presetRows.knight.group !== "defense") {
  throw new Error("Стражник и рыцарь не попали в категорию защиты и удержания.");
}
if (presetRows.doctor.group !== "support" || presetRows.mystic.group !== "support") {
  throw new Error("Лекари не попали в категорию лечения и поддержки.");
}
if (presetRows.technomancer.setting !== "starfinder" || presetRows.mage.setting !== "fantasy") {
  throw new Error("Фэнтези и Starfinder смешались в списке заготовок.");
}

const presetList = presetOptions();
if (presetList.length < 50) throw new Error(`Слишком мало готовых концептов: ${presetList.length}.`);
const fantasyCount = presetList.filter((entry) => entry.setting === "fantasy").length;
const starfinderCount = presetList.filter((entry) => entry.setting === "starfinder").length;
if (fantasyCount < 35 || starfinderCount < 10) {
  throw new Error(`Недостаточно раздельных концептов: fantasy=${fantasyCount}, starfinder=${starfinderCount}.`);
}
for (const id of ["shieldBearer", "bodyguard", "battlefieldMedic", "fieldPriest", "alchemistSupport", "investigator", "merchant", "smith"]) {
  if (!BUILTIN_PRESETS[id]) throw new Error(`Отсутствует новый понятный фэнтезийный концепт ${id}.`);
}
for (const id of ["sfTrooper", "sfHeavy", "sfGuard", "sfMedic", "sfOfficer", "sfHacker", "sfSniper", "sfPilot"]) {
  if (!BUILTIN_PRESETS[id]) throw new Error(`Отсутствует новый понятный Starfinder-концепт ${id}.`);
  if (presetRows[id]?.setting !== "starfinder") throw new Error(`Концепт ${id} попал не в Starfinder.`);
}

for (const [id, preset] of Object.entries(BUILTIN_PRESETS)) {
  const values = completePresetValues(preset.values);
  if (!values.prompt || !values.creatureKind || !values.monsterFamily || !values.profession || !values.role) {
    throw new Error(`Пресет ${id} после полного заполнения остался неполным.`);
  }
  const monster = values.monsterFamily !== "none";
  if (monster && values.creatureKind === "person") throw new Error(`Монстр-пресет ${id} стал person.`);
  if (!monster && values.creatureKind !== "person") throw new Error(`Обычный пресет ${id} сохранил тип монстра.`);
}

console.log("Полная замена концепта встроенными пресетами проверена.");
