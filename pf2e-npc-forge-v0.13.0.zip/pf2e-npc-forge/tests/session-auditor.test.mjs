import { readFileSync } from "node:fs";
import {
  DEFAULT_SESSION_AUDIT_OPTIONS,
  SESSION_AUDIT_FORMAT,
  SESSION_AUDIT_VERSION,
  serializeAuditError,
  sessionAuditHtml,
} from "../scripts/session-auditor.js";

if (SESSION_AUDIT_FORMAT !== "pf2e-npc-forge-session-audit") throw new Error("Неверный формат отчёта полного аудита.");
if (SESSION_AUDIT_VERSION !== 5) throw new Error("Неожиданная версия формата аудита.");
if (!DEFAULT_SESSION_AUDIT_OPTIONS.cleanup) throw new Error("Полный аудит обязан удалять временные документы по умолчанию.");
if (!DEFAULT_SESSION_AUDIT_OPTIONS.liveActorCreation) throw new Error("Полный аудит должен реально создавать тестовые Actor.");
if (!DEFAULT_SESSION_AUDIT_OPTIONS.deepCompendiumScan) throw new Error("Полный аудит должен глубоко читать рабочие компендиумы.");
if (!DEFAULT_SESSION_AUDIT_OPTIONS.testTemporaryScene || !DEFAULT_SESSION_AUDIT_OPTIONS.testTemporaryJournal) {
  throw new Error("Полный аудит должен проверять временные Scene и Journal.");
}

const serialized = serializeAuditError(new TypeError("audit boom"));
if (serialized.name !== "TypeError" || serialized.message !== "audit boom") throw new Error("Ошибка аудита сериализуется неполно.");

const html = sessionAuditHtml({
  status: "completed",
  ok: false,
  steps: [{ id: "x" }],
  summary: { errorCount: 1, warningCount: 2, durationMs: 1250 },
  issues: [{ severity: "error", message: "bad <enum>" }],
});
if (!html.includes("Проверка нашла проблемы") || html.includes("bad <enum>")) {
  throw new Error("HTML аудита не показывает статус или не экранирует сообщение.");
}

const source = readFileSync(new URL("../scripts/session-auditor.js", import.meta.url), "utf8");
for (const marker of [
  "auditPresets",
  "auditOptionMatrix",
  "auditRandomCases",
  "auditSelectedWorkflows",
  "auditDeploymentModes",
  "auditStorageRoundTrip",
  "auditUiControls",
  "auditModuleFiles",
  "auditAllPackIndexes",
  "auditBatches",
  "auditCompendiums",
  "auditWorldActors",
  "temporaryIntegrationTests",
  "AbortError",
  "flags.babele",
  "createEmbeddedDocuments(\"Token\"",
  "createEmbeddedDocuments(\"Combatant\"",
  "restoreRuntime()",
  "itemTypeRegistrySnapshot",
  "issueGroups",
  "suppressedDuringAudit",
  "uniqueIssueGroupCount",
  "observations",
  "recordGenerationWarning",
  "actionableGenerationWarning",
]) {
  if (!source.includes(marker)) throw new Error(`В полном аудите отсутствует защитный участок: ${marker}`);
}

console.log("Полный аудит: формат, безопасные значения, очистка, отмена, захват ошибок и HTML проверены.");
