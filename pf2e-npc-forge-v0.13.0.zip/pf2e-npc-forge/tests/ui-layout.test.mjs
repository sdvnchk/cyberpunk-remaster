import { readFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const css = readFileSync(join(root, "styles/forge.css"), "utf8");
const main = readFileSync(join(root, "scripts/main.js"), "utf8");
const template = readFileSync(join(root, "templates/generator.hbs"), "utf8");
const footer = readFileSync(join(root, "templates/forge-footer.hbs"), "utf8");

for (const marker of [
  "function forgeViewportPosition(current = {})",
  "ApplicationV2",
  "HandlebarsApplicationMixin",
  "static PARTS",
  "contentClasses: [\"pf2e-npc-forge-content\"]",
  "template: FOOTER_TEMPLATE",
  "keepInsideViewport()",
  "globalThis.addEventListener?.(\"resize\"",
  "contentRoot.dataset.pf2eNpcForgeListenersAttached",
]) {
  if (!main.includes(marker)) throw new Error(`Не найдено управление ApplicationV2: ${marker}`);
}

for (const forbidden of [
  "DialogV2.input",
  "configureDialogViewport",
  "forge-dialog-scroll",
  "forge-dialog-footer",
]) {
  if (main.includes(forbidden)) throw new Error(`Остался хрупкий код старого DialogV2: ${forbidden}`);
}

for (const marker of [
  ".pf2e-npc-forge-application .pf2e-npc-forge-content",
  "grid-template-rows: minmax(0, 1fr) auto",
  ".forge-app-body",
  "overflow-y: auto",
  ".forge-app-footer",
  "max-height: calc(100dvh - 8px)",
  "max-width: calc(100dvw - 8px)",
  "container-type: inline-size",
  "repeat(auto-fit",
  "scrollbar-gutter: stable",
  "position: fixed !important",
  ".forge-category-legend",
]) {
  if (!css.includes(marker)) throw new Error(`Не найдено адаптивное правило: ${marker}`);
}

if (!template.trimStart().startsWith('<main class="pf2e-npc-forge forge-app-body"')) {
  throw new Error("Основная форма не является единственной семантической прокручиваемой областью.");
}
if (!template.trimEnd().endsWith("</main>")) {
  throw new Error("Основная часть Кузницы не закрыта тегом main.");
}
for (const marker of [
  "forge-setting-switch",
  'data-forge-setting="fantasy"',
  'data-forge-setting="starfinder"',
  "forge-category-legend",
  "forge-preset-group",
  "data-forge-group-options hidden",
  "data-forge-spell-options hidden",
  "forge-shared-preview",
  "name=\"ancestry\"",
  "name=\"creatureKind\"",
  "forge-shared-sync-note",
  "data-forge-shared-build",
  "forge-shared-build-flow",
  "data-forge-category",
  "data-forge-reset-window",
]) {
  if (!template.includes(marker)) throw new Error(`В новом пользовательском потоке отсутствует ${marker}.`);
}
if ((template.match(/name="creatureKind"/g) ?? []).length !== 1) {
  throw new Error("Тип существа должен иметь ровно одно каноническое поле для быстрой и точной сборки.");
}
if ((template.match(/name="ancestry"/g) ?? []).length !== 1) {
  throw new Error("Раса должна иметь ровно одно каноническое поле для быстрой и точной сборки.");
}
if (template.includes("data-forge-reroll-personality") || template.includes("Личность")) {
  throw new Error("В интерфейсе осталась ненужная пользователю личность.");
}
for (const marker of [
  "--forge-assault",
  "--forge-defense",
  "--forge-support",
  "--forge-magic",
  "--forge-specialist",
  "--forge-civilian",
  "--forge-monster",
  ".forge-list-more",
  ".forge-resize-grip",
  "cursor: nwse-resize",
  ".forge-shared-sync-note",
]) {
  if (!css.includes(marker)) throw new Error(`Отсутствует смысловое цветовое или компактное правило: ${marker}`);
}
for (const marker of ["forge-audit-center", "data-forge-audit-report-panel", "data-forge-audit-save-last", "data-forge-audit-copy-last"]) {
  if (!template.includes(marker)) throw new Error(`В диагностическом центре отсутствует ${marker}.`);
}
for (const marker of ["forge-app-footer", "data-forge-submit", 'type="submit"', 'data-action="close"', "data-forge-resize-grip"]) {
  if (!footer.includes(marker)) throw new Error(`В постоянной нижней панели отсутствует ${marker}.`);
}

console.log("Интерфейс: отдельное ApplicationV2, один scroll-контейнер и постоянная панель действий проверены статически.");
