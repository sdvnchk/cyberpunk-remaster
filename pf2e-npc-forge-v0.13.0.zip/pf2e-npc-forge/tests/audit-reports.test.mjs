import { readFileSync } from "node:fs";
import {
  auditReportFilename,
  formatByteSize,
  serializeAuditReport,
  textByteSize,
} from "../scripts/audit-reports.js";

const report = { createdAt: "2026-07-25T12:30:00.000Z", status: "completed", summary: { failed: 1 } };
const filename = auditReportFilename(report);
if (!filename.endsWith(".json") || filename.includes(":")) throw new Error("Имя отчёта небезопасно для Windows.");
const json = serializeAuditReport(report);
if (JSON.parse(json).summary.failed !== 1 || textByteSize(json) <= 0) throw new Error("Сериализация отчёта повреждена.");
if (!formatByteSize(1024).includes("КБ")) throw new Error("Размер отчёта форматируется неверно.");

const source = readFileSync(new URL("../scripts/audit-reports.js", import.meta.url), "utf8");
for (const marker of [
  "indexedDB",
  "uploadPersistent",
  "showSaveFilePicker",
  "durableLocalCopy",
  "automaticDownloadClaimed: false",
  "checkpointAuditReport",
  "getLastAuditReportRecord",
]) {
  if (!source.includes(marker)) throw new Error(`В защите отчёта отсутствует ${marker}`);
}
if (source.includes("скачан автоматически")) throw new Error("Код снова делает ложное заявление об автоматическом скачивании.");
console.log("Отчёт: имя, JSON, размер, контрольные точки, IndexedDB и persistent storage проверены.");
