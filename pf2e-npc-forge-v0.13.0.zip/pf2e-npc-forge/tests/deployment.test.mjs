import { deployActorsToScene, formationOffsets } from "../scripts/deployment.js";

for (const mode of ["cluster", "line", "wedge", "ring"]) {
  const offsets = formationOffsets(6, mode, 2);
  if (offsets.length !== 6) throw new Error(`Формация ${mode} потеряла участников.`);
  if (new Set(offsets.map((entry) => `${entry.x}:${entry.y}`)).size !== 6) {
    throw new Error(`Формация ${mode} размещает жетоны друг на друга.`);
  }
}
const created = [];
globalThis.canvas = {
  tokens: { controlled: [] },
  scene: {
    id: "scene-1",
    width: 2000,
    height: 2000,
    grid: { size: 100 },
    async createEmbeddedDocuments(type, documents) {
      if (type !== "Token") throw new Error("Неверный тип документа сцены.");
      const tokens = documents.map((document, index) => ({ ...document, id: `token-${index}` }));
      created.push(...tokens);
      return tokens;
    },
  },
};
globalThis.game = { combat: null };
const results = [1, 2, 3].map((number) => ({
  actor: {
    id: `actor-${number}`,
    name: `NPC ${number}`,
    prototypeToken: { width: 1, height: 1, texture: { src: "token.webp" } },
  },
}));
const deployed = await deployActorsToScene(results, {
  deploymentMode: "wedge",
  addToCombat: false,
});
if (deployed.tokens.length !== 3 || created.some((token) => !token.actorLink)) {
  throw new Error("Автоматическое размещение жетонов не сработало.");
}
console.log("Формации и размещение жетонов на активной сцене проверены.");
