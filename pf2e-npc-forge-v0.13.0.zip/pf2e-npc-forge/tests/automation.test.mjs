import {
  actionEconomyPlan,
  auditAutomation,
  medicalProcedureSpec,
  skillCheckPanelSpec,
} from "../scripts/automation.js";
import { randomFeaturePlan } from "../scripts/random-content.js";
import { PROFESSIONS, ROLES, SKILL_LABELS } from "../scripts/blueprints.js";

const concept = {
  name: "Полевой лекарь",
  profession: "doctor",
  role: "healer",
  weapon: "dagger",
  level: 5,
};
const skills = {
  medicine: { base: 16 },
  nature: { base: 13 },
  survival: { base: 12 },
};
const panel = skillCheckPanelSpec(concept, skills);
const medicine = medicalProcedureSpec(concept, skills);
if (!panel.description.includes("@Check[medicine") || !panel.description.includes("Медицина +16")) {
  throw new Error("Панель навыков не создаёт рабочую проверку Медицины с видимым модификатором Actor.");
}
for (const fragment of ["dc:15", "dc:20", "dc:30", "dc:40", "2d8+10", "2d8+30", "2d8+50"]) {
  if (!medicine.description.includes(fragment)) {
    throw new Error(`Медицинская процедура потеряла ${fragment}.`);
  }
}
const report = auditAutomation({ concept, skills, featureSpecs: [panel, medicine] });
if (report.findings.length || report.score !== 100) {
  throw new Error("Рабочие медицинские проверки не прошли аудит автоматизации.");
}

const allSkills = Object.fromEntries(Object.keys(SKILL_LABELS).map((slug) => [slug, { base: 15 }]));
const featureMap = new Map();
for (const role of Object.keys(ROLES)) {
  for (const profession of Object.keys(PROFESSIONS)) {
    for (let seed = 0; seed < 250; seed += 1) {
      const sampleConcept = {
        role,
        profession,
        level: 5,
        complexity: "tactical",
        randomAbilities: true,
        seedAbilities: String(seed),
        randomSeed: String(seed),
      };
      for (const feature of randomFeaturePlan(sampleConcept, { dc: 22, damage: "2d8+4" })) {
        featureMap.set(feature.slug, feature);
      }
    }
  }
}
const globalAudit = auditAutomation({
  concept: { profession: "warrior", role: "soldier" },
  skills: allSkills,
  featureSpecs: [...featureMap.values()],
});
if (globalAudit.findings.some((finding) => finding.code === "decorative-skill-bonus")) {
  throw new Error("В пуле способностей остались декоративные числовые бонусы к навыкам без Rule Element.");
}

const reloadPlan = actionEconomyPlan(
  { weapon: "arquebus", role: "sniper" },
  [{ name: "Выверенный выстрел", actionType: "action", actions: 2 }],
);
if (reloadPlan.reload !== 1 || !reloadPlan.routine.includes("Перезарядить")) {
  throw new Error("Анализ экономики действий не учёл перезарядку однозарядного оружия.");
}
console.log("Рабочие проверки навыков, медицинские КС и аудит автоматизации проверены.");
