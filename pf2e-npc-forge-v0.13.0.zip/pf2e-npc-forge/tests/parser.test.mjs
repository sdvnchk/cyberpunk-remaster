import { getPreview } from "../scripts/generator.js";
import { parseConcept } from "../scripts/parser.js";

const cases = [
  {
    text: "Тифлинг, женщина, 5 уровень, врач по имени Кассандра, лёгкий доспех, кинжал, высокая защита, предельная Медицина, огонь",
    expect: {
      name: "Кассандра",
      ancestry: "tiefling",
      gender: "female",
      level: 5,
      profession: "doctor",
      role: "healer",
      armor: "light",
      weapon: "dagger",
    },
  },
  {
    text: "Элитный орк мужчина 3 уровня, рыцарь в тяжёлых латах, меч и щит",
    expect: {
      ancestry: "orc",
      gender: "male",
      level: 3,
      profession: "knight",
      role: "soldier",
      armor: "heavy",
      weapon: "longswordShield",
      quality: "elite",
    },
  },
  {
    text: "Кицунэ маг 12 уровень, вода и огонь, без доспеха, посох",
    expect: {
      ancestry: "kitsune",
      level: 12,
      profession: "mage",
      role: "caster",
      armor: "none",
      weapon: "staff",
    },
  },
];

for (const test of cases) {
  const concept = parseConcept({
    prompt: test.text,
    ancestry: "auto",
    gender: "auto",
    profession: "auto",
    role: "auto",
    armor: "auto",
    weapon: "auto",
    quality: "auto",
    target: "new",
  });

  for (const [key, expected] of Object.entries(test.expect)) {
    if (concept[key] !== expected) {
      throw new Error(
        `${test.text}: ${key}=${concept[key]}, ожидалось ${expected}`,
      );
    }
  }

  const preview = getPreview(concept);
  if (!(preview.ac > 0 && preview.hp > 0 && preview.attack > 0)) {
    throw new Error("Некорректный предварительный расчёт.");
  }
  if (
    concept.quality === "elite" &&
    (!String(preview.damage).endsWith("+2") ||
      preview.effectiveLevel !== concept.level + (concept.level <= 0 ? 2 : 1))
  ) {
    throw new Error("Элитная корректировка урона или уровня опасности неверна.");
  }
  console.log(
    `${concept.name}: ${concept.ancestry}/${concept.profession}/${concept.role}, ` +
      `ур. ${concept.level}, КБ ${preview.ac}, ОЗ ${preview.hp}, ` +
      `атака ${preview.attack}, урон ${preview.damage}`,
  );
}

let invalidLevelRejected = false;
try {
  parseConcept({
    prompt: "Человек воин 30 уровня",
    ancestry: "auto",
    gender: "auto",
    profession: "auto",
    role: "auto",
    armor: "auto",
    weapon: "auto",
    quality: "auto",
    target: "new",
  });
} catch (error) {
  invalidLevelRejected = /−1 до 20/u.test(error.message);
}
if (!invalidLevelRejected) {
  throw new Error("Уровень за пределами −1…20 не был отклонён явно.");
}
console.log("Явная проверка недопустимого уровня проверена.");

const monsterCases = [
  {
    text: "Стая гноллов 3 уровня, стайные охотники с цепами",
    expect: { creatureKind: "monster", monsterFamily: "gnoll", ancestry: "gnoll" },
  },
  {
    text: "Гигантский паук 2 уровня охраняет гнездо",
    expect: { creatureKind: "beast", monsterFamily: "giantSpider", ancestry: "giantSpider" },
  },
  {
    text: "Древний конструкт 5 уровня охраняет хранилище",
    expect: { creatureKind: "construct", monsterFamily: "construct", ancestry: "construct" },
  },
];

for (const test of monsterCases) {
  const concept = parseConcept({
    prompt: test.text,
    creatureKind: "auto",
    monsterFamily: "auto",
    ancestry: "auto",
    gender: "auto",
    profession: "auto",
    role: "auto",
    armor: "auto",
    weapon: "auto",
    quality: "auto",
    target: "new",
    batchMode: "encounter",
  });
  for (const [key, expected] of Object.entries(test.expect)) {
    if (concept[key] !== expected) {
      throw new Error(`${test.text}: ${key}=${concept[key]}, ожидалось ${expected}`);
    }
  }
  const preview = getPreview(concept);
  if (!preview.monsterLore || preview.strikes.length === 0 || preview.actions.length === 0) {
    throw new Error(`Монстр «${test.text}» не получил экологию, атаки или способности.`);
  }
}
console.log("Распознавание семейств монстров и их предпросмотр проверены.");
