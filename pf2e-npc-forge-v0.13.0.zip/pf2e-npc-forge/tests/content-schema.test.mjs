import { readFileSync } from "node:fs";
import { ANCESTRIES, PROFESSIONS, ROLES, WEAPONS } from "../scripts/blueprints.js";
import { randomContentPlan } from "../scripts/random-content.js";
import { MONSTER_FAMILIES, monsterFeaturePlan, monsterStrikePlan } from "../scripts/monsters.js";
import { MONSTER_TEMPLATES, monsterTemplatePlan } from "../scripts/director.js";
import { sanitizePf2eItemSource } from "../scripts/schema-guard.js";

const choices = JSON.parse(readFileSync(new URL("./fixtures/pf2e-8.3-choices.json", import.meta.url), "utf8"));
globalThis.CONFIG = {
  PF2E: Object.fromEntries(Object.entries(choices).map(([key, values]) => [
    key,
    Object.fromEntries(values.map((value) => [value, value])),
  ])),
};

const creatureTraits = new Set(choices.creatureTraits);
const languages = new Set(choices.languages);
const senses = new Set(choices.senses);
const actionTraits = new Set(choices.actionTraits);
const attackTraits = new Set(choices.npcAttackTraits);
const damageTypes = new Set(choices.damageTypes);
const skillSlugs = new Set(choices.skills);
const actorSizes = new Set(choices.actorSizes);
const senseAcuities = new Set(choices.senseAcuities);
const immunityTypes = new Set(choices.immunityTypes);
const resistanceTypes = new Set(choices.resistanceTypes);
const weaknessTypes = new Set(choices.weaknessTypes);

for (const [id, ancestry] of Object.entries(ANCESTRIES)) {
  for (const trait of ancestry.traits ?? []) {
    if (!creatureTraits.has(trait)) throw new Error(`Происхождение ${id}: невалидный creature trait ${trait}.`);
  }
  for (const language of ancestry.languages ?? []) {
    if (!languages.has(language)) throw new Error(`Происхождение ${id}: невалидный язык ${language}.`);
  }
  for (const sense of ancestry.senses ?? []) {
    if (!senses.has(sense.type)) throw new Error(`Происхождение ${id}: невалидное чувство ${sense.type}.`);
    if (!senseAcuities.has(sense.acuity)) throw new Error(`Происхождение ${id}: невалидная точность чувства ${sense.acuity}.`);
  }
  if (ancestry.size && !actorSizes.has(ancestry.size)) throw new Error(`Происхождение ${id}: невалидный размер ${ancestry.size}.`);
}

for (const [id, role] of Object.entries(ROLES)) {
  for (const skill of Object.keys(role.skills ?? {})) {
    if (!skillSlugs.has(skill)) throw new Error(`Роль ${id}: невалидный навык ${skill}.`);
  }
}
for (const [id, profession] of Object.entries(PROFESSIONS)) {
  for (const skill of Object.keys(profession.skills ?? {})) {
    if (!skillSlugs.has(skill)) throw new Error(`Профессия ${id}: невалидный навык ${skill}.`);
  }
}
for (const [id, weapon] of Object.entries(WEAPONS)) {
  if (!damageTypes.has(weapon.damageType)) throw new Error(`Оружие ${id}: невалидный тип урона ${weapon.damageType}.`);
  for (const trait of weapon.traits ?? []) {
    if (!attackTraits.has(trait)) throw new Error(`Оружие ${id}: невалидный npcAttack trait ${trait}.`);
  }
}

function actionSource(spec) {
  return {
    name: spec.name,
    type: "action",
    system: {
      actionType: { value: spec.actionType },
      actions: { value: spec.actionType === "action" ? (spec.actions ?? 1) : null },
      category: spec.category,
      traits: { value: spec.traits ?? [], otherTags: [] },
      rules: spec.rules ?? [],
    },
  };
}

const base = {
  name: "Проверка",
  level: 8,
  creatureKind: "person",
  monsterFamily: "none",
  ancestry: "human",
  gender: "unspecified",
  profession: "warrior",
  role: "soldier",
  armor: "light",
  weapon: "longsword",
  quality: "standard",
  technology: "fantasy",
  contentSource: "pf2e",
  randomAbilities: true,
  randomSpells: false,
  randomConsumables: false,
  randomSeed: "schema",
  seedAbilities: "schema",
  seedSpells: "schema",
  seedConsumables: "schema",
  spellTheme: "auto",
  elements: [],
  monsterTemplate: "none",
};

for (const role of Object.keys(ROLES)) {
  const profession = Object.keys(PROFESSIONS).find((id) => PROFESSIONS[id].role === role) ?? "warrior";
  for (let seed = 0; seed < 80; seed += 1) {
    const concept = { ...base, role, profession, randomSeed: `${role}-${seed}`, seedAbilities: `${role}-${seed}` };
    const plan = randomContentPlan(concept, { dc: 26, damage: "2d8+8" });
    for (const feature of plan.features) {
      const checked = sanitizePf2eItemSource(actionSource(feature));
      if (checked.corrections.length) {
        throw new Error(`Роль ${role}, способность ${feature.slug}: ${checked.corrections.join(" | ")}`);
      }
    }
  }
}

for (const template of Object.keys(MONSTER_TEMPLATES)) {
  const plan = monsterTemplatePlan({ ...base, monsterTemplate: template });
  for (const trait of plan.traits ?? []) {
    if (!creatureTraits.has(trait)) throw new Error(`Шаблон ${template}: невалидный creature trait ${trait}.`);
  }
  if (plan.size && !actorSizes.has(plan.size)) throw new Error(`Шаблон ${template}: невалидный размер ${plan.size}.`);
  for (const entry of plan.immunities ?? []) {
    if (!immunityTypes.has(entry.type)) throw new Error(`Шаблон ${template}: невалидный иммунитет ${entry.type}.`);
  }
  for (const entry of plan.resistances ?? []) {
    if (!resistanceTypes.has(entry.type)) throw new Error(`Шаблон ${template}: невалидное сопротивление ${entry.type}.`);
  }
  for (const entry of plan.weaknesses ?? []) {
    if (!weaknessTypes.has(entry.type)) throw new Error(`Шаблон ${template}: невалидная слабость ${entry.type}.`);
  }
  for (const feature of plan.features) {
    const checked = sanitizePf2eItemSource(actionSource(feature));
    if (checked.corrections.length) {
      throw new Error(`Шаблон ${template}, способность ${feature.slug}: ${checked.corrections.join(" | ")}`);
    }
  }
}

for (const family of Object.keys(MONSTER_FAMILIES).filter((id) => id !== "none")) {
  const concept = {
    ...base,
    creatureKind: MONSTER_FAMILIES[family].kind,
    monsterFamily: family,
    ancestry: MONSTER_FAMILIES[family].ancestry,
    profession: MONSTER_FAMILIES[family].defaultProfession,
    role: MONSTER_FAMILIES[family].defaultRole,
    weapon: MONSTER_FAMILIES[family].defaultWeapon,
  };
  for (const feature of monsterFeaturePlan(concept, { dc: 26, damage: "2d8+8" })) {
    const checked = sanitizePf2eItemSource(actionSource(feature));
    if (checked.corrections.length) throw new Error(`Семейство ${family}, способность ${feature.slug}: ${checked.corrections.join(" | ")}`);
  }
  for (const strike of monsterStrikePlan(concept)) {
    if (!damageTypes.has(strike.damageType)) throw new Error(`Семейство ${family}: невалидный урон ${strike.damageType}.`);
    for (const trait of strike.traits ?? []) {
      if (!attackTraits.has(trait)) throw new Error(`Семейство ${family}: невалидный npcAttack trait ${trait}.`);
    }
  }
}

console.log("Все роли, профессии, происхождения, оружие, семейства, способности и шаблоны сверены со снимком PF2e 8.3.0.");
