import {
  itemTypeRegistrySnapshot,
  normalizeActionCategory,
  sanitizeNpcSystem,
  sanitizePf2eItemSource,
} from "../scripts/schema-guard.js";

globalThis.game = {
  system: {
    documentTypes: {
      Item: [
        "treasure", "action", "ancestry", "armor", "background", "backpack", "book",
        "campaignFeature", "class", "condition", "consumable", "ammo", "deity", "effect",
        "equipment", "feat", "heritage", "kit", "lore", "melee", "shield", "spell",
        "spellcastingEntry", "weapon",
      ],
    },
  },
};

const fullDocumentTypes = [
  "base", "treasure", "action", "ancestry", "affliction", "armor", "background",
  "backpack", "book", "campaignFeature", "class", "condition", "consumable", "ammo",
  "deity", "effect", "equipment", "feat", "heritage", "kit", "lore", "melee",
  "shield", "spell", "spellcastingEntry", "weapon",
];

globalThis.CONFIG = {
  Item: {
    // Exact kind of partial registry seen in the user's live PF2e 8.3.0 audit:
    // shared-model physical items are intentionally absent here.
    dataModels: Object.fromEntries([
      "action", "campaignFeature", "class", "condition", "effect", "feat", "heritage",
      "kit", "melee", "treasure",
    ].map((type) => [type, class {}])),
    documentClass: {
      TYPES: fullDocumentTypes,
      implementation: { TYPES: fullDocumentTypes },
    },
  },
  PF2E: {
    actionTypes: { action: "", reaction: "", free: "", passive: "" },
    actionsNumber: { 1: "", 2: "", 3: "" },
    actionCategories: { interaction: "", defensive: "", offensive: "", familiar: "" },
    actionTraits: { auditory: "", concentrate: "", healing: "", manipulate: "", magical: "" },
    npcAttackTraits: { magical: "", unarmed: "", agile: "" },
    damageTypes: { fire: "", bludgeoning: "", untyped: "" },
    damageCategories: { persistent: "", precision: "", splash: "" },
    actorSizes: { tiny: "", sm: "", med: "", lg: "", huge: "", grg: "" },
    creatureTraits: { human: "", humanoid: "", fire: "" },
    languages: { common: "" },
    senses: { darkvision: "" },
    senseAcuities: { precise: "", imprecise: "", vague: "" },
    skills: { medicine: {}, perception: {} },
    immunityTypes: { poison: "" },
    resistanceTypes: { fire: "" },
    weaknessTypes: { cold: "" },
    magicTraditions: { arcane: "", divine: "", occult: "", primal: "" },
    consumableTraits: { consumable: "", magical: "", healing: "" },
    equipmentTraits: { invested: "", magical: "" },
    armorTraits: { comfort: "" },
    weaponTraits: { agile: "", finesse: "" },
    shieldTraits: { magical: "" },
    spellTraits: { concentrate: "", manipulate: "", healing: "" },
    effectTraits: { healing: "" },
    usages: { "held-in-one-hand": "", wornarmor: "" },
    weaponCategories: { simple: "", martial: "" },
    weaponGroups: { knife: "", sword: "" },
    armorCategories: { unarmored: "", light: "", medium: "", heavy: "" },
  },
};

if (normalizeActionCategory("support") !== "interaction") {
  throw new Error("Внутренняя категория support не преобразована в interaction.");
}

const registry = itemTypeRegistrySnapshot();
if (registry.authoritativeSource !== "CONFIG.Item.documentClass.TYPES" || !registry.registered.includes("armor")) {
  throw new Error("Защитный слой не использовал полный реестр типов документа PF2e.");
}
if (!registry.dataModelsArePartial || registry.configDataModels.includes("armor")) {
  throw new Error("Тест не воспроизвёл частичный CONFIG.Item.dataModels живой PF2e 8.3.0.");
}

const armor = sanitizePf2eItemSource({
  name: "Проверочная броня",
  type: "armor",
  system: { category: "light", traits: { value: [] }, rules: [] },
});
if (armor.source.type !== "armor") throw new Error("Зарегистрированная броня ошибочно отклонена runtime-реестром.");
if (armor.corrections.some((entry) => entry.includes("CONFIG.Item.dataModels"))) {
  throw new Error("Частичный CONFIG.Item.dataModels ошибочно создаёт пользовательское предупреждение.");
}

const trustedCatalog = sanitizePf2eItemSource({
  name: "Проверочный документ компендиума",
  type: "equipment",
  flags: {
    "pf2e-npc-forge": {
      generated: true,
      catalogClone: true,
      sourcePack: "sf2e-anachronism.equipment",
    },
  },
  system: {
    usage: { value: "installed" },
    traits: { value: ["nanite"], otherTags: [] },
    rules: [
      { key: "TokenLight", value: { bright: 10 } },
      { key: "TokenEffectIcon", value: "icons/test.webp" },
    ],
  },
});
if (!trustedCatalog.source.system.traits.value.includes("nanite")) {
  throw new Error("Признак доверенного документа компендиума был ошибочно удалён.");
}
if (trustedCatalog.source.system.rules.length !== 2) {
  throw new Error("Rule Elements доверенного документа компендиума были ошибочно удалены.");
}
if (trustedCatalog.source.system.usage.value !== "installed") {
  throw new Error("Использование доверенного документа компендиума было ошибочно переписано.");
}

const action = sanitizePf2eItemSource({
  name: "Проверка поддержки",
  type: "action",
  system: {
    actionType: { value: "wrong" },
    actions: { value: 9 },
    category: "support",
    traits: { value: ["auditory", "invented"] },
    rules: [
      { key: "FlatModifier", selector: "medicine", value: 1, type: "circumstance" },
      { key: "FlatModifier", selector: "", value: "bad" },
    ],
  },
});
if (action.source.system.category !== "interaction") throw new Error("Категория action не исправлена.");
if (action.source.system.actionType.value !== "passive") throw new Error("Тип action не исправлен.");
if (action.source.system.actions.value !== null) throw new Error("Пассивное действие сохранило стоимость.");
if (action.source.system.traits.value.includes("invented")) throw new Error("Невалидный action trait не удалён.");
if (action.source.system.rules.length !== 1) throw new Error("Невалидный Rule Element не удалён.");

const melee = sanitizePf2eItemSource({
  name: "Проверочный удар",
  type: "melee",
  system: {
    action: "wrong",
    subjectToMAP: true,
    range: { increment: -20, max: 500 },
    traits: { value: ["magical", "invented"] },
    damageRolls: {
      main: { damage: "2d6+4", damageType: "invented", category: "invented" },
    },
  },
});
if (melee.source.system.action !== "strike") throw new Error("Melee action не нормализован.");
if (melee.source.system.range !== null) throw new Error("Некорректная дальность не удалена.");
if (melee.source.system.damageRolls.main.damageType !== "untyped") throw new Error("Тип урона не нормализован.");
if (melee.source.system.damageRolls.main.category !== null) throw new Error("Категория урона не нормализована.");

const spellcasting = sanitizePf2eItemSource({
  name: "Проверочная магия",
  type: "spellcastingEntry",
  system: {
    ability: { value: "luck" },
    tradition: { value: "technology" },
    prepared: { value: "memorized", flexible: 1 },
    showSlotlessLevels: { value: 0 },
    proficiency: { value: 99 },
  },
});
if (spellcasting.source.system.ability.value !== "cha") throw new Error("Характеристика заклинателя не исправлена.");
if (spellcasting.source.system.tradition.value !== "arcane") throw new Error("Традиция заклинателя не исправлена.");
if (spellcasting.source.system.prepared.value !== "innate") throw new Error("Тип подготовки не исправлен.");
if (spellcasting.source.system.proficiency.value !== 0) throw new Error("Владение заклинателя не исправлено.");

const actor = sanitizeNpcSystem({
  traits: { rarity: "mythic", size: { value: "colossal" }, value: ["human", "invented"] },
  details: { languages: { details: "", value: ["common", "invented"] } },
  perception: { senses: [{ type: "darkvision", acuity: "wrong", range: 60 }, { type: "xray", range: 20 }] },
  skills: { medicine: { base: 10 }, invented: { base: 12 } },
  initiative: { statistic: "invented" },
  attributes: {
    speed: { value: 25, otherSpeeds: [{ type: "fly", value: 30 }, { type: "teleport", value: 50 }] },
    immunities: [{ type: "poison" }, { type: "invented" }],
    resistances: [{ type: "fire", value: 5 }, { type: "invented", value: 5 }],
    weaknesses: [{ type: "cold", value: 5 }, { type: "invented", value: 5 }],
  },
});
if (actor.system.traits.size.value !== "med") throw new Error("Размер NPC не исправлен.");
if (actor.system.traits.rarity !== "common") throw new Error("Редкость NPC не исправлена.");
if (actor.system.skills.invented) throw new Error("Незарегистрированный навык не удалён.");
if (actor.system.initiative.statistic !== "perception") throw new Error("Инициатива не исправлена.");
if (actor.system.attributes.immunities.length !== 1 || actor.system.attributes.resistances.length !== 1 || actor.system.attributes.weaknesses.length !== 1) {
  throw new Error("IWR NPC не прошли фильтрацию.");
}

const translatedConsumable = sanitizePf2eItemSource({
  _id: "translated",
  _stats: { systemVersion: "old" },
  ownership: { default: 0 },
  folder: "folder",
  sort: 100,
  name: "Переведённый расходник",
  type: "consumable",
  flags: { babele: { translated: true }, otherModule: { keep: true } },
  system: {
    description: { value: "<p>Описание</p>" },
    quantity: 0,
    level: { value: -3 },
    usage: { value: "invented" },
    traits: { rarity: "legendary", value: ["consumable", "invented"] },
    rules: [],
  },
});
if (translatedConsumable.source.flags?.babele) throw new Error("Флаги Babele не удалены из клона.");
if (translatedConsumable.source._id || translatedConsumable.source._stats || translatedConsumable.source.folder) {
  throw new Error("Служебные поля документа не удалены.");
}
if (translatedConsumable.source.system.quantity !== 1 || translatedConsumable.source.system.level.value !== 0) {
  throw new Error("Количество или уровень физического предмета не нормализованы.");
}
if (translatedConsumable.source.system.traits.value.includes("invented")) {
  throw new Error("Невалидный trait физического предмета не удалён.");
}

const spell = sanitizePf2eItemSource({
  name: "Проверочное заклинание",
  type: "spell",
  system: {
    description: { value: "" },
    level: { value: 99 },
    location: { value: 42 },
    traits: { value: ["concentrate", "invented"], traditions: ["divine", "technology"] },
    rules: [],
  },
});
if (spell.source.system.level.value !== 10 || spell.source.system.location.value !== null) {
  throw new Error("Заклинание не прошло нормализацию ранга и location.");
}
if (spell.source.system.traits.traditions.includes("technology")) {
  throw new Error("Невалидная традиция заклинания не удалена.");
}

let unsupportedRejected = false;
try {
  sanitizePf2eItemSource({ name: "Набор", type: "kit", system: {} });
} catch {
  unsupportedRejected = true;
}
if (!unsupportedRejected) throw new Error("Неподдерживаемый тип Item не был отклонён до Foundry.");

console.log("Защитный слой схемы PF2e: все создаваемые Item, Actor, метаданные Babele и Rule Elements проверены.");
