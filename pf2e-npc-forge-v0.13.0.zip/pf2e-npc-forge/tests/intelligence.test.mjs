import { analyzeConcept, normalizeConcept } from "../scripts/coherence.js";
import { personalityPlan, tacticsPlan } from "../scripts/personality.js";
import { parseConcept } from "../scripts/parser.js";
import { randomFormValues } from "../scripts/randomizer.js";
import { randomSpellPlan } from "../scripts/random-content.js";

const badSniper = parseConcept({
  prompt: "Стрелок 4 уровня с длинным мечом",
  name: "Проверка",
  ancestry: "human",
  gender: "male",
  profession: "hunter",
  role: "sniper",
  armor: "light",
  weapon: "longsword",
  quality: "standard",
  target: "new",
  autoCorrect: false,
});
const badReport = analyzeConcept(badSniper);
if (!badReport.issues.some((issue) => issue.code === "sniper-without-ranged")) {
  throw new Error("Движок согласованности не заметил стрелка без дальнобойного оружия.");
}

const corrected = normalizeConcept({ ...badSniper, autoCorrect: true });
if (!Number.isFinite(({ shortbow: 60, crossbow: 120 })[corrected.concept.weapon])) {
  throw new Error("Автокоррекция не выдала стрелку дальнобойное оружие.");
}
if (!corrected.corrections.length) {
  throw new Error("Автокоррекция не описала внесённые изменения.");
}

const locked = randomFormValues({
  seed: 10101,
  keep: {
    name: "Неподвижное имя",
    level: 7,
    ancestry: "elf",
    gender: "female",
    profession: "doctor",
    role: "healer",
    armor: "light",
    weapon: "dagger",
  },
});
if (
  locked.name !== "Неподвижное имя" ||
  locked.level !== 7 ||
  locked.profession !== "doctor" ||
  locked.weapon !== "dagger"
) {
  throw new Error("Замки полного рандома не сохранили выбранные поля.");
}

const mage = parseConcept({
  prompt: "Огненный боевой маг 8 уровня",
  name: "Пирра",
  ancestry: "human",
  gender: "female",
  profession: "mage",
  role: "caster",
  armor: "none",
  weapon: "staff",
  quality: "standard",
  complexity: "tactical",
  spellTheme: "fire",
  target: "new",
  randomSpells: true,
  randomSeed: "fire-mage",
});

const explicitControl = normalizeConcept({
  ...mage,
  profession: "mage",
  role: "caster",
  randomSpells: false,
  randomConsumables: false,
  includeSkillActions: false,
  autoCorrect: true,
});
if (explicitControl.concept.randomSpells !== false || explicitControl.concept.randomConsumables !== false || explicitControl.concept.includeSkillActions !== false) {
  throw new Error("Автокоррекция самовольно включила отключённые пользователем категории.");
}
const spellPlan = randomSpellPlan(mage);
if (spellPlan?.theme !== "fire" || !spellPlan.themeLabel.includes("Огонь")) {
  throw new Error("Явная тематика заклинаний не была сохранена.");
}
if (!spellPlan.spells.some((spell) => ["ignition", "fireball"].includes(spell.slug))) {
  throw new Error("Огненный пакет не получил ни одного характерного заклинания.");
}

const personalityA = personalityPlan(mage);
const personalityB = personalityPlan(mage);
if (JSON.stringify(personalityA) !== JSON.stringify(personalityB)) {
  throw new Error("Личность не воспроизводится по зерну.");
}
const tactics = tacticsPlan(mage, spellPlan);
if (!tactics.opening || !tactics.routine || !tactics.weakness) {
  throw new Error("Не сформирован готовый тактический сценарий.");
}

console.log("Согласованность, замки, личности, тактики и тематические заклинания проверены.");
