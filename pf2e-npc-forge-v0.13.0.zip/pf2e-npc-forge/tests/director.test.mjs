import {
  adventurePlan,
  monsterTemplatePlan,
  lootInventoryPlan,
} from "../scripts/director.js";

const base = {
  name: "Гноллья стая",
  level: 5,
  profession: "raider",
  role: "packHunter",
  randomSeed: "director-test",
  adventureMode: "encounter",
  includeLootPlan: true,
  lootRichness: "normal",
  monsterTemplate: "fire",
  contentSource: "pf2e",
};
const first = adventurePlan(base, { dc: 22 });
const second = adventurePlan(base, { dc: 22 });
if (JSON.stringify(first) !== JSON.stringify(second)) {
  throw new Error("Мастерский сценарий не воспроизводится по seed.");
}
if (!first.director.objective || !first.director.phases.length || !first.loot.storyItem) {
  throw new Error("Режиссёр столкновения не создал цель, фазы и добычу.");
}
const noLoot = adventurePlan({ ...base, includeLootPlan: false }, { dc: 22 });
if (noLoot.loot !== null) {
  throw new Error("Отключённый план добычи был создан вопреки настройке.");
}
const lootOnly = adventurePlan({ ...base, adventureMode: "off", includeLootPlan: true }, { dc: 22 });
if (lootOnly.director !== null || !lootOnly.loot?.storyItem) {
  throw new Error("План добычи нельзя использовать независимо от мастерского сценария.");
}
const social = adventurePlan({ ...base, adventureMode: "social" }, { dc: 22 });
if (!social.director.approaches?.length || social.director.dc !== 22) {
  throw new Error("Социальная сцена не получила подходы и КС.");
}
const investigation = adventurePlan({ ...base, adventureMode: "investigation" }, { dc: 22 });
if (investigation.director.clues?.length !== 5 || !investigation.director.falseClue) {
  throw new Error("Расследование не получило пять улик и ложную улику.");
}

const poorLoot = lootInventoryPlan({ ...base, lootRichness: "poor", contentSource: "pf2e", technology: "fantasy" });
const generousLoot = lootInventoryPlan({ ...base, lootRichness: "generous", contentSource: "pf2e", technology: "fantasy" });
const storyLoot = lootInventoryPlan({ ...base, lootRichness: "story", contentSource: "pf2e", technology: "fantasy" });
const sfLoot = lootInventoryPlan({ ...base, lootRichness: "generous", contentSource: "sf2e", technology: "starfinder" });
const totalQuantity = (items) => items.reduce((sum, item) => sum + Number(item.quantity || 0), 0);
if (!poorLoot.length || generousLoot.length <= poorLoot.length || totalQuantity(generousLoot) <= totalQuantity(poorLoot)) {
  throw new Error("Щедрая добыча не отличается от скудной реальным количеством предметов.");
}
if (storyLoot.length !== 1 || storyLoot[0].name !== "Сюжетная улика") {
  throw new Error("Сюжетная добыча не создаёт понятную физическую улику.");
}
if (!sfLoot.length || sfLoot.some((item) => item.source !== "sf2e")) {
  throw new Error("Starfinder-добыча смешалась с фэнтезийными источниками.");
}
const fantasyConsumables = lootInventoryPlan({ ...base, lootRichness: "consumables", contentSource: "pf2e", technology: "fantasy" });
const sfConsumables = lootInventoryPlan({ ...base, lootRichness: "consumables", contentSource: "sf2e", technology: "starfinder" });
if (fantasyConsumables.length < 3 || sfConsumables.length < 3) {
  throw new Error("Режим расходников не создаёт отдельный физический набор добычи.");
}

const template = monsterTemplatePlan(base);
if (!template.traits.includes("fire") || !template.resistances.length || !template.weaknesses.length) {
  throw new Error("Огненный шаблон не создал реальные трейты, сопротивление и слабость.");
}
console.log("Режиссёр сцен, расследования, добыча и шаблоны существ проверены.");
