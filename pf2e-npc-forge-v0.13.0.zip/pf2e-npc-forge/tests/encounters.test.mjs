import { adjustedEncounterBudget, creatureXp, encounterPlan } from "../scripts/encounters.js";
import { parseConcept } from "../scripts/parser.js";

if (creatureXp(3, 3) !== 40 || creatureXp(5, 3) !== 80 || creatureXp(-1, 3) !== 10) {
  throw new Error("Таблица XP существ по относительному уровню неверна.");
}
if (adjustedEncounterBudget("moderate", 4) !== 80 || adjustedEncounterBudget("severe", 5) !== 150) {
  throw new Error("Корректировка бюджета по размеру группы неверна.");
}

const concept = parseConcept({
  prompt: "Гоблинская шайка первого уровня",
  creatureKind: "monster",
  monsterFamily: "goblin",
  ancestry: "goblin",
  gender: "unspecified",
  profession: "raider",
  role: "ambusher",
  armor: "light",
  weapon: "dogslicer",
  quality: "standard",
  target: "new",
  count: 4,
  batchMode: "encounter",
  encounterDifficulty: "moderate",
  partyLevel: 2,
  partySize: 4,
});
const plan = encounterPlan(concept);
if (!plan || plan.budget !== 80 || plan.xp !== 120 || plan.recommendedCount !== 3) {
  throw new Error(`Неверный план столкновения: ${JSON.stringify(plan)}`);
}
if (!plan.status.includes("тяжелее")) {
  throw new Error("План не предупредил о превышении бюджета.");
}
console.log("Бюджет столкновения и рекомендуемый размер группы проверены.");
