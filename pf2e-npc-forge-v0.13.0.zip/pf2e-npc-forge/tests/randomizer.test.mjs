import { randomArtwork } from "../scripts/artwork.js";
import { randomContentPlan, randomSpellPlan } from "../scripts/random-content.js";
import { randomFormValues, randomNameForGender } from "../scripts/randomizer.js";
import { parseConcept } from "../scripts/parser.js";
import { randomMonsterFormValues } from "../scripts/monsters.js";

const first = randomFormValues({ seed: 12345, keep: { tokenPath: "tokens" } });
const repeated = randomFormValues({ seed: 12345, keep: { tokenPath: "tokens" } });
const other = randomFormValues({ seed: 54321, keep: { tokenPath: "tokens" } });
if (JSON.stringify(first) !== JSON.stringify(repeated)) {
  throw new Error("Одинаковое зерно даёт разные случайные формы.");
}
if (JSON.stringify(first) === JSON.stringify(other)) {
  throw new Error("Разные зёрна не меняют случайного NPC.");
}

const fantasyNames = new Set();
const starfinderNames = new Set();
for (let index = 0; index < 500; index += 1) {
  fantasyNames.add(randomNameForGender(index % 2 ? "female" : "male", `fantasy-name-${index}`, { ancestry: "human", technology: "fantasy" }));
  starfinderNames.add(randomNameForGender("unspecified", `sf-name-${index}`, { ancestry: "human", technology: "starfinder" }));
}
if (fantasyNames.size < 260) throw new Error(`Слишком мало разнообразных фэнтезийных имён: ${fantasyNames.size}.`);
if (starfinderNames.size < 220) throw new Error(`Слишком мало разнообразных Starfinder-имён: ${starfinderNames.size}.`);

const controlledRandom = randomFormValues({
  seed: 24680,
  keep: {
    randomAbilities: false,
    randomSpells: false,
    randomConsumables: false,
    randomToken: false,
    includeSkillActions: false,
    createBriefing: false,
    sendChatSummary: false,
    adventureMode: "off",
    includeLootPlan: false,
    deploymentMode: "none",
    addToCombat: false,
  },
});
for (const field of [
  "randomAbilities",
  "randomSpells",
  "randomConsumables",
  "randomToken",
  "includeSkillActions",
  "createBriefing",
  "sendChatSummary",
  "includeLootPlan",
  "addToCombat",
]) {
  if (controlledRandom[field] !== false) {
    throw new Error(`Полный рандом самовольно включил отключённую настройку ${field}.`);
  }
}
if (controlledRandom.adventureMode !== "off" || controlledRandom.deploymentMode !== "none") {
  throw new Error("Полный рандом изменил режим сценария или размещения.");
}

const mage = parseConcept({
  ...first,
  name: "Тестовый маг",
  level: 7,
  profession: "mage",
  role: "caster",
  armor: "none",
  weapon: "staff",
  target: "new",
  randomSeed: "mage-seed",
  randomAbilities: true,
  randomSpells: true,
  randomConsumables: true,
});
const spellPlan = randomSpellPlan(mage);
if (!spellPlan || spellPlan.maxRank !== 4 || spellPlan.spells.length < 8) {
  throw new Error("Маг не получил масштабируемый список заклинаний.");
}
const mageContent = randomContentPlan(mage, { dc: 25, damage: "2d8+6" });
if (!mageContent.features.some((feature) => feature.actionType === "action")) {
  throw new Error("Случайный маг не получил активную способность.");
}
if (!mageContent.features.some((feature) => feature.actionType === "passive")) {
  throw new Error("Случайный маг не получил пассивную способность.");
}

const doctor = parseConcept({
  prompt: "Врач 5 уровня",
  name: "Тестовый врач",
  level: 5,
  ancestry: "human",
  gender: "female",
  profession: "doctor",
  role: "healer",
  armor: "light",
  weapon: "dagger",
  quality: "standard",
  target: "new",
  randomSeed: "doctor-seed",
  randomAbilities: true,
  randomSpells: true,
  randomConsumables: true,
});
const doctorContent = randomContentPlan(doctor, { dc: 22, damage: "2d6+5" });
if (doctorContent.consumables.length < 5) {
  throw new Error("Врач не получил большой профессиональный запас расходников.");
}
if (!doctorContent.spells?.spells?.length) {
  throw new Error("Врач с явно включённой магией не получил список заклинаний.");
}

const mundaneDoctor = parseConcept({
  ...doctor,
  name: "Немагический врач",
  randomSpells: false,
});
if (randomContentPlan(mundaneDoctor, { dc: 22, damage: "2d6+5" }).spells !== null) {
  throw new Error("Врач с выключенной магией ошибочно получил список заклинаний.");
}

const browseResults = {
  tokens: {
    files: [
      "tokens/maps/forest-map.webp",
      "tokens/human/male/human-mage-token.webp",
      "tokens/orc/orc-warrior-token.webp",
    ],
    dirs: [],
  },
};
globalThis.game ??= {};
globalThis.game.world = { id: "test-world" };
globalThis.foundry = {
  applications: {
    apps: {
      FilePicker: {
        implementation: {
          async browse(_source, path) {
            if (!browseResults[path]) throw new Error("missing");
            return browseResults[path];
          },
        },
      },
    },
  },
};
const artConcept = {
  ...mage,
  ancestry: "human",
  gender: "male",
  profession: "mage",
  role: "caster",
  randomToken: true,
  tokenPath: "tokens",
};
const artwork = await randomArtwork(artConcept);
if (artwork.path !== "tokens/human/male/human-mage-token.webp") {
  throw new Error(`Подбор токена выбрал неподходящий файл: ${artwork.path}`);
}

console.log("Случайные NPC, способности, заклинания, расходники и токены проверены.");


const monsterFirst = randomMonsterFormValues(777, { tokenPath: "tokens" });
const monsterRepeat = randomMonsterFormValues(777, { tokenPath: "tokens" });
if (JSON.stringify(monsterFirst) !== JSON.stringify(monsterRepeat)) {
  throw new Error("Одинаковое зерно даёт разные случайные семейства монстров.");
}
if (monsterFirst.monsterFamily === "none" || monsterFirst.creatureKind === "person") {
  throw new Error("Случайный монстр превратился в обычного разумного NPC.");
}
const lockedGnoll = randomMonsterFormValues(778, { monsterFamily: "gnoll", level: 4 });
if (lockedGnoll.monsterFamily !== "gnoll" || lockedGnoll.ancestry !== "gnoll" || lockedGnoll.level !== 4) {
  throw new Error("Замок семейства или уровня случайного монстра не сработал.");
}
const ordinaryRandom = randomFormValues({ seed: 779, keep: {} });
if (ordinaryRandom.monsterFamily !== "none" || ordinaryRandom.creatureKind !== "person") {
  throw new Error("Обычный рандом ошибочно создаёт монстра.");
}
console.log("Случайные монстры и разделение обычного/бестиарного рандома проверены.");
