import { ANCESTRIES, ARMORS, PROFESSIONS, ROLES, WEAPONS } from "../scripts/blueprints.js";
import { getPreview } from "../scripts/generator.js";
import { MONSTER_FAMILIES, randomMonsterFormValues } from "../scripts/monsters.js";
import { parseConcept } from "../scripts/parser.js";
import { BUILTIN_PRESETS } from "../scripts/presets.js";

globalThis.canvas ??= { tokens: { controlled: [] } };
globalThis.game ??= { actors: { get: () => null } };

for (const [familyId, family] of Object.entries(MONSTER_FAMILIES)) {
  if (familyId === "none") continue;
  if (!ANCESTRIES[family.ancestry]) throw new Error(`${familyId}: неизвестное происхождение.`);
  if (!PROFESSIONS[family.defaultProfession]) throw new Error(`${familyId}: неизвестная профессия.`);
  if (!ROLES[family.defaultRole]) throw new Error(`${familyId}: неизвестная роль.`);
  if (!ARMORS[family.defaultArmor]) throw new Error(`${familyId}: неизвестный доспех.`);
  if (!WEAPONS[family.defaultWeapon]) throw new Error(`${familyId}: неизвестное оружие.`);
  if (!family.ecology || !family.motive || !family.negotiation || !family.lair) {
    throw new Error(`${familyId}: семейство не получило полный мастерский контекст.`);
  }
  if (!family.roster?.length || !family.features) {
    throw new Error(`${familyId}: нет состава столкновения или видовых способностей.`);
  }
  for (const [role, profession, weapon, armor] of family.roster) {
    if (!ROLES[role] || !PROFESSIONS[profession] || !WEAPONS[weapon] || !ARMORS[armor]) {
      throw new Error(`${familyId}: ростер ссылается на неизвестный элемент.`);
    }
  }
  const form = randomMonsterFormValues(`family-${familyId}`, {
    monsterFamily: familyId,
    level: 3,
    count: Math.min(5, family.roster.length),
  });
  const concept = parseConcept({ ...form, target: "new" });
  const preview = getPreview(concept);
  if (!preview.monsterLore || preview.actions.length < 2 || preview.strikes.length < 1) {
    throw new Error(`${familyId}: неполный предпросмотр монстра.`);
  }
}

for (const [id, preset] of Object.entries(BUILTIN_PRESETS)) {
  const concept = parseConcept({ ...preset.values, target: "new" });
  const preview = getPreview(concept);
  if (!preview.name || preview.ac <= 0 || preview.hp <= 0 || preview.strikes.length === 0) {
    throw new Error(`Заготовка ${id} не создаёт полноценный предпросмотр.`);
  }
}

console.log(`Бестиарий: ${Object.keys(MONSTER_FAMILIES).length - 1} семейств и все встроенные заготовки проверены.`);
