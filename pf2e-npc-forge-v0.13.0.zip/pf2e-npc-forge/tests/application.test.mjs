import { readFileSync } from "node:fs";
class MockApplicationV2 {
  constructor(options = {}) {
    this.options = options;
    this.position = options.position ?? {};
    this.rendered = false;
    this.front = false;
  }

  async render() {
    this.rendered = true;
    return this;
  }

  bringToFront() {
    this.front = true;
  }

  setPosition(position = {}) {
    this.position = { ...this.position, ...position };
    return this.position;
  }

  async close() {
    this.rendered = false;
    this._onClose?.({});
    return this;
  }
}

function MockHandlebarsApplicationMixin(Base) {
  return class MockHandlebarsApplication extends Base {
    static DEFAULT_OPTIONS = {};
    static PARTS = {};
    async _prepareContext() { return {}; }
    async _onRender() {}
    _onClose() {}
  };
}

globalThis.innerWidth = 1366;
globalThis.innerHeight = 768;
globalThis.foundry = {
  applications: {
    api: {
      ApplicationV2: MockApplicationV2,
      HandlebarsApplicationMixin: MockHandlebarsApplicationMixin,
    },
  },
};
globalThis.game = {
  system: { id: "pf2e" },
  user: { isGM: true },
  settings: { get: () => ({}) },
  modules: new Map(),
};
globalThis.ui = {
  notifications: {
    info() {}, warn() {}, error(message) { throw new Error(message); },
  },
};
globalThis.Hooks = { once() {}, on() {} };

const { openGenerator } = await import(`../scripts/main.js?application-test=${Date.now()}`);
const first = await openGenerator();
if (!first?.rendered) throw new Error("ApplicationV2 не был отрисован.");
if (first.constructor.DEFAULT_OPTIONS.tag !== "form") throw new Error("Корень ApplicationV2 должен быть формой.");
if (!first.constructor.DEFAULT_OPTIONS.window?.contentClasses?.includes("pf2e-npc-forge-content")) {
  throw new Error("Окно не получило контролируемый content-контейнер.");
}
if (first.constructor.DEFAULT_OPTIONS.window?.resizable !== true) {
  throw new Error("Окно ApplicationV2 должно разрешать штатное изменение размера.");
}
if (first.constructor.PARTS?.main?.template?.endsWith("generator.hbs") !== true) {
  throw new Error("Основная часть ApplicationV2 не связана с generator.hbs.");
}
if (first.constructor.PARTS?.footer?.template?.endsWith("forge-footer.hbs") !== true) {
  throw new Error("Постоянный footer ApplicationV2 не подключён.");
}
if (first.position.width > innerWidth - 16 || first.position.height > innerHeight - 16) {
  throw new Error(`Окно превышает viewport: ${JSON.stringify(first.position)}`);
}
const second = await openGenerator();
if (second !== first || !first.front) throw new Error("Повторный запуск должен поднимать существующее окно, а не плодить копии.");
await first.close();
const third = await openGenerator();
if (third === first) throw new Error("После закрытия должен создаваться новый экземпляр окна.");


const mainSource = readFileSync(new URL("../scripts/main.js", import.meta.url), "utf8");
if (!mainSource.includes('applyPreset(preset.values, { forceTarget: "new" });')) {
  throw new Error("Встроенный быстрый пресет не сбрасывает опасную цель на создание нового NPC.");
}
if (!mainSource.includes('preserveStoredSeeds: true, forceTarget: "new"')) {
  throw new Error("Пользовательская заготовка не сбрасывает опасную цель на создание нового NPC.");
}
if (!mainSource.includes('contentRoot.dataset.pf2eNpcForgeListenersAttached')) {
  throw new Error("Слушатели интерфейса не привязаны к фактически отрисованному DOM-корню.");
}
if (mainSource.includes('if (application._pf2eNpcForgeListenersAttached) return')) {
  throw new Error("Остался старый guard, из-за которого кнопки умирали после повторного рендера.");
}

if (!mainSource.includes('function visuallyCenterApplication(application)')) {
  throw new Error('Окно не получает отдельное визуальное центрирование.');
}
if (!mainSource.includes('.window-size.v2')) {
  throw new Error('Плохие сохранённые размеры старой версии не сбрасываются новой схемой хранения.');
}
if (!mainSource.includes('width: 920, height: 780')) {
  throw new Error('Не задан компактный стартовый размер окна 920×780.');
}
if (!mainSource.includes('[data-forge-category]')) {
  throw new Error('Категории быстрых концептов не подключены к обработчикам.');
}

if (!mainSource.includes('export async function runUiControlAudit')) {
  throw new Error("Нет физической проверки кнопок интерфейса.");
}

if (!mainSource.includes('attachApplicationResizeGrip(this, this.element)')) {
  throw new Error('Явная resize-ручка не подключается после рендера.');
}

if (!mainSource.includes('persistForgeWindowSize(this.position)')) {
  throw new Error('Размер окна не сохраняется при закрытии.');
}

if (!mainSource.includes('"mode:quick-to-constructor-state"')) {
  throw new Error('UI-аудит не проверяет перенос быстрой сборки в точную настройку.');
}

console.log("ApplicationV2: создание, безопасные пресеты, ограничение viewport, singleton и повторное открытие проверены на мок-среде.");
